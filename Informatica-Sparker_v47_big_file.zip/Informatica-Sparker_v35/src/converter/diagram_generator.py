"""Diagram generator for Informatica XML mappings."""
from typing import Dict, List, Any, Optional
from lxml import etree
import re


class DiagramGenerator:
    """Generates Mermaid.js diagrams from Informatica XML mappings."""
    
    def __init__(self):
        self.transformation_icons = {
            'Source Qualifier': 'fa:fa-database',
            'Expression': 'fa:fa-code',
            'Filter': 'fa:fa-filter',
            'Lookup Procedure': 'fa:fa-search',
            'Joiner': 'fa:fa-code-branch',
            'Aggregator': 'fa:fa-layer-group',
            'Sorter': 'fa:fa-sort',
            'Router': 'fa:fa-random',
            'Union': 'fa:fa-object-group',
            'Update Strategy': 'fa:fa-sync',
            'Sequence Generator': 'fa:fa-list-ol',
            'Normalizer': 'fa:fa-expand',
            'Rank': 'fa:fa-trophy',
            'Stored Procedure': 'fa:fa-cog'
        }
    
    def generate(self, xml_content: str, diagram_type: str = 'dataflow', 
                 mapping_name: Optional[str] = None) -> Dict[str, Any]:
        """Generate diagram from XML content."""
        try:
            root = etree.fromstring(xml_content.encode('utf-8'))
            
            mappings = self._extract_mappings(root)
            workflows = self._extract_workflows(root)
            
            if not mappings and not workflows:
                return {
                    "success": False,
                    "error": "No mappings or workflows found in XML"
                }
            
            result = {
                "success": True,
                "mappings": list(mappings.keys()),
                "workflows": list(workflows.keys()),
                "diagrams": {}
            }
            
            if diagram_type == 'workflow' and workflows:
                for wf_name, wf_data in workflows.items():
                    result["diagrams"][wf_name] = self._generate_workflow_diagram(wf_name, wf_data)
            elif diagram_type == 'transformation' and mappings:
                target_mappings = [mapping_name] if mapping_name and mapping_name in mappings else list(mappings.keys())
                for m_name in target_mappings:
                    result["diagrams"][m_name] = self._generate_transformation_diagram(m_name, mappings[m_name])
            elif diagram_type == 'pipeline' and mappings:
                target_mappings = [mapping_name] if mapping_name and mapping_name in mappings else list(mappings.keys())
                for m_name in target_mappings:
                    result["diagrams"][m_name] = self._generate_pipeline_diagram(m_name, mappings[m_name])
            elif diagram_type == 'lineage' and mappings:
                target_mappings = [mapping_name] if mapping_name and mapping_name in mappings else list(mappings.keys())
                for m_name in target_mappings:
                    result["diagrams"][m_name] = self._generate_lineage_diagram(m_name, mappings[m_name])
            else:
                target_mappings = [mapping_name] if mapping_name and mapping_name in mappings else list(mappings.keys())
                for m_name in target_mappings:
                    result["diagrams"][m_name] = self._generate_dataflow_diagram(m_name, mappings[m_name])
            
            if mappings:
                result["elements_by_mapping"] = {}
                result["mapping_info_by_mapping"] = {}
                
                for m_name, m_data in mappings.items():
                    result["elements_by_mapping"][m_name] = self._get_elements_list(m_data)
                    result["mapping_info_by_mapping"][m_name] = self._get_mapping_info(m_data)
                
                first_mapping = next(iter(mappings.values()))
                result["mapping_info"] = self._get_mapping_info(first_mapping)
                result["elements"] = self._get_elements_list(first_mapping)
            
            return result
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to parse XML: {str(e)}"
            }
    
    def generate_from_artifact(self, artifact: Dict, diagram_type: str = 'dataflow',
                               mapping_name: Optional[str] = None) -> Dict[str, Any]:
        """Generate diagram from previously analyzed artifact."""
        try:
            analysis = artifact.get('analysis', {})
            mappings_data = analysis.get('mappings', [])
            
            if not mappings_data:
                return {
                    "success": False,
                    "error": "No mappings found in artifact"
                }
            
            result = {
                "success": True,
                "mappings": [m.get('name', 'Unknown') for m in mappings_data],
                "workflows": [],
                "diagrams": {}
            }
            
            target_mappings = [m for m in mappings_data if not mapping_name or m.get('name') == mapping_name]
            
            for mapping in target_mappings:
                m_name = mapping.get('name', 'Unknown')
                if diagram_type == 'transformation':
                    result["diagrams"][m_name] = self._generate_transformation_diagram_from_analysis(m_name, mapping)
                elif diagram_type == 'pipeline':
                    result["diagrams"][m_name] = self._generate_pipeline_diagram_from_analysis(m_name, mapping)
                elif diagram_type == 'lineage':
                    result["diagrams"][m_name] = self._generate_lineage_diagram_from_analysis(m_name, mapping)
                else:
                    result["diagrams"][m_name] = self._generate_dataflow_diagram_from_analysis(m_name, mapping)
            
            if target_mappings:
                result["elements_by_mapping"] = {}
                result["mapping_info_by_mapping"] = {}
                
                for mapping in mappings_data:
                    m_name = mapping.get('name', 'Unknown')
                    result["elements_by_mapping"][m_name] = self._get_elements_list_from_analysis(mapping)
                    result["mapping_info_by_mapping"][m_name] = self._get_mapping_info_from_analysis(mapping)
                
                result["mapping_info"] = self._get_mapping_info_from_analysis(target_mappings[0])
                result["elements"] = self._get_elements_list_from_analysis(target_mappings[0])
            
            return result
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to generate diagram: {str(e)}"
            }
    
    def _extract_mappings(self, root) -> Dict[str, Any]:
        """Extract mapping information from XML."""
        mappings = {}
        
        folder_sources = {}
        folder_targets = {}
        
        for folder in root.findall('.//FOLDER'):
            for source in folder.findall('SOURCE'):
                src_name = source.get('NAME', 'Unknown')
                folder_sources[src_name] = {
                    'name': src_name,
                    'dbname': source.get('DATABASETYPE', 'Unknown'),
                    'owner': source.get('OWNERNAME', '')
                }
            
            for target in folder.findall('TARGET'):
                tgt_name = target.get('NAME', 'Unknown')
                folder_targets[tgt_name] = {
                    'name': tgt_name,
                    'dbname': target.get('DATABASETYPE', 'Unknown')
                }
        
        for source in root.findall('.//SOURCE'):
            src_name = source.get('NAME', 'Unknown')
            if src_name not in folder_sources:
                folder_sources[src_name] = {
                    'name': src_name,
                    'dbname': source.get('DATABASETYPE', 'Unknown'),
                    'owner': source.get('OWNERNAME', '')
                }
        
        for target in root.findall('.//TARGET'):
            tgt_name = target.get('NAME', 'Unknown')
            if tgt_name not in folder_targets:
                folder_targets[tgt_name] = {
                    'name': tgt_name,
                    'dbname': target.get('DATABASETYPE', 'Unknown')
                }
        
        for mapping in root.findall('.//MAPPING'):
            name = mapping.get('NAME', 'Unknown')
            mappings[name] = {
                'name': name,
                'sources': [],
                'targets': [],
                'transformations': [],
                'connectors': [],
                'instances': []
            }
            
            instance_index = {}
            
            for instance in mapping.findall('.//INSTANCE'):
                inst_name = instance.get('NAME', '')
                inst_type = instance.get('TYPE', '')
                trans_name = instance.get('TRANSFORMATION_NAME', '')
                trans_type = instance.get('TRANSFORMATION_TYPE', '')
                
                canonical_name = trans_name or inst_name
                
                instance_index[inst_name] = {
                    'canonical_name': canonical_name,
                    'type': trans_type or inst_type,
                    'instance_type': inst_type
                }
                
                mappings[name]['instances'].append({
                    'name': inst_name,
                    'type': inst_type,
                    'transformation_name': trans_name,
                    'transformation_type': trans_type,
                    'canonical_name': canonical_name
                })
                
                if trans_type == 'Source Definition' or inst_type == 'SOURCE':
                    src_def = folder_sources.get(trans_name) or folder_sources.get(inst_name)
                    if src_def:
                        if not any(s['name'] == src_def['name'] for s in mappings[name]['sources']):
                            mappings[name]['sources'].append(src_def.copy())
                    else:
                        if not any(s['name'] == canonical_name for s in mappings[name]['sources']):
                            mappings[name]['sources'].append({
                                'name': canonical_name,
                                'dbname': 'Unknown',
                                'owner': ''
                            })
                
                elif trans_type == 'Target Definition' or inst_type == 'TARGET':
                    tgt_def = folder_targets.get(trans_name) or folder_targets.get(inst_name)
                    if tgt_def:
                        if not any(t['name'] == tgt_def['name'] for t in mappings[name]['targets']):
                            mappings[name]['targets'].append(tgt_def.copy())
                    else:
                        if not any(t['name'] == canonical_name for t in mappings[name]['targets']):
                            mappings[name]['targets'].append({
                                'name': canonical_name,
                                'dbname': 'Unknown'
                            })
            
            mappings[name]['instance_index'] = instance_index
            
            for source in mapping.findall('.//SOURCE'):
                src_info = {
                    'name': source.get('NAME', 'Unknown'),
                    'dbname': source.get('DATABASETYPE', 'Unknown'),
                    'owner': source.get('OWNERNAME', '')
                }
                if not any(s['name'] == src_info['name'] for s in mappings[name]['sources']):
                    mappings[name]['sources'].append(src_info)
            
            for target in mapping.findall('.//TARGET'):
                tgt_info = {
                    'name': target.get('NAME', 'Unknown'),
                    'dbname': target.get('DATABASETYPE', 'Unknown')
                }
                if not any(t['name'] == tgt_info['name'] for t in mappings[name]['targets']):
                    mappings[name]['targets'].append(tgt_info)
            
            for trans in mapping.findall('.//TRANSFORMATION'):
                trans_type = trans.get('TYPE', 'Unknown')
                trans_name = trans.get('NAME', 'Unknown')
                
                expression_fields = []
                for field in trans.findall('.//TRANSFORMFIELD'):
                    expr = field.get('EXPRESSION', '')
                    if expr and expr.strip():
                        expression_fields.append({
                            'name': field.get('NAME', ''),
                            'expression': expr
                        })
                
                mappings[name]['transformations'].append({
                    'name': trans_name,
                    'type': trans_type,
                    'expressions': expression_fields
                })
            
            for conn in mapping.findall('.//CONNECTOR'):
                mappings[name]['connectors'].append({
                    'from_instance': conn.get('FROMINSTANCE', ''),
                    'from_field': conn.get('FROMFIELD', ''),
                    'to_instance': conn.get('TOINSTANCE', ''),
                    'to_field': conn.get('TOFIELD', '')
                })
        
        return mappings
    
    def _extract_workflows(self, root) -> Dict[str, Any]:
        """Extract workflow information from XML."""
        workflows = {}
        
        for workflow in root.findall('.//WORKFLOW'):
            name = workflow.get('NAME', 'Unknown')
            workflows[name] = {
                'name': name,
                'sessions': [],
                'links': []
            }
            
            for session in workflow.findall('.//SESSION'):
                workflows[name]['sessions'].append({
                    'name': session.get('NAME', 'Unknown'),
                    'mapping': session.get('MAPPINGNAME', '')
                })
            
            for link in workflow.findall('.//TASKINSTANCE'):
                workflows[name]['links'].append({
                    'name': link.get('NAME', ''),
                    'type': link.get('TASKTYPE', '')
                })
        
        return workflows
    
    def _generate_dataflow_diagram(self, name: str, mapping: Dict) -> Dict[str, Any]:
        """Generate a data flow diagram for a mapping."""
        nodes = []
        edges = []
        node_ids = {}
        warnings = []
        
        if not mapping['sources']:
            nodes.append({
                'id': 'no_sources',
                'label': 'No sources detected',
                'type': 'empty'
            })
            warnings.append('No sources detected in XML. Please verify mapping completeness.')
        
        for i, source in enumerate(mapping['sources']):
            node_id = f"src_{i}"
            node_ids[source['name']] = node_id
            nodes.append({
                'id': node_id,
                'label': source['name'],
                'type': 'source',
                'tooltip': f"Source: {source['name']}\\nDatabase: {source.get('dbname', 'N/A')}\\nOwner: {source.get('owner', 'N/A')}"
            })
        
        trans_order = self._determine_transformation_order(mapping)
        
        for i, trans in enumerate(trans_order):
            node_id = f"trans_{i}"
            node_ids[trans['name']] = node_id
            
            expr_list = trans.get('expressions', [])
            expr_preview = ', '.join([e.get('name', '') for e in expr_list[:3]])
            if len(expr_list) > 3:
                expr_preview += f'... (+{len(expr_list)-3} more)'
            
            nodes.append({
                'id': node_id,
                'label': trans['name'],
                'type': 'transformation',
                'trans_type': trans['type'],
                'tooltip': f"Type: {trans['type']}\\nExpressions: {len(expr_list)}\\n{expr_preview}"
            })
        
        if not mapping['targets']:
            nodes.append({
                'id': 'no_targets',
                'label': 'No targets detected',
                'type': 'empty'
            })
            warnings.append('No targets detected in XML. Please verify mapping completeness.')
        
        for i, target in enumerate(mapping['targets']):
            node_id = f"tgt_{i}"
            node_ids[target['name']] = node_id
            nodes.append({
                'id': node_id,
                'label': target['name'],
                'type': 'target',
                'tooltip': f"Target: {target['name']}\\nDatabase: {target.get('dbname', 'N/A')}\\nOwner: {target.get('owner', 'N/A')}"
            })
        
        connected_nodes = set()
        nodes_with_input = set()
        nodes_with_output = set()
        
        instance_index = mapping.get('instance_index', {})
        
        for inst in mapping.get('instances', []):
            inst_name = inst.get('name', '')
            canonical = inst.get('canonical_name', inst_name)
            if canonical in node_ids:
                node_ids[inst_name] = node_ids[canonical]
        
        for conn in mapping['connectors']:
            from_inst = conn['from_instance']
            to_inst = conn['to_instance']
            
            from_canonical = instance_index.get(from_inst, {}).get('canonical_name', from_inst)
            to_canonical = instance_index.get(to_inst, {}).get('canonical_name', to_inst)
            
            from_node_id = node_ids.get(from_inst) or node_ids.get(from_canonical)
            to_node_id = node_ids.get(to_inst) or node_ids.get(to_canonical)
            
            if from_node_id and to_node_id:
                edge_key = f"{from_node_id}->{to_node_id}"
                if edge_key not in connected_nodes:
                    edges.append({
                        'from': from_node_id,
                        'to': to_node_id
                    })
                    connected_nodes.add(edge_key)
                    nodes_with_output.add(from_canonical)
                    nodes_with_output.add(from_inst)
                    nodes_with_input.add(to_canonical)
                    nodes_with_input.add(to_inst)
        
        expression_referenced_transforms = set()
        for trans in trans_order:
            for expr_field in trans.get('expressions', []):
                expr = expr_field.get('expression', '')
                if ':LKP.' in expr or ':SP.' in expr:
                    for other_trans in trans_order:
                        if other_trans['name'] in expr:
                            expression_referenced_transforms.add(other_trans['name'])
        
        lookup_sp_types = {'Lookup Procedure', 'Stored Procedure', 'Lookup'}
        
        for trans in trans_order:
            trans_name = trans['name']
            trans_type = trans.get('type', '')
            
            if trans_name in nodes_with_input or trans_name in nodes_with_output:
                continue
            
            if trans_type in lookup_sp_types:
                continue
            
            if trans_name in expression_referenced_transforms:
                continue
            
            if 'lkp' in trans_name.lower() or 'lookup' in trans_name.lower():
                continue
            if 'sp_' in trans_name.lower() or 'stored' in trans_name.lower():
                continue
                
            warnings.append(f"Transformation '{trans_name}' has no connections. Check XML for broken flow.")
        
        mermaid = self._build_mermaid_syntax(nodes, edges)
        
        return {
            'mermaid': mermaid,
            'nodes': nodes,
            'edges': edges,
            'warnings': warnings
        }
    
    def _generate_transformation_diagram(self, name: str, mapping: Dict) -> Dict[str, Any]:
        """Generate a transformation breakdown diagram showing individual sources and targets."""
        nodes = []
        edges = []
        
        for i, source in enumerate(mapping['sources']):
            node_id = f"src_{i}"
            nodes.append({
                'id': node_id,
                'label': source['name'],
                'type': 'source'
            })
        
        for i, trans in enumerate(mapping['transformations']):
            node_id = f"trans_{i}"
            
            expr_count = len(trans.get('expressions', []))
            label = f"{trans['name']}"
            if expr_count > 0:
                label += f"\\n({expr_count} expr)"
            
            nodes.append({
                'id': node_id,
                'label': label,
                'type': 'transformation',
                'trans_type': trans['type']
            })
        
        for i, target in enumerate(mapping['targets']):
            node_id = f"tgt_{i}"
            nodes.append({
                'id': node_id,
                'label': target['name'],
                'type': 'target'
            })
        
        if mapping['transformations']:
            for i in range(len(mapping['sources'])):
                edges.append({'from': f"src_{i}", 'to': 'trans_0'})
            
            for i in range(len(mapping['transformations']) - 1):
                edges.append({'from': f"trans_{i}", 'to': f"trans_{i+1}"})
            
            last_trans = f"trans_{len(mapping['transformations'])-1}"
            for i in range(len(mapping['targets'])):
                edges.append({'from': last_trans, 'to': f"tgt_{i}"})
        else:
            for i in range(len(mapping['sources'])):
                for j in range(len(mapping['targets'])):
                    edges.append({'from': f"src_{i}", 'to': f"tgt_{j}"})
        
        mermaid = self._build_mermaid_syntax(nodes, edges, 'TB')
        
        return {
            'mermaid': mermaid,
            'nodes': nodes,
            'edges': edges
        }
    
    def _generate_workflow_diagram(self, name: str, workflow: Dict) -> Dict[str, Any]:
        """Generate a workflow diagram."""
        nodes = []
        edges = []
        
        nodes.append({
            'id': 'start',
            'label': 'Start',
            'type': 'start'
        })
        
        prev_node = 'start'
        for i, session in enumerate(workflow['sessions']):
            node_id = f"session_{i}"
            nodes.append({
                'id': node_id,
                'label': session['name'],
                'type': 'session'
            })
            
            edges.append({
                'from': prev_node,
                'to': node_id
            })
            prev_node = node_id
        
        nodes.append({
            'id': 'end',
            'label': 'End',
            'type': 'end'
        })
        
        if workflow['sessions']:
            edges.append({
                'from': f"session_{len(workflow['sessions'])-1}",
                'to': 'end'
            })
        else:
            edges.append({
                'from': 'start',
                'to': 'end'
            })
        
        mermaid = self._build_workflow_mermaid(nodes, edges)
        
        return {
            'mermaid': mermaid,
            'nodes': nodes,
            'edges': edges
        }
    
    def _generate_pipeline_diagram(self, name: str, mapping: Dict) -> Dict[str, Any]:
        """Generate a pipeline diagram showing processing stages."""
        nodes = []
        edges = []
        
        nodes.append({
            'id': 'input',
            'label': 'Input Stage',
            'type': 'stage',
            'stage_type': 'input'
        })
        
        for i, source in enumerate(mapping['sources']):
            node_id = f"src_{i}"
            nodes.append({
                'id': node_id,
                'label': source['name'],
                'type': 'source'
            })
            edges.append({'from': 'input', 'to': node_id})
        
        stage_groups = {
            'Extract': ['Source Qualifier'],
            'Transform': ['Expression', 'Filter', 'Joiner', 'Aggregator', 'Sorter', 'Router', 'Union', 'Normalizer', 'Rank'],
            'Lookup': ['Lookup Procedure'],
            'Load': ['Update Strategy']
        }
        
        stage_nodes = {}
        for stage_name in ['Extract', 'Transform', 'Lookup', 'Load']:
            stage_id = f"stage_{stage_name.lower()}"
            trans_in_stage = [t for t in mapping['transformations'] if t['type'] in stage_groups.get(stage_name, [])]
            if trans_in_stage:
                nodes.append({
                    'id': stage_id,
                    'label': f"{stage_name} ({len(trans_in_stage)})",
                    'type': 'stage',
                    'stage_type': stage_name.lower()
                })
                stage_nodes[stage_name] = stage_id
        
        prev_stage = None
        for i, source in enumerate(mapping['sources']):
            if 'Extract' in stage_nodes:
                edges.append({'from': f"src_{i}", 'to': stage_nodes['Extract']})
                prev_stage = stage_nodes['Extract']
        
        for stage_name in ['Transform', 'Lookup', 'Load']:
            if stage_name in stage_nodes:
                if prev_stage:
                    edges.append({'from': prev_stage, 'to': stage_nodes[stage_name]})
                prev_stage = stage_nodes[stage_name]
        
        nodes.append({
            'id': 'output',
            'label': 'Output Stage',
            'type': 'stage',
            'stage_type': 'output'
        })
        
        for i, target in enumerate(mapping['targets']):
            node_id = f"tgt_{i}"
            nodes.append({
                'id': node_id,
                'label': target['name'],
                'type': 'target'
            })
            edges.append({'from': 'output', 'to': node_id})
        
        if prev_stage:
            edges.append({'from': prev_stage, 'to': 'output'})
        
        mermaid = self._build_pipeline_mermaid(nodes, edges)
        
        return {
            'mermaid': mermaid,
            'nodes': nodes,
            'edges': edges
        }
    
    def _generate_lineage_diagram(self, name: str, mapping: Dict) -> Dict[str, Any]:
        """Generate a source-to-target lineage diagram showing direct data paths."""
        nodes = []
        edges = []
        node_ids = {}
        
        for i, source in enumerate(mapping['sources']):
            node_id = f"src_{i}"
            node_ids[source['name']] = node_id
            nodes.append({
                'id': node_id,
                'label': source['name'],
                'type': 'source',
                'db': source.get('dbname', '')
            })
        
        for i, target in enumerate(mapping['targets']):
            node_id = f"tgt_{i}"
            node_ids[target['name']] = node_id
            nodes.append({
                'id': node_id,
                'label': target['name'],
                'type': 'target',
                'db': target.get('dbname', '')
            })
        
        source_names = {s['name'] for s in mapping['sources']}
        target_names = {t['name'] for t in mapping['targets']}
        
        source_connections = {}
        target_connections = {}
        
        for conn in mapping['connectors']:
            from_inst = conn['from_instance']
            to_inst = conn['to_instance']
            
            if from_inst in source_names:
                if from_inst not in source_connections:
                    source_connections[from_inst] = set()
                source_connections[from_inst].add(to_inst)
            
            if to_inst in target_names:
                if to_inst not in target_connections:
                    target_connections[to_inst] = set()
                target_connections[to_inst].add(from_inst)
        
        for source_name in source_names:
            for target_name in target_names:
                if source_name in node_ids and target_name in node_ids:
                    edges.append({
                        'from': node_ids[source_name],
                        'to': node_ids[target_name],
                        'label': 'data flow'
                    })
        
        mermaid = self._build_lineage_mermaid(nodes, edges)
        
        return {
            'mermaid': mermaid,
            'nodes': nodes,
            'edges': edges
        }
    
    def _generate_dataflow_diagram_from_analysis(self, name: str, mapping: Dict) -> Dict[str, Any]:
        """Generate dataflow diagram from analysis data."""
        nodes = []
        edges = []
        node_ids = {}
        
        sources = mapping.get('sources', [])
        for i, source in enumerate(sources):
            source_name = source if isinstance(source, str) else source.get('name', f'Source_{i}')
            node_id = f"src_{i}"
            node_ids[source_name] = node_id
            nodes.append({
                'id': node_id,
                'label': source_name,
                'type': 'source'
            })
        
        transformations = mapping.get('transformations', [])
        for i, trans in enumerate(transformations):
            trans_name = trans if isinstance(trans, str) else trans.get('name', f'Trans_{i}')
            trans_type = '' if isinstance(trans, str) else trans.get('type', '')
            node_id = f"trans_{i}"
            node_ids[trans_name] = node_id
            nodes.append({
                'id': node_id,
                'label': trans_name,
                'type': 'transformation',
                'trans_type': trans_type
            })
        
        targets = mapping.get('targets', [])
        for i, target in enumerate(targets):
            target_name = target if isinstance(target, str) else target.get('name', f'Target_{i}')
            node_id = f"tgt_{i}"
            node_ids[target_name] = node_id
            nodes.append({
                'id': node_id,
                'label': target_name,
                'type': 'target'
            })
        
        for i, source in enumerate(sources):
            if transformations:
                edges.append({'from': f"src_{i}", 'to': 'trans_0'})
            elif targets:
                for j in range(len(targets)):
                    edges.append({'from': f"src_{i}", 'to': f"tgt_{j}"})
        
        for i in range(len(transformations) - 1):
            edges.append({'from': f"trans_{i}", 'to': f"trans_{i+1}"})
        
        if transformations and targets:
            last_trans = f"trans_{len(transformations)-1}"
            for j in range(len(targets)):
                edges.append({'from': last_trans, 'to': f"tgt_{j}"})
        
        mermaid = self._build_mermaid_syntax(nodes, edges)
        
        return {
            'mermaid': mermaid,
            'nodes': nodes,
            'edges': edges
        }
    
    def _generate_transformation_diagram_from_analysis(self, name: str, mapping: Dict) -> Dict[str, Any]:
        """Generate transformation diagram from analysis data."""
        return self._generate_dataflow_diagram_from_analysis(name, mapping)
    
    def _determine_transformation_order(self, mapping: Dict) -> List[Dict]:
        """Determine the order of transformations based on connectors."""
        transformations = {t['name']: t for t in mapping['transformations']}
        
        incoming = {t['name']: set() for t in mapping['transformations']}
        outgoing = {t['name']: set() for t in mapping['transformations']}
        
        for conn in mapping['connectors']:
            from_inst = conn['from_instance']
            to_inst = conn['to_instance']
            
            if to_inst in incoming:
                incoming[to_inst].add(from_inst)
            if from_inst in outgoing:
                outgoing[from_inst].add(to_inst)
        
        ordered = []
        visited = set()
        
        starts = [t for t, inc in incoming.items() if len(inc) == 0]
        if not starts:
            starts = list(transformations.keys())
        
        queue = starts[:]
        while queue:
            current = queue.pop(0)
            if current in visited:
                continue
            visited.add(current)
            if current in transformations:
                ordered.append(transformations[current])
            for next_t in outgoing.get(current, []):
                if next_t not in visited:
                    queue.append(next_t)
        
        for t_name, t_data in transformations.items():
            if t_name not in visited:
                ordered.append(t_data)
        
        return ordered
    
    def _get_trans_type_class(self, trans_type: str) -> str:
        """Get CSS class name for transformation type."""
        type_map = {
            'Source Qualifier': 'trans_sq',
            'Filter': 'trans_filter',
            'Expression': 'trans_expr',
            'Lookup Procedure': 'trans_lookup',
            'Joiner': 'trans_joiner',
            'Aggregator': 'trans_agg',
            'Sorter': 'trans_sorter',
            'Router': 'trans_router',
            'Union': 'trans_union',
            'Update Strategy': 'trans_update',
            'Normalizer': 'trans_norm',
            'Rank': 'trans_rank',
            'Stored Procedure': 'trans_sp'
        }
        return type_map.get(trans_type, 'trans_default')
    
    def _build_mermaid_syntax(self, nodes: List[Dict], edges: List[Dict], 
                              direction: str = 'LR') -> str:
        """Build Mermaid.js syntax from nodes and edges with color-coded transformations."""
        lines = [f"graph {direction}"]
        
        for node in nodes:
            node_id = self._sanitize_id(node['id'])
            label = self._sanitize_label(node['label'])
            
            if node['type'] == 'source':
                lines.append(f"    {node_id}[(\"{label}\")]")
            elif node['type'] == 'target':
                lines.append(f"    {node_id}[[\"{label}\"]]")
            elif node['type'] == 'transformation':
                trans_type = node.get('trans_type', '')
                if trans_type:
                    lines.append(f"    {node_id}[\"{label}<br/><small>{trans_type}</small>\"]")
                else:
                    lines.append(f"    {node_id}[\"{label}\"]")
            elif node['type'] == 'empty':
                lines.append(f"    {node_id}[\"{label}\"]:::empty")
            else:
                lines.append(f"    {node_id}[\"{label}\"]")
        
        for edge in edges:
            from_id = self._sanitize_id(edge['from'])
            to_id = self._sanitize_id(edge['to'])
            lines.append(f"    {from_id} --> {to_id}")
        
        lines.append("")
        lines.append("    classDef source fill:#10b981,stroke:#059669,color:#fff")
        lines.append("    classDef target fill:#ef4444,stroke:#dc2626,color:#fff")
        lines.append("    classDef empty fill:#6b7280,stroke:#4b5563,color:#fff,stroke-dasharray:5")
        lines.append("    classDef trans_sq fill:#3b82f6,stroke:#2563eb,color:#fff")
        lines.append("    classDef trans_filter fill:#f97316,stroke:#ea580c,color:#fff")
        lines.append("    classDef trans_expr fill:#22c55e,stroke:#16a34a,color:#fff")
        lines.append("    classDef trans_lookup fill:#a855f7,stroke:#9333ea,color:#fff")
        lines.append("    classDef trans_joiner fill:#06b6d4,stroke:#0891b2,color:#fff")
        lines.append("    classDef trans_agg fill:#ec4899,stroke:#db2777,color:#fff")
        lines.append("    classDef trans_sorter fill:#8b5cf6,stroke:#7c3aed,color:#fff")
        lines.append("    classDef trans_router fill:#14b8a6,stroke:#0d9488,color:#fff")
        lines.append("    classDef trans_union fill:#f59e0b,stroke:#d97706,color:#fff")
        lines.append("    classDef trans_update fill:#64748b,stroke:#475569,color:#fff")
        lines.append("    classDef trans_norm fill:#84cc16,stroke:#65a30d,color:#fff")
        lines.append("    classDef trans_rank fill:#0ea5e9,stroke:#0284c7,color:#fff")
        lines.append("    classDef trans_sp fill:#6b7280,stroke:#4b5563,color:#fff")
        lines.append("    classDef trans_default fill:#3b82f6,stroke:#2563eb,color:#fff")
        
        source_nodes = [self._sanitize_id(n['id']) for n in nodes if n['type'] == 'source']
        target_nodes = [self._sanitize_id(n['id']) for n in nodes if n['type'] == 'target']
        
        if source_nodes:
            lines.append(f"    class {','.join(source_nodes)} source")
        if target_nodes:
            lines.append(f"    class {','.join(target_nodes)} target")
        
        for node in nodes:
            if node['type'] == 'transformation':
                node_id = self._sanitize_id(node['id'])
                trans_type = node.get('trans_type', '')
                class_name = self._get_trans_type_class(trans_type)
                lines.append(f"    class {node_id} {class_name}")
        
        return '\n'.join(lines)
    
    def _build_workflow_mermaid(self, nodes: List[Dict], edges: List[Dict]) -> str:
        """Build Mermaid.js syntax for workflow diagrams."""
        lines = ["graph TD"]
        
        for node in nodes:
            node_id = self._sanitize_id(node['id'])
            label = self._sanitize_label(node['label'])
            
            if node['type'] == 'start':
                lines.append(f"    {node_id}(((\"{label}\")))")
            elif node['type'] == 'end':
                lines.append(f"    {node_id}(((\"{label}\")))")
            elif node['type'] == 'session':
                lines.append(f"    {node_id}[\"{label}\"]")
            else:
                lines.append(f"    {node_id}[\"{label}\"]")
        
        for edge in edges:
            from_id = self._sanitize_id(edge['from'])
            to_id = self._sanitize_id(edge['to'])
            lines.append(f"    {from_id} --> {to_id}")
        
        lines.append("")
        lines.append("    classDef start fill:#10b981,stroke:#059669,color:#fff")
        lines.append("    classDef end fill:#ef4444,stroke:#dc2626,color:#fff")
        lines.append("    classDef session fill:#3b82f6,stroke:#2563eb,color:#fff")
        
        for node in nodes:
            node_id = self._sanitize_id(node['id'])
            if node['type'] in ['start', 'end', 'session']:
                lines.append(f"    class {node_id} {node['type']}")
        
        return '\n'.join(lines)
    
    def _build_pipeline_mermaid(self, nodes: List[Dict], edges: List[Dict]) -> str:
        """Build Mermaid.js syntax for pipeline diagrams."""
        lines = ["graph LR"]
        
        for node in nodes:
            node_id = self._sanitize_id(node['id'])
            label = self._sanitize_label(node['label'])
            
            if node['type'] == 'source':
                lines.append(f"    {node_id}[(\"{label}\")]")
            elif node['type'] == 'target':
                lines.append(f"    {node_id}[[\"{label}\"]]")
            elif node['type'] == 'stage':
                lines.append(f"    {node_id}{{\"{label}\"}}")
            else:
                lines.append(f"    {node_id}[\"{label}\"]")
        
        for edge in edges:
            from_id = self._sanitize_id(edge['from'])
            to_id = self._sanitize_id(edge['to'])
            lines.append(f"    {from_id} --> {to_id}")
        
        lines.append("")
        lines.append("    classDef source fill:#10b981,stroke:#059669,color:#fff")
        lines.append("    classDef target fill:#ef4444,stroke:#dc2626,color:#fff")
        lines.append("    classDef stage fill:#8b5cf6,stroke:#7c3aed,color:#fff")
        
        source_nodes = [self._sanitize_id(n['id']) for n in nodes if n['type'] == 'source']
        target_nodes = [self._sanitize_id(n['id']) for n in nodes if n['type'] == 'target']
        stage_nodes = [self._sanitize_id(n['id']) for n in nodes if n['type'] == 'stage']
        
        if source_nodes:
            lines.append(f"    class {','.join(source_nodes)} source")
        if target_nodes:
            lines.append(f"    class {','.join(target_nodes)} target")
        if stage_nodes:
            lines.append(f"    class {','.join(stage_nodes)} stage")
        
        return '\n'.join(lines)
    
    def _build_lineage_mermaid(self, nodes: List[Dict], edges: List[Dict]) -> str:
        """Build Mermaid.js syntax for lineage diagrams."""
        lines = ["graph LR"]
        
        for node in nodes:
            node_id = self._sanitize_id(node['id'])
            label = self._sanitize_label(node['label'])
            db = node.get('db', '')
            
            if node['type'] == 'source':
                if db:
                    lines.append(f"    {node_id}[(\"{label}<br/><small>{db}</small>\")]")
                else:
                    lines.append(f"    {node_id}[(\"{label}\")]")
            elif node['type'] == 'target':
                if db:
                    lines.append(f"    {node_id}[[\"{label}<br/><small>{db}</small>\"]]")
                else:
                    lines.append(f"    {node_id}[[\"{label}\"]]")
            else:
                lines.append(f"    {node_id}[\"{label}\"]")
        
        for edge in edges:
            from_id = self._sanitize_id(edge['from'])
            to_id = self._sanitize_id(edge['to'])
            label = edge.get('label', '')
            if label:
                lines.append(f"    {from_id} -->|\"{label}\"| {to_id}")
            else:
                lines.append(f"    {from_id} --> {to_id}")
        
        lines.append("")
        lines.append("    classDef source fill:#10b981,stroke:#059669,color:#fff")
        lines.append("    classDef target fill:#ef4444,stroke:#dc2626,color:#fff")
        
        source_nodes = [self._sanitize_id(n['id']) for n in nodes if n['type'] == 'source']
        target_nodes = [self._sanitize_id(n['id']) for n in nodes if n['type'] == 'target']
        
        if source_nodes:
            lines.append(f"    class {','.join(source_nodes)} source")
        if target_nodes:
            lines.append(f"    class {','.join(target_nodes)} target")
        
        return '\n'.join(lines)
    
    def _generate_pipeline_diagram_from_analysis(self, name: str, mapping: Dict) -> Dict[str, Any]:
        """Generate pipeline diagram from analysis data."""
        nodes = []
        edges = []
        
        sources = mapping.get('sources', [])
        targets = mapping.get('targets', [])
        transformations = mapping.get('transformations', [])
        
        nodes.append({
            'id': 'input',
            'label': f"Input ({len(sources)} sources)",
            'type': 'stage'
        })
        
        if transformations:
            nodes.append({
                'id': 'process',
                'label': f"Process ({len(transformations)} transforms)",
                'type': 'stage'
            })
            edges.append({'from': 'input', 'to': 'process'})
        
        nodes.append({
            'id': 'output',
            'label': f"Output ({len(targets)} targets)",
            'type': 'stage'
        })
        
        if transformations:
            edges.append({'from': 'process', 'to': 'output'})
        else:
            edges.append({'from': 'input', 'to': 'output'})
        
        mermaid = self._build_pipeline_mermaid(nodes, edges)
        
        return {
            'mermaid': mermaid,
            'nodes': nodes,
            'edges': edges
        }
    
    def _generate_lineage_diagram_from_analysis(self, name: str, mapping: Dict) -> Dict[str, Any]:
        """Generate lineage diagram from analysis data."""
        nodes = []
        edges = []
        
        sources = mapping.get('sources', [])
        targets = mapping.get('targets', [])
        
        for i, source in enumerate(sources):
            source_name = source if isinstance(source, str) else source.get('name', f'Source_{i}')
            nodes.append({
                'id': f"src_{i}",
                'label': source_name,
                'type': 'source'
            })
        
        for i, target in enumerate(targets):
            target_name = target if isinstance(target, str) else target.get('name', f'Target_{i}')
            nodes.append({
                'id': f"tgt_{i}",
                'label': target_name,
                'type': 'target'
            })
        
        for i in range(len(sources)):
            for j in range(len(targets)):
                edges.append({
                    'from': f"src_{i}",
                    'to': f"tgt_{j}"
                })
        
        mermaid = self._build_lineage_mermaid(nodes, edges)
        
        return {
            'mermaid': mermaid,
            'nodes': nodes,
            'edges': edges
        }
    
    def _sanitize_id(self, text: str) -> str:
        """Sanitize node ID for Mermaid."""
        return re.sub(r'[^a-zA-Z0-9_]', '_', text)
    
    def _sanitize_label(self, text: str) -> str:
        """Sanitize label text for Mermaid."""
        text = text.replace('"', "'")
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        return text
    
    def _get_mapping_info(self, mapping: Dict) -> Dict[str, Any]:
        """Get mapping summary information."""
        return {
            'name': mapping['name'],
            'source_count': len(mapping['sources']),
            'target_count': len(mapping['targets']),
            'transformation_count': len(mapping['transformations'])
        }
    
    def _get_mapping_info_from_analysis(self, mapping: Dict) -> Dict[str, Any]:
        """Get mapping summary from analysis data."""
        return {
            'name': mapping.get('name', 'Unknown'),
            'source_count': len(mapping.get('sources', [])),
            'target_count': len(mapping.get('targets', [])),
            'transformation_count': len(mapping.get('transformations', []))
        }
    
    def _get_elements_list(self, mapping: Dict) -> List[Dict]:
        """Get list of all elements in a mapping."""
        elements = []
        
        for source in mapping['sources']:
            elements.append({
                'name': source['name'],
                'type': 'source',
                'icon': 'fa-database'
            })
        
        for trans in mapping['transformations']:
            elements.append({
                'name': trans['name'],
                'type': 'transformation',
                'trans_type': trans['type'],
                'icon': 'fa-cogs'
            })
        
        for target in mapping['targets']:
            elements.append({
                'name': target['name'],
                'type': 'target',
                'icon': 'fa-bullseye'
            })
        
        return elements
    
    def _get_elements_list_from_analysis(self, mapping: Dict) -> List[Dict]:
        """Get list of elements from analysis data."""
        elements = []
        
        sources = mapping.get('sources', [])
        for source in sources:
            source_name = source if isinstance(source, str) else source.get('name', 'Unknown')
            elements.append({
                'name': source_name,
                'type': 'source',
                'icon': 'fa-database'
            })
        
        transformations = mapping.get('transformations', [])
        for trans in transformations:
            trans_name = trans if isinstance(trans, str) else trans.get('name', 'Unknown')
            trans_type = '' if isinstance(trans, str) else trans.get('type', '')
            elements.append({
                'name': trans_name,
                'type': 'transformation',
                'trans_type': trans_type,
                'icon': 'fa-cogs'
            })
        
        targets = mapping.get('targets', [])
        for target in targets:
            target_name = target if isinstance(target, str) else target.get('name', 'Unknown')
            elements.append({
                'name': target_name,
                'type': 'target',
                'icon': 'fa-bullseye'
            })
        
        return elements
