"""
Database Connection Configuration
Pre-configured connections for code generation.
Logic: Both Sources/Lookups and Targets use MSSQL
- Source/Lookup: Use connection name mapping (CDM_PRE_LANDING -> msscdm_dev, etc.)
- Target: Fixed as msscdm_dev3
"""

# Connection to Database Mapping
CONNECTION_DB_MAPPING = {
    "CDM_PRE_LANDING": "msscdm_dev",
    "CDM_PRE_LANDING_INV": "msscdm_inv",
    "CDM_LANDING": "cmx_ors_10_3",
    "CDM_LANDING_INV": "cmx_ors_inv"
}

# MSSQL Connection for Sources and Lookups
MSSQL_SOURCE_CONFIG = {
    "db_type": "sqlserver",
    "database": "msscdm_dev",
    "user": "${MSSQL_USER}",
    "password": "${MSSQL_PASSWORD}",
    "host": "${MSSQL_HOST}",
    "jdbc_url": "jdbc:sqlserver://${MSSQL_HOST}; databaseName=msscdm_dev; user=${MSSQL_USER}; password=${MSSQL_PASSWORD}; trustServerCertificate=true; encrypt=false",
    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
    "driver_jar": "${MSSQL_DRIVER_JAR:/opt/drivers/mssql-jdbc-12.4.2.jre11.jar}"
}

# MSSQL Connection for Targets (Fixed: msscdm_dev3)
MSSQL_TARGET_CONFIG = {
    "db_type": "sqlserver",
    "database": "msscdm_dev3",
    "user": "${MSSQL_USER}",
    "password": "${MSSQL_PASSWORD}",
    "host": "${MSSQL_HOST}",
    "jdbc_url": "jdbc:sqlserver://${MSSQL_HOST}; databaseName=msscdm_dev3; user=${MSSQL_USER}; password=${MSSQL_PASSWORD}; trustServerCertificate=true; encrypt=false",
    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
    "driver_jar": "${MSSQL_DRIVER_JAR:/opt/drivers/mssql-jdbc-12.4.2.jre11.jar}"
}


def get_source_connection(connection_name: str = None):
    """Get MSSQL connection for sources based on connection name."""
    config = MSSQL_SOURCE_CONFIG.copy()
    if connection_name and connection_name in CONNECTION_DB_MAPPING:
        config["database"] = CONNECTION_DB_MAPPING[connection_name]
    return config


def get_lookup_connection(connection_name: str = None):
    """Get MSSQL connection for lookups based on connection name."""
    config = MSSQL_SOURCE_CONFIG.copy()
    if connection_name and connection_name in CONNECTION_DB_MAPPING:
        config["database"] = CONNECTION_DB_MAPPING[connection_name]
    return config


def get_target_connection():
    """Get MSSQL connection for targets (fixed: msscdm_dev3)."""
    return MSSQL_TARGET_CONFIG.copy()


def get_connection_for_type(conn_type: str, connection_name: str = None) -> dict:
    """
    Get connection config based on type.
    
    Args:
        conn_type: 'source', 'lookup', or 'target'
        connection_name: Optional connection name for source/lookup mapping
    
    Returns:
        Connection configuration dictionary
    """
    if conn_type.lower() == 'target':
        return get_target_connection()
    elif conn_type.lower() == 'lookup':
        return get_lookup_connection(connection_name)
    else:
        return get_source_connection(connection_name)


def get_jdbc_url(conn_type: str, connection_name: str = None) -> str:
    """Get JDBC URL for connection type."""
    config = get_connection_for_type(conn_type, connection_name)
    return config["jdbc_url"]


def get_spark_config_for_drivers() -> dict:
    """Get Spark configuration for JDBC drivers (MSSQL only)."""
    return {
        "spark.driver.extraClassPath": MSSQL_SOURCE_CONFIG['driver_jar'],
        "spark.executor.extraClassPath": MSSQL_SOURCE_CONFIG['driver_jar']
    }
