"""Service - orchestrates the analysis and conversion process."""
import os
import json
import zipfile
import uuid
import re
import yaml
from datetime import datetime
from typing import Optional, Dict, Any, List
from .infa_xml_parser import InfaXMLParser
from .analyzer import Analyzer
from .handlers import TransformHandlers
from .codegen import CodeGenerator
from .report import ReportBuilder
from .workflow_builder import WorkflowBuilder
from .logger import ConversionLogger, LogLevel, LogStage
from .models import (
    AnalysisResult, UserConfig, GenerationResult, 
    GeneratedFile, ConversionReport, SourceConfig, TargetConfig,
    SourceType, FileFormat, FileLocation, MappingDefinition
)


class ConversionService:
    """
    Orchestrates the XML analysis and PySpark conversion process.
    
    Generates flattened output structure (no lib/ folder):
    - workflow_orchestration.py - Coordinates execution
    - mapping_{name}.py - Self-contained mapping modules with embedded utilities
    - config.yml - Centralized configuration
    """
    
    def __init__(self, output_dir: str = "output", template_dir: str = "templates"):
        self.output_dir = output_dir
        self.template_dir = template_dir
        self.artifacts: Dict[str, Dict[str, Any]] = {}
        
        os.makedirs(output_dir, exist_ok=True)
    
    def analyze(self, xml_content: bytes, filename: str = "") -> Dict[str, Any]:
        """Analyze XML and return analysis result with artifact ID."""
        artifact_id = str(uuid.uuid4())[:8]
        
        artifact_dir = os.path.join(self.output_dir, artifact_id)
        os.makedirs(artifact_dir, exist_ok=True)
        
        input_path = os.path.join(artifact_dir, "input.xml")
        with open(input_path, "wb") as f:
            f.write(xml_content)
        
        parser = InfaXMLParser(xml_content)
        if not parser.parse():
            return {
                "success": False,
                "error": "Failed to parse XML file",
                "artifact_id": artifact_id
            }
        
        mappings = parser.get_mappings()
        
        analyzer = Analyzer(
            mappings=mappings,
            xml_type=parser.xml_type,
            folder_name=parser.folder_name,
            repository_name=parser.repository_name
        )
        
        analysis_result = analyzer.analyze()
        
        workflow_analysis = parser.get_workflow_analysis()
        configs = parser.get_configs()
        all_dollar_variables = parser.scan_all_dollar_variables()
        
        analysis_path = os.path.join(artifact_dir, "analysis.json")
        with open(analysis_path, "w") as f:
            json.dump(analysis_result.model_dump(), f, indent=2)
        
        self.artifacts[artifact_id] = {
            "parser": parser,
            "mappings": mappings,
            "analysis": analysis_result,
            "workflow_analysis": workflow_analysis,
            "configs": configs,
            "all_dollar_variables": all_dollar_variables,
            "created_at": datetime.now().isoformat(),
            "filename": filename
        }
        
        return {
            "success": True,
            "artifact_id": artifact_id,
            "analysis": analysis_result.model_dump(),
            "workflow_analysis": workflow_analysis,
            "configs": configs,
            "all_dollar_variables": all_dollar_variables
        }
    
    def generate(self, artifact_id: str, user_config_dict: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate PySpark code based on user configuration.
        
        Output structure (flattened - no lib/ folder):
        - workflow_orchestration.py (if workflow exists)
        - mapping_{name}.py for each mapping (self-contained with embedded utilities)
        - config.yml (centralized configuration)
        """
        if artifact_id not in self.artifacts:
            analysis_path = os.path.join(self.output_dir, artifact_id, "analysis.json")
            if not os.path.exists(analysis_path):
                return {
                    "success": False,
                    "error": f"Artifact not found: {artifact_id}"
                }
            
            with open(analysis_path, "r") as f:
                analysis_data = json.load(f)
            
            input_path = os.path.join(self.output_dir, artifact_id, "input.xml")
            with open(input_path, "rb") as f:
                xml_content = f.read()
            
            parser = InfaXMLParser(xml_content)
            parser.parse()
            mappings = parser.get_mappings()
            workflow_analysis = parser.get_workflow_analysis()
            
            self.artifacts[artifact_id] = {
                "parser": parser,
                "mappings": mappings,
                "analysis": AnalysisResult(**analysis_data),
                "workflow_analysis": workflow_analysis
            }
        
        artifact = self.artifacts[artifact_id]
        mappings = artifact["mappings"]
        
        user_config = self._parse_user_config(artifact_id, user_config_dict)
        
        config_path = os.path.join(self.output_dir, artifact_id, "config_user.json")
        with open(config_path, "w") as f:
            json.dump(user_config.model_dump(), f, indent=2)
        
        result = GenerationResult(artifact_id=artifact_id)
        artifact_dir = os.path.join(self.output_dir, artifact_id)
        
        # Create conversion logger for detailed element-level logging
        logger = ConversionLogger()
        logger.log(LogStage.CONFIG, "Generation", artifact_id, "Starting code generation", LogLevel.INFO)
        
        codegen = CodeGenerator(template_dir=self.template_dir)
        codegen.reset()
        
        mapping_info = []
        
        for mapping in mappings:
            logger.set_current_mapping(mapping.name)
            logger.log(LogStage.TRANSFORM, "Mapping", mapping.name, "Processing mapping", LogLevel.INFO)
            
            handlers = TransformHandlers(mapping, user_config, logger)
            ir_plan = handlers.build_ir_plan()
            
            generated_files = codegen.generate(ir_plan, user_config)
            
            for gen_file in generated_files:
                file_path = os.path.join(artifact_dir, gen_file.filename)
                with open(file_path, "w") as f:
                    f.write(gen_file.content)
                result.files.append(gen_file)
            
            safe_name = self._make_safe_name(mapping.name)
            mapping_info.append({
                "name": mapping.name,
                "safe_name": safe_name,
                "module_name": f"mapping_{safe_name}"
            })
            
            mapping_content = ""
            for gf in generated_files:
                if gf.filename.startswith("mapping_"):
                    mapping_content = gf.content
                    break
            
            report_builder = ReportBuilder(ir_plan, mapping_content)
            report = report_builder.build()
            report.generated_files = [gf.filename for gf in generated_files]
            result.reports.append(report)
            
            report_path = os.path.join(artifact_dir, f"report_{mapping.name}.json")
            with open(report_path, "w") as f:
                json.dump(report.model_dump(), f, indent=2)
            
            # Log mapping completion with file count
            logger.log_codegen("Mapping", mapping.name, f"Generated {len(generated_files)} files", LogLevel.SUCCESS)
        
        workflow_analysis = artifact.get("workflow_analysis", {})
        options = user_config_dict.get("options", {})
        generate_orchestration = options.get("generate_orchestration", True)
        
        if workflow_analysis and generate_orchestration:
            logger.log(LogStage.WORKFLOW, "Workflow", "orchestration", "Building workflow orchestration", LogLevel.INFO)
            
            workflow_builder = WorkflowBuilder(workflow_analysis, mappings)
            workflow_dag = workflow_builder.build()
            
            if workflow_dag:
                logger.log(LogStage.WORKFLOW, "Workflow", workflow_dag.workflow_name, f"Found {len(workflow_dag.sessions)} sessions", LogLevel.INFO)
                
                sessions = [s.model_dump() for s in workflow_dag.sessions]
                dependencies = {s.name: s.dependencies for s in workflow_dag.sessions}
                execution_order = workflow_dag.execution_order
                
                orchestration_code = codegen.generate_workflow_orchestration(
                    workflow_name=workflow_dag.workflow_name,
                    mappings=mapping_info,
                    sessions=sessions,
                    dependencies=dependencies,
                    execution_order=execution_order
                )
                
                workflow_safe_name = self._make_safe_name(workflow_dag.workflow_name)
                orch_file = GeneratedFile(
                    filename=f"{workflow_safe_name}.py",
                    content=orchestration_code,
                    file_type="python"
                )
                
                orch_path = os.path.join(artifact_dir, orch_file.filename)
                with open(orch_path, "w") as f:
                    f.write(orch_file.content)
                result.files.append(orch_file)
                
                dag_json = workflow_dag.model_dump()
                dag_path = os.path.join(artifact_dir, "workflow_dag.json")
                with open(dag_path, "w") as f:
                    json.dump(dag_json, f, indent=2)
                
                logger.log(LogStage.WORKFLOW, "Workflow", workflow_dag.workflow_name, "Workflow orchestration generated", LogLevel.SUCCESS)
        
        result.mappings_processed = len(mappings)
        
        # Generate config.yml file
        if mappings:
            primary_mapping_name = mappings[0].name
            config_yaml_content = self._generate_config_yaml(primary_mapping_name, mappings, user_config)
            config_filename = f"config_{self._make_safe_name(primary_mapping_name)}.yml"
            config_file = GeneratedFile(
                filename=config_filename,
                content=config_yaml_content,
                file_type="yaml"
            )
            config_path = os.path.join(artifact_dir, config_filename)
            with open(config_path, "w") as f:
                f.write(config_yaml_content)
            result.files.append(config_file)
            logger.log(LogStage.CONFIG, "Config", config_filename, "Configuration file generated", LogLevel.SUCCESS)
            
            # Generate README.md file
            readme_content = self._generate_readme(primary_mapping_name, mappings, user_config)
            readme_file = GeneratedFile(
                filename="README.md",
                content=readme_content,
                file_type="markdown"
            )
            readme_path = os.path.join(artifact_dir, "README.md")
            with open(readme_path, "w") as f:
                f.write(readme_content)
            result.files.append(readme_file)
            logger.log(LogStage.CONFIG, "README", "README.md", "README documentation generated", LogLevel.SUCCESS)
        
        zip_path = self._create_zip(artifact_id, result)
        result.zip_path = zip_path
        
        # Log completion
        logger.log(LogStage.CONFIG, "Generation", artifact_id, f"Generation complete: {len(result.files)} files", LogLevel.SUCCESS)
        
        # Build per-mapping summaries from analysis data
        analysis = artifact.get("analysis")
        summaries = self._build_mapping_summaries(analysis) if analysis else {}
        
        return {
            "success": True,
            "artifact_id": artifact_id,
            "result": result.model_dump(),
            "zip_path": zip_path,
            "logs": logger.to_dict(),
            "summaries": summaries
        }
    
    def _build_mapping_summaries(self, analysis: AnalysisResult) -> Dict[str, Dict[str, Any]]:
        """Build data flow summary for each mapping."""
        summaries = {}
        
        for mapping_analysis in analysis.mappings:
            mapping_name = mapping_analysis.mapping_name
            
            # Sources
            sources = []
            for src in mapping_analysis.sources:
                db_type = src.get("database_type", "")
                sources.append({
                    "name": src.get("name", ""),
                    "connection": db_type if db_type else ""
                })
            
            # Targets
            targets = []
            for tgt in mapping_analysis.targets:
                db_type = tgt.get("database_type", "")
                targets.append({
                    "name": tgt.get("name", ""),
                    "connection": db_type if db_type else ""
                })
            
            # Transformations by type
            transform_counts = {}
            ts = mapping_analysis.transform_summary
            type_names = {
                "source_qualifiers": "Source Qualifier",
                "expressions": "Expression",
                "filters": "Filter",
                "lookups": "Lookup Procedure",
                "stored_procedures": "Stored Procedure",
                "joiners": "Joiner",
                "aggregators": "Aggregator",
                "sorters": "Sorter",
                "routers": "Router",
                "unions": "Union",
                "others": "Other"
            }
            
            for attr, display_name in type_names.items():
                count = getattr(ts, attr, 0)
                if count > 0:
                    transform_counts[display_name] = count
            
            # Connectors count
            connectors_analysis = mapping_analysis.connectors_analysis
            connector_count = connectors_analysis.get("total_count", 0) if connectors_analysis else 0
            
            summaries[mapping_name] = {
                "sources": sources,
                "targets": targets,
                "transform_counts": transform_counts,
                "connector_count": connector_count
            }
        
        return summaries
    
    def _make_safe_name(self, name: str) -> str:
        """Convert name to valid Python identifier."""
        safe = re.sub(r'[^a-zA-Z0-9_]', '_', name)
        if safe and safe[0].isdigit():
            safe = '_' + safe
        return safe.lower()
    
    def _parse_user_config(self, artifact_id: str, config_dict: Dict[str, Any]) -> UserConfig:
        """Parse user configuration from dictionary."""
        sources = []
        for src in config_dict.get("sources", []):
            source_config = SourceConfig(
                source_name=src.get("source_name", ""),
                source_type=SourceType(src.get("source_type", "SQL")),
                connection_alias=src.get("connection_alias"),
                file_format=FileFormat(src.get("file_format", "csv")) if src.get("file_format") else None,
                file_location=FileLocation(src.get("file_location", "local")) if src.get("file_location") else None,
                file_path=src.get("file_path"),
                delimiter=src.get("delimiter", ","),
                header=src.get("header", True),
                quote_char=src.get("quote_char", '"'),
                escape_char=src.get("escape_char", "\\"),
                encoding=src.get("encoding", "UTF-8")
            )
            sources.append(source_config)
        
        targets = []
        for tgt in config_dict.get("targets", []):
            target_config = TargetConfig(
                target_name=tgt.get("target_name", ""),
                output_format=tgt.get("output_format", "delta"),
                destination_path=tgt.get("destination_path", ""),
                table_name=tgt.get("table_name", ""),
                write_mode=tgt.get("write_mode", "append")
            )
            targets.append(target_config)
        
        db_connections = config_dict.get("db_connections", {})
        
        connection_mappings = config_dict.get("connection_mappings", {})
        
        options = config_dict.get("options", {})
        
        return UserConfig(
            artifact_id=artifact_id,
            sources=sources,
            targets=targets,
            db_connections=db_connections,
            connection_mappings=connection_mappings,
            options=options
        )
    
    def _create_zip(self, artifact_id: str, result: GenerationResult) -> str:
        """Create ZIP file with all generated files (flattened structure)."""
        artifact_dir = os.path.join(self.output_dir, artifact_id)
        zip_filename = f"{artifact_id}_pyspark.zip"
        zip_path = os.path.join(artifact_dir, zip_filename)
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for gen_file in result.files:
                file_path = os.path.join(artifact_dir, gen_file.filename)
                if os.path.exists(file_path):
                    zipf.write(file_path, gen_file.filename)
            
            for report in result.reports:
                report_filename = f"report_{report.mapping_name}.json"
                report_path = os.path.join(artifact_dir, report_filename)
                if os.path.exists(report_path):
                    zipf.write(report_path, report_filename)
            
            dag_path = os.path.join(artifact_dir, "workflow_dag.json")
            if os.path.exists(dag_path):
                zipf.write(dag_path, "workflow_dag.json")
        
        return zip_path
    
    def get_artifact(self, artifact_id: str) -> Optional[Dict[str, Any]]:
        """Get artifact information."""
        if artifact_id in self.artifacts:
            artifact = self.artifacts[artifact_id]
            return {
                "artifact_id": artifact_id,
                "created_at": artifact.get("created_at"),
                "filename": artifact.get("filename"),
                "analysis": artifact.get("analysis").model_dump() if artifact.get("analysis") else None
            }
        
        artifact_dir = os.path.join(self.output_dir, artifact_id)
        if os.path.exists(artifact_dir):
            analysis_path = os.path.join(artifact_dir, "analysis.json")
            if os.path.exists(analysis_path):
                with open(analysis_path, "r") as f:
                    analysis_data = json.load(f)
                return {
                    "artifact_id": artifact_id,
                    "analysis": analysis_data
                }
        
        return None
    
    def get_download_path(self, artifact_id: str) -> Optional[str]:
        """Get path to download ZIP file."""
        artifact_dir = os.path.join(self.output_dir, artifact_id)
        zip_path = os.path.join(artifact_dir, f"{artifact_id}_pyspark.zip")
        
        if os.path.exists(zip_path):
            return zip_path
        
        return None
    
    def _generate_config_yaml(self, mapping_name: str, mappings: List[MappingDefinition], user_config: UserConfig) -> str:
        """Generate config.yml file with environment variables and connection settings."""
        safe_name = self._make_safe_name(mapping_name)
        
        config = {
            'environment': {
                'name': '${ENV_NAME:development}',
                'log_level': '${LOG_LEVEL:INFO}'
            },
            'spark': {
                'app_name': safe_name,
                'configs': {
                    'spark.ui.port': '${SPARK_UI_PORT:4040}',
                    'spark.driver.extraClassPath': '${MSSQL_DRIVER_JAR:/opt/drivers/mssql-jdbc-12.4.2.jre11.jar}',
                    'spark.executor.extraClassPath': '${MSSQL_DRIVER_JAR:/opt/drivers/mssql-jdbc-12.4.2.jre11.jar}',
                    'spark.executor.extraJavaOptions': '-Djava.library.path=${MSSQL_AUTH_DLL_DIR:C:/Drivers}',
                    'spark.driver.extraJavaOptions': '-Djava.library.path=${MSSQL_AUTH_DLL_DIR:C:/Drivers}',
                    'spark.driver.memory': '${SPARK_DRIVER_MEMORY:16g}',
                    'spark.executor.memory': '${SPARK_EXECUTOR_MEMORY:16g}',
                    'spark.memory.offHeap.enabled': '${SPARK_OFFHEAP_ENABLED:true}',
                    'spark.memory.offHeap.size': '${SPARK_OFFHEAP_SIZE:16g}',
                    'spark.sql.shuffle.partitions': '${SPARK_SHUFFLE_PARTITIONS:50}',
                    'spark.default.parallelism': '${SPARK_DEFAULT_PARALLELISM:50}',
                    'spark.sql.debug.maxToStringFields': '${SPARK_DEBUG_MAX_FIELDS:100}',
                    'spark.driver.maxResultSize': '${SPARK_DRIVER_MAX_RESULT:8g}',
                    'spark.sql.autoBroadcastJoinThreshold': '${SPARK_AUTO_BROADCAST_THRESHOLD:-1}',
                    'spark.memory.fraction': '${SPARK_MEMORY_FRACTION:0.8}',
                    'spark.memory.storageFraction': '${SPARK_STORAGE_FRACTION:0.3}',
                    'spark.dynamicAllocation.enabled': '${SPARK_DYNAMIC_ALLOCATION:true}',
                    'spark.shuffle.service.enabled': '${SPARK_SHUFFLE_SERVICE:true}'
                }
            },
            'connections': {
                'CDM_PRE_LANDING': {
                    'db_type': 'sqlserver',
                    'host': '${MSSQL_HOST}',
                    'database': 'msscdm_dev',
                    'jdbc_url': 'jdbc:sqlserver://${MSSQL_HOST}; databaseName=msscdm_dev; user=${MSSQL_USER}; password=${MSSQL_PASSWORD}; trustServerCertificate=true; encrypt=false',
                    'user': '${MSSQL_USER}',
                    'password': '${MSSQL_PASSWORD}',
                    'driver': 'com.microsoft.sqlserver.jdbc.SQLServerDriver',
                    'driver_jar': '${MSSQL_DRIVER_JAR:/opt/drivers/mssql-jdbc-12.4.2.jre11.jar}',
                    'fetchsize': '${MSSQL_FETCHSIZE:10000}'
                },
                'CDM_PRE_LANDING_INV': {
                    'db_type': 'sqlserver',
                    'host': '${MSSQL_HOST}',
                    'database': 'msscdm_inv',
                    'jdbc_url': 'jdbc:sqlserver://${MSSQL_HOST}; databaseName=msscdm_inv; user=${MSSQL_USER}; password=${MSSQL_PASSWORD}; trustServerCertificate=true; encrypt=false',
                    'user': '${MSSQL_USER}',
                    'password': '${MSSQL_PASSWORD}',
                    'driver': 'com.microsoft.sqlserver.jdbc.SQLServerDriver',
                    'driver_jar': '${MSSQL_DRIVER_JAR:/opt/drivers/mssql-jdbc-12.4.2.jre11.jar}'
                },
                'CDM_LANDING': {
                    'db_type': 'sqlserver',
                    'host': '${MSSQL_HOST}',
                    'database': 'cmx_ors_10_3',
                    'jdbc_url': 'jdbc:sqlserver://${MSSQL_HOST}; databaseName=cmx_ors_10_3; user=${MSSQL_USER}; password=${MSSQL_PASSWORD}; trustServerCertificate=true; encrypt=false',
                    'user': '${MSSQL_USER}',
                    'password': '${MSSQL_PASSWORD}',
                    'driver': 'com.microsoft.sqlserver.jdbc.SQLServerDriver',
                    'driver_jar': '${MSSQL_DRIVER_JAR:/opt/drivers/mssql-jdbc-12.4.2.jre11.jar}'
                },
                'CDM_LANDING_INV': {
                    'db_type': 'sqlserver',
                    'host': '${MSSQL_HOST}',
                    'database': 'cmx_ors_inv',
                    'jdbc_url': 'jdbc:sqlserver://${MSSQL_HOST}; databaseName=cmx_ors_inv; user=${MSSQL_USER}; password=${MSSQL_PASSWORD}; trustServerCertificate=true; encrypt=false',
                    'user': '${MSSQL_USER}',
                    'password': '${MSSQL_PASSWORD}',
                    'driver': 'com.microsoft.sqlserver.jdbc.SQLServerDriver',
                    'driver_jar': '${MSSQL_DRIVER_JAR:/opt/drivers/mssql-jdbc-12.4.2.jre11.jar}'
                },
                'TARGET': {
                    'db_type': 'sqlserver',
                    'host': '${MSSQL_HOST}',
                    'database': 'msscdm_dev3',
                    'jdbc_url': 'jdbc:sqlserver://${MSSQL_HOST}; databaseName=msscdm_dev3; user=${MSSQL_USER}; password=${MSSQL_PASSWORD}; trustServerCertificate=true; encrypt=false',
                    'user': '${MSSQL_USER}',
                    'password': '${MSSQL_PASSWORD}',
                    'driver': 'com.microsoft.sqlserver.jdbc.SQLServerDriver',
                    'driver_jar': '${MSSQL_DRIVER_JAR:/opt/drivers/mssql-jdbc-12.4.2.jre11.jar}',
                    'mode': '${MSSQL_WRITE_MODE:append}'
                }
            },
            'params': {
                'SRC_SYSTEM_NM': '${SRC_SYSTEM_NM:SSC}'
            }
        }
        
        if user_config.db_connections:
            for conn_name, conn_info in user_config.db_connections.items():
                if conn_name not in config['connections']:
                    config['connections'][conn_name] = conn_info
        
        return yaml.dump(config, default_flow_style=False, sort_keys=False, allow_unicode=True)
    
    def _generate_readme(self, mapping_name: str, mappings: List[MappingDefinition], user_config: UserConfig) -> str:
        """Generate README.md with environment setup and target table schema."""
        safe_name = self._make_safe_name(mapping_name)
        
        readme_lines = [
            f"# {mapping_name} - PySpark Conversion",
            "",
            "This code was auto-generated from Informatica PowerCenter XML by the Informatica to PySpark Converter.",
            "",
            "## 1. Environment Variables Setup",
            "",
            "### PowerShell",
            "```powershell",
            "# Required environment variables (MSSQL for both source and target)",
            "$env:MSSQL_HOST='your_server.com\\INSTANCE'",
            "$env:MSSQL_USER='spark_user'",
            "$env:MSSQL_PASSWORD='your_mssql_password'",
            "$env:MSSQL_DRIVER_JAR='C:/Drivers/mssql-jdbc-12.4.2.jre11.jar'",
            "",
            "# Optional parameters (with defaults)",
            "$env:SRC_SYSTEM_NM='SSC'",
            "$env:ENV_NAME='development'",
            "$env:LOG_LEVEL='INFO'",
            "```",
            "",
            "### Bash/Linux",
            "```bash",
            "# Required environment variables (MSSQL for both source and target)",
            "export MSSQL_HOST='your_server.com\\INSTANCE'",
            "export MSSQL_USER='spark_user'",
            "export MSSQL_PASSWORD='your_mssql_password'",
            "export MSSQL_DRIVER_JAR='/opt/drivers/mssql-jdbc-12.4.2.jre11.jar'",
            "",
            "# Optional parameters (with defaults)",
            "export SRC_SYSTEM_NM='SSC'",
            "export ENV_NAME='development'",
            "export LOG_LEVEL='INFO'",
            "```",
            "",
            "## 2. Target Table Schema",
            "",
        ]
        
        for mapping in mappings:
            for target in mapping.targets:
                readme_lines.append(f"### Target: {target.name} (Database: msscdm_dev3)")
                readme_lines.append("")
                readme_lines.append("```sql")
                readme_lines.append(f"-- MSSQL CREATE TABLE syntax")
                readme_lines.append(f"IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[{target.name}]') AND type in (N'U'))")
                readme_lines.append("BEGIN")
                readme_lines.append(f"    CREATE TABLE [dbo].[{target.name}] (")
                
                field_lines = []
                for i, field in enumerate(target.fields):
                    mssql_type = self._convert_to_mssql_type(field.datatype, field.precision, field.scale)
                    nullable = " NULL" if field.nullable else " NOT NULL"
                    is_identity = field.name.upper() == "SRC_ROWID"
                    identity = " IDENTITY(1,1)" if is_identity else ""
                    
                    field_line = f"        [{field.name}] {mssql_type}{identity}{nullable}"
                    field_lines.append(field_line)
                
                readme_lines.append(",\n".join(field_lines))
                readme_lines.append("    )")
                readme_lines.append("END")
                readme_lines.append("```")
                readme_lines.append("")
        
        readme_lines.extend([
            "## 3. What is $$SRC_SYSTEM_NM?",
            "",
            "`$$SRC_SYSTEM_NM` is an Informatica runtime parameter used in mapping/workflow sessions.",
            "",
            "**How to find the value:**",
            "1. Open Workflow Manager",
            "2. Open the workflow",
            "3. In the Session task -> Properties / Config Object, check the Parameter File path",
            "4. Open that `.par` file and search for `SRC_SYSTEM_NM`",
            "",
            "In this config, the default is set to `SSC`. Override via environment variable if needed:",
            "```powershell",
            "$env:SRC_SYSTEM_NM='YOUR_VALUE'",
            "```",
            "",
            "## 4. How to Run",
            "",
            "### Quick Run (config in same folder)",
            "```bash",
            f"python {safe_name}.py",
            "```",
            "",
            "### With custom config path",
            "```powershell",
            f"$env:CONFIG_PATH='C:\\path\\to\\config_{safe_name}.yml'",
            f"python {safe_name}.py",
            "```",
            "",
            "## 5. Files Generated",
            "",
            f"- `{safe_name}.py` - Main PySpark mapping code",
            f"- `config_{safe_name}.yml` - Configuration file with environment variables",
            "- `README.md` - This documentation file",
            "",
            "## 6. Notes",
            "",
            "- Passwords with special characters (like `$`, `@`, `*`) must use single quotes in PowerShell",
            "- The `SRC_ROWID` column is typically set as IDENTITY in MSSQL if not mapped from source",
            "- Target database is fixed as msscdm_dev3",
            "- Review and test the generated code before production use",
            ""
        ])
        
        return "\n".join(readme_lines)
    
    def _convert_to_mssql_type(self, datatype: str, precision: int, scale: int) -> str:
        """Convert Informatica/generic datatype to MSSQL type."""
        dt_upper = datatype.upper() if datatype else "NVARCHAR"
        
        type_mapping = {
            'STRING': f'NVARCHAR({precision})' if precision > 0 else 'NVARCHAR(255)',
            'VARCHAR': f'NVARCHAR({precision})' if precision > 0 else 'NVARCHAR(255)',
            'VARCHAR2': f'NVARCHAR({precision})' if precision > 0 else 'NVARCHAR(255)',
            'CHAR': f'NCHAR({precision})' if precision > 0 else 'NCHAR(1)',
            'NVARCHAR': f'NVARCHAR({precision})' if precision > 0 else 'NVARCHAR(255)',
            'NCHAR': f'NCHAR({precision})' if precision > 0 else 'NCHAR(1)',
            'INTEGER': 'INT',
            'INT': 'INT',
            'BIGINT': 'BIGINT',
            'SMALLINT': 'SMALLINT',
            'TINYINT': 'TINYINT',
            'DECIMAL': f'DECIMAL({precision},{scale})' if precision > 0 else 'DECIMAL(18,2)',
            'NUMERIC': f'NUMERIC({precision},{scale})' if precision > 0 else 'NUMERIC(18,2)',
            'NUMBER': f'NUMERIC({precision},{scale})' if precision > 0 else 'NUMERIC(18,2)',
            'FLOAT': 'FLOAT',
            'DOUBLE': 'FLOAT',
            'REAL': 'REAL',
            'DATE': 'DATE',
            'DATETIME': 'DATETIME2',
            'TIMESTAMP': 'DATETIME2',
            'TIME': 'TIME',
            'BOOLEAN': 'BIT',
            'BOOL': 'BIT',
            'TEXT': 'NVARCHAR(MAX)',
            'CLOB': 'NVARCHAR(MAX)',
            'BLOB': 'VARBINARY(MAX)',
            'BINARY': 'VARBINARY(MAX)',
            'VARBINARY': 'VARBINARY(MAX)',
            'MONEY': 'MONEY',
            'SMALLMONEY': 'SMALLMONEY',
            'UNIQUEIDENTIFIER': 'UNIQUEIDENTIFIER',
            'XML': 'XML'
        }
        
        return type_mapping.get(dt_upper, f'NVARCHAR({precision})' if precision > 0 else 'NVARCHAR(255)')
