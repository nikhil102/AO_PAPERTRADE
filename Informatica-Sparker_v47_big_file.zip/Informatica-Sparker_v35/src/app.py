"""Flask application for Informatica XML to PySpark Converter."""
import os
import uuid
import threading
import time
import gc
from flask import Flask, request, jsonify, send_file, send_from_directory
from werkzeug.utils import secure_filename
from converter.service import ConversionService

# Get the project root directory
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATIC_FOLDER = os.path.join(PROJECT_ROOT, 'static')
UPLOAD_FOLDER = os.path.join(PROJECT_ROOT, 'src', 'uploads')
OUTPUT_FOLDER = os.path.join(PROJECT_ROOT, 'src', 'output')
TEMPLATE_FOLDER = os.path.join(PROJECT_ROOT, 'templates')

app = Flask(__name__, static_folder=STATIC_FOLDER, static_url_path='/static')

# Configure for large file uploads (100MB max)
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Increase request timeout handling
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

ALLOWED_EXTENSIONS = {'xml'}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# Background job tracking
processing_jobs = {}


class ProcessingJob:
    """Track background processing jobs for large files."""
    
    def __init__(self, job_id: str, filename: str, file_size: int):
        self.job_id = job_id
        self.filename = filename
        self.file_size = file_size
        self.status = "pending"  # pending, processing, completed, failed
        self.progress = 0
        self.stage = "Initializing"
        self.result = None
        self.error = None
        self.start_time = time.time()
        self.end_time = None
    
    def update(self, status: str = None, progress: int = None, stage: str = None):
        if status:
            self.status = status
        if progress is not None:
            self.progress = progress
        if stage:
            self.stage = stage
    
    def complete(self, result):
        self.status = "completed"
        self.progress = 100
        self.stage = "Complete"
        self.result = result
        self.end_time = time.time()
    
    def fail(self, error: str):
        self.status = "failed"
        self.error = error
        self.end_time = time.time()
    
    def to_dict(self):
        return {
            "job_id": self.job_id,
            "filename": self.filename,
            "file_size": self.file_size,
            "status": self.status,
            "progress": self.progress,
            "stage": self.stage,
            "error": self.error,
            "duration": (self.end_time or time.time()) - self.start_time
        }

conversion_service = ConversionService(
    output_dir=OUTPUT_FOLDER,
    template_dir=TEMPLATE_FOLDER
)


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/')
def index():
    """Serve the main frontend page."""
    return send_from_directory(STATIC_FOLDER, 'index.html')


@app.route('/css/<path:filename>')
def serve_css(filename):
    """Serve CSS files."""
    return send_from_directory(os.path.join(STATIC_FOLDER, 'css'), filename)


@app.route('/js/<path:filename>')
def serve_js(filename):
    """Serve JavaScript files."""
    return send_from_directory(os.path.join(STATIC_FOLDER, 'js'), filename)


@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({"status": "healthy", "service": "Informatica XML to PySpark Converter"})


def process_large_file_background(job_id: str, file_path: str, filename: str):
    """Background worker for processing large XML files."""
    job = processing_jobs.get(job_id)
    if not job:
        return
    
    try:
        job.update(status="processing", progress=10, stage="Reading XML file")
        
        with open(file_path, 'rb') as f:
            xml_content = f.read()
        
        job.update(progress=30, stage="Parsing XML structure")
        
        result = conversion_service.analyze(xml_content, filename)
        
        job.update(progress=80, stage="Building analysis report")
        
        os.remove(file_path)
        gc.collect()
        
        job.complete(result)
        
    except Exception as e:
        job.fail(str(e))
        if os.path.exists(file_path):
            os.remove(file_path)


@app.route('/api/analyze', methods=['POST'])
def analyze():
    """Analyze uploaded XML file and return analysis result.
    
    For files > 10MB, uses async processing with job tracking.
    For smaller files, processes synchronously.
    """
    if 'file' not in request.files:
        return jsonify({"success": False, "error": "No file provided"}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({"success": False, "error": "No file selected"}), 400
    
    if not allowed_file(file.filename):
        return jsonify({"success": False, "error": "Invalid file type. Only XML files are allowed."}), 400
    
    try:
        filename = secure_filename(file.filename)
        
        file.seek(0, 2)
        file_size = file.tell()
        file.seek(0)
        
        large_file_threshold = 10 * 1024 * 1024  # 10MB
        
        if file_size > large_file_threshold:
            job_id = str(uuid.uuid4())[:8]
            file_path = os.path.join(UPLOAD_FOLDER, f"{job_id}_{filename}")
            
            chunk_size = 8192
            with open(file_path, 'wb') as f:
                while True:
                    chunk = file.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
            
            job = ProcessingJob(job_id, filename, file_size)
            processing_jobs[job_id] = job
            
            thread = threading.Thread(
                target=process_large_file_background,
                args=(job_id, file_path, filename)
            )
            thread.daemon = True
            thread.start()
            
            return jsonify({
                "success": True,
                "async": True,
                "job_id": job_id,
                "message": f"Large file ({file_size / 1024 / 1024:.1f} MB) - processing in background",
                "status_url": f"/api/job/{job_id}/status"
            })
        
        else:
            xml_content = file.read()
            result = conversion_service.analyze(xml_content, filename)
            return jsonify(result)
    
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/job/<job_id>/status', methods=['GET'])
def get_job_status(job_id):
    """Get status of an async processing job."""
    job = processing_jobs.get(job_id)
    
    if not job:
        return jsonify({"success": False, "error": "Job not found"}), 404
    
    response = {
        "success": True,
        **job.to_dict()
    }
    
    if job.status == "completed" and job.result:
        response["result"] = job.result
        del processing_jobs[job_id]
    
    return jsonify(response)


@app.route('/api/jobs', methods=['GET'])
def list_jobs():
    """List all active processing jobs."""
    return jsonify({
        "success": True,
        "jobs": [job.to_dict() for job in processing_jobs.values()]
    })


@app.route('/api/generate', methods=['POST'])
def generate():
    """Generate PySpark code based on user configuration."""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({"success": False, "error": "No configuration provided"}), 400
        
        artifact_id = data.get('artifact_id')
        if not artifact_id:
            return jsonify({"success": False, "error": "artifact_id is required"}), 400
        
        user_config = data.get('config', {})
        
        result = conversion_service.generate(artifact_id, user_config)
        
        return jsonify(result)
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/artifact/<artifact_id>', methods=['GET'])
def get_artifact(artifact_id):
    """Get artifact information."""
    artifact = conversion_service.get_artifact(artifact_id)
    
    if artifact:
        return jsonify({"success": True, "artifact": artifact})
    else:
        return jsonify({"success": False, "error": "Artifact not found"}), 404


@app.route('/api/artifact/<artifact_id>/download', methods=['GET'])
def download_artifact(artifact_id):
    """Download generated ZIP file."""
    zip_path = conversion_service.get_download_path(artifact_id)
    
    if zip_path and os.path.exists(zip_path):
        return send_file(
            zip_path,
            mimetype='application/zip',
            as_attachment=True,
            download_name=f'{artifact_id}_pyspark.zip'
        )
    else:
        return jsonify({"success": False, "error": "Download not available"}), 404


@app.route('/api/artifact/<artifact_id>/file/<filename>', methods=['GET'])
def get_file(artifact_id, filename):
    """Get a specific generated file."""
    file_path = os.path.join(OUTPUT_FOLDER, artifact_id, secure_filename(filename))
    
    if os.path.exists(file_path):
        with open(file_path, 'r') as f:
            content = f.read()
        return jsonify({"success": True, "filename": filename, "content": content})
    else:
        return jsonify({"success": False, "error": "File not found"}), 404


@app.route('/api/convert-expression', methods=['POST'])
def convert_expression():
    """Convert Informatica expression to PySpark syntax."""
    try:
        data = request.get_json()
        expression = data.get('expression', '').strip()
        
        if not expression:
            return jsonify({"success": False, "error": "No expression provided"}), 400
        
        # Expression conversion mappings
        conversions = {
            # String functions
            'SUBSTR': 'substring',
            'LTRIM': 'ltrim',
            'RTRIM': 'rtrim',
            'UPPER': 'upper',
            'LOWER': 'lower',
            'CONCAT': 'concat',
            'LENGTH': 'length',
            'INSTR': 'instr',
            'REPLACE': 'regexp_replace',
            'LPAD': 'lpad',
            'RPAD': 'rpad',
            'INITCAP': 'initcap',
            'REVERSE': 'reverse',
            'REPLACESTR': 'regexp_replace',
            'REG_EXTRACT': 'regexp_extract',
            'REG_REPLACE': 'regexp_replace',
            
            # Null handling
            'ISNULL': 'isnull',
            'NVL': 'coalesce',
            
            # Date functions
            'SYSDATE': 'current_date()',
            'SYSTIMESTAMP': 'current_timestamp()',
            'TO_DATE': 'to_date',
            'TO_CHAR': 'date_format',
            'ADD_TO_DATE': 'date_add',
            'DATE_DIFF': 'datediff',
            'LAST_DAY': 'last_day',
            'GET_DATE_PART': 'extract',
            
            # Numeric functions
            'ROUND': 'round',
            'TRUNC': 'trunc',
            'ABS': 'abs',
            'MOD': 'mod',
            'POWER': 'pow',
            'SQRT': 'sqrt',
            'CEIL': 'ceil',
            'FLOOR': 'floor',
            
            # Type conversion
            'TO_INTEGER': 'cast({} as int)',
            'TO_BIGINT': 'cast({} as bigint)',
            'TO_FLOAT': 'cast({} as float)',
            'TO_DECIMAL': 'cast({} as decimal)',
            
            # Aggregate functions
            'SUM': 'sum',
            'AVG': 'avg',
            'COUNT': 'count',
            'MAX': 'max',
            'MIN': 'min',
        }
        
        result = expression
        
        # Replace function names (case-insensitive)
        import re
        for infa_func, pyspark_func in conversions.items():
            pattern = re.compile(re.escape(infa_func) + r'\s*\(', re.IGNORECASE)
            result = pattern.sub(pyspark_func + '(', result)
        
        # Handle IIF -> when/otherwise
        iif_pattern = re.compile(r'IIF\s*\(\s*(.+?)\s*,\s*(.+?)\s*,\s*(.+?)\s*\)', re.IGNORECASE)
        def replace_iif(match):
            condition = match.group(1).strip()
            true_val = match.group(2).strip()
            false_val = match.group(3).strip()
            return f'when({condition}, {true_val}).otherwise({false_val})'
        result = iif_pattern.sub(replace_iif, result)
        
        # Handle NVL2 -> when/otherwise
        nvl2_pattern = re.compile(r'NVL2\s*\(\s*(.+?)\s*,\s*(.+?)\s*,\s*(.+?)\s*\)', re.IGNORECASE)
        def replace_nvl2(match):
            expr = match.group(1).strip()
            not_null_val = match.group(2).strip()
            null_val = match.group(3).strip()
            return f'when(isnull({expr}), {null_val}).otherwise({not_null_val})'
        result = nvl2_pattern.sub(replace_nvl2, result)
        
        # Handle string concatenation with ||
        result = result.replace('||', ', ').replace(', ', ', ')
        if ', ' in result and 'concat' not in result.lower():
            # Wrap in concat if there's concatenation
            parts = result.split(', ')
            if len(parts) > 1 and '(' not in parts[0]:
                result = f"concat({result})"
        
        # Add col() wrapper for column references (simple heuristic)
        # This is a basic implementation - full parser would be more sophisticated
        
        return jsonify({
            "success": True,
            "pyspark_expression": result,
            "original": expression
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/improve-quality', methods=['POST'])
def improve_quality():
    """Analyze and improve PySpark code quality against XML mapping."""
    try:
        if 'xml_file' not in request.files:
            return jsonify({"success": False, "error": "No XML file provided"}), 400
        
        if 'pyspark_file' not in request.files:
            return jsonify({"success": False, "error": "No PySpark file provided"}), 400
        
        xml_file = request.files['xml_file']
        pyspark_file = request.files['pyspark_file']
        
        xml_content = xml_file.read().decode('utf-8')
        pyspark_content = pyspark_file.read().decode('utf-8')
        
        target_platform = request.form.get('target_platform', 'databricks')
        output_format = request.form.get('output_format', 'delta')
        naming_convention = request.form.get('naming_convention', 'snake_case')
        
        from converter.quality_analyzer import QualityAnalyzer
        
        analyzer = QualityAnalyzer(
            target_platform=target_platform,
            output_format=output_format,
            naming_convention=naming_convention
        )
        
        result = analyzer.analyze_and_improve(
            xml_content=xml_content,
            pyspark_code=pyspark_content,
            xml_filename=xml_file.filename,
            pyspark_filename=pyspark_file.filename
        )
        
        return jsonify(result)
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/diagram', methods=['POST'])
def generate_diagram():
    """Generate Mermaid diagram from Informatica XML."""
    try:
        if 'file' not in request.files:
            return jsonify({"success": False, "error": "No file provided"}), 400
        
        file = request.files['file']
        diagram_type = request.form.get('diagram_type', 'dataflow')
        mapping_name = request.form.get('mapping_name')
        
        if file.filename == '':
            return jsonify({"success": False, "error": "No file selected"}), 400
        
        if not allowed_file(file.filename):
            return jsonify({"success": False, "error": "Invalid file type. Only XML files are allowed."}), 400
        
        xml_content = file.read().decode('utf-8')
        
        from converter.diagram_generator import DiagramGenerator
        
        generator = DiagramGenerator()
        result = generator.generate(
            xml_content=xml_content,
            diagram_type=diagram_type,
            mapping_name=mapping_name
        )
        
        return jsonify(result)
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/diagram/from-artifact', methods=['POST'])
def generate_diagram_from_artifact():
    """Generate Mermaid diagram from previously analyzed artifact."""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({"success": False, "error": "No data provided"}), 400
        
        artifact_id = data.get('artifact_id')
        diagram_type = data.get('diagram_type', 'dataflow')
        mapping_name = data.get('mapping_name')
        
        if not artifact_id:
            return jsonify({"success": False, "error": "artifact_id is required"}), 400
        
        artifact = conversion_service.get_artifact(artifact_id)
        
        if not artifact:
            return jsonify({"success": False, "error": "Artifact not found"}), 404
        
        from converter.diagram_generator import DiagramGenerator
        
        generator = DiagramGenerator()
        result = generator.generate_from_artifact(
            artifact=artifact,
            diagram_type=diagram_type,
            mapping_name=mapping_name
        )
        
        return jsonify(result)
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"success": False, "error": str(e)}), 500


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
