/* ── Sidebar (mobile) ── */
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('sidebar-backdrop').classList.toggle('open');
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebar-backdrop').classList.remove('open');
}

/* ── Toast ── */
function toast(msg, type) {
  type = type || 'info';
  var icons = { success: '✔', info: 'ℹ', warn: '⚠', error: '✖' };
  var tc = document.getElementById('toast-container');
  if (!tc) return;
  var t = document.createElement('div');
  t.className = 'toast ' + type;
  t.innerHTML = '<span>' + (icons[type] || 'ℹ') + '</span><span>' + msg + '</span>';
  tc.appendChild(t);
  setTimeout(function() {
    t.style.opacity = '0';
    t.style.transition = 'opacity .3s';
    setTimeout(function() { if (tc.contains(t)) tc.removeChild(t); }, 300);
  }, 3200);
}

/* ── Modal helpers ── */
function openModal(id) {
  var m = document.getElementById(id || 'modal-overlay');
  if (m) m.classList.add('open');
}
function closeModal(id) {
  var m = document.getElementById(id || 'modal-overlay');
  if (m) m.classList.remove('open');
}
function handleOverlayClick(e, id) {
  if (e.target === document.getElementById(id || 'modal-overlay')) closeModal(id);
}

/* ── Timestamp ── */
function nowTs() {
  var d = new Date();
  return d.getHours().toString().padStart(2,'0') + ':' +
         d.getMinutes().toString().padStart(2,'0') + ':' +
         d.getSeconds().toString().padStart(2,'0');
}

/* ── Progress animation util ── */
function animBar(id, speed, max) {
  var el = document.getElementById(id);
  if (!el) return;
  max = max || 99; speed = speed || 0.3;
  function tick() {
    var w = parseFloat(el.style.width) || 0;
    w = Math.min(max, w + (Math.random() * speed));
    el.style.width = w + '%';
    setTimeout(tick, 1800);
  }
  tick();
}

/* ── Dynamic Sidebar Renderer ── */
function renderSidebar() {
  var sidebar = document.getElementById('sidebar');
  if (!sidebar) return;

  var currentPath = location.pathname.split('/').pop() || 'index.html';

  var navData = [
    {
      group: "Discovery",
      items: [
        { href: "./index.html", icon: "◈", text: "Dashboard", title: "Overview and Metrics" },
        { href: "./command-center.html", icon: "🎯", text: "Command Center", badge: "5", badgeClass: "warn", title: "Mission Control room for approvals and critical actions" },
        { href: "./data-discovery.html", icon: "🔍", text: "Data Discovery", title: "Information gathering and exploration" },
        { href: "./upload.html", icon: "📤", text: "Input Sources", title: "Upload center for documents, code and files (Ingress)" },
        { href: "./requirements.html", icon: "📑", text: "Requirements Explorer", title: "Explore discovered business and functional requirements" },
        { href: "./rtm.html", icon: "🔗", text: "Requirement Mapping", title: "Traceability matrix mapping requirements to design (RTM)" }
      ]
    },
    {
      group: "Analysis",
      items: [
        { href: "./agents.html", icon: "🤖", text: "Agent Registry", title: "AI Agent directory and health status" },
        { href: "./ingress-egress.html", icon: "⇄", text: "Data Flows", title: "Visual flow of Ingress -> AI Processing -> Egress" },
        { href: "./knowledge.html", icon: "📚", text: "Knowledge Base", title: "Contextual and reference documents library" },
        { href: "./memory.html", icon: "🧠", text: "Agent Memory", title: "Short-term and long-term vector store memory for AI" },
        { href: "./prompts.html", icon: "✏", text: "Prompt Studio", title: "AI prompt engineering environment" }
      ]
    },
    {
      group: "Design",
      items: [
        { href: "./architecture.html", icon: "🏗", text: "Architecture Studio", title: "Generated systems architecture" },
        { href: "./diagrams.html", icon: "🔷", text: "Diagram Viewer", title: "Visual architecture blueprints and diagrams" },
        { href: "./integrations.html", icon: "🔌", text: "Integrations Hub", title: "External API and system sync dashboard" }
      ]
    },
    {
      group: "Delivery",
      items: [
        { href: "./pipeline.html", icon: "⟶", text: "Pipeline View", badge: "Live", badgeClass: "live", title: "Real-time pipeline running status" },
        { href: "./run-details.html", icon: "📋", text: "Run Details", title: "Detailed execution metrics per run" },
        { href: "./testcases.html", icon: "🧪", text: "Test Cases", title: "Automated test scenario and coverage mapping" },
        { href: "./quality.html", icon: "📊", text: "Quality Dashboard", title: "Validation pass rates and verification metrics" },
        { href: "./templates.html", icon: "🗂", text: "Template Library", title: "Standard corporate document and deliverable templates" },
        { href: "./versions.html", icon: "↩", text: "Version Control", title: "History and rollback checkpoints" },
        { href: "./analytics.html", icon: "📈", text: "Analytics", title: "Cycle time and pipeline throughput insights" }
      ]
    },
    {
      group: "Governance",
      items: [
        { href: "./checkpoints.html", icon: "✓", text: "Review Checkpoints", badge: "3", badgeClass: "warn", title: "Human approval gates in the loop (A2H Checkpoints)" },
        { href: "./audit.html", icon: "🛡", text: "Audit Trail", title: "Tamper-proof log of user and AI operations" },
        { href: "./risks.html", icon: "⚠", text: "Risks Explorer", title: "Identified project and compliance risks" },
        { href: "./logs.html", icon: "≡", text: "System Logs", title: "Technical debugging events log" },
        { href: "./tokenops.html", icon: "💰", text: "AI Usage Monitoring", title: "AI usage, tokens, and model costs (TokenOps)" }
      ]
    },
    {
      group: "Administration",
      items: [
        { href: "./settings.html", icon: "⚙", text: "Configuration", title: "System configuration and prompt limits settings" },
        { href: "./customers.html", icon: "🏢", text: "Customer Workspace", title: "Customer tenant workspaces configuration" },
        { href: "./marketplace.html", icon: "🛒", text: "Marketplace", title: "Browse external AI agents and pre-built templates" }
      ]
    }
  ];

  var html = '';
  // Logo
  html += '<a class="sidebar-logo" href="./index.html">' +
          '<img class="logo-icon" src="./logo.svg" alt="Logo" />' +
          '<div><div class="logo-text">AgentSDLC</div><div class="logo-sub">Command Center v1.0</div></div>' +
          '</a>';

  // Navigation sections
  navData.forEach(function(sec) {
    html += '<div class="nav-section">';
    html += '<div class="nav-section-title">' + sec.group + '</div>';
    sec.items.forEach(function(item) {
      var activeClass = '';
      var itemFile = item.href.split('/').pop();
      if (itemFile === currentPath) {
        activeClass = ' active';
      }
      var badgeHtml = '';
      if (item.badge) {
        badgeHtml = '<span class="nav-badge ' + (item.badgeClass || '') + '">' + item.badge + '</span>';
      }
      html += '<a class="nav-item' + activeClass + '" href="' + item.href + '" title="' + item.title + '">' +
              '<span class="icon">' + item.icon + '</span>' +
              '<span class="nav-text">' + item.text + '</span>' +
              badgeHtml +
              '</a>';
    });
    html += '</div>';
  });

  // Footer User Pill
  html += '<div class="sidebar-footer">' +
          '<div class="user-pill">' +
          '<div class="avatar">SE</div>' +
          '<div><div class="user-name">Supervisor Eng.</div><div class="user-role">Admin • Phase 1</div></div>' +
          '</div>' +
          '</div>';

  sidebar.innerHTML = html;
}

/* ── Role Selector Widget & Storage ── */
function setupRoleSelector() {
  var topbar = document.getElementById('topbar');
  if (!topbar) return;

  var actions = topbar.querySelector('.topbar-actions');
  if (!actions) return;

  if (document.getElementById('workspace-role-selector')) return;

  var wrapper = document.createElement('div');
  wrapper.className = 'role-selector-wrap';
  wrapper.id = 'workspace-role-selector';
  wrapper.innerHTML = 
    '<span>Workspace View:</span>' +
    '<select class="role-selector" onchange="changeWorkspaceRole(this.value)">' +
      '<option value="pm">Project Manager</option>' +
      '<option value="business">Business User</option>' +
      '<option value="architect">Solutions Architect</option>' +
      '<option value="developer">Software Developer</option>' +
    '</select>';

  actions.insertBefore(wrapper, actions.firstChild);

  var savedRole = localStorage.getItem('workspaceRole') || 'pm';
  var selector = wrapper.querySelector('.role-selector');
  selector.value = savedRole;
  applyWorkspaceRole(savedRole);
}

function changeWorkspaceRole(role) {
  localStorage.setItem('workspaceRole', role);
  applyWorkspaceRole(role);
  toast('Switched workspace view to ' + getRoleFriendlyName(role), 'info');
}

function applyWorkspaceRole(role) {
  document.body.classList.remove('role-business', 'role-architect', 'role-developer', 'role-pm');
  document.body.classList.add('role-' + role);
}

function getRoleFriendlyName(role) {
  switch (role) {
    case 'business': return 'Business User';
    case 'architect': return 'Solutions Architect';
    case 'developer': return 'Software Developer';
    case 'pm': return 'Project Manager';
    default: return 'Project Manager';
  }
}

/* ── Page Question Banners Injection ── */
function setupQuestionBanners() {
  var page = location.pathname.split('/').pop() || 'index.html';
  var content = document.getElementById('content');
  if (!content) return;

  var question = "";
  switch (page) {
    case 'requirements.html':
      question = "What requirements were discovered?";
      break;
    case 'architecture.html':
      question = "What architecture has been generated?";
      break;
    case 'pipeline.html':
      question = "How does data move through the system?";
      break;
    case 'agents.html':
      question = "Which AI agents are working?";
      break;
    case 'artifacts.html':
      question = "What deliverables have been generated?";
      break;
    case 'diagrams.html':
      question = "What diagrams exist?";
      break;
    case 'testcases.html':
      question = "What test scenarios were generated?";
      break;
    case 'audit.html':
      question = "What actions happened?";
      break;
    case 'logs.html':
      question = "What technical events occurred?";
      break;
    case 'risks.html':
      question = "What could go wrong?";
      break;
    case 'tokenops.html':
      question = "How much AI usage and cost occurred?";
      break;
    case 'command-center.html':
      question = "What needs human attention right now?";
      break;
    case 'index.html':
      question = "What is the real-time status of active projects and AI agents?";
      break;
    default:
      return;
  }

  var banner = document.createElement('div');
  banner.className = 'question-banner';
  banner.innerHTML = '🎯 <span>Core Question:</span> ' + question;

  var header = content.querySelector('.section-header');
  if (header) {
    header.parentNode.insertBefore(banner, header.nextSibling);
  } else {
    content.insertBefore(banner, content.firstChild);
  }
}

/* ── Explainability Context Injector ── */
function setupExplainability() {
  var page = location.pathname.split('/').pop() || 'index.html';
  var content = document.getElementById('content');
  if (!content) return;

  var explainText = "";
  var inputSource = "";
  var agentCreator = "";
  var nextStep = "";

  if (page === 'requirements.html') {
    explainText = "This requirements log was extracted from unstructured input files to build formal business mappings.";
    inputSource = "Client Onboarding Document (PDF) + MOM Transcripts";
    agentCreator = "Review Agent (Validator Agent)";
    nextStep = "Proceed to human review under Approvals or view Requirement Mapping.";
  } else if (page === 'architecture.html') {
    explainText = "This system architecture schematic was automatically synthesized to represent functional models.";
    inputSource = "Business Requirements Document (BRD) + SSO Integration specs";
    agentCreator = "Solutions Architect Agent";
    nextStep = "Review diagram structures and verify external integrations.";
  } else if (page === 'testcases.html') {
    explainText = "These test cases were auto-generated to guarantee complete functional coverage of requirements.";
    inputSource = "Business Requirements Mapping (RTM) + SSO logic";
    agentCreator = "QA Automation Agent";
    nextStep = "Export test cases to Jira/Xray or execute verify pass rate.";
  } else if (page === 'diagrams.html') {
    explainText = "Visual system flow diagram showing communication interfaces between authentication servers.";
    inputSource = "Architecture Studio specifications";
    agentCreator = "Architect Graph Agent";
    nextStep = "Link diagram components to physical deployment items.";
  } else if (page === 'tokenops.html') {
    explainText = "Token consumption tracking dashboard analyzing cost-efficiency across multiple LLM endpoints.";
    inputSource = "System operational telemetry and API usage logs";
    agentCreator = "Cost & Performance Monitoring Agent";
    nextStep = "Configure billing alert thresholds or limit prompt rates.";
  } else {
    return;
  }

  var card = document.createElement('div');
  card.className = 'ai-explainability-card';
  card.innerHTML = 
    '<div class="ai-explainability-title">' +
      '<span>🤖 AI Deliverable Explainability Insights</span>' +
    '</div>' +
    '<div class="ai-explainability-grid">' +
      '<div class="ai-explainability-item">' +
        '<span class="ai-explainability-label">Why was it generated?</span>' +
        '<span class="ai-explainability-value">' + explainText + '</span>' +
      '</div>' +
      '<div class="ai-explainability-item">' +
        '<span class="ai-explainability-label">Input Source used</span>' +
        '<span class="ai-explainability-value">📄 ' + inputSource + '</span>' +
      '</div>' +
      '<div class="ai-explainability-item">' +
        '<span class="ai-explainability-label">Generating AI Agent</span>' +
        '<span class="ai-explainability-value">Review Agent</span>' +
      '</div>' +
      '<div class="ai-explainability-item">' +
        '<span class="ai-explainability-label">What should the user do next?</span>' +
        '<span class="ai-explainability-value">➡️ ' + nextStep + '</span>' +
      '</div>' +
    '</div>';

  var header = content.querySelector('.section-header');
  if (header) {
    header.parentNode.insertBefore(card, header.nextSibling);
  } else {
    content.insertBefore(card, content.firstChild);
  }
}

/* ── Global AI Command Bar ── */
function setupGlobalCommandBar() {
  var topbar = document.getElementById('topbar');
  if (!topbar) return;

  // Replace page-title with the global AI command bar
  var pageTitle = topbar.querySelector('.page-title');
  if (pageTitle) {
    var barWrap = document.createElement('div');
    barWrap.className = 'global-command-bar-wrap';
    barWrap.innerHTML = 
      '<span class="global-command-search-icon">🔍</span>' +
      '<input type="text" class="global-command-bar" id="orion-command-bar" placeholder="Ask Orion or type commands (e.g. \'show architecture\', \'show test cases\')..." />';
    
    topbar.replaceChild(barWrap, pageTitle);

    var input = document.getElementById('orion-command-bar');
    input.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') {
        var val = this.value.trim();
        if (val) {
          handleOrionInput(val);
          this.value = '';
        }
      }
    });
  }
}

/* ── Orion Right Sidebar Copilot Injection ── */
/* ── Orion Right Sidebar Copilot Injection ── */
function renderAiSidebar() {
  if (document.getElementById('ai-assistant-sidebar')) return;

  var sidebar = document.createElement('div');
  sidebar.id = 'ai-assistant-sidebar';
  sidebar.innerHTML = 
    '<div class="ai-sidebar-header">' +
      '<div class="ai-sidebar-title">✨ Orion Copilot</div>' +
      '<div style="display:flex; align-items:center; gap:12px;">' +
        '<div class="ai-status-indicator">Active</div>' +
        '<span style="cursor:pointer; font-size:16px; font-weight:bold; color:var(--muted)" onclick="toggleCopilot()">✕</span>' +
      '</div>' +
    '</div>' +
    '<div class="ai-sidebar-context">' +
      '<div class="ai-context-title">Active SDLC State</div>' +
      '<div class="ai-context-item">Active Runs: <strong>3 Projects</strong></div>' +
      '<div class="ai-context-item">Approvals Pending: <strong>2 Gateways</strong></div>' +
      '<div class="ai-context-item">Review Queue: <strong>1 Architecture</strong></div>' +
      '<div class="ai-context-item">Generated Assets: <strong>14 Artifacts</strong></div>' +
    '</div>' +
    '<div class="ai-chat-area" id="orion-chat-log">' +
      '<div class="chat-bubble assistant">' +
        '<strong>Good Morning.</strong><br/>' +
        'Here is your SDLC context:<br/>' +
        '• 3 Active Project Runs<br/>' +
        '• 2 Pending Reviews<br/>' +
        '• 1 Architecture awaiting sign-off<br/>' +
        '• 14 Deliverables generated.<br/><br/>' +
        '<strong>Recommended action:</strong> Review Payroll Modernization Requirement Mapping (RTM).' +
      '</div>' +
    '</div>' +
    '<div class="ai-suggestions-area">' +
      '<div class="suggestion-chip" onclick="handleOrionInput(\'Show status\')">📊 Status</div>' +
      '<div class="suggestion-chip" onclick="handleOrionInput(\'Show pending approvals\')">✓ Approvals</div>' +
      '<div class="suggestion-chip" onclick="handleOrionInput(\'Show architecture\')">🏗️ Architecture</div>' +
      '<div class="suggestion-chip" onclick="handleOrionInput(\'Show test cases\')">🧪 Test Cases</div>' +
      '<div class="suggestion-chip" onclick="handleOrionInput(\'What should I do next?\')">➡️ Next Action</div>' +
    '</div>' +
    '<div class="ai-input-area">' +
      '<input type="text" class="ai-chat-input" id="orion-chat-input" placeholder="Type command/question..." />' +
      '<button class="btn btn-primary btn-sm" onclick="sendOrionChat()">Send</button>' +
    '</div>';

  document.body.appendChild(sidebar);

  var input = document.getElementById('orion-chat-input');
  input.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
      sendOrionChat();
    }
  });

  // Inject toggle button into topbar
  var topbar = document.getElementById('topbar');
  if (topbar) {
    var actions = topbar.querySelector('.topbar-actions');
    if (actions && !document.getElementById('topbar-toggle-copilot')) {
      var toggle = document.createElement('button');
      toggle.id = 'topbar-toggle-copilot';
      toggle.className = 'btn btn-ghost btn-sm';
      toggle.style.gap = '4px';
      toggle.innerHTML = '✨ Orion';
      toggle.onclick = toggleCopilot;
      actions.insertBefore(toggle, actions.firstChild);
    }
  }

  // Set initial collapsed/expanded state from localStorage
  applyCopilotState();
}

/* ── Copilot Collapse/Expand Logic ── */
function toggleCopilot() {
  var sidebar = document.getElementById('ai-assistant-sidebar');
  var main = document.getElementById('main');
  if (!sidebar || !main) return;

  var isClosed = sidebar.classList.contains('closed');
  if (isClosed) {
    sidebar.classList.remove('closed');
    main.classList.remove('copilot-closed');
    localStorage.setItem('copilotState', 'open');
    toast("Orion Copilot expanded", "info");
  } else {
    sidebar.classList.add('closed');
    main.classList.add('copilot-closed');
    localStorage.setItem('copilotState', 'closed');
    toast("Orion Copilot collapsed", "info");
  }
}

function applyCopilotState() {
  var state = localStorage.getItem('copilotState') || 'open';
  var sidebar = document.getElementById('ai-assistant-sidebar');
  var main = document.getElementById('main');
  if (!sidebar || !main) return;

  if (state === 'closed') {
    sidebar.classList.add('closed');
    main.classList.add('copilot-closed');
  } else {
    sidebar.classList.remove('closed');
    main.classList.remove('copilot-closed');
  }
}

function sendOrionChat() {
  var input = document.getElementById('orion-chat-input');
  if (!input) return;
  var val = input.value.trim();
  if (val) {
    handleOrionInput(val);
    input.value = '';
  }
}

/* ── Orion Conversational Logic Parser ── */
function handleOrionInput(text) {
  var chatLog = document.getElementById('orion-chat-log');
  if (!chatLog) return;

  // 1. Post user message
  var userMsg = document.createElement('div');
  userMsg.className = 'chat-bubble user';
  userMsg.innerText = text;
  chatLog.appendChild(userMsg);
  chatLog.scrollTop = chatLog.scrollHeight;

  // 2. Parse command to navigate or reply
  var cmd = text.toLowerCase();
  var reply = "";
  var redirectUrl = "";

  if (cmd.indexOf('architecture') !== -1 || cmd.indexOf('diagram') !== -1) {
    reply = "Orion: Navigating to the Architecture Studio and Diagram Viewer...";
    redirectUrl = "./architecture.html";
  } else if (cmd.indexOf('requirement') !== -1 || cmd.indexOf('brd') !== -1) {
    reply = "Orion: Navigating to the Requirements Explorer & Business Mapping...";
    redirectUrl = "./requirements.html";
  } else if (cmd.indexOf('mapping') !== -1 || cmd.indexOf('rtm') !== -1) {
    reply = "Orion: Navigating to the Requirement Mapping Dashboard (RTM)...";
    redirectUrl = "./rtm.html";
  } else if (cmd.indexOf('test') !== -1 || cmd.indexOf('tc-') !== -1) {
    reply = "Orion: Navigating to the Test Case Generation Dashboard...";
    redirectUrl = "./testcases.html";
  } else if (cmd.indexOf('pipeline') !== -1 || cmd.indexOf('run') !== -1) {
    reply = "Orion: Directing you to the Pipeline View and active run execution metrics...";
    redirectUrl = "./pipeline.html";
  } else if (cmd.indexOf('approval') !== -1 || cmd.indexOf('gate') !== -1 || cmd.indexOf('review') !== -1) {
    reply = "Orion: Opening Human Review Checkpoints and Pending Gates...";
    redirectUrl = "./checkpoints.html";
  } else if (cmd.indexOf('risk') !== -1 || cmd.indexOf('wrong') !== -1) {
    reply = "Orion: Loading the Risk Monitoring dashboard...";
    redirectUrl = "./risks.html";
  } else if (cmd.indexOf('status') !== -1) {
    reply = "<strong>Active status report:</strong><br/>" +
            "• #RUN-0042 (Acme Corp): In progress at <strong>Requirements</strong> (68%)<br/>" +
            "• #RUN-0041 (NovaBanc): Awaiting review at <strong>Requirement Mapping</strong><br/>" +
            "• #RUN-0040 (TerraLogic): Awaiting final <strong>Sign-Off</strong>.";
  } else if (cmd.indexOf('next') !== -1 || cmd.indexOf('todo') !== -1) {
    reply = "Orion: Your next recommended action is to sign off on the <strong>Acme Corp Payroll BRD</strong>. " +
            "Would you like me to open the review gates now?";
  } else if (cmd.indexOf('why') !== -1 || cmd.indexOf('explain') !== -1) {
    reply = "Orion: Deliverables are generated based on uploaded templates and context files via LLM. " +
            "You can review the specific model confidence and prompt cost logs in the governance center.";
  } else {
    reply = "Orion: I understand. Let me help you with that. Opening the Command Center for approvals and overview...";
    redirectUrl = "./command-center.html";
  }

  // 3. Post assistant reply
  setTimeout(function() {
    var astMsg = document.createElement('div');
    astMsg.className = 'chat-bubble assistant';
    astMsg.innerHTML = reply;
    chatLog.appendChild(astMsg);
    chatLog.scrollTop = chatLog.scrollHeight;
    toast("Orion processed: " + text, "info");

    // 4. Redirect if URL matched
    if (redirectUrl) {
      setTimeout(function() {
        window.location.href = redirectUrl;
      }, 1000);
    }
  }, 500);
}

/* Initialize All Redesign Systems */
(function() {
  renderSidebar();
  renderAiSidebar();
  setupGlobalCommandBar();
  setupRoleSelector();
  setupQuestionBanners();
  setupExplainability();
})();
