"""Fabric workflow entry point for the LoanProduct mapping."""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from fabric_runtime import require_conversion_ready


def run_workflow():
    require_conversion_ready(Path(__file__).with_name("m_intg_loanproduct__sym_loan.py"))
    from m_intg_loanproduct__sym_loan import main
    return main() == 0


if __name__ == "__main__":
    raise SystemExit(0 if run_workflow() else 1)
