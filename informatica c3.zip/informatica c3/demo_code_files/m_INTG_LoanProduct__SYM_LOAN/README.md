# Fabric status

See [Fabric deployment status](../FABRIC_README.md) before running this
mapping. The generated mapplet lineage and SQL update branches still
require correction and an end-to-end database test.

# m_INTG_LoanProduct__SYM_LOAN - PySpark Conversion

This code was auto-generated from Informatica PowerCenter XML by the Informatica to PySpark Converter.

## 1. Environment Variables Setup

### PowerShell
```powershell
# Required environment variables for the configured database connections
$env:JDBC_DRIVER_PATHS='C:/Drivers/*'
# Azure SQL connection placeholders from the generated config
$env:AZURE_SQL_HOST='yourserver.database.windows.net'
$env:AZURE_SQL_TARGET_DATABASE='your_target_database'
$env:AZURE_SQL_USER='your_sql_user'
$env:AZURE_SQL_PASSWORD='your_password'
$env:MSSQL_DRIVER_JAR='C:/Drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
$env:SRC_SYSTEM_NM='SSC'
$env:ENV_NAME='development'
$env:LOG_LEVEL='INFO'
```

### Bash/Linux
```bash
# Required environment variables for the configured database connections
export JDBC_DRIVER_PATHS='/opt/drivers/*'
# Azure SQL connection placeholders from the generated config
export AZURE_SQL_HOST='yourserver.database.windows.net'
export AZURE_SQL_TARGET_DATABASE='your_target_database'
export AZURE_SQL_USER='your_sql_user'
export AZURE_SQL_PASSWORD='your_password'
export MSSQL_DRIVER_JAR='/opt/drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
export SRC_SYSTEM_NM='SSC'
export ENV_NAME='development'
export LOG_LEVEL='INFO'
```

Set any database name environment variables used by the generated config, then verify target database and access with the client.
## 2. Target Table Schema

### Target: ETL_Exception (Database: configured target connection)

```sql
-- MSSQL CREATE TABLE syntax
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ETL_Exception]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[ETL_Exception] (
        [ETL_Exception_ID] INT NOT NULL,
        [ETL_FolderName] NVARCHAR(255) NOT NULL,
        [ETL_WorkflowName] NVARCHAR(255) NOT NULL,
        [ETL_SessionName] NVARCHAR(255) NOT NULL,
        [ETL_JobSeqID] BIGINT NULL,
        [ETL_InsertDT] DATETIME2 NULL,
        [ETL_UpdateDT] DATETIME2 NULL,
        [SourceSystemName] NVARCHAR(255) NULL,
        [SourceObjectName] NVARCHAR(255) NULL,
        [TargetTableName] NVARCHAR(255) NULL,
        [TargetColumnName] NVARCHAR(255) NULL,
        [Target_NaturalKeyText] NVARCHAR(500) NULL,
        [ETL_EffectiveDT] DATETIME2 NULL,
        [ExceptionTypeCode] NVARCHAR(50) NOT NULL,
        [ExceptionSeverityLevel] SMALLINT NOT NULL,
        [ETL_ActionTakenCode] NVARCHAR(50) NULL,
        [SourceExceptionValue] NVARCHAR(255) NULL,
        [SupportingDetailText] NVARCHAR(2000) NULL,
        [ResolutionStatusCode] NVARCHAR(50) NULL,
        [ResolutionComments] NVARCHAR(2000) NULL
    )
END
```

### Target: INTG_LoanProduct (Database: configured target connection)

```sql
-- MSSQL CREATE TABLE syntax
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[INTG_LoanProduct]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[INTG_LoanProduct] (
        [LoanProduct_ID] BIGINT NOT NULL,
        [ETL_NaturalKeyText] NVARCHAR(500) NOT NULL,
        [ETL_RecordBeginDT] DATETIME2 NOT NULL,
        [ETL_RecordEndDT] DATETIME2 NOT NULL,
        [ETL_CurrentRecordFlag] NCHAR(1) NOT NULL,
        [ETL_Insert_JobSeqID] BIGINT NOT NULL,
        [ETL_LatestUpdate_JobSeqID] BIGINT NOT NULL,
        [ETL_InsertDT] DATETIME2 NOT NULL,
        [ETL_LatestUpdateDT] DATETIME2 NOT NULL,
        [ETL_DeleteDT] DATETIME2 NULL,
        [ETL_ChangeControlChecksum] NVARCHAR(32) NOT NULL,
        [LoanProduct_DurableID] BIGINT NOT NULL,
        [Account_ID] BIGINT NOT NULL,
        [Account_DurableID] BIGINT NULL,
        [Sym_LoanProdIdentifierText] NVARCHAR(20) NOT NULL,
        [LoanProdCatalog_ID] BIGINT NOT NULL,
        [LoanProdNoteNbr] NVARCHAR(10) NOT NULL,
        [LoanProdOrigLoanDate] DATETIME2 NULL,
        [LoanProdOpenDate] DATETIME2 NULL,
        [LoanProdChargeOffDate] DATETIME2 NULL,
        [LoanProdClosedDate] DATETIME2 NULL,
        [LoanProdReferenceText] NVARCHAR(20) NOT NULL,
        [LoanProdCollateralDate] DATETIME2 NULL,
        [LoanProdApprover_UserID] BIGINT NOT NULL,
        [LoanProdApprovalDate] DATETIME2 NULL,
        [LoanProdPurpose_CodeID] BIGINT NOT NULL,
        [LoanProdECOA_CodeID] BIGINT NOT NULL,
        [LoanProdCreditReporting_CodeID] BIGINT NOT NULL,
        [LoanProdPaymentType_CodeID] BIGINT NOT NULL,
        [LoanProdPaymentFrequency_CodeID] BIGINT NOT NULL,
        [LoanProdPaymentCount] SMALLINT NOT NULL,
        [LoanProdDueDay1] SMALLINT NOT NULL,
        [LoanProdDueDay2] SMALLINT NOT NULL,
        [LoanProdBalloonDate] DATETIME2 NULL,
        [LoanProdInterestRate] INT NOT NULL,
        [LoanProdSplitRate] INT NOT NULL,
        [LoanProdLateChargeType_CodeID] BIGINT NOT NULL,
        [LoanProdOrigBalanceAmount] MONEY NOT NULL,
        [LoanProdCreditLimitAmount] MONEY NOT NULL,
        [LoanProdSecuredAmount] MONEY NOT NULL,
        [LoanProdInsuranceType_CodeID] BIGINT NOT NULL,
        [LoanProdAvailCreditCalc_CodeID] BIGINT NOT NULL,
        [LoanProdCreditLimitExpirationDate] DATETIME2 NULL,
        [LoanProdInterestRateIndex_CodeID] BIGINT NOT NULL,
        [LoanProdInterestRateMargin] INT NOT NULL,
        [LoanProdMaxInterestRate] INT NOT NULL,
        [LoanProdMinInterestRate] INT NOT NULL,
        [LoanProdCreditReportNbr] NVARCHAR(20) NOT NULL,
        [LoanProdEffectiveAPR_Rate] INT NOT NULL,
        [LoanProdOrigRate] INT NOT NULL,
        [LoanProdMaturityDate] DATETIME2 NULL,
        [LoanProdEscrowAmount] MONEY NOT NULL,
        [LoanProdEscrowID] NVARCHAR(10) NOT NULL,
        [LoanProdOrigUnamortFeeAmount] MONEY NOT NULL,
        [LoanProdMinAdvanceAmount] MONEY NOT NULL,
        [LoanProdOwningBranch_ID] BIGINT NOT NULL,
        [LoanProdFASB_91_CodeID] BIGINT NOT NULL,
        [LoanProdAPR_Rate] INT NOT NULL,
        [LoanProdPrepaidFinanceChargeAmount] MONEY NOT NULL,
        [LoanProdCreditLimitGroup_CodeID] BIGINT NOT NULL,
        [LoanProdPromoType_CodeID] BIGINT NOT NULL,
        [LoanProdVariablePromoRateFlag] NCHAR(1) NOT NULL,
        [LoanProdPromoRate] INT NOT NULL,
        [LoanProdApplicationID] NCHAR(4) NOT NULL,
        [LoanProdDealerStateCodeText] NCHAR(2) NOT NULL,
        [LoanProdDealerCityText] NVARCHAR(50) NOT NULL,
        [LoanProdDealerReserveAmount] MONEY NOT NULL,
        [LoanProdDealerCodeText] NVARCHAR(10) NULL,
        [LoanProdFirstPaymentDate] DATETIME2 NULL,
        [LoanProdVIN_Nbr] NVARCHAR(20) NOT NULL,
        [LoanProdCenterOneRecall_CodeID] BIGINT NOT NULL,
        [LoanProdOrigInsuranceType_CodeID] BIGINT NOT NULL,
        [LoanProdOrigCollateralValueAmount] MONEY NOT NULL,
        [LoanProdDQ_NoticeType_CodeID] BIGINT NOT NULL,
        [LoanProdCreatedByUser_ID] BIGINT NOT NULL,
        [LoanProdCreatedAtBranch_ID] BIGINT NOT NULL,
        [LoanProdMFOEL_CodeID] BIGINT NOT NULL,
        [LoanProdMaxDueDateAdvPeriodCount] SMALLINT NOT NULL,
        [LoanProdInitBegCycleDateOption_CodeID] BIGINT NOT NULL,
        [LoanProdBegCycleDateDay_1_Nbr] SMALLINT NOT NULL,
        [LoanProdBegCycleDateDay_2_Nbr] SMALLINT NOT NULL,
        [LoanProdINMLA_Flag] NCHAR(1) NOT NULL,
        [LoanProdINMLA_UserID] BIGINT NOT NULL,
        [LoanProdInvestorType] NVARCHAR(10) NULL,
        [LoanProdRealEstateOwnedFlag] NCHAR(1) NULL,
        [LoanProdExternalStatus_CodeID] BIGINT NOT NULL,
        [LoanProdCategory_CodeID] BIGINT NOT NULL,
        [LoanProdInvestorGroupCodeText] NVARCHAR(3) NULL,
        [LoanName] NVARCHAR(50) NULL,
        [LoanProdAmortizationTermCount] SMALLINT NULL,
        [MICRAccountNbr] NVARCHAR(20) NULL,
        [PrevAutoLeaseLoanNbr] NVARCHAR(20) NULL,
        [LoanProdInterestOnlyTermCount] SMALLINT NULL,
        [LoanProdInterestOnlyEndDate] DATETIME2 NULL,
        [LoanProdServicerLoanRating] NVARCHAR(20) NULL,
        [LoanProdNAICSCode] INT NULL,
        [LoanProdOwningPercent] DECIMAL(20,15) NOT NULL,
        [LoanProdServicerApplicationIdentifierText] NVARCHAR(20) NULL,
        [LoanProdServicerAccountNumberText] NVARCHAR(20) NULL,
        [LoanProdServicerFeeAmount] MONEY NOT NULL,
        [LoanProdServicerSignUpFeeAmount] MONEY NOT NULL,
        [LoanProdServicerTotalFeeAmount] MONEY NOT NULL,
        [LoanProdPaidInFullDate] DATETIME2 NULL,
        [LeaseContractedMilesPerYearNbr] INT NULL,
        [LeaseResidualValueAmount] MONEY NOT NULL,
        [LeaseResidualHoldbackAmount] MONEY NOT NULL,
        [LeaseFirstPaymentAmount] MONEY NOT NULL,
        [LeaseFirstTaxPaymentAmount] MONEY NOT NULL,
        [LeaseSettlementDate] DATETIME2 NULL,
        [LeaseTurnInDate] DATETIME2 NULL,
        [LeaseLossDate] DATETIME2 NULL,
        [LoanAppLoanToValueRate] DECIMAL(8,5) NULL,
        [LoanProdCreditFrozenFlag] NCHAR(1) NULL,
        [LoanProdModStartDate] DATETIME2 NULL,
        [LoanProdModEndDate] DATETIME2 NULL,
        [LoanProdModDescriptionText] NVARCHAR(50) NULL,
        [LoanProdModTermCount] SMALLINT NULL,
        [LoanProdModInterestRate] INT NULL,
        [PrivateMortgageInsuranceBorrowerIdentificationNbr] NVARCHAR(40) NULL,
        [PrivateMortgageInsuranceCompanyPaymentDescription] NVARCHAR(50) NULL,
        [PrivateMortgageInsuranceCompany_CodeID] BIGINT NOT NULL,
        [PrivateMortgageInsuranceCompanyName] NVARCHAR(20) NULL,
        [FeeBillingDate] DATETIME2 NULL
    )
END
```

### Target: ETL_AuditBalanceControl (Database: configured target connection)

```sql
-- MSSQL CREATE TABLE syntax
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ETL_AuditBalanceControl]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[ETL_AuditBalanceControl] (
        [ETL_AuditBalanceControlID] INT NOT NULL,
        [ETL_FolderName] NVARCHAR(255) NOT NULL,
        [ETL_WorkflowName] NVARCHAR(255) NOT NULL,
        [ETL_SessionName] NVARCHAR(255) NOT NULL,
        [ETL_JobSeqID] BIGINT NULL,
        [ETL_WorkflowRunID] NVARCHAR(255) NULL,
        [ETL_RunStatusCode] NVARCHAR(50) NULL,
        [ETL_ChangeControlDT] DATETIME2 NULL,
        [ETL_ChangeControlNbr] BIGINT NULL,
        [ETL_ChangeControlRecordLimit] BIGINT NULL,
        [ETL_LastSuccess_ChangeControlDT] DATETIME2 NULL,
        [ETL_LastSuccess_ChangeControlNbr] BIGINT NULL,
        [ETL_SessionBeginDT] DATETIME2 NULL,
        [ETL_SessionEndDT] DATETIME2 NULL,
        [ETL_SourceRowCount] INT NULL,
        [ETL_TargetInsertRowCount] INT NULL,
        [ETL_TargetInsertVersionRowCount] INT NULL,
        [ETL_TargetUpdateRowCount] INT NULL,
        [ETL_TargetDeleteRowCount] INT NULL,
        [ETL_SessionExceptionCount] INT NULL,
        [ETL_MinRecordBeginDT] DATETIME2 NULL,
        [ETL_MaxRecordBeginDT] DATETIME2 NULL
    )
END
```

## 3. What is $$SRC_SYSTEM_NM?

`$$SRC_SYSTEM_NM` is an Informatica runtime parameter used in mapping/workflow sessions.

**How to find the value:**
1. Open Workflow Manager
2. Open the workflow
3. In the Session task -> Properties / Config Object, check the Parameter File path
4. Open that `.par` file and search for `SRC_SYSTEM_NM`

In this config, the default is set to `SSC`. Override via environment variable if needed:
```powershell
$env:SRC_SYSTEM_NM='YOUR_VALUE'
```

## 4. How to Run

### Quick Run (config in same folder)
```bash
python m_intg_loanproduct__sym_loan.py
```

### With custom config path
```powershell
$env:CONFIG_PATH='C:\path\to\config_m_intg_loanproduct__sym_loan.yml'
python m_intg_loanproduct__sym_loan.py
```

## 5. Files Generated

- `m_intg_loanproduct__sym_loan.py` - Main PySpark mapping code
- `config_m_intg_loanproduct__sym_loan.yml` - Configuration file with environment variables
- `README.md` - This documentation file

## 6. Notes

- Passwords with special characters (like `$`, `@`, `*`) must use single quotes in PowerShell
- The `SRC_ROWID` column is typically set as IDENTITY in MSSQL if not mapped from source
- Confirm each target database and table with the client before execution
- Review and test the generated code before production use
