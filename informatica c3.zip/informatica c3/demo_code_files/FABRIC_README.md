# Microsoft Fabric / SQL Server deployment status

These three directories contain converted PySpark mappings. Once the
conversion blockers below are resolved, run each `workflow.py` as the
entry point in a Fabric Spark environment, with its
mapping file, YAML config, `fabric_target_mappings.json`,
`conversion_status.json`, and the sibling `fabric_runtime.py` available
on the Python path. Fabric provides Spark and the Microsoft SQL connector;
no Windows authentication DLL or hard-coded local JDBC JAR is configured.

## SQL settings

Set these in the Fabric job environment or a secret-backed notebook cell
before importing a mapping:

- `MSSQL_HOST`, `MSSQL_USER`, `MSSQL_PASSWORD` (required)
- `MSSQL_PORT` (default `1433`)
- `MSSQL_DB_DIDW02`, `MSSQL_DB_EDW02`, `MSSQL_DB_MANAGEMENT`
  (default to the original Informatica database names)
- `MSSQL_DB_ACQUISITION`, `MSSQL_DB_STAGING` for the SYM databases
- `PM_FOLDER_NAME`, `PM_WORKFLOW_NAME`, `PM_SESSION_NAME` for the
  Informatica audit and change-control filters
- `MSSQL_DB_SUFFIX` if the Informatica temporary table names carry an
  environment suffix
- `MSSQL_ENCRYPT` (default `true`) and
  `MSSQL_TRUST_SERVER_CERTIFICATE` (default `false`)
- `MSSQL_WRITE_PARTITIONS` (default `8`) and
  `MSSQL_BATCH_SIZE` (default `5000`)
- `MSSQL_WRITE_FORMAT` (default `jdbc`). After the mapping is validated
  on Fabric, set to `com.microsoft.sqlserver.jdbc.spark` to use Fabric's
  preinstalled bulk SQL connector. This path uses `NO_DUPLICATES` on
  executor retry.

The Fabric Spark runtime must be able to reach the SQL Server host on the
configured port. The SQL login needs read access to the source objects and
write access to the target objects. Store credentials in Fabric secrets or
a managed connection, then inject them into the job environment; do not
commit passwords to YAML.

Run `fabric_sql_smoke_test.py` in Fabric first. It runs only
`SELECT 1` against each configured database and prints the database names
that connected successfully.

## Conversion readiness

The generated mapping bodies are **not yet safe to run as production ETL**.
Each `workflow.py` checks `conversion_status.json` and fails before
importing PySpark or writing SQL while the mapping is incomplete. Direct
mapping execution runs the same check in `main()`.

The supplied XML contains the shared audit mapplets; their audit input has
been wired. The generated LoanProduct exception branch still refers to
undefined `df_input`, because its upstream Informatica Normalizer was not
converted. All three action-code mapplets have stateful local-variable
rules that the converter omitted. The SYM staging-control mapplet also has
untranslated parameters and expressions. See each mapping's
`conversion_status.json` for its blocking rules.

The mappings also create a synthetic `jkey` by coalescing source tables
to one partition. This both limits throughput and can produce invalid
row alignment when tables have different ordering. Replace such joins
with the actual Informatica key relationships, then test against sample
source and expected target rows.

The target column links now come from the XML connectors, and update-target
branches use key-based SQL merges. These operations still need validation
against the actual target table schemas and expected rows.

The local workspace has no PySpark, SQL connection, or Fabric runtime.
Python syntax and fail-closed workflow checks were run locally; no
end-to-end database run was possible.
Do not treat the generated report's `coverage_percent: 100` as a
successful execution test.

Microsoft Fabric SQL connector guidance:
https://learn.microsoft.com/en-us/fabric/data-engineering/spark-sql-connector
