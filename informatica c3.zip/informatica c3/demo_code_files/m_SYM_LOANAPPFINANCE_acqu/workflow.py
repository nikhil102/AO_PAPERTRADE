"""Fabric workflow entry point for the LoanAppFinance mapping."""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from fabric_runtime import require_conversion_ready


def run_workflow():
    require_conversion_ready(Path(__file__).with_name("m_sym_loanappfinance_acqu.py"))
    from m_sym_loanappfinance_acqu import main
    return main() == 0


if __name__ == "__main__":
    raise SystemExit(0 if run_workflow() else 1)
