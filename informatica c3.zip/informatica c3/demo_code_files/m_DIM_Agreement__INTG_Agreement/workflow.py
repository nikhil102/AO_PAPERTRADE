"""Fabric workflow entry point for the Agreement mapping."""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from fabric_runtime import require_conversion_ready


def run_workflow():
    require_conversion_ready(Path(__file__).with_name("m_dim_agreement__intg_agreement.py"))
    from m_dim_agreement__intg_agreement import main
    return main() == 0


if __name__ == "__main__":
    raise SystemExit(0 if run_workflow() else 1)
