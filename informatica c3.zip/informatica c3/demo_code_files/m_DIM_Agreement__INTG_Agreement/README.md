# Fabric status

See [Fabric deployment status](../FABRIC_README.md) before running this
mapping. The generated mapplet lineage and SQL update branches still
require correction and an end-to-end database test.

# m_DIM_Agreement__INTG_Agreement - PySpark Conversion

This code was auto-generated from Informatica PowerCenter XML by the Informatica to PySpark Converter.

## 1. Environment Variables Setup

### PowerShell
```powershell
# Required environment variables for the configured database connections
$env:JDBC_DRIVER_PATHS='C:/Drivers/*'
# Azure SQL connection placeholders from the generated config
$env:AZURE_SQL_HOST='yourserver.database.windows.net'
$env:AZURE_SQL_TARGET_DATABASE='your_target_database'
$env:AZURE_SQL_USER='your_sql_user'
$env:AZURE_SQL_PASSWORD='your_password'
$env:MSSQL_DRIVER_JAR='C:/Drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
$env:SRC_SYSTEM_NM='SSC'
$env:ENV_NAME='development'
$env:LOG_LEVEL='INFO'
```

### Bash/Linux
```bash
# Required environment variables for the configured database connections
export JDBC_DRIVER_PATHS='/opt/drivers/*'
# Azure SQL connection placeholders from the generated config
export AZURE_SQL_HOST='yourserver.database.windows.net'
export AZURE_SQL_TARGET_DATABASE='your_target_database'
export AZURE_SQL_USER='your_sql_user'
export AZURE_SQL_PASSWORD='your_password'
export MSSQL_DRIVER_JAR='/opt/drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
export SRC_SYSTEM_NM='SSC'
export ENV_NAME='development'
export LOG_LEVEL='INFO'
```

Set any database name environment variables used by the generated config, then verify target database and access with the client.
## 2. Target Table Schema

### Target: ETL_AuditBalanceControl (Database: configured target connection)

```sql
-- MSSQL CREATE TABLE syntax
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ETL_AuditBalanceControl]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[ETL_AuditBalanceControl] (
        [ETL_AuditBalanceControlID] INT NOT NULL,
        [ETL_FolderName] NVARCHAR(255) NOT NULL,
        [ETL_WorkflowName] NVARCHAR(255) NOT NULL,
        [ETL_SessionName] NVARCHAR(255) NOT NULL,
        [ETL_JobSeqID] BIGINT NULL,
        [ETL_WorkflowRunID] NVARCHAR(255) NULL,
        [ETL_RunStatusCode] NVARCHAR(50) NULL,
        [ETL_ChangeControlDT] DATETIME2 NULL,
        [ETL_ChangeControlNbr] BIGINT NULL,
        [ETL_ChangeControlRecordLimit] BIGINT NULL,
        [ETL_LastSuccess_ChangeControlDT] DATETIME2 NULL,
        [ETL_LastSuccess_ChangeControlNbr] BIGINT NULL,
        [ETL_SessionBeginDT] DATETIME2 NULL,
        [ETL_SessionEndDT] DATETIME2 NULL,
        [ETL_SourceRowCount] INT NULL,
        [ETL_TargetInsertRowCount] INT NULL,
        [ETL_TargetInsertVersionRowCount] INT NULL,
        [ETL_TargetUpdateRowCount] INT NULL,
        [ETL_TargetDeleteRowCount] INT NULL,
        [ETL_SessionExceptionCount] INT NULL,
        [ETL_MinRecordBeginDT] DATETIME2 NULL,
        [ETL_MaxRecordBeginDT] DATETIME2 NULL
    )
END
```

### Target: DIM_Agreement (Database: configured target connection)

```sql
-- MSSQL CREATE TABLE syntax
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DIM_Agreement]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[DIM_Agreement] (
        [DIM_Agreement_ID] INT NOT NULL,
        [ETL_NaturalKeyText] NVARCHAR(500) NOT NULL,
        [ETL_RecordBeginDT] DATETIME2 NOT NULL,
        [ETL_RecordEndDT] DATETIME2 NOT NULL,
        [ETL_CurrentRecordFlag] NCHAR(1) NOT NULL,
        [ETL_Insert_JobSeqID] BIGINT NOT NULL,
        [ETL_LatestUpdate_JobSeqID] BIGINT NOT NULL,
        [ETL_InsertDT] DATETIME2 NOT NULL,
        [ETL_LatestUpdateDT] DATETIME2 NOT NULL,
        [ETL_DeleteDT] DATETIME2 NULL,
        [ETL_ChangeControlChecksum] NVARCHAR(32) NOT NULL,
        [ETL_CreatedBy] NVARCHAR(50) NOT NULL,
        [ETL_UpdatedBy] NVARCHAR(50) NOT NULL,
        [ETL_ActiveFlag] NCHAR(1) NOT NULL,
        [DIM_Agreement_DurableID] INT NOT NULL,
        [AgreementID_Text] NVARCHAR(10) NULL,
        [CertificateNumberText] NVARCHAR(20) NULL,
        [OpenDate] DATETIME2 NULL,
        [CloseDate] DATETIME2 NULL,
        [FeeCalcMethod_CodeValue] NVARCHAR(50) NULL,
        [FeeCalcMethod_CodeDesc] NVARCHAR(50) NULL,
        [FundingSeqNbr] SMALLINT NULL,
        [TargetOwnershipPercent] DECIMAL(6,3) NULL,
        [InterestRate] DECIMAL(6,3) NULL,
        [FixedFeePercent] DECIMAL(6,3) NULL,
        [FundingMaxAmount] MONEY NULL,
        [FundingDate] DATETIME2 NULL,
        [DistributeLateChargesFlag] NCHAR(1) NOT NULL,
        [ProrateatFundingFlag] NCHAR(1) NOT NULL,
        [OriginationFeePercent] DECIMAL(6,3) NULL,
        [OriginationFeeAmount] MONEY NULL,
        [OriginationFeePaidAmount] MONEY NULL,
        [DistributeLoanAdvancesFlag] NCHAR(1) NOT NULL,
        [DistributionRoundingMethod_CodeValue] NVARCHAR(50) NULL,
        [DistributionRoundingMethod_CodeDesc] NVARCHAR(50) NULL,
        [DIM_EffectiveBegin_DateID] DATETIME2 NULL,
        [DIM_EffectiveEnd_DateID] DATETIME2 NULL
    )
END
```

## 3. What is $$SRC_SYSTEM_NM?

`$$SRC_SYSTEM_NM` is an Informatica runtime parameter used in mapping/workflow sessions.

**How to find the value:**
1. Open Workflow Manager
2. Open the workflow
3. In the Session task -> Properties / Config Object, check the Parameter File path
4. Open that `.par` file and search for `SRC_SYSTEM_NM`

In this config, the default is set to `SSC`. Override via environment variable if needed:
```powershell
$env:SRC_SYSTEM_NM='YOUR_VALUE'
```

## 4. How to Run

### Quick Run (config in same folder)
```bash
python m_dim_agreement__intg_agreement.py
```

### With custom config path
```powershell
$env:CONFIG_PATH='C:\path\to\config_m_dim_agreement__intg_agreement.yml'
python m_dim_agreement__intg_agreement.py
```

## 5. Files Generated

- `m_dim_agreement__intg_agreement.py` - Main PySpark mapping code
- `config_m_dim_agreement__intg_agreement.yml` - Configuration file with environment variables
- `README.md` - This documentation file

## 6. Notes

- Passwords with special characters (like `$`, `@`, `*`) must use single quotes in PowerShell
- The `SRC_ROWID` column is typically set as IDENTITY in MSSQL if not mapped from source
- Confirm each target database and table with the client before execution
- Review and test the generated code before production use
