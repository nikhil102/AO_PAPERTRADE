"""Read-only Fabric to SQL Server connectivity check for the three databases."""

import os

from pyspark.sql import SparkSession


DATABASES = (
    "MSSQL_DB_DIDW02",
    "MSSQL_DB_EDW02",
    "MSSQL_DB_MANAGEMENT",
    "MSSQL_DB_ACQUISITION",
    "MSSQL_DB_STAGING",
)
DEFAULTS = (
    "EDW_DIDW02",
    "EDW_EDW02",
    "EDW_ETL_DW_Management",
    "EDW_SYM_DW_Acquisition",
    "EDW_SYM_DW_Staging",
)


def main():
    host = os.environ["MSSQL_HOST"]
    user = os.environ["MSSQL_USER"]
    password = os.environ["MSSQL_PASSWORD"]
    port = os.getenv("MSSQL_PORT", "1433")
    encrypt = os.getenv("MSSQL_ENCRYPT", "true")
    trust = os.getenv("MSSQL_TRUST_SERVER_CERTIFICATE", "false")
    spark = SparkSession.builder.appName("fabric-sql-smoke-test").getOrCreate()

    for variable, default in zip(DATABASES, DEFAULTS):
        database = os.getenv(variable, default)
        url = (
            f"jdbc:sqlserver://{host}:{port};databaseName={database};"
            f"encrypt={encrypt};trustServerCertificate={trust};loginTimeout=30"
        )
        rows = (
            spark.read.format("jdbc")
            .option("url", url)
            .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
            .option("user", user)
            .option("password", password)
            .option("query", "SELECT 1 AS connection_ok")
            .load()
            .collect()
        )
        assert len(rows) == 1 and rows[0][0] == 1
        print(f"Connected to {database}")


if __name__ == "__main__":
    main()
