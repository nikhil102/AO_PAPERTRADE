"""Shared runtime checks for the three Fabric PySpark mappings."""

import os
import re
import logging
import json
from pathlib import Path
from uuid import uuid4


_PLACEHOLDER = re.compile(r"\$\{[^}]+\}")


def require_conversion_ready(mapping_path):
    """Prevent partial generated mappings from writing to production SQL."""
    status_path = Path(mapping_path).with_name("conversion_status.json")
    status = json.loads(status_path.read_text(encoding="utf-8"))
    if not status.get("ready"):
        issues = "; ".join(status.get("blocking_issues", []))
        raise RuntimeError(f"Mapping conversion is not ready: {issues}")


def validate_connections(config):
    """Fail before starting a job if SQL connection details are incomplete."""
    connections = config.get("connections") or {}
    required = (
        "EDW_DIDW02",
        "EDW_EDW02",
        "EDW_ETL_DW_Management",
        "EDW_SYM_DW_Acquisition",
        "EDW_SYM_DW_Staging",
        "TARGET",
    )
    for alias in required:
        connection = connections.get(alias)
        if not connection:
            raise ValueError(f"Missing SQL connection: {alias}")
        for key in ("jdbc_url", "user", "password"):
            value = str(connection.get(key) or "")
            if not value or _PLACEHOLDER.search(value) or "${" in value:
                raise ValueError(f"Configure {alias}.{key} before running the workflow")
        if "sqlserver://:" in connection["jdbc_url"] or "sqlserver://;" in connection["jdbc_url"]:
            raise ValueError(f"Configure the host in {alias}.jdbc_url")


def configure_spark(spark):
    """Set only settings safe to change on an existing Fabric Spark session."""
    spark.conf.set("spark.sql.adaptive.enabled", "true")
    return spark


def resolve_sql_tokens(query, config):
    """Replace Informatica SQL placeholders with configured SQL Server values."""
    database_names = {
        "ETL_DW_Management": "EDW_ETL_DW_Management",
        "DIDW02": "EDW_DIDW02",
        "EDW02": "EDW_EDW02",
        "SYM_DW_Acquisition": "EDW_SYM_DW_Acquisition",
        "SYM_DW_Staging": "EDW_SYM_DW_Staging",
    }
    for prefix, alias in database_names.items():
        name = config["connections"][alias]["database"]
        if not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", name):
            raise ValueError(f"Invalid SQL database identifier for {alias}")
        query = query.replace(prefix + "$$DBSuffixDevOrQA", f"[{name}]")
    # Some Informatica temporary-table names carry the suffix as part of
    # the table identifier, rather than as part of a database identifier.
    suffix = os.getenv("MSSQL_DB_SUFFIX", "")
    if not re.fullmatch(r"[A-Za-z_0-9]*", suffix):
        raise ValueError("Invalid MSSQL_DB_SUFFIX")
    query = query.replace("$$DBSuffixDevOrQA", suffix)
    parameters = {
        "$PMFolderName": "PM_FOLDER_NAME",
        "$PMWorkflowName": "PM_WORKFLOW_NAME",
        "$PMSessionName": "PM_SESSION_NAME",
    }
    for token, variable in parameters.items():
        if token in query:
            value = os.getenv(variable)
            if not value:
                raise ValueError(f"Set {variable} for Informatica SQL filters")
            query = query.replace(token, value.replace("'", "''"))
    if re.search(r"\$\$[A-Za-z_]|\$PM[A-Za-z_]", query):
        raise ValueError("Unresolved Informatica SQL parameter")
    return query


def split_sql_server_cte(query):
    """Return prepareQuery/query pieces for a leading SQL Server CTE."""
    if not re.match(r"\s*WITH\b", query, re.IGNORECASE):
        return "", query
    depth = 0
    quote = False
    line_comment = False
    i = 0
    while i < len(query):
        char = query[i]
        if line_comment:
            if char == "\n":
                line_comment = False
            i += 1
            continue
        if not quote and query[i:i + 2] == "--":
            line_comment = True
            i += 2
            continue
        if char == "'":
            if quote and query[i:i + 2] == "''":
                i += 2
                continue
            quote = not quote
        elif not quote:
            if char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            elif depth == 0 and re.match(r"SELECT\b", query[i:], re.IGNORECASE):
                return query[:i].rstrip() + " ", query[i:]
        i += 1
    raise ValueError("Could not split SQL Server CTE for Spark JDBC")


def strip_top_level_order_by(query):
    """Spark DataFrames are unordered; remove SQL ordering illegal in a subquery."""
    depth = 0
    quote = False
    line_comment = False
    found = None
    i = 0
    while i < len(query):
        char = query[i]
        if line_comment:
            if char == "\n":
                line_comment = False
            i += 1
            continue
        if not quote and query[i:i + 2] == "--":
            line_comment = True
            i += 2
            continue
        if char == "'":
            if quote and query[i:i + 2] == "''":
                i += 2
                continue
            quote = not quote
        elif not quote:
            if char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            elif depth == 0 and re.match(r"ORDER\s+BY\b", query[i:], re.IGNORECASE):
                found = i
        i += 1
    return query[:found].rstrip() if found is not None else query


def _sql_identifier(identifier):
    parts = identifier.split(".")
    if not 1 <= len(parts) <= 2 or any(
        not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", part) for part in parts
    ):
        raise ValueError(f"Invalid SQL identifier: {identifier}")
    return ".".join(f"[{part}]" for part in parts)


def align_to_sql_table(df, connection, table):
    """Cast generated columns to the existing SQL Server target schema."""
    from pyspark.sql import functions as F

    qualified = table if "." in table else "dbo." + table
    target_schema = (
        df.sparkSession.read.format("jdbc")
        .option("url", connection["jdbc_url"])
        .option("driver", connection["driver"])
        .option("user", connection["user"])
        .option("password", connection["password"])
        .option("dbtable", qualified)
        .load()
        .schema
    )
    fields = {field.name.lower(): field for field in target_schema.fields}
    unexpected = [name for name in df.columns if name.lower() not in fields]
    if unexpected:
        raise ValueError(f"Columns absent from {table}: {unexpected}")
    return df.select(*[
        F.col(name).cast(fields[name.lower()].dataType).alias(fields[name.lower()].name)
        for name in df.columns
    ])


def project_target(df, field_pairs, target_instance):
    """Apply the exact source-port to target-column links from Informatica XML."""
    from pyspark.sql import functions as F

    columns = {column.lower(): column for column in df.columns}
    missing = [source for source, _ in field_pairs if source.lower() not in columns]
    if missing:
        raise ValueError(f"Missing ports for {target_instance}: {missing}")
    outputs = [target.lower() for _, target in field_pairs]
    if len(outputs) != len(set(outputs)):
        raise ValueError(f"Duplicate target columns for {target_instance}")
    return df.select(*[
        F.col(columns[source.lower()]).alias(target)
        for source, target in field_pairs
    ])


def audit_input(spark, connection):
    """One audit row for the configured Informatica session, including first runs."""
    from pyspark.sql import functions as F

    names = {
        "ETL_FolderName": os.getenv("PM_FOLDER_NAME"),
        "ETL_WorkflowName": os.getenv("PM_WORKFLOW_NAME"),
        "ETL_SessionName": os.getenv("PM_SESSION_NAME"),
    }
    missing = [name for name, value in names.items() if not value]
    if missing:
        raise ValueError("Set PM_FOLDER_NAME, PM_WORKFLOW_NAME and PM_SESSION_NAME")
    job = spark.range(1).select(*[
        F.lit(value).alias(name) for name, value in names.items()
    ])
    where = " AND ".join(
        f"[{name}] = '{value.replace(chr(39), chr(39) * 2)}'"
        for name, value in names.items()
    )
    existing = (
        spark.read.format("jdbc")
        .option("url", connection["jdbc_url"])
        .option("driver", connection["driver"])
        .option("user", connection["user"])
        .option("password", connection["password"])
        .option("query", f"SELECT * FROM dbo.ETL_AuditBalanceControl WHERE {where}")
        .load()
    )
    keys = list(names)
    return (job.join(existing, keys, "left")
        .withColumn("sessstarttime", F.current_timestamp()))


def expire_type2_versions(df, version_column, include_active=False):
    """Recreate the ordered Type 2 expiration mapplet with a Spark window."""
    from pyspark.sql import Window
    from pyspark.sql import functions as F

    columns = {column.lower(): column for column in df.columns}
    required = ("ETL_NaturalKeyText", "ETL_RecordBeginDT", "ETL_RecordEndDT")
    for name in required:
        if name.lower() not in columns:
            raise ValueError(f"Missing version expiration input: {name}")
    if version_column.lower() not in columns:
        raise ValueError(f"Missing version identifier: {version_column}")
    order = [F.col(columns["etl_recordbegindt"]).desc()]
    if "etl_latestupdatedt" in columns:
        order.append(F.col(columns["etl_latestupdatedt"]).desc())
    order.append(F.col(columns[version_column.lower()]).desc())
    window = Window.partitionBy(F.col(columns["etl_naturalkeytext"])).orderBy(*order)
    previous = F.lag(F.col(columns["etl_recordbegindt"])).over(window)
    sentinel = F.to_timestamp(F.lit("9999-12-31 00:00:00"))
    output = (df
        .withColumn("version_ID", F.col(columns[version_column.lower()]))
        .withColumn("_old_end", F.col(columns["etl_recordenddt"]))
        .withColumn("ETL_RecordEndDT", F.coalesce(previous, sentinel))
        .withColumn("ETL_CurrentRecordFlag",
                    F.when(previous.isNull(), F.lit("Y")).otherwise(F.lit("N"))))
    changed = ~F.col("_old_end").eqNullSafe(F.col("ETL_RecordEndDT"))
    if include_active:
        if "etl_activeflag" not in columns or "etl_deletedt" not in columns:
            raise ValueError("Missing active flag inputs for Type 2 expiration")
        output = (output
            .withColumn("_old_active", F.col(columns["etl_activeflag"]))
            .withColumn("ETL_ActiveFlag",
                        F.when(previous.isNull() & F.col(columns["etl_deletedt"]).isNull(),
                               F.lit("Y")).otherwise(F.lit("N")))
            .withColumn("DIM_EffectiveEndDT",
                        F.date_format(F.date_sub(F.to_date("ETL_RecordEndDT"), 2),
                                      "yyyyMMdd").cast("int")))
        changed = changed | ~F.col("_old_active").eqNullSafe(F.col("ETL_ActiveFlag"))
    return output.filter(changed).drop("_old_end", "_old_active")


def merge_sql_server(df, connection, table, keys, insert_missing=False):
    """Stage a DataFrame and update or upsert SQL Server rows by business key."""
    df = align_to_sql_table(df, connection, table)
    available = {column.lower(): column for column in df.columns}
    if not keys or any(key.lower() not in available for key in keys):
        raise ValueError(f"Missing SQL merge key for {table}: {keys}")
    keys = [available[key.lower()] for key in keys]
    if not df.take(1):
        return False
    if df.groupBy(*keys).count().filter("count > 1").take(1):
        raise ValueError(f"Duplicate merge keys in {table} input")
    columns = list(df.columns)
    target = _sql_identifier(table if "." in table else "dbo." + table)
    stage_name = "_fabric_stage_" + uuid4().hex
    qualified_stage = _sql_identifier("dbo." + stage_name)
    match = " AND ".join(
        f"target.{_sql_identifier(key)} = source.{_sql_identifier(key)}"
        for key in keys
    )
    updates = [column for column in columns if column not in keys]
    if not updates:
        raise ValueError(f"No update columns for {table}")
    set_clause = ", ".join(
        f"target.{_sql_identifier(column)} = source.{_sql_identifier(column)}"
        for column in updates
    )
    sql = (
        f"MERGE {target} WITH (HOLDLOCK) AS target "
        f"USING {qualified_stage} AS source ON {match} "
        f"WHEN MATCHED THEN UPDATE SET {set_clause} "
    )
    if insert_missing:
        names = ", ".join(_sql_identifier(column) for column in columns)
        values = ", ".join(f"source.{_sql_identifier(column)}" for column in columns)
        sql += f"WHEN NOT MATCHED THEN INSERT ({names}) VALUES ({values}) "
    sql += ";"
    jvm = df.sparkSession._jvm
    jvm.java.lang.Class.forName(connection["driver"])
    java_connection = None
    stage_created = False
    try:
        max_parts = max(1, int(os.getenv("MSSQL_WRITE_PARTITIONS", "8")))
        (df.coalesce(max_parts).write.format("jdbc")
            .option("url", connection["jdbc_url"])
            .option("dbtable", "dbo." + stage_name)
            .option("driver", connection["driver"])
            .option("user", connection["user"])
            .option("password", connection["password"])
            .option("batchsize", os.getenv("MSSQL_BATCH_SIZE", "5000"))
            .mode("error").save())
        stage_created = True
        java_connection = jvm.java.sql.DriverManager.getConnection(
            connection["jdbc_url"], connection["user"], connection["password"]
        )
        statement = java_connection.createStatement()
        try:
            statement.execute(sql)
        finally:
            statement.close()
    finally:
        try:
            if stage_created:
                if java_connection is None:
                    java_connection = jvm.java.sql.DriverManager.getConnection(
                        connection["jdbc_url"], connection["user"], connection["password"]
                    )
                cleanup = java_connection.createStatement()
                try:
                    cleanup.execute(f"DROP TABLE {qualified_stage}")
                finally:
                    cleanup.close()
        except Exception:
            logging.exception("Could not drop SQL staging table %s", stage_name)
        finally:
            if java_connection is not None:
                java_connection.close()
    return True
