"""
Database Connection Configuration
Pre-configured connections for code generation.
Logic: Targets use PostgreSQL, all other SQL (sources/lookups) use MSSQL
"""

# MSSQL Connection for Sources and Lookups
MSSQL_CONFIG = {
    "db_type": "sqlserver",
    "database": "msscdm_dev3",
    "user": "spark_user",
    "password": "spark@25091990",
    "host": "w908925.cguser.capgroup.com\\CGSQL",
    "jdbc_url": "jdbc:sqlserver://w908925.cguser.capgroup.com\\CGSQL;databaseName=msscdm_dev3;user=spark_user;password=spark@25091990;trustServerCertificate=true;encrypt=false",
    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
    "driver_jar": "C:/Driver/mssql-jdbc-12.4.2.jre11.jar"
}

# PostgreSQL Connection for Targets
POSTGRESQL_CONFIG = {
    "db_type": "postgresql",
    "host": "cdm-saas-metadata.global-g1cpbonguyey.global.rds.amazonaws.com",
    "port": 5440,
    "database": "cdmmetadata",
    "user": "cdm_user_admin",
    "password": "9Lz@6Is8*&MG$)ur",
    "jdbc_url": "jdbc:postgresql://cdm-saas-metadata.global-g1cpbonguyey.global.rds.amazonaws.com:5440/cdmmetadata",
    "driver": "org.postgresql.Driver",
    "driver_jar": "C:/Driver/postgresql-42.6.2.jar"
}


def get_source_connection():
    """Get MSSQL connection for sources."""
    return MSSQL_CONFIG.copy()


def get_lookup_connection():
    """Get MSSQL connection for lookups."""
    return MSSQL_CONFIG.copy()


def get_target_connection():
    """Get PostgreSQL connection for targets."""
    return POSTGRESQL_CONFIG.copy()


def get_connection_for_type(conn_type: str) -> dict:
    """
    Get connection config based on type.
    
    Args:
        conn_type: 'source', 'lookup', or 'target'
    
    Returns:
        Connection configuration dictionary
    """
    if conn_type.lower() == 'target':
        return get_target_connection()
    else:
        return get_source_connection()


def get_jdbc_url(conn_type: str) -> str:
    """Get JDBC URL for connection type."""
    config = get_connection_for_type(conn_type)
    return config["jdbc_url"]


def get_spark_config_for_drivers() -> dict:
    """Get Spark configuration for JDBC drivers."""
    return {
        "spark.driver.extraClassPath": f"{MSSQL_CONFIG['driver_jar']};{POSTGRESQL_CONFIG['driver_jar']}",
        "spark.executor.extraClassPath": f"{MSSQL_CONFIG['driver_jar']};{POSTGRESQL_CONFIG['driver_jar']}"
    }
