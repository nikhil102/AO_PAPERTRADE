"""Expression Translator - translates Informatica expressions to PySpark."""
import re
from typing import Dict, List, Optional, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from .logger import ConversionLogger


def sanitize_for_expr(expr: str) -> str:
    """
    Sanitize an expression for use inside expr("...").
    - Escape embedded double quotes
    - Handle empty strings properly
    - Remove problematic patterns
    """
    if not expr:
        return ""
    
    result = expr.replace('\\', '\\\\')
    result = result.replace('"', '\\"')
    result = re.sub(r'""([^"]*?)""', r'"\1"', result)
    
    return result


def wrap_with_expr(condition: str) -> str:
    """
    Wrap a condition in expr() for safe filter usage.
    This avoids bare Python identifiers like isnull(col) without col() wrapper.
    """
    if not condition or condition.strip().lower() in ('true', 'false'):
        return condition
    
    sanitized = sanitize_for_expr(condition)
    return f'expr("{sanitized}")'


class ExpressionTranslator:
    """Translates Informatica expressions to PySpark/SQL expressions."""
    
    FUNCTION_MAP = {
        'NVL': 'coalesce',
        'IS_SPACES': "trim({}) = ''",
        'IS_NUMBER': 'cast({} as double) is not null',
        'TO_CHAR': 'cast({} as string)',
        'TO_DATE': 'to_date',
        'TO_DECIMAL': 'cast({} as decimal)',
        'TO_INTEGER': 'cast({} as int)',
        'TO_BIGINT': 'cast({} as bigint)',
        'TO_FLOAT': 'cast({} as float)',
        'SUBSTR': 'substring',
        'INSTR': 'instr',
        'LTRIM': 'ltrim',
        'RTRIM': 'rtrim',
        'TRIM': 'trim',
        'UPPER': 'upper',
        'LOWER': 'lower',
        'LENGTH': 'length',
        'LPAD': 'lpad',
        'RPAD': 'rpad',
        'CONCAT': 'concat',
        'REPLACE': 'regexp_replace',
        'REG_REPLACE': 'regexp_replace',
        'REG_MATCH': 'regexp_extract',
        'ROUND': 'round',
        'TRUNC': 'trunc',
        'ABS': 'abs',
        'MOD': 'mod',
        'POWER': 'pow',
        'SQRT': 'sqrt',
        'FLOOR': 'floor',
        'CEIL': 'ceil',
        'LOG': 'log',
        'EXP': 'exp',
        'SYSDATE': 'current_date()',
        'SYSTIMESTAMP': 'current_timestamp()',
        'SESSSTARTTIME': 'current_timestamp()',
        'ADD_TO_DATE': 'date_add',
        'DATE_DIFF': 'datediff',
        'GET_DATE_PART': 'date_part',
        'SET_DATE_PART': None,
        'LAST_DAY': 'last_day',
        'MAKE_DATE_TIME': 'to_timestamp',
        'SUM': 'sum',
        'COUNT': 'count',
        'AVG': 'avg',
        'MIN': 'min',
        'MAX': 'max',
        'FIRST': 'first',
        'LAST': 'last',
        'MEDIAN': 'percentile_approx({}, 0.5)',
        'STDDEV': 'stddev',
        'VARIANCE': 'variance',
    }
    
    def __init__(self, mapping_name: str = "", pm_variables: Dict[str, str] = None, logger: Optional["ConversionLogger"] = None):
        self.mapping_name = mapping_name
        self.pm_variables = pm_variables or {}
        self.warnings: List[str] = []
        self.logger = logger
        
    def translate(self, expression: str, context: str = "column", field_name: str = "") -> str:
        """Translate an Informatica expression to PySpark."""
        if not expression:
            return ""
        
        original = expression
        result = expression
        
        result = self._replace_pm_variables(result)
        
        result = self._translate_lkp_references(result)
        
        result = self._translate_isnull(result)
        
        result = self._translate_in_function(result)
        
        result = self._translate_instr(result)
        
        result = self._translate_is_number(result)
        
        result = self._translate_iif(result)
        
        result = self._translate_decode(result)
        
        result = self._translate_functions(result)
        
        result = self._translate_operators(result)
        
        result = self._translate_string_literals(result)
        
        result = self._clean_up(result)
        
        if self.logger and field_name:
            from .logger import LogLevel
            if result != original:
                self.logger.log_expression(
                    field_name, 
                    original, 
                    result, 
                    LogLevel.SUCCESS
                )
            else:
                self.logger.log_expression(
                    field_name, 
                    original, 
                    result, 
                    LogLevel.INFO,
                    "Expression unchanged (already PySpark compatible)"
                )
        
        return result
    
    def translate_for_filter(self, expression: str, field_name: str = "") -> str:
        """
        Translate expression for filter context - wraps in expr() for safe usage.
        This avoids bare Python identifiers that would fail at runtime.
        """
        if not expression:
            return "True"
        
        translated = self.translate(expression, "filter", field_name)
        
        if translated.strip().lower() in ('true', 'false'):
            return translated
        
        return wrap_with_expr(translated)
    
    def _translate_isnull(self, expr: str) -> str:
        """Translate ISNULL(x) to (x IS NULL) for use in Spark SQL expr."""
        pattern = re.compile(r'\bISNULL\s*\(\s*([^)]+)\s*\)', re.IGNORECASE)
        
        def replace_isnull(match):
            arg = match.group(1).strip()
            return f'({arg} IS NULL)'
        
        return pattern.sub(replace_isnull, expr)
    
    def _translate_in_function(self, expr: str) -> str:
        """Translate Informatica IN(x, a, b, c) to Spark SQL x IN (a, b, c).
        
        Informatica syntax: IN(value, list_item1, list_item2, ...)
        Spark SQL syntax: value IN (list_item1, list_item2, ...)
        """
        # Use a marker to prevent re-matching already translated expressions
        marker = "__SPARK_IN__"
        pattern = re.compile(r'\bIN\s*\(', re.IGNORECASE)
        
        max_iterations = 100  # Safety limit
        iteration = 0
        
        while pattern.search(expr) and iteration < max_iterations:
            iteration += 1
            match = pattern.search(expr)
            if not match:
                break
            
            args = self._extract_function_args(expr, match.end() - 1)
            
            if len(args) >= 2:
                test_value = args[0]
                list_items = args[1:]
                # Use marker to prevent re-matching
                sql_expr = f"({test_value} {marker}({', '.join(list_items)}))"
                
                full_match = expr[match.start():self._find_closing_paren(expr, match.end() - 1) + 1]
                expr = expr.replace(full_match, sql_expr, 1)
            else:
                break
        
        # Replace markers with actual IN keyword
        expr = expr.replace(marker, "IN ")
        return expr
    
    def _translate_instr(self, expr: str) -> str:
        """Translate Informatica INSTR(string, substring, start, occurrence) to Spark instr(string, substring).
        
        Informatica INSTR takes 4 args, Spark instr takes only 2.
        We ignore start and occurrence parameters.
        """
        pattern = re.compile(r'\bINSTR\s*\(', re.IGNORECASE)
        
        max_iterations = 100  # Safety limit
        iteration = 0
        
        while pattern.search(expr) and iteration < max_iterations:
            iteration += 1
            match = pattern.search(expr)
            if not match:
                break
            
            args = self._extract_function_args(expr, match.end() - 1)
            
            if len(args) >= 2:
                string_arg = args[0]
                substring_arg = args[1]
                # Use lowercase 'instr' which won't match the uppercase pattern
                sql_expr = f"instr({string_arg}, {substring_arg})"
                
                full_match = expr[match.start():self._find_closing_paren(expr, match.end() - 1) + 1]
                expr = expr.replace(full_match, sql_expr, 1)
            else:
                break
        
        return expr
    
    def _translate_is_number(self, expr: str) -> str:
        """Translate Informatica IS_NUMBER(x) to Spark SQL check.
        
        IS_NUMBER returns true if the string can be converted to a valid number.
        In Spark: (CAST(x AS DOUBLE) IS NOT NULL AND TRIM(x) != '')
        """
        pattern = re.compile(r'\bIS_NUMBER\s*\(\s*([^)]+)\s*\)', re.IGNORECASE)
        
        def replace_is_number(match):
            arg = match.group(1).strip()
            return f"(CAST({arg} AS DOUBLE) IS NOT NULL AND TRIM({arg}) != '')"
        
        return pattern.sub(replace_is_number, expr)
    
    def _translate_string_literals(self, expr: str) -> str:
        """Ensure string literals are properly quoted for Spark SQL.
        
        IMPORTANT: Keep single quotes for Spark SQL string literals.
        Do NOT rewrite 'x' -> "x" as double-quotes are identifiers in Spark SQL.
        """
        # Single quotes are the correct SQL string literal format
        # No conversion needed - keep expressions as-is
        return expr
    
    def _translate_lkp_references(self, expr: str) -> str:
        """
        Translate :LKP.lookup_name(column) references to actual column names.
        After lookup join, the lookup columns are available directly in the DataFrame.
        :LKP.LKP_CUSTOMER(CUST_ID) -> CUST_ID (the return port from the lookup)
        """
        pattern = re.compile(r':LKP\.(\w+)\s*\(\s*([^)]+)\s*\)', re.IGNORECASE)
        
        def replace_lkp(match):
            lookup_name = match.group(1)
            column_name = match.group(2).strip()
            self.warnings.append(f"Replaced :LKP.{lookup_name}({column_name}) with direct column reference")
            return column_name
        
        return pattern.sub(replace_lkp, expr)
    
    def _replace_pm_variables(self, expr: str) -> str:
        """Replace $PM variables with actual values using SQL string literals (single quotes)."""
        result = expr
        
        # Use single quotes for SQL string literals
        safe_mapping_name = self.mapping_name.replace("'", "''")
        
        result = re.sub(
            r'\$PMMappingName',
            f"'{safe_mapping_name}'",
            result,
            flags=re.IGNORECASE
        )
        
        result = re.sub(
            r'\$PMWorkflowName',
            f"'{safe_mapping_name}'",
            result,
            flags=re.IGNORECASE
        )
        
        result = re.sub(
            r'\$PMSessionName',
            f"'{safe_mapping_name}'",
            result,
            flags=re.IGNORECASE
        )
        
        result = re.sub(
            r'\$PMFolderName',
            "'default'",
            result,
            flags=re.IGNORECASE
        )
        
        for var_name, var_value in self.pm_variables.items():
            if var_value:
                # SQL string literal - escape single quotes
                safe_value = str(var_value).replace("'", "''")
                result = re.sub(
                    re.escape(var_name),
                    f"'{safe_value}'",
                    result,
                    flags=re.IGNORECASE
                )
            else:
                # Unresolved: keep as literal placeholder so code still runs
                safe_var = var_name.replace("'", "''")
                result = re.sub(
                    re.escape(var_name),
                    f"'{safe_var}'",
                    result,
                    flags=re.IGNORECASE
                )
        
        remaining_pm = re.findall(r'\$PM[A-Za-z_][A-Za-z0-9_]*', result)
        for pm_var in remaining_pm:
            self.warnings.append(f"Unresolved PM variable: {pm_var}")
            safe_pm = pm_var.replace("'", "''")
            result = result.replace(pm_var, f"'{safe_pm}'")
        
        return result
    
    def _translate_iif(self, expr: str) -> str:
        """Translate IIF(condition, true_val, false_val) to CASE WHEN for SQL expr()."""
        pattern = re.compile(r'IIF\s*\(', re.IGNORECASE)
        
        while pattern.search(expr):
            match = pattern.search(expr)
            if not match:
                break
            
            start = match.end()
            args = self._extract_function_args(expr, start - 1)
            
            if len(args) >= 2:
                condition = args[0]
                true_val = args[1]
                false_val = args[2] if len(args) > 2 else "NULL"
                
                sql_expr = f"CASE WHEN {condition} THEN {true_val} ELSE {false_val} END"
                
                full_match = expr[match.start():self._find_closing_paren(expr, match.end() - 1) + 1]
                expr = expr.replace(full_match, sql_expr, 1)
            else:
                break
        
        return expr
    
    def _translate_decode(self, expr: str) -> str:
        """Translate DECODE to CASE WHEN for SQL expr()."""
        pattern = re.compile(r'DECODE\s*\(', re.IGNORECASE)
        
        while pattern.search(expr):
            match = pattern.search(expr)
            if not match:
                break
            
            start = match.end()
            args = self._extract_function_args(expr, start - 1)
            
            if len(args) >= 3:
                test_expr = args[0]
                pairs = args[1:]
                
                when_clauses = []
                default_val = "NULL"
                
                i = 0
                while i < len(pairs) - 1:
                    search_val = pairs[i]
                    result_val = pairs[i + 1]
                    when_clauses.append(f"WHEN {test_expr} = {search_val} THEN {result_val}")
                    i += 2
                
                if len(pairs) % 2 == 1:
                    default_val = pairs[-1]
                
                sql_expr = "CASE " + " ".join(when_clauses) + f" ELSE {default_val} END"
                
                full_match = expr[match.start():self._find_closing_paren(expr, match.end() - 1) + 1]
                expr = expr.replace(full_match, sql_expr, 1)
            else:
                break
        
        return expr
    
    def _translate_functions(self, expr: str) -> str:
        """Translate Informatica functions to PySpark equivalents."""
        result = expr
        
        for infa_func, spark_func in self.FUNCTION_MAP.items():
            if spark_func is None:
                continue
            
            pattern = re.compile(rf'\b{infa_func}\s*\(', re.IGNORECASE)
            
            if '{}' in spark_func:
                while pattern.search(result):
                    match = pattern.search(result)
                    if not match:
                        break
                    
                    args = self._extract_function_args(result, match.end() - 1)
                    if args:
                        new_func = spark_func.format(args[0])
                        full_match = result[match.start():self._find_closing_paren(result, match.end() - 1) + 1]
                        result = result.replace(full_match, new_func, 1)
                    else:
                        break
            else:
                result = pattern.sub(f'{spark_func}(', result)
        
        return result
    
    def _translate_operators(self, expr: str) -> str:
        """Translate operators to SQL syntax for use in expr()."""
        result = expr
        
        result = re.sub(r'\|\|', ' || ', result)
        
        result = re.sub(r'\b(AND)\b', r' AND ', result, flags=re.IGNORECASE)
        result = re.sub(r'\b(OR)\b', r' OR ', result, flags=re.IGNORECASE)
        result = re.sub(r'\b(NOT)\b', r' NOT ', result, flags=re.IGNORECASE)
        
        result = re.sub(r'<>', '!=', result)
        
        result = re.sub(r'\s+', ' ', result)
        
        # IMPORTANT: Keep single quotes for Spark SQL string literals.
        # Do NOT rewrite 'x' -> "x" as double-quotes are identifiers in Spark SQL.
        
        return result
    
    def _clean_up(self, expr: str) -> str:
        """Clean up the translated expression."""
        result = expr
        
        result = re.sub(r'\s+', ' ', result)
        result = result.strip()
        
        return result
    
    def _extract_function_args(self, expr: str, start_paren: int) -> List[str]:
        """Extract arguments from a function call."""
        if start_paren >= len(expr) or expr[start_paren] != '(':
            return []
        
        args = []
        current_arg = ""
        depth = 0
        
        for i in range(start_paren + 1, len(expr)):
            char = expr[i]
            
            if char == '(':
                depth += 1
                current_arg += char
            elif char == ')':
                if depth == 0:
                    if current_arg.strip():
                        args.append(current_arg.strip())
                    break
                depth -= 1
                current_arg += char
            elif char == ',' and depth == 0:
                args.append(current_arg.strip())
                current_arg = ""
            else:
                current_arg += char
        
        return args
    
    def _find_closing_paren(self, expr: str, start: int) -> int:
        """Find the position of the closing parenthesis."""
        depth = 0
        for i in range(start, len(expr)):
            if expr[i] == '(':
                depth += 1
            elif expr[i] == ')':
                depth -= 1
                if depth == 0:
                    return i
        return len(expr) - 1
