(function () {
  "use strict";

  const data = window.FASTRECON_DOCS || { examples: [], setup: null };
  const allItems = data.setup ? [data.setup, ...data.examples] : data.examples;

  document.getElementById("version-badge").textContent = "v" + data.version;
  document.getElementById("footer-version").textContent = "v" + data.version;
  document.getElementById("stat-examples").textContent = data.examples.length;
  document.getElementById("footer-count").textContent = data.examples.length;

  const CATEGORY_LABELS = {
    intro: "Setup",
    files: "File",
    sql: "SQL",
    mixed: "Mixed",
    modes: "Mode",
    config: "Config",
    scale: "Scale",
    output: "Output",
  };

  // ---------- sidebar ----------
  const sidebar = document.getElementById("example-list");
  for (const ex of allItems) {
    const li = document.createElement("li");
    const a = document.createElement("a");
    a.href = "#ex-" + ex.id;
    a.dataset.id = ex.id;
    a.innerHTML =
      "<span>" + escapeHtml(ex.title) + "</span>" +
      '<small>' + (CATEGORY_LABELS[ex.category] || ex.category) + " · " + ex.id + "</small>";
    li.appendChild(a);
    sidebar.appendChild(li);
  }

  // ---------- example cards ----------
  const host = document.getElementById("examples-host");
  for (const ex of allItems) {
    host.appendChild(buildExampleCard(ex));
  }

  function buildExampleCard(ex) {
    const tag = CATEGORY_LABELS[ex.category] || ex.category;
    const wrap = document.createElement("article");
    wrap.className = "example";
    wrap.id = "ex-" + ex.id;
    wrap.dataset.category = ex.category;
    wrap.dataset.search = (ex.title + " " + ex.blurb + " " + ex.id + " " + ex.code).toLowerCase();

    wrap.innerHTML =
      '<header>' +
        '<h3>' + escapeHtml(ex.title) + '</h3>' +
        '<span class="tag">' + escapeHtml(tag) + '</span>' +
        '<span class="id">' + escapeHtml(ex.id) + '.py</span>' +
      '</header>' +
      '<p class="blurb">' + escapeHtml(ex.blurb) + '</p>' +
      '<div class="tabbar">' +
        '<button data-tab="code" class="active">Python</button>' +
        '<button data-tab="output">Output</button>' +
      '</div>' +
      '<div class="tab-panel active" data-panel="code">' +
        '<button class="copy-btn" data-copy="code">Copy</button>' +
        '<pre><code class="language-python">' + escapeHtml(ex.code) + '</code></pre>' +
      '</div>' +
      '<div class="tab-panel" data-panel="output">' +
        '<button class="copy-btn" data-copy="output">Copy</button>' +
        '<pre><code>' + escapeHtml(ex.output || "(no output captured)") + '</code></pre>' +
      '</div>';

    // tab switching
    const tabBtns = wrap.querySelectorAll(".tabbar button");
    const panels = wrap.querySelectorAll(".tab-panel");
    tabBtns.forEach(function (btn) {
      btn.addEventListener("click", function () {
        tabBtns.forEach(function (b) { b.classList.remove("active"); });
        btn.classList.add("active");
        panels.forEach(function (p) {
          p.classList.toggle("active", p.dataset.panel === btn.dataset.tab);
        });
      });
    });

    // copy buttons
    wrap.querySelectorAll(".copy-btn").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const which = btn.dataset.copy;
        const text = which === "code" ? ex.code : ex.output;
        navigator.clipboard.writeText(text).then(function () {
          const original = btn.textContent;
          btn.textContent = "Copied";
          setTimeout(function () { btn.textContent = original; }, 1200);
        });
      });
    });

    return wrap;
  }

  // ---------- highlight ----------
  if (window.hljs) {
    document.querySelectorAll("pre code").forEach(function (block) {
      window.hljs.highlightElement(block);
    });
  }

  // ---------- filtering ----------
  const chips = document.querySelectorAll(".chip");
  let activeFilter = "all";
  chips.forEach(function (chip) {
    chip.addEventListener("click", function () {
      chips.forEach(function (c) { c.classList.remove("active"); });
      chip.classList.add("active");
      activeFilter = chip.dataset.filter;
      applyFilters();
    });
  });

  function applyFilters() {
    const cards = document.querySelectorAll(".example");
    let visible = 0;
    cards.forEach(function (card) {
      const show = activeFilter === "all" || card.dataset.category === activeFilter;
      card.style.display = show ? "" : "none";
      if (show) visible++;
    });

    let empty = document.getElementById("empty-state");
    if (visible === 0) {
      if (!empty) {
        empty = document.createElement("div");
        empty.id = "empty-state";
        empty.className = "no-results";
        empty.textContent = "No examples in this category.";
        host.appendChild(empty);
      }
    } else if (empty) {
      empty.remove();
    }
  }

  // ---------- sidebar active highlight on scroll ----------
  const links = Array.from(sidebar.querySelectorAll("a"));
  const linkById = {};
  links.forEach(function (l) { linkById[l.dataset.id] = l; });

  const io = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        const id = entry.target.id.replace(/^ex-/, "");
        links.forEach(function (l) { l.classList.remove("active"); });
        if (linkById[id]) linkById[id].classList.add("active");
      }
    });
  }, { rootMargin: "-30% 0px -55% 0px" });
  document.querySelectorAll(".example").forEach(function (el) { io.observe(el); });

  // ---------- helpers ----------
  function escapeHtml(s) {
    if (s == null) return "";
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }
})();
