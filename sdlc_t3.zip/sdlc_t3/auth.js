// auth.js - Application Authentication Guard
(function() {
    const isLoggedIn = sessionStorage.getItem('isLoggedIn') === 'true' || localStorage.getItem('isLoggedIn') === 'true';
    const isLoginPage = window.location.pathname.toLowerCase().includes('login.html');

    if (!isLoggedIn && !isLoginPage) {
        window.location.href = 'login.html';
    } else if (isLoggedIn && isLoginPage) {
        window.location.href = 'index.html';
    }
})();

// Global logout action
window.logout = function() {
    sessionStorage.removeItem('isLoggedIn');
    localStorage.removeItem('isLoggedIn');
    window.location.href = 'login.html';
};
