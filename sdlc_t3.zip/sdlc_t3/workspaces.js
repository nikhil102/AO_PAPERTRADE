// workspaces.js - Customer Workspaces Page Controller

document.addEventListener('DOMContentLoaded', () => {
    initPage();
});

// Load projects state
let projects = [];
try {
    projects = JSON.parse(localStorage.getItem('agentic_sdlc_projects')) || [];
} catch (e) {
    projects = [];
}

// Default initial client database
const DEFAULT_CLIENTS = [
    { name: 'Acme Corp', domain: 'Payroll / HR', domainKey: 'payroll', runs: 12, artifacts: 68, maturity: 4.8, runId: '#RUN-0042', status: 'running' },
    { name: 'NovaBanc', domain: 'Core Banking', domainKey: 'banking', runs: 24, artifacts: 142, maturity: 5.0, runId: '#RUN-0041', status: 'running' },
    { name: 'TerraLogic', domain: 'ERP / CRM', domainKey: 'erp', runs: 8, artifacts: 44, maturity: 3.9, runId: '#RUN-0040', status: 'running' },
    { name: 'FinPulse Ltd', domain: 'Risk Management', domainKey: 'risk', runs: 18, artifacts: 104, maturity: 4.6, runId: 'Completed', status: 'completed' },
    { name: 'DataPeak Inc', domain: 'Data Engineering', domainKey: 'data', runs: 6, artifacts: 24, maturity: 3.2, runId: 'Blocked', status: 'blocked' },
    { name: 'CloudBridge', domain: 'Cloud Migration', domainKey: 'cloud', runs: 3, artifacts: 12, maturity: 3.5, runId: '#RUN-0043', status: 'running' }
];

let clients = [];
try {
    clients = JSON.parse(localStorage.getItem('config_workspaces_clients')) || DEFAULT_CLIENTS;
} catch (e) {
    clients = DEFAULT_CLIENTS;
}

let activeView = 'list'; // 'list' or 'grid'

// Sorting State
let sortField = 'name'; // 'name', 'runs', 'artifacts', 'maturity'
let sortOrder = 'asc'; // 'asc' or 'desc'

function initPage() {
    renderProjectList();
    setupDropdowns();
    setupFilters();
    setupModal();
    renderClients();
}

/* ----------------------------------------------------
   Sidebar Rendering
   ---------------------------------------------------- */
function renderProjectList(filter = '') {
    const container = document.getElementById('project-list-container');
    if (!container) return;
    
    container.innerHTML = '';
    const filteredProjects = projects.filter(p => 
        p.name.toLowerCase().includes(filter.toLowerCase()) || 
        p.customer.toLowerCase().includes(filter.toLowerCase())
    );

    if (filteredProjects.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="padding: 20px;">
                <p style="font-size: 12px; color: var(--text-sidebar-muted);">No projects match search</p>
            </div>
        `;
        return;
    }

    filteredProjects.forEach(proj => {
        const badgeClass = `badge-` + proj.status.toLowerCase().replace(' ', '');
        const item = document.createElement('div');
        item.className = 'project-item';
        item.dataset.id = proj.id;
        item.innerHTML = `
            <div class="project-item-top">
                <span class="project-item-name">${proj.name}</span>
                <span class="badge ${badgeClass}">${proj.status}</span>
            </div>
            <span class="project-item-desc">${proj.customer}</span>
        `;
        item.addEventListener('click', () => {
            window.location.href = `index.html?projectId=${proj.id}`;
        });
        container.appendChild(item);
    });
}

/* ----------------------------------------------------
   Dropdown toggles
   ---------------------------------------------------- */
function setupDropdowns() {
    const searchInput = document.getElementById('project-search');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            renderProjectList(e.target.value);
        });
    }

    // New Project Button click
    const btnNewProject = document.getElementById('btn-new-project');
    if (btnNewProject) {
        btnNewProject.addEventListener('click', () => {
            window.location.href = 'create-project.html';
        });
    }

    // Settings dropdown toggling
    const btnSettingsToggle = document.getElementById('btn-settings-toggle');
    const settingsDropdownMenu = document.getElementById('settings-dropdown-menu');
    if (btnSettingsToggle && settingsDropdownMenu) {
        btnSettingsToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            settingsDropdownMenu.classList.toggle('hidden');
        });
        
        document.addEventListener('click', (e) => {
            if (!settingsDropdownMenu.classList.contains('hidden') && !e.target.closest('#settings-dropdown-menu') && e.target !== btnSettingsToggle) {
                settingsDropdownMenu.classList.add('hidden');
            }
        });
    }
}

/* ----------------------------------------------------
   Search and Filters
   ---------------------------------------------------- */
function setupFilters() {
    const search = document.getElementById('workspace-search-input');
    const domain = document.getElementById('filter-domain');
    const status = document.getElementById('filter-status');
    const listBtn = document.getElementById('btn-view-list');
    const gridBtn = document.getElementById('btn-view-grid');

    if (search) search.addEventListener('input', renderClients);
    if (domain) domain.addEventListener('change', renderClients);
    if (status) status.addEventListener('change', renderClients);

    if (listBtn && gridBtn) {
        listBtn.addEventListener('click', () => {
            activeView = 'list';
            listBtn.classList.add('active');
            gridBtn.classList.remove('active');
            renderClients();
        });
        gridBtn.addEventListener('click', () => {
            activeView = 'grid';
            gridBtn.classList.add('active');
            listBtn.classList.remove('active');
            renderClients();
        });
    }
}

/* ----------------------------------------------------
   Render Clients Listings with sorting
   ---------------------------------------------------- */
function renderClients() {
    const container = document.getElementById('workspaces-display-container');
    if (!container) return;

    const query = (document.getElementById('workspace-search-input')?.value || '').toLowerCase();
    const domainVal = document.getElementById('filter-domain')?.value || 'all';
    const statusVal = document.getElementById('filter-status')?.value || 'all';

    let filtered = clients.filter(c => {
        const matchesQuery = c.name.toLowerCase().includes(query) || c.domain.toLowerCase().includes(query);
        const matchesDomain = domainVal === 'all' || c.domainKey === domainVal;
        const matchesStatus = statusVal === 'all' || c.status === statusVal;
        return matchesQuery && matchesDomain && matchesStatus;
    });

    // Sort database entries based on state
    filtered.sort((a, b) => {
        let valA = a[sortField];
        let valB = b[sortField];

        if (typeof valA === 'string') {
            valA = valA.toLowerCase();
            valB = valB.toLowerCase();
        }

        if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
        if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
        return 0;
    });

    container.innerHTML = '';
    
    if (filtered.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="padding: 40px 20px;">
                <div class="empty-state-icon" style="width:54px; height:54px; background: rgba(100,116,139,0.08); color: var(--text-muted);">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                </div>
                <h3>No Customer Workspaces Found</h3>
                <p class="text-muted text-small">Try adjusting search query or filters.</p>
            </div>
        `;
        return;
    }

    if (activeView === 'list') {
        renderListView(filtered, container);
    } else {
        renderGridView(filtered, container);
    }
}

function renderListView(data, container) {
    const tableDiv = document.createElement('div');
    tableDiv.className = 'table-container';
    
    let rowsHtml = '';
    data.forEach(item => {
        let statusBadge = '';
        if (item.status === 'running') {
            statusBadge = `<span class="badge badge-accent" style="display:inline-flex; align-items:center; gap:4px;"><span class="pulse-dot active"></span> ${item.runId}</span>`;
        } else if (item.status === 'completed') {
            statusBadge = `<span class="badge badge-success">${item.runId}</span>`;
        } else {
            statusBadge = `<span class="badge badge-danger">${item.runId}</span>`;
        }

        // Color coded rating
        let ratingColor = 'var(--text-main)';
        if (item.maturity >= 4.5) ratingColor = 'var(--success)';
        else if (item.maturity >= 3.5) ratingColor = 'var(--warning)';
        else ratingColor = 'var(--error)';

        rowsHtml += `
            <tr>
                <td style="font-weight: 600; color: var(--text-main); font-family: var(--font-heading);">🏢 ${item.name}</td>
                <td>${item.domain}</td>
                <td class="text-center font-bold" style="color:var(--text-main);">${item.runs}</td>
                <td class="text-center font-bold" style="color:var(--text-main);">${item.artifacts}</td>
                <td>
                    <div style="display:flex; align-items:center; gap:6px;">
                        <span class="font-bold" style="color: ${ratingColor};">${item.maturity.toFixed(1)}</span>
                        <span style="color:var(--warning); font-size:14px;">★</span>
                    </div>
                </td>
                <td>${statusBadge}</td>
                <td>
                    <div style="display:flex; gap:6px;">
                        <button class="btn btn-secondary workspace-action-btn" data-name="${item.name}" data-action="manage" style="padding:4px 8px; font-size:11px;">Manage</button>
                        <button class="btn btn-secondary workspace-action-btn" data-name="${item.name}" data-action="logs" style="padding:4px 8px; font-size:11px;">Logs</button>
                    </div>
                </td>
            </tr>
        `;
    });

    const getHeaderClass = (field) => {
        if (sortField !== field) return 'sortable-header';
        return `sortable-header ${sortOrder}`;
    };

    const getHeaderIndicator = (field) => {
        if (sortField !== field) return '⇅';
        return sortOrder === 'asc' ? '▲' : '▼';
    };

    tableDiv.innerHTML = `
        <table class="workspace-table">
            <thead>
                <tr>
                    <th class="${getHeaderClass('name')}" data-sort="name">Customer Name <span class="sort-indicator">${getHeaderIndicator('name')}</span></th>
                    <th>Operational Domain</th>
                    <th class="text-center ${getHeaderClass('runs')}" data-sort="runs">Runs <span class="sort-indicator">${getHeaderIndicator('runs')}</span></th>
                    <th class="text-center ${getHeaderClass('artifacts')}" data-sort="artifacts">Artifacts <span class="sort-indicator">${getHeaderIndicator('artifacts')}</span></th>
                    <th class="${getHeaderClass('maturity')}" data-sort="maturity">Maturity <span class="sort-indicator">${getHeaderIndicator('maturity')}</span></th>
                    <th>Active Pipeline Run</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${rowsHtml}
            </tbody>
        </table>
    `;
    container.appendChild(tableDiv);
    bindActionButtons(tableDiv);
    bindSortHeaders(tableDiv);
}

function renderGridView(data, container) {
    const gridDiv = document.createElement('div');
    gridDiv.className = 'workspace-grid-container';
    gridDiv.style.display = 'grid';
    gridDiv.style.gridTemplateColumns = 'repeat(auto-fill, minmax(300px, 1fr))';
    gridDiv.style.gap = '18px';
    gridDiv.style.marginTop = '12px';

    data.forEach(item => {
        let statusBadge = '';
        if (item.status === 'running') {
            statusBadge = `<span class="badge badge-accent" style="display:inline-flex; align-items:center; gap:4px;"><span class="pulse-dot active"></span> ${item.runId}</span>`;
        } else if (item.status === 'completed') {
            statusBadge = `<span class="badge badge-success">${item.runId}</span>`;
        } else {
            statusBadge = `<span class="badge badge-danger">${item.runId}</span>`;
        }

        let ratingColor = 'var(--text-main)';
        if (item.maturity >= 4.5) ratingColor = 'var(--success)';
        else if (item.maturity >= 3.5) ratingColor = 'var(--warning)';
        else ratingColor = 'var(--error)';

        // Map running agent fleet visually
        const agents = getAgentFleet(item.domainKey);
        let agentsHtml = '';
        agents.forEach(agentName => {
            const shortName = agentName.split(' ')[0] || 'AI';
            const icon = getAgentIcon(agentName);
            agentsHtml += `
                <span class="agent-fleet-badge" title="${agentName}">
                    <span class="agent-fleet-dot ${item.status === 'running' ? 'pulse' : ''}"></span>
                    ${icon} ${shortName}
                </span>
            `;
        });

        const card = document.createElement('div');
        card.className = 'setup-card';
        card.style.gap = '12px';
        card.style.padding = '20px';
        card.innerHTML = `
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <h4 style="font-family:var(--font-heading); font-size:14.5px; font-weight:700; color:var(--text-main);">🏢 ${item.name}</h4>
                ${statusBadge}
            </div>
            <span style="font-size:12px; color:var(--text-muted);">${item.domain}</span>
            <div style="border-top: 1px solid var(--border-color); padding-top:10px; display:flex; justify-content:space-between; font-size:11px; color:var(--text-muted);">
                <span>Runs: <strong style="color:var(--text-main); font-size:12px;">${item.runs}</strong></span>
                <span>Artifacts: <strong style="color:var(--text-main); font-size:12px;">${item.artifacts}</strong></span>
                <span style="display:flex; align-items:center; gap:2px;">
                    Maturity: <strong style="color:${ratingColor}; font-size:12px;">${item.maturity.toFixed(1)}</strong>
                    <span style="color:var(--warning);">★</span>
                </span>
            </div>
            
            <!-- Active Agents fleet Display -->
            <div class="agent-fleet-display">
                ${agentsHtml}
            </div>

            <div style="margin-top:10px; display:flex; gap:8px;">
                <button class="btn btn-secondary workspace-action-btn btn-block" data-name="${item.name}" data-action="manage" style="font-size:11px; padding:6px 0; font-weight:600;">Manage</button>
                <button class="btn btn-secondary workspace-action-btn btn-block" data-name="${item.name}" data-action="logs" style="font-size:11px; padding:6px 0; font-weight:600;">View Logs</button>
            </div>
        `;
        gridDiv.appendChild(card);
    });

    container.appendChild(gridDiv);
    bindActionButtons(gridDiv);
}

function bindActionButtons(parent) {
    parent.querySelectorAll('.workspace-action-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const clientName = btn.dataset.name;
            const action = btn.dataset.action;
            if (action === 'manage') {
                showToast(`Opening management console for ${clientName}...`, 'info');
            } else {
                showToast(`Fetching operation trace logs for ${clientName} pipeline...`, 'info');
            }
        });
    });
}

function bindSortHeaders(tableElement) {
    tableElement.querySelectorAll('.sortable-header').forEach(header => {
        header.addEventListener('click', () => {
            const field = header.dataset.sort;
            if (sortField === field) {
                // Toggle order
                sortOrder = sortOrder === 'asc' ? 'desc' : 'asc';
            } else {
                // Change field
                sortField = field;
                // Numeric fields sort descending first for better UX
                sortOrder = (field === 'runs' || field === 'artifacts' || field === 'maturity') ? 'desc' : 'asc';
            }
            renderClients();
        });
    });
}

// Active Agent Fleet Helper
function getAgentFleet(domainKey) {
    switch (domainKey) {
        case 'banking':
            return ['Deliverables Agent', 'Template Agent', 'Requirement Agent', 'Validator Agent', 'Documenter Agent'];
        case 'payroll':
            return ['Deliverables Agent', 'Requirement Agent', 'Documenter Agent'];
        case 'risk':
            return ['Deliverables Agent', 'Requirement Agent', 'Validator Agent'];
        case 'erp':
            return ['Deliverables Agent', 'Template Agent', 'Validator Agent'];
        case 'data':
            return ['Deliverables Agent', 'Template Agent', 'Documenter Agent'];
        case 'cloud':
            return ['Deliverables Agent', 'Validator Agent', 'Documenter Agent'];
        default:
            return ['Deliverables Agent', 'Documenter Agent'];
    }
}

function getAgentIcon(agentName) {
    if (agentName.includes('Deliverables')) return '🕵️';
    if (agentName.includes('Template')) return '🏗️';
    if (agentName.includes('Requirement')) return '📝';
    if (agentName.includes('Validator')) return '🧪';
    return '📘';
}

/* ----------------------------------------------------
   Workspace Creation Modal
   ---------------------------------------------------- */
function setupModal() {
    const modal = document.getElementById('add-client-modal');
    const openBtn = document.getElementById('btn-add-client');
    const closeBtn = document.getElementById('client-modal-close-btn');
    const cancelBtn = document.getElementById('client-modal-cancel-btn');
    const form = document.getElementById('add-client-form');
    const submitBtn = document.getElementById('btn-submit-client');

    // Maturity slider bindings
    const sliderMaturity = document.getElementById('slider-client-maturity');
    const labelMaturity = document.getElementById('maturity-modal-value');
    if (sliderMaturity && labelMaturity) {
        sliderMaturity.addEventListener('input', (e) => {
            labelMaturity.textContent = parseFloat(e.target.value).toFixed(1);
        });
    }

    if (!modal) return;

    if (openBtn) {
        openBtn.addEventListener('click', () => {
            modal.classList.remove('hidden');
        });
    }

    const closeModal = () => modal.classList.add('hidden');

    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (cancelBtn) cancelBtn.addEventListener('click', closeModal);

    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const name = document.getElementById('input-client-name').value.trim();
            const domain = document.getElementById('input-client-domain').value.trim();
            const ratingVal = parseFloat(sliderMaturity ? sliderMaturity.value : "3.5") || 3.5;

            const domainKey = domain.toLowerCase().split(' ')[0] || 'data';

            // Simulate workspace initialization progress
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = "Creating Workspace...";
            }

            setTimeout(() => {
                const newClient = {
                    name: name,
                    domain: domain,
                    domainKey: domainKey,
                    runs: 0,
                    artifacts: 0,
                    maturity: ratingVal,
                    runId: 'Completed',
                    status: 'completed'
                };

                clients.push(newClient);
                localStorage.setItem('config_workspaces_clients', JSON.stringify(clients));
                
                showToast(`Workspace for ${name} created successfully.`, 'success');
                
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = "Create Workspace";
                }
                
                closeModal();
                form.reset();
                if (sliderMaturity && labelMaturity) {
                    sliderMaturity.value = 3.5;
                    labelMaturity.textContent = "3.5";
                }
                renderClients();
            }, 800);
        });
    }
}

/* ----------------------------------------------------
   Toast Notifications
   ---------------------------------------------------- */
function showToast(message, type = 'info') {
    const area = document.getElementById('toast-area');
    if (!area) return;
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <span class="toast-indicator"></span>
        <span class="toast-message">${message}</span>
        <span class="toast-close">&times;</span>
    `;

    toast.querySelector('.toast-close').addEventListener('click', () => {
        toast.classList.add('hide');
        setTimeout(() => toast.remove(), 300);
    });

    area.appendChild(toast);

    setTimeout(() => {
        if (toast.parentNode) {
            toast.classList.add('hide');
            setTimeout(() => toast.remove(), 300);
        }
    }, 4000);
}

// Mobile drawer controls
function setupMobileToggles() {
    const toggleSidebarBtn = document.getElementById('toggle-sidebar-btn');
    const toggleRightPanelBtn = document.getElementById('toggle-right-panel-btn');
    const sidebar = document.getElementById('sidebar');
    const commandPanel = document.getElementById('command-panel');

    if (toggleSidebarBtn) {
        toggleSidebarBtn.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            if (commandPanel) commandPanel.classList.remove('active');
        });
    }
    if (toggleRightPanelBtn && commandPanel) {
        toggleRightPanelBtn.addEventListener('click', () => {
            commandPanel.classList.toggle('active');
            sidebar.classList.remove('active');
        });
    }
}
window.setupMobileToggles = setupMobileToggles;
