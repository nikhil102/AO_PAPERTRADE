/* 
========================================================================
  Agentic SDLC AI Assistant - Usability Controller
========================================================================
*/

// Default initial projects (used if not already in localStorage)
const DEFAULT_PROJECTS = [
    {
        id: 'proj-1',
        name: 'Payroll Migration BRD',
        customer: 'Global Retail Corp',
        phase: 'Requirements & RTM',
        status: 'In Review',
        progress: 65,
        stepIndex: 4, // 0: Project Setup, 1: Upload, 2: Classify, 3: Generate, 4: A2H Review, 5: Sign-off
        runId: 'RUN-4892A',
        ingress: [
            { id: 'ing-1', name: 'Source payroll file schema', source: 'payroll_sample.csv', confidence: 96, action: 'Accept' },
            { id: 'ing-2', name: 'Employee database records', source: 'sow_payroll.pdf', confidence: 91, action: 'Accept' },
            { id: 'ing-3', name: 'Department cost-center links', source: 'meeting_notes.docx', confidence: 78, action: 'Accept' },
            { id: 'ing-4', name: 'Tax calculations rules', source: 'meeting_notes.docx', confidence: 94, action: 'Accept' },
            { id: 'ing-5', name: 'Threshold limit triggers', source: 'source_to_target_mapping.xlsx', confidence: 72, action: 'Accept' }
        ],
        egress: [
            { id: 'egr-1', name: 'W2 annual summary structure', source: 'source_to_target_mapping.xlsx', confidence: 95, action: 'Accept' },
            { id: 'egr-2', name: 'Direct deposit bank payloads', source: 'source_to_target_mapping.xlsx', confidence: 93, action: 'Accept' },
            { id: 'egr-3', name: 'Salary summary export CSV', source: 'payroll_sample.csv', confidence: 89, action: 'Accept' },
            { id: 'egr-4', name: 'Audit logs feed schema', source: 'meeting_notes.docx', confidence: 90, action: 'Accept' }
        ],
        chatHistory: [
            {
                sender: 'user',
                text: 'I want to create BRD and RTM for a payroll data migration project.',
                time: '10:24 AM'
            },
            {
                sender: 'ai',
                text: 'Sure. Please upload SOW, MOM, source files, sample data, existing templates, or any diagrams. I will classify them into Ingress and Egress.',
                time: '10:25 AM'
            },
            {
                sender: 'files',
                files: [
                    { name: 'sow_payroll.pdf', size: '2.4 MB', type: 'doc' },
                    { name: 'payroll_sample.csv', size: '480 KB', type: 'data' },
                    { name: 'source_to_target_mapping.xlsx', size: '1.2 MB', type: 'data' },
                    { name: 'meeting_notes.docx', size: '120 KB', type: 'doc' }
                ],
                time: '10:27 AM'
            },
            {
                sender: 'ai',
                text: 'I have received 4 files. I am analyzing project inputs.',
                time: '10:27 AM'
            },
            {
                sender: 'compact-progress',
                text: '5/5 Agents complete. Requirement classifications and spreadsheet outputs successfully drafted.',
                time: '10:28 AM'
            },
            {
                sender: 'ai',
                text: 'I found both Ingress and Egress requirements. Please review the classification.',
                time: '10:28 AM'
            },
            {
                sender: 'classifier',
                time: '10:29 AM'
            },
            {
                sender: 'ai',
                text: 'I generated draft BRDI, BRDE, RTMI, and RTME. These Excel outputs are ready for A2H review.',
                time: '10:30 AM'
            },
            {
                sender: 'artifacts',
                cards: [
                    { id: 'art-brdi', name: 'BRDI.xlsx', type: 'xls', agent: 'Template Agent', version: 'v1.0', confidence: 96, status: 'Review' },
                    { id: 'art-brde', name: 'BRDE.xlsx', type: 'xls', agent: 'Template Agent', version: 'v1.0', confidence: 94, status: 'Review' },
                    { id: 'art-rtmi', name: 'RTMI.xlsx', type: 'xls', agent: 'Requirement Agent', version: 'v1.0', confidence: 91, status: 'Review' },
                    { id: 'art-rtme', name: 'RTME.xlsx', type: 'xls', agent: 'Requirement Agent', version: 'v1.0', confidence: 92, status: 'Review' }
                ],
                time: '10:30 AM'
            }
        ],
        artifacts: [
            { id: 'art-deliv', name: 'Deliverables List', type: 'doc', agent: 'Deliverables Agent', version: 'v1.2', confidence: 95, status: 'Approved' },
            { id: 'art-tbrdi', name: 'TBRDI', type: 'doc', agent: 'Template Agent', version: 'v1.0', confidence: 93, status: 'Approved' },
            { id: 'art-tbrde', name: 'TBRDE', type: 'doc', agent: 'Template Agent', version: 'v1.0', confidence: 94, status: 'Approved' },
            { id: 'art-brdi', name: 'BRDI', type: 'xls', agent: 'Template Agent', version: 'v1.0', confidence: 96, status: 'Review' },
            { id: 'art-brde', name: 'BRDE', type: 'xls', agent: 'Template Agent', version: 'v1.0', confidence: 94, status: 'Review' },
            { id: 'art-rtmi', name: 'RTMI', type: 'xls', agent: 'Requirement Agent', version: 'v1.0', confidence: 91, status: 'Review' },
            { id: 'art-rtme', name: 'RTME', type: 'xls', agent: 'Requirement Agent', version: 'v1.0', confidence: 92, status: 'Review' },
            { id: 'art-land', name: 'Current Landscape Diagram', type: 'diagram', agent: 'Requirement Agent', version: 'v1.1', confidence: 90, status: 'Approved' },
            { id: 'art-tarch', name: 'Target Architecture Diagram', type: 'diagram', agent: 'Documenter Agent', version: 'v1.1', confidence: 95, status: 'Approved' }
        ],
        reviewQueue: [
            { id: 'art-brdi', name: 'BRDI.xlsx', confidence: 96, status: 'pending' },
            { id: 'art-brde', name: 'BRDE.xlsx', confidence: 94, status: 'pending' },
            { id: 'art-rtmi', name: 'RTMI.xlsx', confidence: 91, status: 'pending' },
            { id: 'art-rtme', name: 'RTME.xlsx', confidence: 92, status: 'pending' }
        ]
    },
    {
        id: 'proj-2',
        name: 'Customer 360 Egress Flow',
        customer: 'Horizon Telecom',
        phase: 'Data Mapping Spec',
        status: 'Draft',
        progress: 15,
        stepIndex: 1, // Shifted from 0 to 1
        runId: 'RUN-2104B',
        ingress: [],
        egress: [],
        chatHistory: [
            {
                sender: 'user',
                text: 'I want to map Customer 360 customer ingestion records to downstream CRM systems.',
                time: 'Yesterday'
            },
            {
                sender: 'ai',
                text: 'Welcome to the Customer 360 project workspace. Please upload the CRM JSON schema, source mapping details, or API payloads to begin. I will ingest the schema and map downstream outputs.',
                time: 'Yesterday'
            }
        ],
        artifacts: [
            { id: 'art-deliv-2', name: 'Deliverables List', type: 'doc', agent: 'Deliverables Agent', version: 'v1.0', confidence: 92, status: 'Draft' }
        ],
        reviewQueue: []
    },
    {
        id: 'proj-3',
        name: 'Databricks Modernization',
        customer: 'FinTech Solutions',
        phase: 'Production Baseline',
        status: 'Signed Off',
        progress: 100,
        stepIndex: 5, // Shifted from 4 to 5
        runId: 'RUN-8971F',
        ingress: [],
        egress: [],
        chatHistory: [
            {
                sender: 'user',
                text: 'Deploy baseline Spark configs for migration.',
                time: '06/10/2026'
            },
            {
                sender: 'ai',
                text: 'Running deployment rules. Databricks configuration schema verified successfully.',
                time: '06/10/2026'
            },
            {
                sender: 'ai',
                text: 'Validation completed. Project is Signed Off.',
                time: '06/10/2026'
            }
        ],
        artifacts: [
            { id: 'art-mod-3', name: 'Modernization Plan', type: 'doc', agent: 'Documenter Agent', version: 'v2.1', confidence: 98, status: 'Approved' },
            { id: 'art-mig-3', name: 'Migration Schema Mapping', type: 'xls', agent: 'Template Agent', version: 'v1.5', confidence: 96, status: 'Approved' },
            { id: 'art-final-3', name: 'Final Sign-off Certificate', type: 'doc', agent: 'Documenter Agent', version: 'v1.0', confidence: 99, status: 'Approved' },
            { id: 'art-word-base-3', name: 'Signed-off Word Baseline', type: 'doc', agent: 'Documenter Agent', version: 'v1.0', confidence: 98, status: 'Approved' },
            { id: 'art-excel-base-3', name: 'Signed-off Excel Baseline', type: 'xls', agent: 'Template Agent', version: 'v1.0', confidence: 97, status: 'Approved' }
        ],
        reviewQueue: []
    },
    {
        id: 'proj-4',
        name: 'Insurance Claims RTM',
        customer: 'SafeGuard Mutual',
        phase: 'QA validation',
        status: 'Signed Off',
        progress: 100,
        stepIndex: 5, // Shifted from 4 to 5
        runId: 'RUN-3312E',
        ingress: [],
        egress: [],
        chatHistory: [
            {
                sender: 'user',
                text: 'Verify insurance claims lifecycle test cases.',
                time: '05/28/2026'
            },
            {
                sender: 'ai',
                text: 'Test cases coverage is 100% mapped to requirements. Sign-off complete.',
                time: '05/28/2026'
            }
        ],
        artifacts: [
            { id: 'art-rtm-4', name: 'RTM Claims Mapping', type: 'xls', agent: 'Requirement Agent', version: 'v2.0', confidence: 97, status: 'Approved' },
            { id: 'art-test-4', name: 'Test Executions Log', type: 'doc', agent: 'Validator Agent', version: 'v1.2', confidence: 95, status: 'Approved' },
            { id: 'art-word-base-4', name: 'Signed-off Word Baseline', type: 'doc', agent: 'Documenter Agent', version: 'v1.0', confidence: 99, status: 'Approved' }
        ],
        reviewQueue: []
    }
];

// Initialize localStorage if not present
let savedProjects = localStorage.getItem('agentic_sdlc_projects');
if (savedProjects) {
    try {
        savedProjects = JSON.parse(savedProjects);
    } catch (e) {
        savedProjects = null;
    }
}
if (!savedProjects || !Array.isArray(savedProjects) || savedProjects.length === 0) {
    savedProjects = DEFAULT_PROJECTS;
    localStorage.setItem('agentic_sdlc_projects', JSON.stringify(savedProjects));
}

// Retrieve active project ID or default to 'proj-1'
const urlParams = new URLSearchParams(window.location.search);
let activeId = urlParams.get('projectId');
if (!activeId) {
    activeId = localStorage.getItem('agentic_sdlc_active_project_id') || 'proj-1';
} else {
    localStorage.setItem('agentic_sdlc_active_project_id', activeId);
}

// Application State
const state = {
    activeProjectId: activeId,
    rightPanelCollapsed: false,
    projects: savedProjects,
    agents: [
        { name: 'Deliverables Agent', status: 'idle', tokens: '14,289', confidence: 95, lastAction: 'Classified ingress rules', time: '0.8s', task: 'Idle' },
        { name: 'Template Agent', status: 'idle', tokens: '22,410', confidence: 91, lastAction: 'Generated BRDI draft', time: '1.4s', task: 'Idle' },
        { name: 'Requirement Agent', status: 'idle', tokens: '48,150', confidence: 89, lastAction: 'Mapped target KPIs', time: '2.1s', task: 'Idle' },
        { name: 'Validator Agent', status: 'idle', tokens: '8,014', confidence: 97, lastAction: 'Verified schemas', time: '0.5s', task: 'Idle' },
        { name: 'Documenter Agent', status: 'idle', tokens: '35,660', confidence: 94, lastAction: 'Compiled final baseline', time: '1.8s', task: 'Idle' }
    ],
    uploadedFilesQueue: [],
    selectedFeedbackArtifact: null
};

// Helper function to persist projects state
function saveProjectsToStorage() {
    localStorage.setItem('agentic_sdlc_projects', JSON.stringify(state.projects));
    localStorage.setItem('agentic_sdlc_active_project_id', state.activeProjectId);
}

// UI Selectors
const DOM = {
    appWrapper: document.getElementById('app-wrapper'),
    projectListContainer: document.getElementById('project-list-container'),
    activeProjectTitle: document.getElementById('active-project-title'),
    chatMessagesContainer: document.getElementById('chat-messages-container'),
    runIdText: document.getElementById('run-id-text'),
    runCustomerText: document.getElementById('run-customer-text'),
    runPhaseText: document.getElementById('run-phase-text'),
    runProgressPercent: document.getElementById('run-progress-percent'),
    runProgressBar: document.getElementById('run-progress-bar'),
    agentGridContainer: document.getElementById('agent-grid-container'),
    generatedArtifactsList: document.getElementById('generated-artifacts-list'),
    reviewQueueContainer: document.getElementById('review-queue-container'),
    a2hPendingCount: document.getElementById('a2h-metric-pending'),
    a2hStatusShield: document.getElementById('a2h-status-shield'),
    a2hShieldLabel: document.getElementById('a2h-shield-label'),
    a2hShieldTitle: document.getElementById('a2h-shield-title'),
    a2hMetricConfidence: document.getElementById('a2h-metric-confidence'),
    metricPendingBox: document.getElementById('metric-pending-box'),
    composerInput: document.getElementById('composer-input'),
    btnSend: document.getElementById('btn-send'),
    btnAttach: document.getElementById('btn-attach'),
    attachmentMenu: document.getElementById('attachment-menu-popup'),
    filePreviewsContainer: document.getElementById('file-previews-container'),
    btnStartRun: document.getElementById('btn-start-run'),
    btnExport: document.getElementById('btn-export'),
    btnCollapseRight: document.getElementById('btn-collapse-right'),
    projectSearch: document.getElementById('project-search'),
    btnNewProject: document.getElementById('btn-new-project'),
    newProjectModal: document.getElementById('new-project-modal'),
    modalCloseBtn: document.getElementById('modal-close-btn'),
    modalCancelBtn: document.getElementById('modal-cancel-btn'),
    newProjectForm: document.getElementById('new-project-form'),
    feedbackModal: document.getElementById('feedback-modal'),
    feedbackCloseBtn: document.getElementById('feedback-close-btn'),
    feedbackCancelBtn: document.getElementById('feedback-cancel-btn'),
    feedbackSubmitBtn: document.getElementById('feedback-submit-btn'),
    feedbackText: document.getElementById('feedback-text'),
    feedbackArtifactLabel: document.getElementById('feedback-artifact-label'),
    toastArea: document.getElementById('toast-area'),
    dragDropOverlay: document.getElementById('drag-drop-overlay'),
    toggleSidebarBtn: document.getElementById('toggle-sidebar-btn'),
    toggleRightPanelBtn: document.getElementById('toggle-right-panel-btn'),
    sidebar: document.getElementById('sidebar'),
    commandPanel: document.getElementById('command-panel'),
    stickyActionCard: document.getElementById('sticky-action-card'),
    stickyActionText: document.getElementById('sticky-action-text'),
    stickyActionBtnGroup: document.getElementById('sticky-action-btn-group'),
    badgeReview: document.getElementById('badge-tab-review'),
    badgeAgents: document.getElementById('badge-tab-agents'),
    badgeArtifacts: document.getElementById('badge-tab-artifacts'),
    runTabRecommendText: document.getElementById('run-tab-recommend-text'),
    runTabRecommendBtns: document.getElementById('run-tab-recommend-btns')
};

/* ----------------------------------------------------
   Initializer & Lifecycle
   ---------------------------------------------------- */
document.addEventListener('DOMContentLoaded', () => {
    initApp();
    setupEventListeners();
});

function initApp() {
    // Check if redirect has 'created=true'
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('created') === 'true') {
        // Remove query params from url without reloading page
        const newUrl = window.location.pathname;
        window.history.replaceState({}, document.title, newUrl);
        // Show success toast
        setTimeout(() => {
            showToast("Project created successfully. Continue by uploading project inputs.", "success");
        }, 300);
    }

    renderProjectList();
    loadProject(state.activeProjectId);
    renderAgents();
}

/* ----------------------------------------------------
   Rendering Engine
   ---------------------------------------------------- */

// Render Sidebar Project List
function renderProjectList(filter = '') {
    DOM.projectListContainer.innerHTML = '';
    const filteredProjects = state.projects.filter(p => 
        p.name.toLowerCase().includes(filter.toLowerCase()) || 
        p.customer.toLowerCase().includes(filter.toLowerCase())
    );

    if (filteredProjects.length === 0) {
        DOM.projectListContainer.innerHTML = `
            <div class="empty-state" style="padding: 20px;">
                <p style="font-size: 12px; color: var(--text-sidebar-muted);">No projects match search</p>
            </div>
        `;
        return;
    }

    filteredProjects.forEach(proj => {
        const isActive = proj.id === state.activeProjectId;
        const badgeClass = `badge-` + proj.status.toLowerCase().replace(' ', '');
        
        const item = document.createElement('div');
        item.className = `project-item ${isActive ? 'active' : ''}`;
        item.dataset.id = proj.id;
        item.innerHTML = `
            <div class="project-item-top">
                <span class="project-item-name">${proj.name}</span>
                <span class="badge ${badgeClass}">${proj.status}</span>
            </div>
            <span class="project-item-desc">${proj.customer}</span>
        `;
        item.addEventListener('click', () => {
            loadProject(proj.id);
            DOM.sidebar.classList.remove('active');
        });
        DOM.projectListContainer.appendChild(item);
    });
}

// Render Agent Grid in Right Panel
function renderAgents() {
    DOM.agentGridContainer.innerHTML = '';
    state.agents.forEach(agent => {
        let statusDotClass = 'pulse-dot';
        if (agent.status === 'active') statusDotClass += ' active';
        if (agent.status === 'working') statusDotClass += ' working';
        
        const card = document.createElement('div');
        card.className = 'agent-card-right';
        card.innerHTML = `
            <div class="agent-card-header">
                <div class="agent-header-left">
                    <span class="${statusDotClass}"></span>
                    <span class="agent-name-rt">${agent.name}</span>
                </div>
                <span class="agent-card-action-text text-primary">${agent.task}</span>
            </div>
            <div class="text-small text-muted" style="margin-top: 2px;">
                <strong>Last Action:</strong> ${agent.lastAction}
            </div>
            <div class="agent-card-stats">
                <span>Tokens: <strong class="text-monospace">${agent.tokens}</strong></span>
                <span>Conf: <strong class="text-primary">${agent.confidence}%</strong></span>
                <span>Time: <strong>${agent.time}</strong></span>
            </div>
        `;
        DOM.agentGridContainer.appendChild(card);
    });
}

// Render Stepper State
function renderStepper(stepIndex) {
    const steps = document.querySelectorAll('.stepper-step');
    steps.forEach(step => {
        const idx = parseInt(step.dataset.step);
        step.className = 'stepper-step';
        
        if (idx < stepIndex) {
            step.classList.add('completed');
        } else if (idx === stepIndex) {
            step.classList.add('active');
        } else {
            step.classList.add('pending');
        }
    });
}

// Update count badges and console headers inside right panel tabs
function updateRightPanelBadges(project) {
    // Review count
    const pendingReviewCount = project.reviewQueue.filter(q => q.status === 'pending' || q.status === 'changes-requested').length;
    DOM.badgeReview.textContent = pendingReviewCount;
    if (pendingReviewCount > 0) {
        DOM.badgeReview.classList.add('badge-warning');
        DOM.badgeReview.style.backgroundColor = 'var(--warning)';
        DOM.badgeReview.style.color = '#000000';
    } else {
        DOM.badgeReview.className = 'tab-badge';
        DOM.badgeReview.removeAttribute('style');
    }

    // A2H Gated count indicator
    DOM.a2hPendingCount.textContent = pendingReviewCount;

    // Average confidence metrics
    const avgConfidence = project.reviewQueue.length > 0 ? Math.round(project.reviewQueue.reduce((acc, q) => acc + q.confidence, 0) / project.reviewQueue.length) : 95;
    DOM.a2hMetricConfidence.textContent = `${avgConfidence}%`;

    // Swap A2H Console Card Active/Cleared Pulse States
    if (pendingReviewCount > 0) {
        DOM.a2hStatusShield.className = 'a2h-console-card active';
        DOM.a2hShieldLabel.textContent = 'GUARDRAIL ACTIVE';
        DOM.a2hShieldTitle.textContent = 'Supervisor Sign-off Required';
        DOM.metricPendingBox.className = 'metric-box box-amber';
    } else {
        DOM.a2hStatusShield.className = 'a2h-console-card cleared';
        DOM.a2hShieldLabel.textContent = 'GUARDRAIL CLEARED';
        DOM.a2hShieldTitle.textContent = 'All Checkpoints Approved';
        DOM.metricPendingBox.className = 'metric-box box-green';
    }

    // Agents online badge (static 5 in this demo context)
    DOM.badgeAgents.textContent = '5';

    // Artifacts badge
    DOM.badgeArtifacts.textContent = project.artifacts.length;
}

// Load Active Project State into Workspaces
function loadProject(projectId) {
    state.activeProjectId = projectId;
    const project = state.projects.find(p => p.id === projectId);
    if (!project) return;

    // Persist current state to localStorage
    saveProjectsToStorage();

    // Highlight sidebar active item
    document.querySelectorAll('.project-item').forEach(item => {
        if (item.dataset.id === projectId) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });

    // Update main titles & parameters
    DOM.activeProjectTitle.textContent = project.name;
    DOM.runIdText.textContent = project.runId;
    DOM.runCustomerText.textContent = project.customer;
    DOM.runPhaseText.textContent = project.phase;
    DOM.runProgressPercent.textContent = `${project.progress}%`;
    DOM.runProgressBar.style.width = `${project.progress}%`;

    // Render Stepper and Sticky action
    renderStepper(project.stepIndex);
    renderStickyActionCard(project);

    // Update count badges
    updateRightPanelBadges(project);

    // Update Compact header counts
    const agentsOnlineText = document.getElementById('agents-online-header-badge');
    const onlineBadge = document.getElementById('agents-completed-pill');
    if (project.stepIndex === 5) {
        agentsOnlineText.innerHTML = `<span class="pulse-dot active"></span> 5 Agents idle`;
        onlineBadge.textContent = `5/5 completed`;
    } else if (project.stepIndex === 3) {
        agentsOnlineText.innerHTML = `<span class="pulse-dot working"></span> Agents running`;
        onlineBadge.textContent = `Running Pipeline`;
    } else {
        agentsOnlineText.innerHTML = `<span class="pulse-dot active"></span> 5 Agents online`;
        onlineBadge.textContent = `5 Online`;
    }

    // Render Chat History
    renderChatHistory(project.chatHistory);

    // Render Sidebars Panel Elements
    renderGeneratedArtifacts(project.artifacts);
    renderReviewQueue(project.reviewQueue);
}

// Render Chat Message Stream
function renderChatHistory(history) {
    DOM.chatMessagesContainer.innerHTML = '';
    if (history.length === 0) {
        DOM.chatMessagesContainer.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                </div>
                <h3>Ingest Project Scope</h3>
                <p>Upload project SOW inputs or MOM checklists to initialize the agent analyzer.</p>
            </div>
        `;
        return;
    }

    history.forEach(msg => {
        appendMessageElement(msg);
    });
    scrollToBottom();
}

// Low level append message helper
function appendMessageElement(msg) {
    const isAI = msg.sender === 'ai';
    const isUser = msg.sender === 'user';
    const isFiles = msg.sender === 'files';
    const isCompactProgress = msg.sender === 'compact-progress';
    const isClassifier = msg.sender === 'classifier';
    const isArtifacts = msg.sender === 'artifacts';
    const isLoadingState = msg.sender === 'loading-run';

    if (isUser || isAI) {
        const wrap = document.createElement('div');
        wrap.className = `msg-wrapper ${msg.sender}`;
        wrap.innerHTML = `
            <div class="msg-sender">${isAI ? 'Agentic SDLC AI' : 'Human Supervisor'}</div>
            <div class="msg-bubble">${msg.text}</div>
            <div class="msg-time">${msg.time || getFormattedTime()}</div>
        `;
        DOM.chatMessagesContainer.appendChild(wrap);
    } else if (isLoadingState) {
        const wrap = document.createElement('div');
        wrap.className = 'msg-wrapper ai';
        wrap.innerHTML = `
            <div class="msg-sender">Agent fleet orchestrator</div>
            <div class="msg-bubble text-muted" style="display: flex; align-items: center; gap: 10px; background-color: var(--bg-card); border: 1px solid var(--border-color);">
                <span class="pulse-dot working"></span>
                <span>${msg.text}</span>
            </div>
        `;
        DOM.chatMessagesContainer.appendChild(wrap);
    } else if (isFiles) {
        const wrap = document.createElement('div');
        wrap.className = 'msg-wrapper user';
        let filesHtml = '';
        msg.files.forEach(f => {
            filesHtml += `
                <div class="file-card-bubble">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
                    <div class="file-card-info">
                        <div class="file-card-name" title="${f.name}">${f.name}</div>
                        <div class="file-card-size">${f.size}</div>
                    </div>
                </div>
            `;
        });
        wrap.innerHTML = `
            <div class="msg-sender">Human Supervisor</div>
            <div class="msg-bubble" style="background: var(--bg-bubble-user);">
                <span style="font-size: 13px; font-weight: 500; display: block; margin-bottom: 6px;">Uploaded inputs:</span>
                <div class="uploaded-files-msg">${filesHtml}</div>
            </div>
            <div class="msg-time">${msg.time || getFormattedTime()}</div>
        `;
        DOM.chatMessagesContainer.appendChild(wrap);
    } else if (isCompactProgress) {
        const wrap = document.createElement('div');
        wrap.className = 'msg-wrapper ai';
        wrap.innerHTML = `
            <div class="msg-sender">Agent pipeline status</div>
            <div class="agent-progress-card">
                <div class="agent-progress-header">
                    <span class="agent-progress-title">Agent Fleet Orchestration</span>
                    <span class="badge badge-success">5/5 Completed</span>
                </div>
                <div class="text-small" style="line-height: 1.4; color: var(--text-main);">
                    ${msg.text}
                </div>
            </div>
            <div class="msg-time">${msg.time || getFormattedTime()}</div>
        `;
        DOM.chatMessagesContainer.appendChild(wrap);
    } else if (isClassifier) {
        const wrap = document.createElement('div');
        wrap.className = 'msg-wrapper ai';
        
        const project = state.projects.find(p => p.id === state.activeProjectId);
        if (!project) return;

        // Ingress summary stats
        const totalIngress = project.ingress.length;
        const totalEgress = project.egress.length;
        const lowConfCount = project.ingress.filter(i => i.confidence < 80).length + project.egress.filter(e => e.confidence < 80).length;

        let ingressHtml = '';
        project.ingress.forEach(item => {
            const isLowConf = item.confidence < 80;
            const confBadge = `<span class="badge ${isLowConf ? 'badge-danger' : 'badge-success'}" style="font-size:9px; padding:0 4px;">${item.confidence}% conf</span>`;
            
            ingressHtml += `
                <li class="classifier-item-card ingress-card" id="card-${item.id}">
                    <div class="classifier-item-header">
                        <span class="classifier-item-name">${item.name}</span>
                        ${confBadge}
                    </div>
                    <span class="classifier-item-meta">Source: ${item.source}</span>
                    <select class="classifier-select-action" data-id="${item.id}" data-type="ingress">
                        <option value="Accept" ${item.action === 'Accept' ? 'selected' : ''}>Accept Ingress</option>
                        <option value="Move Egress">Move to Egress</option>
                        <option value="Clarification" ${item.action === 'Clarification' ? 'selected' : ''}>Needs Clarification</option>
                    </select>
                </li>
            `;
        });

        let egressHtml = '';
        project.egress.forEach(item => {
            const isLowConf = item.confidence < 80;
            const confBadge = `<span class="badge ${isLowConf ? 'badge-danger' : 'badge-success'}" style="font-size:9px; padding:0 4px;">${item.confidence}% conf</span>`;

            egressHtml += `
                <li class="classifier-item-card egress-card" id="card-${item.id}">
                    <div class="classifier-item-header">
                        <span class="classifier-item-name">${item.name}</span>
                        ${confBadge}
                    </div>
                    <span class="classifier-item-meta">Source: ${item.source}</span>
                    <select class="classifier-select-action" data-id="${item.id}" data-type="egress">
                        <option value="Accept" ${item.action === 'Accept' ? 'selected' : ''}>Accept Egress</option>
                        <option value="Move Ingress">Move to Ingress</option>
                        <option value="Clarification" ${item.action === 'Clarification' ? 'selected' : ''}>Needs Clarification</option>
                    </select>
                </li>
            `;
        });

        wrap.innerHTML = `
            <div class="msg-sender">Requirement classifier Agent</div>
            <div class="classifier-widget">
                <div class="agent-progress-header" style="margin-bottom: 4px;">
                    <span class="agent-progress-title">Ingress / Egress Matrix Mapping</span>
                    <span class="badge badge-success">Analyzed</span>
                </div>
                
                <div class="classifier-summary-row">
                    <span>Ingress Inputs: ${totalIngress} items</span>
                    <span>Egress Outputs: ${totalEgress} items</span>
                    <span class="${lowConfCount > 0 ? 'text-primary' : ''}">Low Confidence: ${lowConfCount} items</span>
                </div>

                <div class="classifier-grid">
                    <div class="classifier-column">
                        <div class="classifier-col-title col-ingress">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
                            Ingress (Inputs)
                        </div>
                        <ul class="classifier-list">${ingressHtml}</ul>
                    </div>
                    <div class="classifier-column">
                        <div class="classifier-col-title col-egress">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 21 3 21 3 15"></polyline><line x1="14" y1="10" x2="3" y2="21"></line></svg>
                            Egress (Outputs)
                        </div>
                        <ul class="classifier-list">${egressHtml}</ul>
                    </div>
                </div>
            </div>
            <div class="msg-time">${msg.time || getFormattedTime()}</div>
        `;
        DOM.chatMessagesContainer.appendChild(wrap);
        setupClassificationSelectListeners(wrap);
    } else if (isArtifacts) {
        const wrap = document.createElement('div');
        wrap.className = 'msg-wrapper ai';
        let cardsHtml = '';
        
        msg.cards.forEach(card => {
            let isApproved = card.status === 'Approved';
            let isReview = card.status === 'Review';
            let statusBadge = `<span class="badge badge-review">Review Pending</span>`;
            if (isApproved) statusBadge = `<span class="badge badge-success">Approved</span>`;
            if (card.status === 'Changes Requested') statusBadge = `<span class="badge badge-danger">Changes Requested</span>`;

            let actionButtons = '';
            if (isReview) {
                actionButtons = `
                    <div class="artifact-actions-chat">
                        <button class="btn btn-secondary review-chat-btn" data-id="${card.id}">Download</button>
                        <button class="btn btn-primary approve-chat-btn" data-id="${card.id}">Approve</button>
                    </div>
                `;
            } else if (card.status === 'Changes Requested') {
                actionButtons = `
                    <div class="artifact-actions-chat">
                        <button class="btn btn-secondary reingest-chat-btn" data-id="${card.id}">Re-ingest</button>
                        <button class="btn btn-primary approve-chat-btn" data-id="${card.id}">Approve</button>
                    </div>
                `;
            } else {
                actionButtons = `
                    <div class="artifact-actions-chat" style="grid-template-columns: 1fr;">
                        <span class="btn btn-secondary" style="border: none; cursor: default; background: var(--bg-input); color: var(--success);"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> Approved Checkpoint</span>
                    </div>
                `;
            }

            cardsHtml += `
                <div class="artifact-card-chat" id="chat-card-${card.id}">
                    <div class="artifact-card-top">
                        <div class="artifact-icon icon-excel">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="9" y1="3" x2="9" y2="21"></line><line x1="3" y1="9" x2="21" y2="9"></line></svg>
                        </div>
                        <div style="min-width: 0; flex-grow: 1;">
                            <div class="artifact-name">${card.name}</div>
                            <div class="artifact-meta-chat">By ${card.agent} &bull; V${card.version} &bull; <span class="confidence-pill">${card.confidence}% conf</span></div>
                        </div>
                    </div>
                    <div style="margin-top: 4px; display: flex; align-items: center; justify-content: space-between;">
                        <span class="text-small text-muted">A2H Checkpoint</span>
                        ${statusBadge}
                    </div>
                    ${actionButtons}
                </div>
            `;
        });

        wrap.innerHTML = `
            <div class="msg-sender">Deliverables compiler agent</div>
            <div style="width: 100%; max-width: 680px;">
                <div class="artifact-cards-grid">${cardsHtml}</div>
            </div>
            <div class="msg-time">${msg.time || getFormattedTime()}</div>
        `;
        DOM.chatMessagesContainer.appendChild(wrap);
        setupChatCardActions(wrap);
    }
}

// Render Generated Artifacts inside Tab 4
function renderGeneratedArtifacts(artifacts) {
    DOM.generatedArtifactsList.innerHTML = '';
    if (artifacts.length === 0) {
        DOM.generatedArtifactsList.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>
                </div>
                <p class="text-muted text-small" style="max-width: 200px;">No artifacts generated yet. Upload project inputs to begin.</p>
            </div>
        `;
        return;
    }

    artifacts.forEach(art => {
        let iconClass = 'icon-word';
        let iconSvg = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>`;

        if (art.type === 'xls') {
            iconClass = 'icon-excel';
            iconSvg = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="9" y1="3" x2="9" y2="21"></line><line x1="3" y1="9" x2="21" y2="9"></line></svg>`;
        } else if (art.type === 'diagram') {
            iconClass = 'icon-diagram';
            iconSvg = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9"></rect><rect x="14" y="3" width="7" height="5"></rect><rect x="14" y="12" width="7" height="9"></rect></svg>`;
        }

        const badgeClass = `badge-` + art.status.toLowerCase().replace(' ', '');

        const item = document.createElement('div');
        item.className = 'artifact-card-rt';
        item.innerHTML = `
            <div class="artifact-info-rt">
                <div class="artifact-icon ${iconClass}" style="width: 24px; height: 24px; border-radius: 4px;">
                    ${iconSvg}
                </div>
                <div class="artifact-details-rt">
                    <span class="art-title-rt" title="${art.name}">${art.name}</span>
                    <div class="art-badge-wrap">
                        <span class="art-type-badge art-type-${art.type}">${art.type}</span>
                        <span class="badge ${badgeClass}" style="padding: 0px 6px; font-size: 9px;">${art.status}</span>
                    </div>
                </div>
            </div>
            <div style="display: flex; gap: 2px;">
                <button class="icon-btn download-art-btn" data-name="${art.name}" title="Download Artifact">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline></svg>
                </button>
            </div>
        `;
        
        item.querySelector('.download-art-btn').addEventListener('click', (e) => {
            e.stopPropagation();
            showToast(`Downloading: ${art.name}`, 'info');
        });
        
        DOM.generatedArtifactsList.appendChild(item);
    });
}

// Render review items inside Tab 2
function renderReviewQueue(queue) {
    DOM.reviewQueueContainer.innerHTML = '';
    
    // Update KPI counters
    const count = queue.filter(q => q.status === 'pending' || q.status === 'changes-requested').length;
    
    if (count === 0) {
        DOM.reviewQueueContainer.innerHTML = `
            <div class="empty-state" style="padding: 20px;">
                <div class="empty-state-icon" style="width:48px; height:48px; background: rgba(16,185,129,0.08); color: var(--success);">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                </div>
                <h3>No human review pending</h3>
                <p class="text-muted text-small" style="max-width: 200px;">All generated Excel files are approved. Agent run can continue.</p>
            </div>
        `;
        return;
    }

    queue.forEach(item => {
        let badgeClass = 'badge-warning';
        if (item.status === 'approved') badgeClass = 'badge-success';
        if (item.status === 'changes-requested') badgeClass = 'badge-danger';

        const card = document.createElement('div');
        card.className = `review-item-rt ${item.status}`;
        card.innerHTML = `
            <div class="review-item-header-rt">
                <span class="review-item-name-rt">${item.name}</span>
                <span class="badge ${badgeClass}">${item.status.replace('-', ' ')}</span>
            </div>
            <span class="review-item-meta-rt">Confidence: ${item.confidence}% &bull; A2H Checkpoint</span>
            <div class="review-actions-row">
                <button class="btn btn-secondary req-changes-rt-btn" data-id="${item.id}" ${item.status === 'approved' ? 'disabled' : ''}>Change</button>
                <button class="btn btn-secondary reingest-rt-btn" data-id="${item.id}" ${item.status === 'approved' ? 'disabled' : ''}>Re-ingest</button>
                <button class="btn btn-primary approve-rt-btn" data-id="${item.id}" ${item.status === 'approved' ? 'disabled' : ''}>Approve</button>
            </div>
        `;
        
        card.querySelector('.approve-rt-btn').addEventListener('click', () => {
            approveArtifact(item.id);
        });
        card.querySelector('.req-changes-rt-btn').addEventListener('click', () => {
            openFeedbackModal(item.id, item.name);
        });
        card.querySelector('.reingest-rt-btn').addEventListener('click', () => {
            simulateReingest(item.id, item.name);
        });

        DOM.reviewQueueContainer.appendChild(card);
    });
}

// Render dynamic recommended action banner in chat AND Tab 1 recommended action slot
function renderStickyActionCard(project) {
    DOM.stickyActionCard.classList.add('hidden');
    DOM.stickyActionBtnGroup.innerHTML = '';
    DOM.runTabRecommendBtns.innerHTML = '';

    // Step 1: Upload inputs
    if (project.stepIndex === 1) {
        const descText = 'Ingest project documents to map source fields and build RTM baseline schemas.';
        
        DOM.stickyActionCard.classList.remove('hidden');
        DOM.stickyActionText.innerHTML = descText;
        DOM.stickyActionBtnGroup.innerHTML = `<button class="btn btn-primary" id="sticky-btn-upload">Upload Files</button>`;
        
        DOM.runTabRecommendText.innerHTML = descText;
        DOM.runTabRecommendBtns.innerHTML = `<button class="btn btn-primary" id="tab-btn-upload">Upload Files</button>`;

        const triggerUpload = () => {
            DOM.composerInput.focus();
            DOM.btnAttach.click();
        };
        document.getElementById('sticky-btn-upload').addEventListener('click', triggerUpload);
        document.getElementById('tab-btn-upload').addEventListener('click', triggerUpload);
    }
    // Step 2: Run mapping (files uploaded but run not started)
    else if (project.stepIndex === 2) {
        const descText = 'Inputs ingested. Run automated SDLC agents to classify fields into Ingress/Egress layers.';
        
        DOM.stickyActionCard.classList.remove('hidden');
        DOM.stickyActionText.innerHTML = descText;
        DOM.stickyActionBtnGroup.innerHTML = `<button class="btn btn-primary" id="sticky-btn-startrun">Start Agent Run</button>`;
        
        DOM.runTabRecommendText.innerHTML = descText;
        DOM.runTabRecommendBtns.innerHTML = `<button class="btn btn-primary" id="tab-btn-startrun">Start Agent Run</button>`;

        const triggerRun = () => {
            triggerAgentPipelineRun();
        };
        document.getElementById('sticky-btn-startrun').addEventListener('click', triggerRun);
        document.getElementById('tab-btn-startrun').addEventListener('click', triggerRun);
    }
    // Step 4: A2H Review (reviewing Excel spreadsheets)
    else if (project.stepIndex === 4) {
        const pendingItem = project.reviewQueue.find(q => q.status === 'pending' || q.status === 'changes-requested');
        
        if (pendingItem) {
            const descText = `Awaiting supervisor sign-off on <strong>${pendingItem.name}</strong> before Word compilation.`;
            
            DOM.stickyActionCard.classList.remove('hidden');
            DOM.stickyActionText.innerHTML = descText;
            DOM.runTabRecommendText.innerHTML = descText;
            
            if (pendingItem.status === 'changes-requested') {
                const buttonsHtml = `
                    <button class="btn btn-secondary recommend-reingest-btn">Re-ingest Excel</button>
                    <button class="btn btn-primary recommend-approve-btn">Approve Checkpoint</button>
                `;
                DOM.stickyActionBtnGroup.innerHTML = buttonsHtml;
                DOM.runTabRecommendBtns.innerHTML = buttonsHtml;

                const triggerReingest = () => simulateReingest(pendingItem.id, pendingItem.name);
                const triggerApprove = () => approveArtifact(pendingItem.id);

                DOM.stickyActionBtnGroup.querySelector('.recommend-reingest-btn').addEventListener('click', triggerReingest);
                DOM.runTabRecommendBtns.querySelector('.recommend-reingest-btn').addEventListener('click', triggerReingest);

                DOM.stickyActionBtnGroup.querySelector('.recommend-approve-btn').addEventListener('click', triggerApprove);
                DOM.runTabRecommendBtns.querySelector('.recommend-approve-btn').addEventListener('click', triggerApprove);
            } else {
                const buttonsHtml = `
                    <button class="btn btn-secondary recommend-changes-btn">Request Changes</button>
                    <button class="btn btn-primary recommend-approve-btn">Approve Checkpoint</button>
                `;
                DOM.stickyActionBtnGroup.innerHTML = buttonsHtml;
                DOM.runTabRecommendBtns.innerHTML = buttonsHtml;

                const triggerChanges = () => openFeedbackModal(pendingItem.id, pendingItem.name);
                const triggerApprove = () => approveArtifact(pendingItem.id);

                DOM.stickyActionBtnGroup.querySelector('.recommend-changes-btn').addEventListener('click', triggerChanges);
                DOM.runTabRecommendBtns.querySelector('.recommend-changes-btn').addEventListener('click', triggerChanges);

                DOM.stickyActionBtnGroup.querySelector('.recommend-approve-btn').addEventListener('click', triggerApprove);
                DOM.runTabRecommendBtns.querySelector('.recommend-approve-btn').addEventListener('click', triggerApprove);
            }
        } else {
            const descText = 'All Excel checkpoints approved. Proceed to compile Word baseline artifacts.';
            
            DOM.stickyActionCard.classList.remove('hidden');
            DOM.stickyActionText.innerHTML = descText;
            DOM.stickyActionBtnGroup.innerHTML = `<button class="btn btn-primary" id="sticky-btn-compile">Generate Final Baseline</button>`;
            
            DOM.runTabRecommendText.innerHTML = descText;
            DOM.runTabRecommendBtns.innerHTML = `<button class="btn btn-primary" id="tab-btn-compile">Generate Final Baseline</button>`;

            const triggerWordCompile = () => {
                triggerWordCompilation(project);
            };
            document.getElementById('sticky-btn-compile').addEventListener('click', triggerWordCompile);
            document.getElementById('tab-btn-compile').addEventListener('click', triggerWordCompile);
        }
    } else if (project.stepIndex === 5) {
        const descText = 'SDLC baseline generated and locked. Package artifacts for release baseline.';
        DOM.runTabRecommendText.innerHTML = descText;
        DOM.runTabRecommendBtns.innerHTML = `<button class="btn btn-primary" id="tab-btn-export-pkg">Download Baseline Package</button>`;
        document.getElementById('tab-btn-export-pkg').addEventListener('click', () => {
            showToast(`Downloading signed-off SDLC baseline package...`, 'success');
        });
    }
}

/* ----------------------------------------------------
   Interactions & State Mutators
   ---------------------------------------------------- */

// Setup dropdown selectors on Ingress/Egress matrix card
function setupClassificationSelectListeners(container) {
    container.querySelectorAll('.classifier-select-action').forEach(select => {
        select.addEventListener('change', (e) => {
            const id = e.target.dataset.id;
            const type = e.target.dataset.type;
            const newVal = e.target.value;
            
            const project = state.projects.find(p => p.id === state.activeProjectId);
            if (!project) return;

            let item = null;
            if (type === 'ingress') {
                item = project.ingress.find(i => i.id === id);
            } else {
                item = project.egress.find(e => e.id === id);
            }

            if (!item) return;

            if (newVal === 'Move Egress' && type === 'ingress') {
                project.ingress = project.ingress.filter(i => i.id !== id);
                item.id = 'egr-' + Math.random().toString(36).substr(2, 9);
                item.action = 'Accept';
                project.egress.push(item);
                showToast(`Moved ${item.name} to Egress outputs.`, 'info');
                loadProject(state.activeProjectId);
            } else if (newVal === 'Move Ingress' && type === 'egress') {
                project.egress = project.egress.filter(e => e.id !== id);
                item.id = 'ing-' + Math.random().toString(36).substr(2, 9);
                item.action = 'Accept';
                project.ingress.push(item);
                showToast(`Moved ${item.name} to Ingress inputs.`, 'info');
                loadProject(state.activeProjectId);
            } else if (newVal === 'Clarification') {
                item.action = 'Clarification';
                showToast(`Flagged ${item.name} for clarification.`, 'warning');
                loadProject(state.activeProjectId);
            } else if (newVal === 'Accept') {
                item.action = 'Accept';
                item.confidence = 99;
                showToast(`Accepted mapping for ${item.name}.`, 'success');
                loadProject(state.activeProjectId);
            }
        });
    });
}

// Attach event listeners to chat message buttons
function setupChatCardActions(container) {
    container.querySelectorAll('.approve-chat-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const id = e.target.dataset.id;
            approveArtifact(id);
        });
    });

    container.querySelectorAll('.reingest-chat-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const id = e.target.dataset.id;
            const project = state.projects.find(p => p.id === state.activeProjectId);
            const card = project.chatHistory.find(c => c.sender === 'artifacts').cards.find(c => c.id === id);
            simulateReingest(id, card.name);
        });
    });
}

// Approve an artifact (from chat or queue)
function approveArtifact(artifactId) {
    const project = state.projects.find(p => p.id === state.activeProjectId);
    if (!project) return;

    // Update Project Artifact state
    const art = project.artifacts.find(a => a.id === artifactId);
    if (art) art.status = 'Approved';

    // Update Review Queue state
    const qItem = project.reviewQueue.find(q => q.id === artifactId);
    if (qItem) qItem.status = 'approved';

    // Update Chat History Card State
    const artifactsMsg = project.chatHistory.find(c => c.sender === 'artifacts');
    if (artifactsMsg) {
        const chatCard = artifactsMsg.cards.find(c => c.id === artifactId);
        if (chatCard) chatCard.status = 'Approved';
    }

    loadProject(state.activeProjectId);
    showToast(`Approved ${art ? art.name : artifactId} checkpoint.`, 'success');
}

// Trigger Word compilation upon final approval
function triggerWordCompilation(project) {
    showTypingIndicator();
    project.chatHistory.push({
        sender: 'loading-run',
        text: 'Documenter Agent compiling final Word baseline and audit trails...'
    });
    scrollToBottom();

    setTimeout(() => {
        removeTypingIndicator();
        
        project.chatHistory = project.chatHistory.filter(h => h.sender !== 'loading-run');
        
        project.status = 'Signed Off';
        project.progress = 100;
        project.phase = 'Production Baseline';
        project.stepIndex = 5; // Sign-off state
        
        project.reviewQueue = [];

        // Ingest final baselines to artifacts list
        project.artifacts.push(
            { id: 'art-word-base', name: 'Signed-off Word Baseline', type: 'doc', agent: 'Documenter Agent', version: 'v1.0', confidence: 99, status: 'Approved' },
            { id: 'art-excel-base', name: 'Signed-off Excel Baseline', type: 'xls', agent: 'Template Agent', version: 'v1.0', confidence: 98, status: 'Approved' }
        );

        project.chatHistory.push({
            sender: 'ai',
            text: '🎉 **All Excel checkpoints approved by Human Supervisor.**<br><br>Final signed-off deliverables compiled: **Signed-off Word Baseline** and **Signed-off Excel Baseline** are generated and ready for release. SDLC baseline locked.',
            time: getFormattedTime()
        });

        showToast('Final baselines generated. Project Signed Off.', 'success');
        
        loadProject(state.activeProjectId);
        renderProjectList();
    }, 2000);
}

// Feedback Dialog setup
function openFeedbackModal(artifactId, artifactName) {
    state.selectedFeedbackArtifact = { id: artifactId, name: artifactName };
    DOM.feedbackArtifactLabel.textContent = artifactName;
    DOM.feedbackText.value = '';
    DOM.feedbackModal.classList.remove('hidden');
}

function submitFeedback() {
    const feedback = DOM.feedbackText.value.trim();
    if (!feedback) {
        showToast('Please type feedback suggestions.', 'warning');
        return;
    }

    const artifactId = state.selectedFeedbackArtifact.id;
    const artifactName = state.selectedFeedbackArtifact.name;
    const project = state.projects.find(p => p.id === state.activeProjectId);
    if (!project) return;

    // Update Status to "Changes Requested"
    const art = project.artifacts.find(a => a.id === artifactId);
    if (art) art.status = 'Changes Requested';

    const qItem = project.reviewQueue.find(q => q.id === artifactId);
    if (qItem) qItem.status = 'changes-requested';

    const artifactsMsg = project.chatHistory.find(c => c.sender === 'artifacts');
    if (artifactsMsg) {
        const chatCard = artifactsMsg.cards.find(c => c.id === artifactId);
        if (chatCard) chatCard.status = 'Changes Requested';
    }

    DOM.feedbackModal.classList.add('hidden');

    project.chatHistory.push({
        sender: 'user',
        text: `**Requested Changes for ${artifactName}**:<br>"${feedback}"`,
        time: getFormattedTime()
    });

    loadProject(state.activeProjectId);
    showToast(`Changes requested for ${artifactName}`, 'warning');

    // Trigger Agent response
    showTypingIndicator();
    setTimeout(() => {
        removeTypingIndicator();
        project.chatHistory.push({
            sender: 'ai',
            text: `Feedback received. Adjusting mapping variables for **${artifactName}**. Adjust the source files or parameters, then click **Re-ingest** to recheck rules.`,
            time: getFormattedTime()
        });
        loadProject(state.activeProjectId);
    }, 1500);
}

// Simulate re-ingesting spreadsheets after edit
function simulateReingest(artifactId, artifactName) {
    showToast(`Re-ingesting updated ${artifactName}...`, 'info');
    
    const project = state.projects.find(p => p.id === state.activeProjectId);
    if (!project) return;

    project.chatHistory.push({
        sender: 'loading-run',
        text: `Validator Agent parsing corrected rules for ${artifactName}...`
    });
    scrollToBottom();

    project.progress = 75;
    DOM.runProgressPercent.textContent = '75%';
    DOM.runProgressBar.style.width = '75%';

    state.agents[3].status = 'active';
    state.agents[3].lastAction = `Parsing recheck parameters on ${artifactName}...`;
    renderAgents();

    setTimeout(() => {
        state.agents[3].status = 'idle';
        state.agents[3].lastAction = `Re-verified schemas. Checks passed.`;
        renderAgents();

        project.chatHistory = project.chatHistory.filter(h => h.sender !== 'loading-run');

        const art = project.artifacts.find(a => a.id === artifactId);
        if (art) art.status = 'Approved';

        const qItem = project.reviewQueue.find(q => q.id === artifactId);
        if (qItem) qItem.status = 'approved';

        const artifactsMsg = project.chatHistory.find(c => c.sender === 'artifacts');
        if (artifactsMsg) {
            const chatCard = artifactsMsg.cards.find(c => c.id === artifactId);
            if (chatCard) {
                chatCard.status = 'Approved';
                chatCard.confidence = 98;
            }
        }

        project.chatHistory.push({
            sender: 'ai',
            text: `Successfully re-ingested **${artifactName}**. Code discrepancies corrected. Accuracy rating boosted to **98% confidence**. Checkpoint verified.`,
            time: getFormattedTime()
        });

        showToast(`Edited Excel ${artifactName} re-ingested successfully.`, 'success');
        loadProject(state.activeProjectId);
    }, 2000);
}

/* ----------------------------------------------------
   New Message sending & typing
   ---------------------------------------------------- */
function handleSendMessage() {
    const text = DOM.composerInput.value.trim();
    const hasFiles = state.uploadedFilesQueue.length > 0;

    if (!text && !hasFiles) return;

    const project = state.projects.find(p => p.id === state.activeProjectId);
    if (!project) return;

    // 1. Ingest files first if queue not empty
    if (hasFiles) {
        project.chatHistory.push({
            sender: 'files',
            files: [...state.uploadedFilesQueue],
            time: getFormattedTime()
        });
        state.uploadedFilesQueue = [];
        DOM.filePreviewsContainer.innerHTML = '';
        DOM.filePreviewsContainer.classList.add('hidden');
        project.stepIndex = 2;
        project.progress = 20;
    }

    // 2. Add text message if present
    if (text) {
        project.chatHistory.push({
            sender: 'user',
            text: text,
            time: getFormattedTime()
        });
        DOM.composerInput.value = '';
    }

    loadProject(state.activeProjectId);

    showTypingIndicator();
    setTimeout(() => {
        removeTypingIndicator();
        
        let responseText = '';
        let triggerRun = false;
        
        const lowerText = text.toLowerCase();
        
        if (lowerText.includes('run') || lowerText.includes('start') || lowerText.includes('generate')) {
            responseText = 'Directing the agent pipeline to execute generation check metrics. Initiating Run parameters.';
            triggerRun = true;
        } else if (hasFiles) {
            responseText = `I have received the files. The workspace has transitioned to the next phase. Let's initiate the agent run to classify the inputs and map deliverables. Click **Start Agent Run** below or in the header to execute.`;
        } else if (lowerText.includes('missing') || lowerText.includes('sow') || lowerText.includes('template')) {
            responseText = 'Uploading local templates or schemas will train the validator checkpoints. Please select MOM or Code from the Attach popover to ingest.';
        } else if (lowerText.includes('rtm') || lowerText.includes('coverage')) {
            responseText = 'RTMI coverage is currently 91%. Two requirements are currently flagged for review. Review the Ingress/Egress matrix cards in chat.';
        } else {
            responseText = `I am ready to process your inputs. Upload documents (SOW, MOM, schema files) to partition requirements, or request checklist runs.`;
        }

        project.chatHistory.push({
            sender: 'ai',
            text: responseText,
            time: getFormattedTime()
        });

        loadProject(state.activeProjectId);

        if (triggerRun) {
            triggerAgentPipelineRun();
        }
    }, 1500);
}

// Typing Indicator helpers
function showTypingIndicator() {
    const ind = document.createElement('div');
    ind.className = 'msg-wrapper ai';
    ind.id = 'typing-indicator-node';
    ind.innerHTML = `
        <div class="msg-sender">Agentic SDLC AI</div>
        <div class="msg-bubble typing-bubble">
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
        </div>
    `;
    DOM.chatMessagesContainer.appendChild(ind);
    scrollToBottom();
}

function removeTypingIndicator() {
    const node = document.getElementById('typing-indicator-node');
    if (node) node.remove();
}

/* ----------------------------------------------------
   Simulation: File Upload Pipeline
   ---------------------------------------------------- */
function simulateFileUpload(type) {
    DOM.attachmentMenu.classList.add('hidden');
    
    let fileName = '';
    let fileSize = '';
    if (type === 'doc') { fileName = 'sow_contract_draft.pdf'; fileSize = '1.8 MB'; }
    else if (type === 'data') { fileName = 'data_dictionary_v2.xlsx'; fileSize = '920 KB'; }
    else if (type === 'code') { fileName = 'claims_processing_schema.sql'; fileSize = '45 KB'; }
    else if (type === 'diagram') { fileName = 'current_network_topology.png'; fileSize = '1.4 MB'; }
    else if (type === 'mom') { fileName = 'mom_workshop_june.docx'; fileSize = '85 KB'; }
    else if (type === 'ui') { fileName = 'claims_dashboard_wireframe.png'; fileSize = '2.1 MB'; }

    DOM.filePreviewsContainer.classList.remove('hidden');
    const progId = 'prog-' + Math.random().toString(36).substr(2, 9);
    
    const chip = document.createElement('div');
    chip.className = 'uploading-progress-chip';
    chip.id = progId;
    chip.innerHTML = `
        <span>Uploading ${fileName}...</span>
        <div class="uploading-bar">
            <div class="uploading-bar-fill" id="${progId}-fill"></div>
        </div>
    `;
    DOM.filePreviewsContainer.appendChild(chip);

    setTimeout(() => {
        const fill = document.getElementById(`${progId}-fill`);
        if (fill) fill.style.width = '100%';
    }, 100);

    setTimeout(() => {
        const item = document.getElementById(progId);
        if (item) item.remove();

        state.uploadedFilesQueue.push({ name: fileName, size: fileSize, type: type });

        const fileChip = document.createElement('div');
        fileChip.className = 'file-preview-chip';
        fileChip.innerHTML = `
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>
            <span>${fileName}</span>
            <div class="preview-progress-bar">
                <div class="preview-progress-fill"></div>
            </div>
            <span class="chip-remove" data-name="${fileName}">&times;</span>
        `;
        
        fileChip.querySelector('.chip-remove').addEventListener('click', (e) => {
            const name = e.target.dataset.name;
            state.uploadedFilesQueue = state.uploadedFilesQueue.filter(f => f.name !== name);
            fileChip.remove();
            if (state.uploadedFilesQueue.length === 0) DOM.filePreviewsContainer.classList.add('hidden');
        });

        DOM.filePreviewsContainer.appendChild(fileChip);
        showToast(`File ${fileName} uploaded successfully.`, 'success');
    }, 1300);
}

/* ----------------------------------------------------
   Simulation: Agent Run Execution
   ---------------------------------------------------- */
function triggerAgentPipelineRun() {
    const project = state.projects.find(p => p.id === state.activeProjectId);
    if (!project) return;

    project.stepIndex = 3;
    project.progress = 30;
    project.status = 'In Review';
    loadProject(state.activeProjectId);
    
    const headerGlow = document.querySelector('.chat-header .pulse-dot');
    if (headerGlow) {
        headerGlow.className = 'pulse-dot working';
    }

    showToast('Agent SDLC Run started.', 'info');

    // Step 1: Analyzing files loading indicators in chat
    project.chatHistory.push({
        sender: 'loading-run',
        text: 'Deliverables Agent parsing schemas and MOM files...'
    });
    loadProject(state.activeProjectId);

    state.agents[0].status = 'active';
    state.agents[0].task = 'Parsing files';
    state.agents[0].lastAction = 'Analyzing sow_contract_draft.pdf';
    renderAgents();

    // Step 2: (1.5s) Ingest next loading state
    setTimeout(() => {
        project.chatHistory = project.chatHistory.filter(h => h.sender !== 'loading-run');
        project.chatHistory.push({
            sender: 'loading-run',
            text: 'Template Agent drafting column boundaries and business validation checks...'
        });
        project.progress = 50;
        loadProject(state.activeProjectId);

        state.agents[0].status = 'idle';
        state.agents[0].task = 'Idle';
        state.agents[0].lastAction = 'Completed schema classification';
        state.agents[1].status = 'active';
        state.agents[1].task = 'Compiling layouts';
        state.agents[1].lastAction = 'Formatting Excel cells';
        renderAgents();
    }, 1500);

    // Step 3: (3s) Requirement Agent compiling KPIs
    setTimeout(() => {
        project.chatHistory = project.chatHistory.filter(h => h.sender !== 'loading-run');
        project.chatHistory.push({
            sender: 'loading-run',
            text: 'Requirement Agent compiling final RTM mapping arrays...'
        });
        project.progress = 70;
        loadProject(state.activeProjectId);

        state.agents[1].status = 'idle';
        state.agents[1].task = 'Idle';
        state.agents[2].status = 'active';
        state.agents[2].task = 'Linking checks';
        state.agents[2].lastAction = 'Verifying test case matrix rules';
        renderAgents();
    }, 3000);

    // Step 4: (4.5s) Completion
    setTimeout(() => {
        project.chatHistory = project.chatHistory.filter(h => h.sender !== 'loading-run');
        project.stepIndex = 4;
        project.progress = 85;

        state.agents.forEach(a => {
            a.status = 'idle';
            a.task = 'Idle';
        });
        state.agents[0].lastAction = 'Classified ingress rules';
        state.agents[1].lastAction = 'Generated BRDI draft';
        state.agents[2].lastAction = 'Mapped target KPIs';
        state.agents[3].lastAction = 'Verified schemas';
        state.agents[4].lastAction = 'Compiled final baseline';
        renderAgents();

        if (headerGlow) {
            headerGlow.className = 'pulse-dot active';
        }

        project.chatHistory.push({
            sender: 'compact-progress',
            text: '5/5 agents finished processing. Excel matrices generated successfully.',
            time: getFormattedTime()
        });

        project.ingress = [
            { id: 'ing-1', name: 'Source payroll file schema', source: 'payroll_sample.csv', confidence: 96, action: 'Accept' },
            { id: 'ing-2', name: 'Employee database records', source: 'sow_payroll.pdf', confidence: 91, action: 'Accept' },
            { id: 'ing-3', name: 'Department cost-center links', source: 'meeting_notes.docx', confidence: 78, action: 'Accept' },
            { id: 'ing-4', name: 'Tax calculations rules', source: 'meeting_notes.docx', confidence: 94, action: 'Accept' },
            { id: 'ing-5', name: 'Threshold limit triggers', source: 'source_to_target_mapping.xlsx', confidence: 72, action: 'Accept' }
        ];
        project.egress = [
            { id: 'egr-1', name: 'W2 annual summary structure', source: 'source_to_target_mapping.xlsx', confidence: 95, action: 'Accept' },
            { id: 'egr-2', name: 'Direct deposit bank payloads', source: 'source_to_target_mapping.xlsx', confidence: 93, action: 'Accept' },
            { id: 'egr-3', name: 'Salary summary export CSV', source: 'payroll_sample.csv', confidence: 89, action: 'Accept' },
            { id: 'egr-4', name: 'Audit logs feed schema', source: 'meeting_notes.docx', confidence: 90, action: 'Accept' }
        ];

        project.chatHistory.push({
            sender: 'classifier',
            time: getFormattedTime()
        });

        project.chatHistory.push({
            sender: 'ai',
            text: 'Ingress and Egress criteria mapped. I have compiled draft BRDI, BRDE, RTMI, and RTME excel checkcards below. Please review checkpoints.',
            time: getFormattedTime()
        });

        project.artifacts = [
            { id: 'art-deliv', name: 'Deliverables List', type: 'doc', agent: 'Deliverables Agent', version: 'v1.2', confidence: 95, status: 'Approved' },
            { id: 'art-tbrdi', name: 'TBRDI', type: 'doc', agent: 'Template Agent', version: 'v1.0', confidence: 93, status: 'Approved' },
            { id: 'art-tbrde', name: 'TBRDE', type: 'doc', agent: 'Template Agent', version: 'v1.0', confidence: 94, status: 'Approved' },
            { id: 'art-brdi', name: 'BRDI', type: 'xls', agent: 'Template Agent', version: 'v1.0', confidence: 96, status: 'Review' },
            { id: 'art-brde', name: 'BRDE', type: 'xls', agent: 'Template Agent', version: 'v1.0', confidence: 94, status: 'Review' },
            { id: 'art-rtmi', name: 'RTMI', type: 'xls', agent: 'Requirement Agent', version: 'v1.0', confidence: 91, status: 'Review' },
            { id: 'art-rtme', name: 'RTME', type: 'xls', agent: 'Requirement Agent', version: 'v1.0', confidence: 92, status: 'Review' },
            { id: 'art-land', name: 'Current Landscape Diagram', type: 'diagram', agent: 'Requirement Agent', version: 'v1.1', confidence: 90, status: 'Approved' },
            { id: 'art-tarch', name: 'Target Architecture Diagram', type: 'diagram', agent: 'Documenter Agent', version: 'v1.1', confidence: 95, status: 'Approved' }
        ];

        project.chatHistory.push({
            sender: 'artifacts',
            cards: [
                { id: 'art-brdi', name: 'BRDI.xlsx', type: 'xls', agent: 'Template Agent', version: 'v1.0', confidence: 96, status: 'Review' },
                { id: 'art-brde', name: 'BRDE.xlsx', type: 'xls', agent: 'Template Agent', version: 'v1.0', confidence: 94, status: 'Review' },
                { id: 'art-rtmi', name: 'RTMI.xlsx', type: 'xls', agent: 'Requirement Agent', version: 'v1.0', confidence: 91, status: 'Review' },
                { id: 'art-rtme', name: 'RTME.xlsx', type: 'xls', agent: 'Requirement Agent', version: 'v1.0', confidence: 92, status: 'Review' }
            ],
            time: getFormattedTime()
        });

        project.reviewQueue = [
            { id: 'art-brdi', name: 'BRDI.xlsx', confidence: 96, status: 'pending' },
            { id: 'art-brde', name: 'BRDE.xlsx', confidence: 94, status: 'pending' },
            { id: 'art-rtmi', name: 'RTMI.xlsx', confidence: 91, status: 'pending' },
            { id: 'art-rtme', name: 'RTME.xlsx', confidence: 92, status: 'pending' }
        ];

        loadProject(state.activeProjectId);
        showToast('BRDI, BRDE drafts compiled. Stepping to A2H review.', 'success');
        
        document.getElementById('btn-tab-review').click();
    }, 4500);
}

/* ----------------------------------------------------
   Project Creation Modal Form
   ---------------------------------------------------- */
function createNewProject(e) {
    e.preventDefault();
    
    const name = document.getElementById('new-project-name').value.trim();
    const customer = document.getElementById('new-project-customer').value.trim();

    if (!name || !customer) return;

    const newProjId = 'proj-' + (state.projects.length + 1);
    const runId = 'RUN-' + Math.floor(1000 + Math.random() * 9000) + 'X';

    const newProject = {
        id: newProjId,
        name: name,
        customer: customer,
        phase: 'Ingestion & Scope',
        status: 'Draft',
        progress: 10,
        stepIndex: 0,
        runId: runId,
        ingress: [],
        egress: [],
        chatHistory: [
            {
                sender: 'ai',
                text: `Welcome! I have initialized **${name}** under customer tenant **${customer}**.<br><br>Let's begin requirements modeling. Click **Attach** or drag & drop files here to upload project documents (SOW, MOM workshop notes, sample code, schema logs). I will parse them into Ingress / Egress layers.`,
                time: getFormattedTime()
            }
        ],
        artifacts: [],
        reviewQueue: []
    };

    state.projects.unshift(newProject);
    state.activeProjectId = newProjId;

    DOM.newProjectModal.classList.add('hidden');
    DOM.newProjectForm.reset();

    renderProjectList();
    loadProject(newProjId);
    showToast(`Initialized project: ${name}`, 'success');
}

/* ----------------------------------------------------
   Toast Component Notification
   ---------------------------------------------------- */
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <span class="toast-indicator"></span>
        <span class="toast-message">${message}</span>
        <span class="toast-close">&times;</span>
    `;

    toast.querySelector('.toast-close').addEventListener('click', () => {
        toast.classList.add('hide');
        setTimeout(() => toast.remove(), 300);
    });

    DOM.toastArea.appendChild(toast);

    setTimeout(() => {
        if (toast.parentNode) {
            toast.classList.add('hide');
            setTimeout(() => toast.remove(), 300);
        }
    }, 4000);
}

/* ----------------------------------------------------
   Core Event Listeners
   ---------------------------------------------------- */
function setupEventListeners() {
    DOM.btnSend.addEventListener('click', handleSendMessage);
    DOM.composerInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') handleSendMessage();
    });


    // Tab switcher events
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.dataset.tab;
            
            tabBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            
            btn.classList.add('active');
            document.getElementById(target).classList.add('active');
        });
    });

    DOM.projectSearch.addEventListener('input', (e) => {
        renderProjectList(e.target.value);
    });

    DOM.btnAttach.addEventListener('click', (e) => {
        e.stopPropagation();
        DOM.attachmentMenu.classList.toggle('hidden');
    });

    document.addEventListener('click', () => {
        DOM.attachmentMenu.classList.add('hidden');
    });

    DOM.attachmentMenu.querySelectorAll('.attachment-menu-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.stopPropagation();
            const type = item.dataset.type;
            simulateFileUpload(type);
        });
    });

    document.getElementById('btn-mic').addEventListener('click', () => {
        showToast('Voice dictation listener activated...', 'info');
    });

    DOM.btnStartRun.addEventListener('click', () => {
        triggerAgentPipelineRun();
    });

    DOM.btnExport.addEventListener('click', () => {
        const project = state.projects.find(p => p.id === state.activeProjectId);
        showToast(`Packaging SDLC artifacts for ${project.name} baseline zip...`, 'info');
    });

    DOM.btnCollapseRight.addEventListener('click', () => {
        state.rightPanelCollapsed = !state.rightPanelCollapsed;
        if (state.rightPanelCollapsed) {
            DOM.appWrapper.classList.add('right-collapsed');
            DOM.btnCollapseRight.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="15" y1="3" x2="15" y2="21"></line></svg>`;
            showToast('Command Panel collapsed.', 'info');
        } else {
            DOM.appWrapper.classList.remove('right-collapsed');
            DOM.btnCollapseRight.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="9" y1="3" x2="9" y2="21"></line></svg>`;
            showToast('Command Panel expanded.', 'info');
        }
    });

    DOM.btnNewProject.addEventListener('click', () => {
        window.location.href = 'create-project.html';
    });

    // Settings dropdown toggling
    const btnSettingsToggle = document.getElementById('btn-settings-toggle');
    const settingsDropdownMenu = document.getElementById('settings-dropdown-menu');
    if (btnSettingsToggle && settingsDropdownMenu) {
        btnSettingsToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            settingsDropdownMenu.classList.toggle('hidden');
        });
        
        document.addEventListener('click', (e) => {
            if (!settingsDropdownMenu.classList.contains('hidden') && !e.target.closest('#settings-dropdown-menu') && e.target !== btnSettingsToggle) {
                settingsDropdownMenu.classList.add('hidden');
            }
        });
    }
    DOM.modalCloseBtn.addEventListener('click', () => {
        DOM.newProjectModal.classList.add('hidden');
    });
    DOM.modalCancelBtn.addEventListener('click', () => {
        DOM.newProjectModal.classList.add('hidden');
    });
    DOM.newProjectForm.addEventListener('submit', createNewProject);

    DOM.feedbackCloseBtn.addEventListener('click', () => {
        DOM.feedbackModal.classList.add('hidden');
    });
    DOM.feedbackCancelBtn.addEventListener('click', () => {
        DOM.feedbackModal.classList.add('hidden');
    });
    DOM.feedbackSubmitBtn.addEventListener('click', submitFeedback);

    DOM.toggleSidebarBtn.addEventListener('click', () => {
        DOM.sidebar.classList.toggle('active');
        DOM.commandPanel.classList.remove('active');
    });

    DOM.toggleRightPanelBtn.addEventListener('click', () => {
        DOM.commandPanel.classList.toggle('active');
        DOM.sidebar.classList.remove('active');
    });

    window.addEventListener('dragover', (e) => {
        e.preventDefault();
        DOM.dragDropOverlay.classList.add('drag-active');
    });

    DOM.dragDropOverlay.addEventListener('dragleave', (e) => {
        e.preventDefault();
        DOM.dragDropOverlay.classList.remove('drag-active');
    });

    DOM.dragDropOverlay.addEventListener('drop', (e) => {
        e.preventDefault();
        DOM.dragDropOverlay.classList.remove('drag-active');
        
        const droppedFiles = e.dataTransfer.files;
        if (droppedFiles.length > 0) {
            simulateFileUpload('doc');
        } else {
            simulateFileUpload('doc');
        }
    });
}

/* ----------------------------------------------------
   Utility Functions
   ---------------------------------------------------- */
function getFormattedTime() {
    const date = new Date();
    let hours = date.getHours();
    let minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    minutes = minutes < 10 ? '0'+minutes : minutes;
    return hours + ':' + minutes + ' ' + ampm;
}

function scrollToBottom() {
    setTimeout(() => {
        DOM.chatMessagesContainer.scrollTop = DOM.chatMessagesContainer.scrollHeight;
    }, 100);
}
