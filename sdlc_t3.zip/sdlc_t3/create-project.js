// create-project.js - Project Setup Form Controller

document.addEventListener('DOMContentLoaded', () => {
    initPage();
});

// Load projects state
let projects = [];
try {
    projects = JSON.parse(localStorage.getItem('agentic_sdlc_projects')) || [];
} catch (e) {
    projects = [];
}

function initPage() {
    renderProjectList();
    setupInputExpectations();
    setupSDLCConfiguration();
    setupFormActions();
    setupMobileToggles();
}

/* ----------------------------------------------------
   Sidebar Rendering
   ---------------------------------------------------- */
function renderProjectList(filter = '') {
    const container = document.getElementById('project-list-container');
    if (!container) return;
    
    container.innerHTML = '';
    const filteredProjects = projects.filter(p => 
        p.name.toLowerCase().includes(filter.toLowerCase()) || 
        p.customer.toLowerCase().includes(filter.toLowerCase())
    );

    if (filteredProjects.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="padding: 20px;">
                <p style="font-size: 12px; color: var(--text-sidebar-muted);">No projects match search</p>
            </div>
        `;
        return;
    }

    filteredProjects.forEach(proj => {
        const badgeClass = `badge-` + proj.status.toLowerCase().replace(' ', '');
        const item = document.createElement('div');
        item.className = 'project-item';
        item.dataset.id = proj.id;
        item.innerHTML = `
            <div class="project-item-top">
                <span class="project-item-name">${proj.name}</span>
                <span class="badge ${badgeClass}">${proj.status}</span>
            </div>
            <span class="project-item-desc">${proj.customer}</span>
        `;
        item.addEventListener('click', () => {
            window.location.href = `index.html?projectId=${proj.id}`;
        });
        container.appendChild(item);
    });
}

/* ----------------------------------------------------
   SDLC Configuration Card Logic
   ---------------------------------------------------- */
function setupSDLCConfiguration() {
    const selectMode = document.getElementById('select-project-mode');
    const warningNote = document.getElementById('mode-warning-note');
    
    // Make warning note visible right away because select option is disabled by default
    if (warningNote) {
        warningNote.classList.remove('hidden');
    }

    // Double safety check if they click the dropdown
    selectMode.addEventListener('change', (e) => {
        if (e.target.value === 'Future Nothing Input Mode') {
            showToast("Future Nothing Input Mode is currently disabled.", "warning");
        }
    });

    selectMode.addEventListener('click', () => {
        // Show tooltip reminder when they focus/click the mode selector
        showToast("Future Nothing Input Mode requires agent maturity.", "info");
    });
}

/* ----------------------------------------------------
   Input Expectations Checkbox Selection & Chips
   ---------------------------------------------------- */
function setupInputExpectations() {
    const checkboxCards = document.querySelectorAll('.checkbox-card');
    const chipsContainer = document.getElementById('chips-container');

    function updateChips() {
        const selectedVals = [];
        checkboxCards.forEach(card => {
            const checkbox = card.querySelector('input[type="checkbox"]');
            if (checkbox.checked) {
                selectedVals.push(checkbox.value);
                card.classList.add('selected');
            } else {
                card.classList.remove('selected');
            }
        });

        chipsContainer.innerHTML = '';
        if (selectedVals.length === 0) {
            chipsContainer.innerHTML = `<span class="empty-chips-text">No inputs selected. Click checkboxes above.</span>`;
            return;
        }

        selectedVals.forEach(val => {
            const chip = document.createElement('span');
            chip.className = 'selected-chip';
            chip.innerHTML = `${val} <span class="selected-chip-remove" data-val="${val}">&times;</span>`;
            
            chip.querySelector('.selected-chip-remove').addEventListener('click', (e) => {
                e.stopPropagation();
                const targetVal = e.target.dataset.val;
                
                checkboxCards.forEach(card => {
                    const checkbox = card.querySelector('input[type="checkbox"]');
                    if (checkbox.value === targetVal) {
                        checkbox.checked = false;
                    }
                });
                updateChips();
            });

            chipsContainer.appendChild(chip);
        });
    }

    checkboxCards.forEach(card => {
        const checkbox = card.querySelector('input[type="checkbox"]');
        
        // Listen to native input toggle
        checkbox.addEventListener('change', (e) => {
            updateChips();
        });

        // Click wrapper to toggle checkbox
        card.addEventListener('click', (e) => {
            // Prevent duplicate toggle if click landed directly on checkbox input
            if (e.target !== checkbox && !e.target.closest('.checkbox-card-indicator')) {
                checkbox.checked = !checkbox.checked;
                updateChips();
            }
        });
    });
}

/* ----------------------------------------------------
   Form Submission and Validation
   ---------------------------------------------------- */
function setupFormActions() {
    const searchInput = document.getElementById('project-search');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            renderProjectList(e.target.value);
        });
    }

    // Cancel Button redirect
    document.getElementById('btn-setup-cancel').addEventListener('click', () => {
        window.location.href = 'index.html';
    });

    // Save Draft Action
    document.getElementById('btn-setup-save-draft').addEventListener('click', () => {
        // Save draft just does a validation-free toast
        showToast("Draft saved successfully.", "success");
    });

    // Create & Continue Submit Action
    document.getElementById('btn-setup-create').addEventListener('click', () => {
        if (validateForm()) {
            executeProjectCreation();
        } else {
            showToast("Please fill in all required project fields.", "error");
            
            // Scroll to validation errors
            const firstInvalid = document.querySelector('.form-group.invalid');
            if (firstInvalid) {
                firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }
    });

    // Clear validation errors on inputs
    const requiredInputs = ['input-customer-name', 'input-project-name', 'input-business-unit', 'input-description'];
    requiredInputs.forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            input.addEventListener('input', (e) => {
                if (e.target.value.trim()) {
                    e.target.closest('.form-group').classList.remove('invalid');
                }
            });
        }
    });
}

function validateForm() {
    let isValid = true;
    const fields = [
        { id: 'group-customer-name', inputId: 'input-customer-name' },
        { id: 'group-project-name', inputId: 'input-project-name' },
        { id: 'group-business-unit', inputId: 'input-business-unit' },
        { id: 'group-description', inputId: 'input-description' }
    ];

    fields.forEach(field => {
        const group = document.getElementById(field.id);
        const input = document.getElementById(field.inputId);
        if (!input || !input.value.trim()) {
            if (group) group.classList.add('invalid');
            isValid = false;
        } else {
            if (group) group.classList.remove('invalid');
        }
    });

    return isValid;
}

function executeProjectCreation() {
    // 1. Shift Stepper active index visually
    const stepperSteps = document.querySelectorAll('.stepper-step');
    if (stepperSteps.length >= 2) {
        stepperSteps[0].className = 'stepper-step completed';
        stepperSteps[1].className = 'stepper-step active';
    }

    // 2. Gather values
    const customer = document.getElementById('input-customer-name').value.trim();
    const name = document.getElementById('input-project-name').value.trim();
    const bu = document.getElementById('input-business-unit').value.trim();
    const description = document.getElementById('input-description').value.trim();
    
    const phase = document.getElementById('select-sdlc-phase').value;
    const mode = document.getElementById('select-project-mode').value;
    const scope = document.getElementById('select-automation-scope').value;
    const humanApproval = document.getElementById('toggle-human-approval').checked;

    // Get selected expectations list
    const selectedExpectations = [];
    document.querySelectorAll('.checkbox-card input[type="checkbox"]').forEach(checkbox => {
        if (checkbox.checked) {
            selectedExpectations.push(checkbox.value);
        }
    });

    // 3. Create unique project object
    const newProjId = 'proj-' + Date.now();
    const runId = 'RUN-' + Math.floor(1000 + Math.random() * 9000) + 'A';

    const chatText = `Welcome! I have initialized **${name}** under customer tenant **${customer}** with the following configuration:
<br><br>
&bull; **SDLC Phase:** ${phase}<br>
&bull; **Project Mode:** ${mode}<br>
&bull; **Automation Scope:** ${scope}<br>
&bull; **Human Approval:** ${humanApproval ? 'Required (Excel Review points active)' : 'Skipped (Direct run)'}<br>
&bull; **Expected Inputs:** ${selectedExpectations.length > 0 ? selectedExpectations.join(', ') : 'None specified'}
<br><br>
Let's begin requirements modeling. Click **Attach** or drag & drop files here to upload project documents (SOW, MOM workshop notes, sample code, schema logs). I will parse them into Ingress / Egress layers.`;

    const newProject = {
        id: newProjId,
        name: name,
        customer: customer,
        phase: phase + " & Scope",
        status: 'Draft',
        progress: 10,
        stepIndex: 1, // Start at step 2: "Upload Inputs"
        runId: runId,
        ingress: [],
        egress: [],
        chatHistory: [
            {
                sender: 'ai',
                text: chatText,
                time: getFormattedTime()
            }
        ],
        artifacts: [
            { id: 'art-deliv-' + Date.now(), name: 'Deliverables List', type: 'doc', agent: 'Deliverables Agent', version: 'v1.0', confidence: 95, status: 'Draft' }
        ],
        reviewQueue: []
    };

    // 4. Update localStorage projects
    projects.unshift(newProject);
    localStorage.setItem('agentic_sdlc_projects', JSON.stringify(projects));
    localStorage.setItem('agentic_sdlc_active_project_id', newProjId);

    // 5. Toast notification
    showToast("Project created successfully. Continue by uploading project inputs.", "success");

    // 6. Smooth redirect
    setTimeout(() => {
        window.location.href = `index.html?projectId=${newProjId}&created=true`;
    }, 1500);
}

/* ----------------------------------------------------
   Responsive Mobile drawer layout selectors
   ---------------------------------------------------- */
function setupMobileToggles() {
    const toggleSidebarBtn = document.getElementById('toggle-sidebar-btn');
    const toggleRightPanelBtn = document.getElementById('toggle-right-panel-btn');
    const sidebar = document.getElementById('sidebar');
    const commandPanel = document.getElementById('command-panel');

    if (toggleSidebarBtn) {
        toggleSidebarBtn.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            commandPanel.classList.remove('active');
        });
    }
    if (toggleRightPanelBtn) {
        toggleRightPanelBtn.addEventListener('click', () => {
            commandPanel.classList.toggle('active');
            sidebar.classList.remove('active');
        });
    }

    // Settings dropdown toggling
    const btnSettingsToggle = document.getElementById('btn-settings-toggle');
    const settingsDropdownMenu = document.getElementById('settings-dropdown-menu');
    if (btnSettingsToggle && settingsDropdownMenu) {
        btnSettingsToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            settingsDropdownMenu.classList.toggle('hidden');
        });
        
        document.addEventListener('click', (e) => {
            if (!settingsDropdownMenu.classList.contains('hidden') && !e.target.closest('#settings-dropdown-menu') && e.target !== btnSettingsToggle) {
                settingsDropdownMenu.classList.add('hidden');
            }
        });
    }
}

/* ----------------------------------------------------
   Toast helper notification component
   ---------------------------------------------------- */
function showToast(message, type = 'info') {
    const area = document.getElementById('toast-area');
    if (!area) return;
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <span class="toast-indicator"></span>
        <span class="toast-message">${message}</span>
        <span class="toast-close">&times;</span>
    `;

    toast.querySelector('.toast-close').addEventListener('click', () => {
        toast.classList.add('hide');
        setTimeout(() => toast.remove(), 300);
    });

    area.appendChild(toast);

    setTimeout(() => {
        if (toast.parentNode) {
            toast.classList.add('hide');
            setTimeout(() => toast.remove(), 300);
        }
    }, 4000);
}

function getFormattedTime() {
    const date = new Date();
    let hours = date.getHours();
    let minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    minutes = minutes < 10 ? '0'+minutes : minutes;
    return hours + ':' + minutes + ' ' + ampm;
}
