// marketplace.js - Marketplace Portal Controller

document.addEventListener('DOMContentLoaded', () => {
    initPage();
});

// Load projects state
let projects = [];
try {
    projects = JSON.parse(localStorage.getItem('agentic_sdlc_projects')) || [];
} catch (e) {
    projects = [];
}

// Default Listings database
const DEFAULT_ASSETS = [
    { id: 'mkt-1', name: 'Healthcare BRD Accelerator', category: 'template', badge: 'Popular', badgeType: 'warning', desc: 'Complete BRD + RTM template set for HIPAA-compliant healthcare systems. Includes HL7 FHIR standards reference requirements.', author: 'HealthTech Labs', rating: 4.7, installs: 1230, icon: '📋' },
    { id: 'mkt-2', name: 'E2E Test Suite Generator', category: 'agent', badge: 'Verified', badgeType: 'success', desc: 'Automatically generates comprehensive E2E test suites from BRD documents. Delivers 95%+ coverage validation.', author: 'QA Agent Corp', rating: 4.8, installs: 980, icon: '🧪' },
    { id: 'mkt-3', name: 'BFSI Req. Agent Pack', category: 'agent', badge: 'Featured', badgeType: 'accent', desc: 'Pre-configured requirement gathering agent optimized for BFSI domain with 200+ regulatory compliance checks.', author: 'AgentSDLC Core', rating: 4.9, installs: 840, icon: '🤖' },
    { id: 'mkt-4', name: 'Analytics Domain Pack', category: 'template', badge: 'Popular', badgeType: 'warning', desc: 'Templates and RTM structures for business intelligence and analytics pipelines. Includes KPI tracking specs.', author: 'DataBI Group', rating: 4.5, installs: 670, icon: '📊' },
    { id: 'mkt-5', name: 'Supervisor SDLC Orchestrator Pack', category: 'accelerator', badge: 'Core Pack', badgeType: 'accent', desc: 'The ultimate control agent package. Seamlessly orchestrates analysis, code generation, requirements traceability, and checkpoints across 6 agent personas.', author: 'AgentSDLC Core', rating: 4.9, installs: 420, icon: '👑' },
    { id: 'mkt-6', name: 'Security NFR Library', category: 'security', badge: 'New', badgeType: 'primary', desc: '500+ security Non-Functional Requirements mapped to OWASP Top 10, SOC 2, ISO 27001, and GDPR standards.', author: 'SecOps Intel', rating: 4.9, installs: 310, icon: '🔒' },
    { id: 'mkt-7', name: 'Cloud Migration RTM Template', category: 'template', badge: 'New', badgeType: 'primary', desc: 'Requirements Traceability Matrix template for cloud migration projects. Maps on-prem instances to AWS/Azure/GCP targets.', author: 'CloudOps Pro', rating: 4.6, installs: 150, icon: '🔗' }
];

// Specifications database
const ASSET_SPECS = {
    'mkt-1': { model: 'Gemini 1.5 Pro', license: 'Commercial', memory: 'Low (< 20MB)', compliance: ['HIPAA', 'HL7 FHIR', 'SOC 2'] },
    'mkt-2': { model: 'Gemini 1.5 Flash', license: 'Apache 2.0', memory: 'Medium (approx. 80MB)', compliance: ['ISO 29119', 'NIST'] },
    'mkt-3': { model: 'Gemini 1.5 Pro', license: 'Commercial', memory: 'High (approx. 250MB)', compliance: ['BFSI Compliant', 'PCI-DSS', 'SEC'] },
    'mkt-4': { model: 'Gemini 1.5 Flash', license: 'Apache 2.0', memory: 'Low (< 10MB)', compliance: ['ISO 9001', 'GDP'] },
    'mkt-5': { model: 'Gemini 1.5 Pro (Multimodal)', license: 'Commercial (Core)', memory: 'Extreme (approx. 500MB)', compliance: ['SOC 2 Type II', 'ISO 27001', 'GDPR'] },
    'mkt-6': { model: 'OpenAI GPT-4o', license: 'Apache 2.0', memory: 'Medium (approx. 120MB)', compliance: ['GDPR', 'OWASP Top 10', 'SOC 2', 'ISO 27001'] },
    'mkt-7': { model: 'Claude 3.5 Sonnet', license: 'MIT License', memory: 'Low (< 15MB)', compliance: ['AWS CAF', 'Azure WAF'] }
};

let assets = [];
try {
    assets = JSON.parse(localStorage.getItem('mkt_assets')) || DEFAULT_ASSETS;
} catch(e) {
    assets = DEFAULT_ASSETS;
}

let activeCategory = 'all';

function initPage() {
    renderProjectList();
    setupDropdowns();
    setupFilters();
    updateTabCounts();
    setupDetailsModal();
    renderAssets();
}

/* ----------------------------------------------------
   Sidebar Project list
   ---------------------------------------------------- */
function renderProjectList(filter = '') {
    const container = document.getElementById('project-list-container');
    if (!container) return;
    
    container.innerHTML = '';
    const filteredProjects = projects.filter(p => 
        p.name.toLowerCase().includes(filter.toLowerCase()) || 
        p.customer.toLowerCase().includes(filter.toLowerCase())
    );

    if (filteredProjects.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="padding: 20px;">
                <p style="font-size: 12px; color: var(--text-sidebar-muted);">No projects match search</p>
            </div>
        `;
        return;
    }

    filteredProjects.forEach(proj => {
        const badgeClass = `badge-` + proj.status.toLowerCase().replace(' ', '');
        const item = document.createElement('div');
        item.className = 'project-item';
        item.dataset.id = proj.id;
        item.innerHTML = `
            <div class="project-item-top">
                <span class="project-item-name">${proj.name}</span>
                <span class="badge ${badgeClass}">${proj.status}</span>
            </div>
            <span class="project-item-desc">${proj.customer}</span>
        `;
        item.addEventListener('click', () => {
            window.location.href = `index.html?projectId=${proj.id}`;
        });
        container.appendChild(item);
    });
}

/* ----------------------------------------------------
   Sidebar settings dropdown toggling
   ---------------------------------------------------- */
function setupDropdowns() {
    const searchInput = document.getElementById('project-search');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            renderProjectList(e.target.value);
        });
    }

    // New Project click
    const btnNewProject = document.getElementById('btn-new-project');
    if (btnNewProject) {
        btnNewProject.addEventListener('click', () => {
            window.location.href = 'create-project.html';
        });
    }

    // Settings dropdown menu click
    const btnSettingsToggle = document.getElementById('btn-settings-toggle');
    const settingsDropdownMenu = document.getElementById('settings-dropdown-menu');
    if (btnSettingsToggle && settingsDropdownMenu) {
        btnSettingsToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            settingsDropdownMenu.classList.toggle('hidden');
        });
        
        document.addEventListener('click', (e) => {
            if (!settingsDropdownMenu.classList.contains('hidden') && !e.target.closest('#settings-dropdown-menu') && e.target !== btnSettingsToggle) {
                settingsDropdownMenu.classList.add('hidden');
            }
        });
    }
}

/* ----------------------------------------------------
   Category Filter & Searches
   ---------------------------------------------------- */
function setupFilters() {
    const search = document.getElementById('asset-search-input');
    const sort = document.getElementById('sort-assets');
    const filterBtns = document.querySelectorAll('#catalog-category-filters .toggle-view-btn');

    if (search) search.addEventListener('input', renderAssets);
    if (sort) sort.addEventListener('change', renderAssets);

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            activeCategory = btn.dataset.category;
            renderAssets();
        });
    });

    // Deploy featured asset
    const featuredBtn = document.querySelector('#featured-asset-banner .install-asset-btn');
    if (featuredBtn) {
        const isFeaturedInstalled = localStorage.getItem('installed_mkt-5') === 'true';
        if (isFeaturedInstalled) {
            featuredBtn.textContent = 'Deployed ✓';
            featuredBtn.disabled = true;
            featuredBtn.style.backgroundColor = '#E2E8F0';
            featuredBtn.style.color = 'var(--text-muted)';
            featuredBtn.style.cursor = 'not-allowed';
        }
        featuredBtn.addEventListener('click', () => {
            simulateInstallation(featuredBtn, "Supervisor SDLC Orchestrator Pack", "featured");
        });
    }
}

/* ----------------------------------------------------
   Category tab counts calculator
   ---------------------------------------------------- */
function updateTabCounts() {
    const countAll = document.getElementById('count-all');
    const countAgent = document.getElementById('count-agent');
    const countTemplate = document.getElementById('count-template');
    const countAccelerator = document.getElementById('count-accelerator');
    const countSecurity = document.getElementById('count-security');

    if (countAll) countAll.textContent = assets.length;
    if (countAgent) countAgent.textContent = assets.filter(a => a.category === 'agent').length;
    if (countTemplate) countTemplate.textContent = assets.filter(a => a.category === 'template').length;
    if (countAccelerator) countAccelerator.textContent = assets.filter(a => a.category === 'accelerator').length;
    if (countSecurity) countSecurity.textContent = assets.filter(a => a.category === 'security').length;
}

/* ----------------------------------------------------
   Render Catalog Assets Grid
   ---------------------------------------------------- */
function renderAssets() {
    const container = document.getElementById('assets-grid-container');
    if (!container) return;

    const query = (document.getElementById('asset-search-input')?.value || '').toLowerCase();
    const sortVal = document.getElementById('sort-assets')?.value || 'popularity';

    // 1. Filter
    let filtered = assets.filter(item => {
        const matchesQuery = item.name.toLowerCase().includes(query) || item.desc.toLowerCase().includes(query) || item.author.toLowerCase().includes(query);
        const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
        return matchesQuery && matchesCategory;
    });

    // 2. Sort
    filtered.sort((a, b) => {
        if (sortVal === 'installs') {
            return b.installs - a.installs;
        } else if (sortVal === 'rating') {
            return b.rating - a.rating;
        } else {
            return (b.installs * b.rating) - (a.installs * a.rating);
        }
    });

    container.innerHTML = '';

    if (filtered.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1; padding: 40px 20px;">
                <div class="empty-state-icon" style="width:54px; height:54px; background: rgba(100,116,139,0.08); color: var(--text-muted);">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                </div>
                <h3>No Marketplace Assets Found</h3>
                <p class="text-muted text-small">Try refining your search keyword or selected category filter.</p>
            </div>
        `;
        return;
    }

    filtered.forEach(item => {
        const isInstalled = localStorage.getItem(`installed_${item.id}`) === 'true';
        const card = document.createElement('div');
        card.className = 'setup-card';
        card.style.gap = '14px';
        card.style.padding = '20px';
        card.style.transition = 'transform 0.2s, box-shadow 0.2s';
        card.style.cursor = 'default';

        // Hover animations
        card.addEventListener('mouseover', () => {
            card.style.transform = 'translateY(-2px)';
            card.style.boxShadow = 'var(--shadow-md)';
        });
        card.addEventListener('mouseout', () => {
            card.style.transform = 'none';
            card.style.boxShadow = 'var(--shadow-sm)';
        });

        // Badge markup
        const badgeClass = `badge-` + item.badgeType;
        const deployBtnText = isInstalled ? 'Deployed ✓' : 'Deploy';
        const deployBtnDisabled = isInstalled ? 'disabled' : '';
        const deployBtnStyle = isInstalled ? 'background-color:#E2E8F0; color:var(--text-muted); cursor:not-allowed;' : '';

        card.innerHTML = `
            <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                <div style="font-size:32px; width:48px; height:48px; border-radius:var(--border-radius-md); background:var(--bg-input); display:flex; align-items:center; justify-content:center;">${item.icon}</div>
                <span class="badge ${badgeClass}">${item.badge}</span>
            </div>
            <div>
                <h4 style="font-family:var(--font-heading); font-size:14px; font-weight:700; color:var(--text-main); margin-bottom:4px;">${item.name}</h4>
                <p class="text-muted" style="font-size:12px; line-height:1.4; height:50px; overflow:hidden; display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical;">${item.desc}</p>
            </div>
            <div style="font-size:11px; color:var(--text-muted); display:flex; justify-content:space-between; align-items:center;">
                <span>by <strong>${item.author}</strong></span>
                <span style="display:flex; align-items:center; gap:2px;"><span style="color:var(--warning);">★</span> <strong>${item.rating}</strong> (${item.installs})</span>
            </div>
            
            <div class="asset-card-actions">
                <button class="btn-specs-trigger" data-id="${item.id}">Specs</button>
                <button class="btn btn-primary install-asset-btn" data-id="${item.id}" data-name="${item.name}" ${deployBtnDisabled} style="${deployBtnStyle} font-size:11px; padding:8px 0; font-weight:600; flex-grow:1; margin-top:0;">
                    ${deployBtnText}
                </button>
            </div>
        `;

        card.querySelector('.install-asset-btn').addEventListener('click', (e) => {
            simulateInstallation(e.target, item.name, item.id);
        });

        container.appendChild(card);
    });

    bindSpecsButtons();
}

/* ----------------------------------------------------
   Simulation: Milestone Installation loader
   ---------------------------------------------------- */
function simulateInstallation(button, name, id = 'featured') {
    button.disabled = true;
    button.style.backgroundColor = '#E2E8F0';
    button.style.color = 'var(--text-muted)';
    button.style.cursor = 'not-allowed';

    let progress = 0;
    button.textContent = `Deploying... Ingesting prompts`;
    showToast(`Initializing installation for: ${name}...`, 'info');

    const interval = setInterval(() => {
        progress += Math.floor(Math.random() * 15) + 12;
        if (progress >= 100) {
            progress = 100;
            clearInterval(interval);
            button.textContent = `Deployed ✓`;
            
            const targetId = id === 'featured' ? 'mkt-5' : id;
            localStorage.setItem(`installed_${targetId}`, 'true');
            
            if (id === 'featured') {
                renderAssets(); // Redraw assets to reflect featured package install
            }

            showToast(`Package "${name}" successfully deployed to platform registry.`, 'success');
        } else {
            // Apply milestone messages
            if (progress < 30) {
                button.textContent = `Deploying... Ingesting prompts`;
            } else if (progress < 60) {
                button.textContent = `Deploying... Wiring nodes`;
            } else if (progress < 90) {
                button.textContent = `Deploying... Verifying security`;
            } else {
                button.textContent = `Deploying... Registering pack`;
            }
        }
    }, 350);
}

/* ----------------------------------------------------
   Specs Details Modal Controller
   ---------------------------------------------------- */
function setupDetailsModal() {
    const modal = document.getElementById('asset-details-modal');
    const closeBtn = document.getElementById('spec-modal-close-btn');
    const closeBtnBottom = document.getElementById('spec-modal-close-btn-bottom');

    if (!modal) return;
    
    const closeModal = () => modal.classList.add('hidden');
    
    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (closeBtnBottom) closeBtnBottom.addEventListener('click', closeModal);
}

function bindSpecsButtons() {
    const triggers = document.querySelectorAll('.btn-specs-trigger');
    const modal = document.getElementById('asset-details-modal');
    
    if (!modal) return;

    triggers.forEach(btn => {
        btn.addEventListener('click', () => {
            const assetId = btn.dataset.id;
            const asset = assets.find(a => a.id === assetId);
            const specs = ASSET_SPECS[assetId];
            
            if (!asset || !specs) return;

            // Map content into modal
            document.getElementById('spec-icon').textContent = asset.icon;
            document.getElementById('spec-name').textContent = asset.name;
            document.getElementById('spec-author').textContent = `by ${asset.author}`;
            document.getElementById('spec-desc').textContent = asset.desc;
            document.getElementById('spec-model').textContent = specs.model;
            document.getElementById('spec-license').textContent = specs.license;
            document.getElementById('spec-memory').textContent = specs.memory;

            // Map compliance tags
            const complianceBox = document.getElementById('spec-compliance');
            if (complianceBox) {
                complianceBox.innerHTML = '';
                specs.compliance.forEach(tag => {
                    const badge = document.createElement('span');
                    badge.className = 'compliance-tag';
                    badge.textContent = tag;
                    complianceBox.appendChild(badge);
                });
            }

            modal.classList.remove('hidden');
        });
    });
}

/* ----------------------------------------------------
   Toast notifications
   ---------------------------------------------------- */
function showToast(message, type = 'info') {
    const area = document.getElementById('toast-area');
    if (!area) return;
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <span class="toast-indicator"></span>
        <span class="toast-message">${message}</span>
        <span class="toast-close">&times;</span>
    `;

    toast.querySelector('.toast-close').addEventListener('click', () => {
        toast.classList.add('hide');
        setTimeout(() => toast.remove(), 300);
    });

    area.appendChild(toast);

    setTimeout(() => {
        if (toast.parentNode) {
            toast.classList.add('hide');
            setTimeout(() => toast.remove(), 300);
        }
    }, 4000);
}

// Mobile drawer controls
function setupMobileToggles() {
    const toggleSidebarBtn = document.getElementById('toggle-sidebar-btn');
    const toggleRightPanelBtn = document.getElementById('toggle-right-panel-btn');
    const sidebar = document.getElementById('sidebar');
    const commandPanel = document.getElementById('command-panel');

    if (toggleSidebarBtn) {
        toggleSidebarBtn.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            if (commandPanel) commandPanel.classList.remove('active');
        });
    }
    if (toggleRightPanelBtn && commandPanel) {
        toggleRightPanelBtn.addEventListener('click', () => {
            commandPanel.classList.toggle('active');
            sidebar.classList.remove('active');
        });
    }
}
window.setupMobileToggles = setupMobileToggles;
