// configuration.js - Redesigned Configuration Page Controller

document.addEventListener('DOMContentLoaded', () => {
    initPage();
});

// Load projects state
let projects = [];
try {
    projects = JSON.parse(localStorage.getItem('agentic_sdlc_projects')) || [];
} catch (e) {
    projects = [];
}

function initPage() {
    renderProjectList();
    setupDropdowns();
    setupTabs();
    setupChoiceCards();
    setupConfigForm();
    setupLLMTestButtons();
    setupMobileToggles();
}

/* ----------------------------------------------------
   Sidebar Rendering
   ---------------------------------------------------- */
function renderProjectList(filter = '') {
    const container = document.getElementById('project-list-container');
    if (!container) return;
    
    container.innerHTML = '';
    const filteredProjects = projects.filter(p => 
        p.name.toLowerCase().includes(filter.toLowerCase()) || 
        p.customer.toLowerCase().includes(filter.toLowerCase())
    );

    if (filteredProjects.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="padding: 20px;">
                <p style="font-size: 12px; color: var(--text-sidebar-muted);">No projects match search</p>
            </div>
        `;
        return;
    }

    filteredProjects.forEach(proj => {
        const badgeClass = `badge-` + proj.status.toLowerCase().replace(' ', '');
        const item = document.createElement('div');
        item.className = 'project-item';
        item.dataset.id = proj.id;
        item.innerHTML = `
            <div class="project-item-top">
                <span class="project-item-name">${proj.name}</span>
                <span class="badge ${badgeClass}">${proj.status}</span>
            </div>
            <span class="project-item-desc">${proj.customer}</span>
        `;
        item.addEventListener('click', () => {
            window.location.href = `index.html?projectId=${proj.id}`;
        });
        container.appendChild(item);
    });
}

/* ----------------------------------------------------
   Tabs Switcher Control
   ---------------------------------------------------- */
function setupTabs() {
    const tabBtns = document.querySelectorAll('.config-tab-btn');
    const tabPanes = document.querySelectorAll('.config-tab-pane');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetTab = btn.dataset.tab;
            
            // Toggle active buttons
            tabBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Toggle tab content display
            tabPanes.forEach(pane => {
                if (pane.id === targetTab) {
                    pane.classList.add('active');
                } else {
                    pane.classList.remove('active');
                }
            });
        });
    });
}

/* ----------------------------------------------------
   Choice Cards selection controls
   ---------------------------------------------------- */
function setupChoiceCards() {
    // 1. Framework Cards
    const frameworkCards = document.querySelectorAll('#framework-cards-container .choice-card');
    const hiddenFrameworkSelect = document.getElementById('select-orchestration-framework');
    
    frameworkCards.forEach(card => {
        card.addEventListener('click', () => {
            frameworkCards.forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            
            const value = card.dataset.value;
            if (hiddenFrameworkSelect) {
                hiddenFrameworkSelect.value = value;
            }
        });
    });

    // 2. Memory Cards
    const memoryCards = document.querySelectorAll('#memory-cards-container .choice-card');
    const hiddenMemorySelect = document.getElementById('select-memory-backend');

    memoryCards.forEach(card => {
        card.addEventListener('click', () => {
            memoryCards.forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            
            const value = card.dataset.value;
            if (hiddenMemorySelect) {
                hiddenMemorySelect.value = value;
            }
        });
    });
}

/* ----------------------------------------------------
   Configuration Forms Control & Storage Integration
   ---------------------------------------------------- */
function setupConfigForm() {
    // Range Slider 1: Max File Ingest
    const sliderFilesize = document.getElementById('slider-filesize');
    const labelFilesize = document.getElementById('filesize-value');
    
    if (sliderFilesize && labelFilesize) {
        const savedSize = localStorage.getItem('config_max_filesize') || "50";
        sliderFilesize.value = savedSize;
        labelFilesize.textContent = savedSize + " MB";
        
        sliderFilesize.addEventListener('input', (e) => {
            labelFilesize.textContent = e.target.value + " MB";
        });
    }

    // Range Slider 2: A2H confidence threshold gate
    const sliderA2h = document.getElementById('slider-a2h-threshold');
    const labelA2h = document.getElementById('a2h-threshold-value');

    if (sliderA2h && labelA2h) {
        const savedThreshold = localStorage.getItem('config_a2h_threshold') || "85";
        sliderA2h.value = savedThreshold;
        labelA2h.textContent = savedThreshold + "%";

        sliderA2h.addEventListener('input', (e) => {
            labelA2h.textContent = e.target.value + "%";
        });
    }

    // Dropdowns & Inputs References
    const frameworkSelect = document.getElementById('select-orchestration-framework');
    const memorySelect = document.getElementById('select-memory-backend');
    const strategy = document.getElementById('select-prompt-strategy');
    const parallelism = document.getElementById('select-parallelism-mode');
    const schema = document.getElementById('select-schema-extraction');
    const autoBypass = document.getElementById('chk-auto-bypass');
    const strictTypes = document.getElementById('chk-strict-types');

    // LLM inputs
    const keyGemini = document.getElementById('key-gemini');
    const modelGemini = document.getElementById('model-gemini');
    const keyClaude = document.getElementById('key-claude');
    const modelClaude = document.getElementById('model-claude');
    const keyOpenai = document.getElementById('key-openai');
    const modelOpenai = document.getElementById('model-openai');

    // Restore saved framework states (sync with visual cards)
    const savedFramework = localStorage.getItem('config_framework') || "langgraph";
    if (frameworkSelect) {
        frameworkSelect.value = savedFramework;
        document.querySelectorAll('#framework-cards-container .choice-card').forEach(c => {
            if (c.dataset.value === savedFramework) {
                c.classList.add('selected');
            } else {
                c.classList.remove('selected');
            }
        });
    }

    const savedMemory = localStorage.getItem('config_memory') || "postgresql";
    if (memorySelect) {
        memorySelect.value = savedMemory;
        document.querySelectorAll('#memory-cards-container .choice-card').forEach(c => {
            if (c.dataset.value === savedMemory) {
                c.classList.add('selected');
            } else {
                c.classList.remove('selected');
            }
        });
    }

    // Restore standard dropdown options
    if (strategy) strategy.value = localStorage.getItem('config_strategy') || "progressive";
    if (parallelism) parallelism.value = localStorage.getItem('config_parallelism') || "parallel";
    if (schema) schema.value = localStorage.getItem('config_schema') || "auto";

    // Restore checkboxes
    if (autoBypass) autoBypass.checked = localStorage.getItem('config_auto_bypass') === 'true';
    if (strictTypes) strictTypes.checked = localStorage.getItem('config_strict_types') !== 'false'; // default true

    // Restore LLM configuration values
    if (keyGemini) keyGemini.value = localStorage.getItem('config_gemini_key') || "AIzaSyDummyKeyForGeminiAPI";
    if (modelGemini) modelGemini.value = localStorage.getItem('config_gemini_model') || "gemini-1.5-pro";
    if (keyClaude) keyClaude.value = localStorage.getItem('config_claude_key') || "";
    if (modelClaude) modelClaude.value = localStorage.getItem('config_claude_model') || "claude-3-5-sonnet";
    if (keyOpenai) keyOpenai.value = localStorage.getItem('config_openai_key') || "";
    if (modelOpenai) modelOpenai.value = localStorage.getItem('config_openai_model') || "gpt-4o";

    // Sync provider status labels if they have stored keys
    updateProviderStatusLabel('gemini', keyGemini ? keyGemini.value : "");
    updateProviderStatusLabel('claude', keyClaude ? keyClaude.value : "");
    updateProviderStatusLabel('openai', keyOpenai ? keyOpenai.value : "");

    // Save configurations click logic
    const saveBtn = document.getElementById('btn-save-config');
    if (saveBtn) {
        saveBtn.addEventListener('click', () => {
            // Write form options to storage
            if (sliderFilesize) localStorage.setItem('config_max_filesize', sliderFilesize.value);
            if (sliderA2h) localStorage.setItem('config_a2h_threshold', sliderA2h.value);
            if (frameworkSelect) localStorage.setItem('config_framework', frameworkSelect.value);
            if (memorySelect) localStorage.setItem('config_memory', memorySelect.value);
            if (strategy) localStorage.setItem('config_strategy', strategy.value);
            if (parallelism) localStorage.setItem('config_parallelism', parallelism.value);
            if (schema) localStorage.setItem('config_schema', schema.value);
            if (autoBypass) localStorage.setItem('config_auto_bypass', autoBypass.checked);
            if (strictTypes) localStorage.setItem('config_strict_types', strictTypes.checked);

            // Write LLM keys and defaults
            if (keyGemini) localStorage.setItem('config_gemini_key', keyGemini.value);
            if (modelGemini) localStorage.setItem('config_gemini_model', modelGemini.value);
            if (keyClaude) localStorage.setItem('config_claude_key', keyClaude.value);
            if (modelClaude) localStorage.setItem('config_claude_model', modelClaude.value);
            if (keyOpenai) localStorage.setItem('config_openai_key', keyOpenai.value);
            if (modelOpenai) localStorage.setItem('config_openai_model', modelOpenai.value);

            showToast("Platform configurations updated successfully.", "success");
        });
    }
}

/* ----------------------------------------------------
   LLM Provider Connection Testing Simulation
   ---------------------------------------------------- */
function setupLLMTestButtons() {
    const testBtns = document.querySelectorAll('.btn-test-conn');
    
    testBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const provider = btn.dataset.provider;
            const keyInput = document.getElementById(`key-${provider}`);
            const statusLabel = document.getElementById(`status-${provider}`);
            
            if (!keyInput || !statusLabel) return;
            
            const keyVal = keyInput.value.trim();
            if (!keyVal) {
                showToast(`Unable to test ${getProviderDisplayName(provider)}: API Key is required.`, "error");
                return;
            }

            // Simulate testing animation
            btn.disabled = true;
            const originalText = btn.textContent;
            btn.textContent = "Testing...";
            statusLabel.textContent = "Testing...";
            statusLabel.className = "provider-status disconnected";

            setTimeout(() => {
                btn.disabled = false;
                btn.textContent = originalText;
                
                // Update connected state status indicators
                statusLabel.textContent = "Connected";
                statusLabel.className = "provider-status connected";
                
                showToast(`Connection to ${getProviderDisplayName(provider)} model established successfully.`, "success");
            }, 1500);
        });
    });
}

function updateProviderStatusLabel(provider, keyVal) {
    const label = document.getElementById(`status-${provider}`);
    if (!label) return;
    
    if (keyVal.trim().length > 0) {
        label.textContent = "Connected";
        label.className = "provider-status connected";
    } else {
        label.textContent = "Disconnected";
        label.className = "provider-status disconnected";
    }
}

function getProviderDisplayName(provider) {
    switch (provider) {
        case 'gemini': return "Google Gemini";
        case 'claude': return "Anthropic Claude";
        case 'openai': return "OpenAI GPT";
        default: return provider;
    }
}

/* ----------------------------------------------------
   Sidebar setting dropdown dismiss toggles
   ---------------------------------------------------- */
function setupDropdowns() {
    const searchInput = document.getElementById('project-search');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            renderProjectList(e.target.value);
        });
    }

    const btnNewProject = document.getElementById('btn-new-project');
    if (btnNewProject) {
        btnNewProject.addEventListener('click', () => {
            window.location.href = 'create-project.html';
        });
    }

    const btnSettingsToggle = document.getElementById('btn-settings-toggle');
    const settingsDropdownMenu = document.getElementById('settings-dropdown-menu');
    if (btnSettingsToggle && settingsDropdownMenu) {
        btnSettingsToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            settingsDropdownMenu.classList.toggle('hidden');
        });
        
        document.addEventListener('click', (e) => {
            if (!settingsDropdownMenu.classList.contains('hidden') && !e.target.closest('#settings-dropdown-menu') && e.target !== btnSettingsToggle) {
                settingsDropdownMenu.classList.add('hidden');
            }
        });
    }
}

/* ----------------------------------------------------
   Responsive Mobile Drawer Controls
   ---------------------------------------------------- */
function setupMobileToggles() {
    const toggleSidebarBtn = document.getElementById('toggle-sidebar-btn');
    const toggleRightPanelBtn = document.getElementById('toggle-right-panel-btn');
    const sidebar = document.getElementById('sidebar');
    const commandPanel = document.getElementById('command-panel');

    if (toggleSidebarBtn) {
        toggleSidebarBtn.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            if (commandPanel) commandPanel.classList.remove('active');
        });
    }
    if (toggleRightPanelBtn && commandPanel) {
        toggleRightPanelBtn.addEventListener('click', () => {
            commandPanel.classList.toggle('active');
            sidebar.classList.remove('active');
        });
    }
}

/* ----------------------------------------------------
   Toast Notifications
   ---------------------------------------------------- */
function showToast(message, type = 'info') {
    const area = document.getElementById('toast-area');
    if (!area) return;
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <span class="toast-indicator"></span>
        <span class="toast-message">${message}</span>
        <span class="toast-close">&times;</span>
    `;

    toast.querySelector('.toast-close').addEventListener('click', () => {
        toast.classList.add('hide');
        setTimeout(() => toast.remove(), 300);
    });

    area.appendChild(toast);

    setTimeout(() => {
        if (toast.parentNode) {
            toast.classList.add('hide');
            setTimeout(() => toast.remove(), 300);
        }
    }, 4000);
}
