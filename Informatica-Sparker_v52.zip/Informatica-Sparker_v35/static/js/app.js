/**
 * Informatica XML to PySpark Converter
 * Frontend JavaScript Application
 */

class App {
    constructor() {
        this.currentStep = 1;
        this.artifactId = null;
        this.analysisData = null;
        this.workflowAnalysis = null;
        this.selectedFile = null;
        this.userConfig = {
            sources: [],
            targets: [],
            db_connections: {}
        };
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.initTheme();
    }
    
    bindEvents() {
        const uploadZone = document.getElementById('uploadZone');
        const fileInput = document.getElementById('fileInput');
        const removeFileBtn = document.getElementById('removeFileBtn');
        const analyzeBtn = document.getElementById('analyzeBtn');
        
        uploadZone.addEventListener('click', () => fileInput.click());
        uploadZone.addEventListener('dragover', (e) => this.handleDragOver(e));
        uploadZone.addEventListener('dragleave', (e) => this.handleDragLeave(e));
        uploadZone.addEventListener('drop', (e) => this.handleDrop(e));
        fileInput.addEventListener('change', (e) => this.handleFileSelect(e));
        removeFileBtn.addEventListener('click', () => this.removeFile());
        analyzeBtn.addEventListener('click', () => this.analyzeFile());
        
        document.getElementById('backToStep1').addEventListener('click', () => this.goToStep(1));
        document.getElementById('goToStep3').addEventListener('click', () => this.goToStep(3));
        document.getElementById('backToStep2').addEventListener('click', () => this.goToStep(2));
        document.getElementById('generateBtn').addEventListener('click', () => this.goToGeneratePage());
        document.getElementById('backToStep3').addEventListener('click', () => this.goToStep(3));
        
        // Generate Page events (Step 4)
        const startGenerateBtn = document.getElementById('startGenerateBtn');
        const downloadGeneratedBtn = document.getElementById('downloadGeneratedBtn');
        const clearLogsBtn = document.getElementById('clearLogsBtn');
        const newConversionBtn = document.getElementById('newConversionBtn');
        
        if (startGenerateBtn) startGenerateBtn.addEventListener('click', () => this.startGeneration());
        if (downloadGeneratedBtn) downloadGeneratedBtn.addEventListener('click', () => this.downloadGeneratedCode());
        if (clearLogsBtn) clearLogsBtn.addEventListener('click', () => this.clearLogs());
        if (newConversionBtn) newConversionBtn.addEventListener('click', () => this.startNewConversion());
        
        // Generate Modal V2 - Left Tabs
        document.querySelectorAll('.gen-left-tab').forEach(tab => {
            tab.addEventListener('click', (e) => this.switchGenLeftTab(e.currentTarget.dataset.genLeftTab));
        });
        
        // Generate Modal V2 - Right Tabs
        document.querySelectorAll('.gen-right-tab').forEach(tab => {
            tab.addEventListener('click', (e) => this.switchGenRightTab(e.currentTarget.dataset.genRightTab));
        });
        
        // Code file select dropdown
        const genCodeFileSelect = document.getElementById('genCodeFileSelect');
        if (genCodeFileSelect) {
            genCodeFileSelect.addEventListener('change', (e) => this.loadGeneratedFileCode(e.target.value));
        }
        
        const summaryMappingSelect = document.getElementById('summaryMappingSelect');
        if (summaryMappingSelect) {
            summaryMappingSelect.addEventListener('change', (e) => this.renderSummaryForMapping(e.target.value));
        }
        
        // Log filter dropdown
        const logFilterSelect = document.getElementById('logFilterSelect');
        if (logFilterSelect) {
            logFilterSelect.addEventListener('change', (e) => this.filterLogs(e.target.value));
        }
        
        // Copy generated code button
        const copyGenCodeBtn = document.getElementById('copyGenCodeBtn');
        if (copyGenCodeBtn) {
            copyGenCodeBtn.addEventListener('click', () => this.copyGeneratedCode());
        }
        
        const addConnectionBtn = document.getElementById('addConnectionBtn');
        if (addConnectionBtn) {
            addConnectionBtn.addEventListener('click', () => this.addConnection());
        }
        
        const openConnectionSettingsLink = document.getElementById('openConnectionSettings');
        if (openConnectionSettingsLink) {
            openConnectionSettingsLink.addEventListener('click', (e) => {
                e.preventDefault();
                this.openConnectionsManager();
            });
        }
        
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.switchTab(e.currentTarget.dataset.tab));
        });
        
        document.querySelectorAll('.etl-sub-tab').forEach(btn => {
            btn.addEventListener('click', (e) => this.switchEtlSubTab(e.currentTarget.dataset.etlTab));
        });
        
        document.querySelectorAll('.config-sub-tab').forEach(btn => {
            btn.addEventListener('click', (e) => this.switchConfigSubTab(e.currentTarget.dataset.configTab));
        });
        
        document.getElementById('themeToggle').addEventListener('click', () => this.toggleTheme());
        
        document.getElementById('closeModalBtn').addEventListener('click', () => this.closeModal());
        document.querySelector('.modal-overlay').addEventListener('click', () => this.closeModal());
        document.getElementById('copyCodeBtn').addEventListener('click', () => this.copyCode());
        
        // About Modal
        const openAboutBtn = document.getElementById('openAboutModal');
        const openAboutDropdown = document.getElementById('openAbout');
        const closeAboutBtn = document.getElementById('closeAboutModal');
        const aboutModal = document.getElementById('aboutModal');
        const aboutOverlay = document.getElementById('aboutModalOverlay');
        
        const openAboutModal = () => {
            if (aboutModal) {
                aboutModal.classList.add('active');
                document.querySelectorAll('.header-dropdown.open').forEach(d => d.classList.remove('open'));
            }
        };
        
        if (openAboutBtn) {
            openAboutBtn.addEventListener('click', openAboutModal);
        }
        
        if (openAboutDropdown) {
            openAboutDropdown.addEventListener('click', (e) => {
                e.preventDefault();
                openAboutModal();
            });
        }
        
        if (closeAboutBtn && aboutModal) {
            closeAboutBtn.addEventListener('click', () => {
                aboutModal.classList.remove('active');
            });
        }
        
        if (aboutOverlay && aboutModal) {
            aboutOverlay.addEventListener('click', () => {
                aboutModal.classList.remove('active');
            });
        }
        
        // Main dropdown (merged Tools + Docs)
        const mainDropdownBtn = document.getElementById('mainDropdownBtn');
        const mainDropdown = mainDropdownBtn?.closest('.header-dropdown');
        if (mainDropdownBtn && mainDropdown) {
            mainDropdownBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                mainDropdown.classList.toggle('open');
            });
        }
        
        // Close dropdowns when clicking outside
        document.addEventListener('click', (e) => {
            document.querySelectorAll('.header-dropdown.open').forEach(dropdown => {
                if (!dropdown.contains(e.target)) {
                    dropdown.classList.remove('open');
                }
            });
        });
        
        // Tools menu items
        const toolPySparkConverter = document.getElementById('toolPySparkConverter');
        const toolExpressionConverter = document.getElementById('toolExpressionConverter');
        
        if (toolPySparkConverter) {
            toolPySparkConverter.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchTool('pyspark');
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        if (toolExpressionConverter) {
            toolExpressionConverter.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchTool('expression');
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        const toolImproveQuality = document.getElementById('toolImproveQuality');
        if (toolImproveQuality) {
            toolImproveQuality.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchTool('improve');
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        const toolMappingDiagram = document.getElementById('toolMappingDiagram');
        if (toolMappingDiagram) {
            toolMappingDiagram.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchTool('diagram');
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        // XML Docs Modal
        const openXmlReferenceBtn = document.getElementById('openXmlReference');
        const xmlDocsModal = document.getElementById('xmlDocsModal');
        const closeXmlDocsBtn = document.getElementById('closeXmlDocsModal');
        const xmlDocsOverlay = document.getElementById('xmlDocsOverlay');
        
        if (openXmlReferenceBtn) {
            openXmlReferenceBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.openXmlDocsModal();
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        if (closeXmlDocsBtn) {
            closeXmlDocsBtn.addEventListener('click', () => this.closeXmlDocsModal());
        }
        
        if (xmlDocsOverlay) {
            xmlDocsOverlay.addEventListener('click', () => this.closeXmlDocsModal());
        }
        
        // PySpark Guide and About
        const openPySparkGuide = document.getElementById('openPySparkGuide');
        const openAbout = document.getElementById('openAbout');
        
        if (openPySparkGuide) {
            openPySparkGuide.addEventListener('click', (e) => {
                e.preventDefault();
                this.openPySparkGuideModal();
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        // PySpark Guide Modal
        const closePySparkGuideBtn = document.getElementById('closePySparkGuideModal');
        const pysparkGuideOverlay = document.getElementById('pysparkGuideOverlay');
        
        if (closePySparkGuideBtn) {
            closePySparkGuideBtn.addEventListener('click', () => this.closePySparkGuideModal());
        }
        
        if (pysparkGuideOverlay) {
            pysparkGuideOverlay.addEventListener('click', () => this.closePySparkGuideModal());
        }
        
        if (openAbout) {
            openAbout.addEventListener('click', (e) => {
                e.preventDefault();
                this.showToast('Informatica to PySpark Converter v4.0 by Capital Group', 'info');
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        // DB Connection Modal
        const openDbConnection = document.getElementById('openDbConnection');
        const closeDbConnectionBtn = document.getElementById('closeDbConnectionModal');
        const dbConnectionOverlay = document.getElementById('dbConnectionOverlay');
        const cancelDbConnection = document.getElementById('cancelDbConnection');
        
        if (openDbConnection) {
            openDbConnection.addEventListener('click', (e) => {
                e.preventDefault();
                this.openConnectionsManager();
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        [closeDbConnectionBtn, dbConnectionOverlay, cancelDbConnection].forEach(el => {
            if (el) el.addEventListener('click', () => this.closeSettingsModal('dbConnectionModal'));
        });
        
        // Add New Connection Button
        const addNewConnection = document.getElementById('addNewConnection');
        if (addNewConnection) {
            addNewConnection.addEventListener('click', () => this.openConnectionForm());
        }
        
        // Connection Form Modal
        const closeConnectionFormBtn = document.getElementById('closeConnectionFormModal');
        const connectionFormOverlay = document.getElementById('connectionFormOverlay');
        const cancelConnectionForm = document.getElementById('cancelConnectionForm');
        const saveConnectionForm = document.getElementById('saveConnectionForm');
        
        [closeConnectionFormBtn, connectionFormOverlay, cancelConnectionForm].forEach(el => {
            if (el) el.addEventListener('click', () => this.closeSettingsModal('connectionFormModal'));
        });
        
        if (saveConnectionForm) {
            saveConnectionForm.addEventListener('click', () => this.saveConnection());
        }
        
        // File Path Modal
        const openFilePath = document.getElementById('openFilePath');
        const closeFilePathBtn = document.getElementById('closeFilePathModal');
        const filePathOverlay = document.getElementById('filePathOverlay');
        const cancelFilePath = document.getElementById('cancelFilePath');
        const saveFilePath = document.getElementById('saveFilePath');
        
        if (openFilePath) {
            openFilePath.addEventListener('click', (e) => {
                e.preventDefault();
                this.openSettingsModal('filePathModal');
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        [closeFilePathBtn, filePathOverlay, cancelFilePath].forEach(el => {
            if (el) el.addEventListener('click', () => this.closeSettingsModal('filePathModal'));
        });
        
        if (saveFilePath) {
            saveFilePath.addEventListener('click', () => this.saveFilePathSettings());
        }
    }
    
    openSettingsModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('open');
            document.body.style.overflow = 'hidden';
            this.loadSettingsFromStorage(modalId);
        }
    }
    
    closeSettingsModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('open');
            document.body.style.overflow = '';
        }
    }
    
    loadSettingsFromStorage(modalId) {
        if (modalId === 'filePathModal') {
            const settings = JSON.parse(localStorage.getItem('filePathSettings') || '{}');
            if (settings.sourceFilePath) document.getElementById('sourceFilePath').value = settings.sourceFilePath;
            if (settings.lookupFilePath) document.getElementById('lookupFilePath').value = settings.lookupFilePath;
            if (settings.targetFilePath) document.getElementById('targetFilePath').value = settings.targetFilePath;
            if (settings.logFilePath) document.getElementById('logFilePath').value = settings.logFilePath;
            if (settings.checkpointPath) document.getElementById('checkpointPath').value = settings.checkpointPath;
            if (settings.cloudStorageType) document.getElementById('cloudStorageType').value = settings.cloudStorageType;
            if (settings.cloudBasePath) document.getElementById('cloudBasePath').value = settings.cloudBasePath;
        }
    }
    
    // Connection Management Methods
    getConnections() {
        return JSON.parse(localStorage.getItem('dbConnections') || '[]');
    }
    
    saveConnections(connections) {
        localStorage.setItem('dbConnections', JSON.stringify(connections));
    }
    
    openConnectionsManager() {
        this.openSettingsModal('dbConnectionModal');
        this.renderConnectionsList();
    }
    
    renderConnectionsList() {
        const connections = this.getConnections();
        const listEl = document.getElementById('connectionsList');
        const countEl = document.getElementById('connectionCount');
        const emptyEl = document.getElementById('emptyConnections');
        
        countEl.textContent = connections.length;
        
        if (connections.length === 0) {
            listEl.innerHTML = '';
            listEl.appendChild(emptyEl.cloneNode(true));
            return;
        }
        
        const typeIcons = {
            source: 'fas fa-arrow-right',
            target: 'fas fa-arrow-left',
            lookup: 'fas fa-search'
        };
        
        listEl.innerHTML = connections.map(conn => `
            <div class="connection-card" data-id="${conn.id}">
                <div class="connection-icon ${conn.connType}-type">
                    <i class="${typeIcons[conn.connType] || 'fas fa-database'}"></i>
                </div>
                <div class="connection-details">
                    <div class="connection-name">${this.escapeHtml(conn.name)}</div>
                    <div class="connection-meta">
                        <span class="connection-badge ${conn.connType}">${conn.connType}</span>
                        <span class="connection-badge">${conn.dbType.toUpperCase()}</span>
                        <span class="connection-url" title="${this.escapeHtml(conn.jdbcUrl)}">${this.escapeHtml(conn.jdbcUrl)}</span>
                    </div>
                </div>
                <div class="connection-actions">
                    <button class="btn btn-secondary" onclick="window.converter.editConnection('${conn.id}')" title="Edit" data-testid="button-edit-conn-${conn.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-danger" onclick="window.converter.deleteConnection('${conn.id}')" title="Delete" data-testid="button-delete-conn-${conn.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    openConnectionForm(connectionId = null) {
        const modal = document.getElementById('connectionFormModal');
        const title = document.getElementById('connectionFormTitle');
        const editingId = document.getElementById('editingConnectionId');
        
        // Reset form
        document.getElementById('connName').value = '';
        document.getElementById('connType').value = 'source';
        document.getElementById('connDbType').value = 'oracle';
        document.getElementById('connJdbcUrl').value = '';
        document.getElementById('connUser').value = '';
        document.getElementById('connPassword').value = '';
        document.getElementById('connSchema').value = '';
        
        if (connectionId) {
            const connections = this.getConnections();
            const conn = connections.find(c => c.id === connectionId);
            if (conn) {
                title.textContent = 'Edit Connection';
                editingId.value = connectionId;
                document.getElementById('connName').value = conn.name;
                document.getElementById('connType').value = conn.connType;
                document.getElementById('connDbType').value = conn.dbType;
                document.getElementById('connJdbcUrl').value = conn.jdbcUrl;
                document.getElementById('connUser').value = conn.user || '';
                document.getElementById('connPassword').value = conn.password || '';
                document.getElementById('connSchema').value = conn.schema || '';
            }
        } else {
            title.textContent = 'Add Connection';
            editingId.value = '';
        }
        
        modal.classList.add('open');
    }
    
    saveConnection() {
        const name = document.getElementById('connName').value.trim();
        const connType = document.getElementById('connType').value;
        const dbType = document.getElementById('connDbType').value;
        const jdbcUrl = document.getElementById('connJdbcUrl').value.trim();
        const user = document.getElementById('connUser').value.trim();
        const password = document.getElementById('connPassword').value;
        const schema = document.getElementById('connSchema').value.trim();
        const editingId = document.getElementById('editingConnectionId').value;
        
        if (!name) {
            this.showToast('Connection name is required', 'error');
            return;
        }
        if (!jdbcUrl) {
            this.showToast('JDBC URL is required', 'error');
            return;
        }
        
        const connections = this.getConnections();
        
        // Check for duplicate names
        const duplicate = connections.find(c => c.name.toLowerCase() === name.toLowerCase() && c.id !== editingId);
        if (duplicate) {
            this.showToast('A connection with this name already exists', 'error');
            return;
        }
        
        if (editingId) {
            // Update existing
            const index = connections.findIndex(c => c.id === editingId);
            if (index !== -1) {
                connections[index] = { ...connections[index], name, connType, dbType, jdbcUrl, user, password, schema };
            }
        } else {
            // Add new
            connections.push({
                id: 'conn_' + Date.now(),
                name,
                connType,
                dbType,
                jdbcUrl,
                user,
                password,
                schema
            });
        }
        
        this.saveConnections(connections);
        this.closeSettingsModal('connectionFormModal');
        this.renderConnectionsList();
        this.showToast(editingId ? 'Connection updated' : 'Connection added', 'success');
    }
    
    editConnection(connectionId) {
        this.openConnectionForm(connectionId);
    }
    
    deleteConnection(connectionId) {
        if (!confirm('Are you sure you want to delete this connection?')) return;
        
        const connections = this.getConnections();
        const filtered = connections.filter(c => c.id !== connectionId);
        this.saveConnections(filtered);
        this.renderConnectionsList();
        this.showToast('Connection deleted', 'success');
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    saveFilePathSettings() {
        const settings = {
            sourceFilePath: document.getElementById('sourceFilePath').value,
            lookupFilePath: document.getElementById('lookupFilePath').value,
            targetFilePath: document.getElementById('targetFilePath').value,
            logFilePath: document.getElementById('logFilePath').value,
            checkpointPath: document.getElementById('checkpointPath').value,
            cloudStorageType: document.getElementById('cloudStorageType').value,
            cloudBasePath: document.getElementById('cloudBasePath').value
        };
        localStorage.setItem('filePathSettings', JSON.stringify(settings));
        this.closeSettingsModal('filePathModal');
        this.showToast('File path settings saved', 'success');
    }
    
    switchTool(tool) {
        const pysparkView = document.getElementById('pysparkConverterView');
        const expressionView = document.getElementById('expressionConverterView');
        const improveView = document.getElementById('improveQualityView');
        const diagramView = document.getElementById('mappingDiagramView');
        const toolPySpark = document.getElementById('toolPySparkConverter');
        const toolExpression = document.getElementById('toolExpressionConverter');
        const toolImprove = document.getElementById('toolImproveQuality');
        const toolDiagram = document.getElementById('toolMappingDiagram');
        
        // Hide all views
        if (pysparkView) pysparkView.style.display = 'none';
        if (expressionView) expressionView.style.display = 'none';
        if (improveView) improveView.style.display = 'none';
        if (diagramView) diagramView.style.display = 'none';
        
        // Remove active from all menu items
        if (toolPySpark) toolPySpark.classList.remove('active');
        if (toolExpression) toolExpression.classList.remove('active');
        if (toolImprove) toolImprove.classList.remove('active');
        if (toolDiagram) toolDiagram.classList.remove('active');
        
        if (tool === 'pyspark') {
            if (pysparkView) pysparkView.style.display = '';
            if (toolPySpark) toolPySpark.classList.add('active');
        } else if (tool === 'expression') {
            if (expressionView) expressionView.style.display = 'block';
            if (toolExpression) toolExpression.classList.add('active');
            this.initExpressionConverter();
        } else if (tool === 'improve') {
            if (improveView) improveView.style.display = 'block';
            if (toolImprove) toolImprove.classList.add('active');
            this.initImproveQuality();
        } else if (tool === 'diagram') {
            if (diagramView) diagramView.style.display = 'block';
            if (toolDiagram) toolDiagram.classList.add('active');
            this.initMappingDiagram();
        }
    }
    
    initExpressionConverter() {
        const convertBtn = document.getElementById('convertExpressionBtn');
        const clearBtn = document.getElementById('clearExpressionBtn');
        const copyBtn = document.getElementById('copyPySparkExprBtn');
        
        if (convertBtn && !convertBtn.hasAttribute('data-initialized')) {
            convertBtn.setAttribute('data-initialized', 'true');
            convertBtn.addEventListener('click', () => this.convertExpression());
        }
        
        if (clearBtn && !clearBtn.hasAttribute('data-initialized')) {
            clearBtn.setAttribute('data-initialized', 'true');
            clearBtn.addEventListener('click', () => this.clearExpression());
        }
        
        if (copyBtn && !copyBtn.hasAttribute('data-initialized')) {
            copyBtn.setAttribute('data-initialized', 'true');
            copyBtn.addEventListener('click', () => this.copyPySparkExpression());
        }
        
        // Function item click to insert
        document.querySelectorAll('.function-item').forEach(item => {
            if (!item.hasAttribute('data-initialized')) {
                item.setAttribute('data-initialized', 'true');
                item.addEventListener('click', () => {
                    const infaFunc = item.getAttribute('data-infa');
                    const textarea = document.getElementById('infaExpression');
                    if (textarea) {
                        const start = textarea.selectionStart;
                        const end = textarea.selectionEnd;
                        const text = textarea.value;
                        textarea.value = text.substring(0, start) + infaFunc + '()' + text.substring(end);
                        textarea.focus();
                        textarea.setSelectionRange(start + infaFunc.length + 1, start + infaFunc.length + 1);
                    }
                });
            }
        });
    }
    
    async convertExpression() {
        const input = document.getElementById('infaExpression');
        const output = document.getElementById('pysparkExpressionOutput');
        
        if (!input || !output) return;
        
        const expression = input.value.trim();
        if (!expression) {
            this.showToast('Please enter an Informatica expression', 'warning');
            return;
        }
        
        try {
            const response = await fetch('/api/convert-expression', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ expression })
            });
            
            const result = await response.json();
            
            if (result.success) {
                output.innerHTML = `<code>${this.escapeHtml(result.pyspark_expression)}</code>`;
                this.showToast('Expression converted successfully', 'success');
            } else {
                output.innerHTML = `<span class="error-text">${this.escapeHtml(result.error || 'Conversion failed')}</span>`;
                this.showToast(result.error || 'Conversion failed', 'error');
            }
        } catch (error) {
            output.innerHTML = `<span class="error-text">Error: ${this.escapeHtml(error.message)}</span>`;
            this.showToast('Failed to convert expression', 'error');
        }
    }
    
    clearExpression() {
        const input = document.getElementById('infaExpression');
        const output = document.getElementById('pysparkExpressionOutput');
        
        if (input) input.value = '';
        if (output) output.innerHTML = '<span class="placeholder-text">Converted PySpark expression will appear here...</span>';
    }
    
    copyPySparkExpression() {
        const output = document.getElementById('pysparkExpressionOutput');
        if (!output) return;
        
        const code = output.querySelector('code');
        if (code) {
            navigator.clipboard.writeText(code.textContent).then(() => {
                this.showToast('Copied to clipboard', 'success');
            });
        } else {
            this.showToast('No expression to copy', 'warning');
        }
    }
    
    initImproveQuality() {
        this.improveXmlFile = null;
        this.improvePysparkFile = null;
        this.improvedCode = null;
        
        const xmlDropZone = document.getElementById('xmlDropZone');
        const xmlFileInput = document.getElementById('xmlFileInput');
        const pysparkDropZone = document.getElementById('pysparkDropZone');
        const pysparkFileInput = document.getElementById('pysparkFileInput');
        const analyzeQualityBtn = document.getElementById('analyzeQualityBtn');
        const removeXmlFile = document.getElementById('removeXmlFile');
        const removePysparkFile = document.getElementById('removePysparkFile');
        
        if (xmlDropZone && !xmlDropZone.hasAttribute('data-initialized')) {
            xmlDropZone.setAttribute('data-initialized', 'true');
            xmlDropZone.addEventListener('click', () => xmlFileInput?.click());
            xmlDropZone.addEventListener('dragover', (e) => { e.preventDefault(); e.currentTarget.classList.add('dragover'); });
            xmlDropZone.addEventListener('dragleave', (e) => { e.preventDefault(); e.currentTarget.classList.remove('dragover'); });
            xmlDropZone.addEventListener('drop', (e) => this.handleImproveXmlDrop(e));
        }
        
        if (xmlFileInput && !xmlFileInput.hasAttribute('data-initialized')) {
            xmlFileInput.setAttribute('data-initialized', 'true');
            xmlFileInput.addEventListener('change', (e) => this.handleImproveXmlSelect(e));
        }
        
        if (pysparkDropZone && !pysparkDropZone.hasAttribute('data-initialized')) {
            pysparkDropZone.setAttribute('data-initialized', 'true');
            pysparkDropZone.addEventListener('click', () => pysparkFileInput?.click());
            pysparkDropZone.addEventListener('dragover', (e) => { e.preventDefault(); e.currentTarget.classList.add('dragover'); });
            pysparkDropZone.addEventListener('dragleave', (e) => { e.preventDefault(); e.currentTarget.classList.remove('dragover'); });
            pysparkDropZone.addEventListener('drop', (e) => this.handleImprovePysparkDrop(e));
        }
        
        if (pysparkFileInput && !pysparkFileInput.hasAttribute('data-initialized')) {
            pysparkFileInput.setAttribute('data-initialized', 'true');
            pysparkFileInput.addEventListener('change', (e) => this.handleImprovePysparkSelect(e));
        }
        
        if (analyzeQualityBtn && !analyzeQualityBtn.hasAttribute('data-initialized')) {
            analyzeQualityBtn.setAttribute('data-initialized', 'true');
            analyzeQualityBtn.addEventListener('click', () => this.analyzeQuality());
        }
        
        // Notebook tab switching
        document.querySelectorAll('.notebook-nav-btn').forEach(btn => {
            if (!btn.hasAttribute('data-initialized')) {
                btn.setAttribute('data-initialized', 'true');
                btn.addEventListener('click', () => this.switchNotebookTab(btn.dataset.notebookTab));
            }
        });
        
        if (removeXmlFile && !removeXmlFile.hasAttribute('data-initialized')) {
            removeXmlFile.setAttribute('data-initialized', 'true');
            removeXmlFile.addEventListener('click', () => this.removeImproveXmlFile());
        }
        
        if (removePysparkFile && !removePysparkFile.hasAttribute('data-initialized')) {
            removePysparkFile.setAttribute('data-initialized', 'true');
            removePysparkFile.addEventListener('click', () => this.removeImprovePysparkFile());
        }
        
        // Quality tabs
        document.querySelectorAll('.quality-tab-btn').forEach(btn => {
            if (!btn.hasAttribute('data-initialized')) {
                btn.setAttribute('data-initialized', 'true');
                btn.addEventListener('click', (e) => this.switchQualityTab(e.currentTarget.dataset.qualityTab));
            }
        });
        
        // Copy and download buttons
        const copyImprovedBtn = document.getElementById('copyImprovedCodeBtn');
        const downloadImprovedBtn = document.getElementById('downloadImprovedCodeBtn');
        
        if (copyImprovedBtn && !copyImprovedBtn.hasAttribute('data-initialized')) {
            copyImprovedBtn.setAttribute('data-initialized', 'true');
            copyImprovedBtn.addEventListener('click', () => this.copyImprovedCode());
        }
        
        if (downloadImprovedBtn && !downloadImprovedBtn.hasAttribute('data-initialized')) {
            downloadImprovedBtn.setAttribute('data-initialized', 'true');
            downloadImprovedBtn.addEventListener('click', () => this.downloadImprovedCode());
        }
    }
    
    // ============================================
    // MAPPING DIAGRAM METHODS
    // ============================================
    
    initMappingDiagram() {
        this.diagramData = null;
        this.diagramZoom = 1;
        this._diagramInitialized = false;
        this.currentDiagramType = 'dataflow';
        
        const dropZone = document.getElementById('diagramDropZone');
        const fileInput = document.getElementById('diagramFileInput');
        const usePrevBtn = document.getElementById('usePreviousXmlBtn');
        const mappingSelect = document.getElementById('diagramMappingSelect');
        const zoomIn = document.getElementById('zoomInBtn');
        const zoomOut = document.getElementById('zoomOutBtn');
        const resetZoom = document.getElementById('resetZoomBtn');
        const downloadBtn = document.getElementById('downloadDiagramBtn');
        
        if (dropZone && !dropZone.hasAttribute('data-initialized')) {
            dropZone.setAttribute('data-initialized', 'true');
            dropZone.addEventListener('click', (e) => {
                if (e.target.tagName !== 'LABEL' && !e.target.closest('label')) {
                    fileInput?.click();
                }
            });
            dropZone.addEventListener('dragover', (e) => { 
                e.preventDefault(); 
                dropZone.classList.add('drag-over'); 
            });
            dropZone.addEventListener('dragleave', (e) => { 
                e.preventDefault(); 
                dropZone.classList.remove('drag-over'); 
            });
            dropZone.addEventListener('drop', (e) => this.handleDiagramDrop(e));
        }
        
        const browseLabel = dropZone?.querySelector('label[for="diagramFileInput"]');
        if (browseLabel && !browseLabel.hasAttribute('data-initialized')) {
            browseLabel.setAttribute('data-initialized', 'true');
            browseLabel.addEventListener('click', (e) => {
                e.stopPropagation();
            });
        }
        
        if (fileInput && !fileInput.hasAttribute('data-initialized')) {
            fileInput.setAttribute('data-initialized', 'true');
            fileInput.addEventListener('change', (e) => this.handleDiagramFileSelect(e));
        }
        
        if (usePrevBtn && !usePrevBtn.hasAttribute('data-initialized')) {
            usePrevBtn.setAttribute('data-initialized', 'true');
            usePrevBtn.addEventListener('click', () => this.usePreviousXmlForDiagram());
        }
        
        document.querySelectorAll('.diagram-tab').forEach(tab => {
            if (!tab.hasAttribute('data-initialized')) {
                tab.setAttribute('data-initialized', 'true');
                tab.addEventListener('click', (e) => this.switchDiagramType(e.currentTarget.dataset.type));
            }
        });
        
        if (mappingSelect && !mappingSelect.hasAttribute('data-initialized')) {
            mappingSelect.setAttribute('data-initialized', 'true');
            mappingSelect.addEventListener('change', () => this.switchDiagramMapping());
        }
        
        if (zoomIn && !zoomIn.hasAttribute('data-initialized')) {
            zoomIn.setAttribute('data-initialized', 'true');
            zoomIn.addEventListener('click', () => this.zoomDiagram(0.2));
        }
        
        if (zoomOut && !zoomOut.hasAttribute('data-initialized')) {
            zoomOut.setAttribute('data-initialized', 'true');
            zoomOut.addEventListener('click', () => this.zoomDiagram(-0.2));
        }
        
        if (resetZoom && !resetZoom.hasAttribute('data-initialized')) {
            resetZoom.setAttribute('data-initialized', 'true');
            resetZoom.addEventListener('click', () => this.resetDiagramZoom());
        }
        
        if (downloadBtn && !downloadBtn.hasAttribute('data-initialized')) {
            downloadBtn.setAttribute('data-initialized', 'true');
            downloadBtn.addEventListener('click', () => this.downloadDiagram());
        }
        
        document.querySelectorAll('.collapsible-header').forEach(header => {
            if (!header.hasAttribute('data-initialized')) {
                header.setAttribute('data-initialized', 'true');
                header.addEventListener('click', () => {
                    header.closest('.collapsible').classList.toggle('collapsed');
                });
            }
        });
        
        if (typeof mermaid !== 'undefined' && !this._diagramInitialized) {
            this._diagramInitialized = true;
            mermaid.initialize({
                startOnLoad: false,
                theme: document.body.classList.contains('dark') ? 'dark' : 'default',
                securityLevel: 'loose',
                flowchart: {
                    useMaxWidth: true,
                    htmlLabels: true,
                    curve: 'basis'
                }
            });
        }
    }
    
    switchDiagramType(type) {
        this.currentDiagramType = type;
        
        document.querySelectorAll('.diagram-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.type === type);
        });
        
        if (this.diagramData) {
            this.regenerateDiagram();
        }
    }
    
    handleDiagramDrop(e) {
        e.preventDefault();
        e.currentTarget.classList.remove('drag-over');
        const files = e.dataTransfer.files;
        if (files.length > 0 && files[0].name.toLowerCase().endsWith('.xml')) {
            this.processDiagramFile(files[0]);
        } else {
            this.showToast('Please upload an XML file', 'warning');
        }
    }
    
    handleDiagramFileSelect(e) {
        const files = e.target.files;
        if (files.length > 0) {
            this.processDiagramFile(files[0]);
        }
    }
    
    async processDiagramFile(file) {
        this.diagramFile = file;
        const formData = new FormData();
        formData.append('file', file);
        formData.append('diagram_type', this.currentDiagramType || 'dataflow');
        
        try {
            this.showToast('Generating diagram...', 'info');
            
            const response = await fetch('/api/diagram', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.diagramData = result;
                this.displayDiagram(result);
                this.showToast('Diagram generated successfully', 'success');
            } else {
                this.showToast(result.error || 'Failed to generate diagram', 'error');
            }
        } catch (error) {
            this.showToast('Error generating diagram: ' + error.message, 'error');
        }
    }
    
    async usePreviousXmlForDiagram() {
        if (!this.artifactId) {
            this.showToast('No previous XML file available. Please upload a file first.', 'warning');
            return;
        }
        
        try {
            this.showToast('Generating diagram from previous analysis...', 'info');
            
            const response = await fetch('/api/diagram/from-artifact', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    artifact_id: this.artifactId,
                    diagram_type: this.currentDiagramType || 'dataflow'
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.diagramData = result;
                this.displayDiagram(result);
                this.showToast('Diagram generated successfully', 'success');
            } else {
                this.showToast(result.error || 'Failed to generate diagram', 'error');
            }
        } catch (error) {
            this.showToast('Error generating diagram: ' + error.message, 'error');
        }
    }
    
    displayDiagram(result) {
        const uploadPanel = document.getElementById('diagramUploadPanel');
        const viewerContainer = document.getElementById('diagramViewerContainer');
        const mappingSelector = document.getElementById('diagramMappingSelector');
        const mappingSelect = document.getElementById('diagramMappingSelect');
        const warningsPanel = document.getElementById('diagramWarnings');
        const warningsText = document.getElementById('diagramWarningsText');
        const tabsBar = document.getElementById('diagramTabsBar');
        const controlsBar = document.getElementById('diagramControlsBar');
        
        if (uploadPanel) uploadPanel.style.display = 'none';
        if (viewerContainer) viewerContainer.style.display = 'flex';
        if (tabsBar) tabsBar.style.display = 'flex';
        if (controlsBar) controlsBar.style.display = 'flex';
        
        if (result.mappings && result.mappings.length > 0 && mappingSelect) {
            mappingSelect.innerHTML = result.mappings.map(m => 
                `<option value="${this.escapeHtml(m)}">${this.escapeHtml(m)}</option>`
            ).join('');
            
            if (result.mappings.length > 1 && mappingSelector) {
                mappingSelector.style.display = 'flex';
            }
        }
        
        if (result.mapping_info) {
            const info = result.mapping_info;
            document.getElementById('diagramMappingName').textContent = info.name || '-';
            document.getElementById('diagramSourceCount').textContent = info.source_count || 0;
            document.getElementById('diagramTargetCount').textContent = info.target_count || 0;
            document.getElementById('diagramTransformCount').textContent = info.transformation_count || 0;
        }
        
        if (result.elements) {
            this.displayDiagramElements(result.elements);
            this.populateParsedXmlSummary(result.elements);
        }
        
        const firstMapping = result.mappings?.[0];
        if (firstMapping && result.diagrams?.[firstMapping]) {
            const diagramData = result.diagrams[firstMapping];
            this.currentDiagramNodes = diagramData.nodes || [];
            this.renderMermaidDiagram(diagramData.mermaid);
            
            if (diagramData.warnings && diagramData.warnings.length > 0 && warningsPanel && warningsText) {
                warningsPanel.style.display = 'flex';
                warningsText.textContent = diagramData.warnings.join(' | ');
            } else if (warningsPanel) {
                warningsPanel.style.display = 'none';
            }
        }
    }
    
    populateParsedXmlSummary(elements) {
        const sourcesList = document.getElementById('parsedSourcesList');
        const targetsList = document.getElementById('parsedTargetsList');
        const transformsList = document.getElementById('parsedTransformsList');
        
        if (!sourcesList || !targetsList || !transformsList) return;
        
        const sources = elements.filter(e => e.type === 'source');
        const targets = elements.filter(e => e.type === 'target');
        const transforms = elements.filter(e => e.type === 'transformation');
        
        sourcesList.innerHTML = sources.length > 0 
            ? sources.map(s => `<li>${this.escapeHtml(s.name)}</li>`).join('')
            : '<li class="empty-item">No sources found</li>';
        
        targetsList.innerHTML = targets.length > 0
            ? targets.map(t => `<li>${this.escapeHtml(t.name)}</li>`).join('')
            : '<li class="empty-item">No targets found</li>';
        
        transformsList.innerHTML = transforms.length > 0
            ? transforms.map(t => `<li>${this.escapeHtml(t.name)} <small>(${this.escapeHtml(t.trans_type || '')})</small></li>`).join('')
            : '<li class="empty-item">No transformations found</li>';
    }
    
    displayDiagramElements(elements) {
        const container = document.getElementById('diagramElementsList');
        if (!container) return;
        
        let html = '';
        elements.forEach(el => {
            const icon = el.icon || 'fa-cog';
            const typeClass = el.type || 'transformation';
            const typeBadge = el.trans_type || el.type || '';
            
            html += `
                <div class="element-item ${typeClass}" data-element="${this.escapeHtml(el.name)}">
                    <i class="fas ${icon}"></i>
                    <span>${this.escapeHtml(el.name)}</span>
                    ${typeBadge ? `<span class="element-type-badge">${this.escapeHtml(typeBadge)}</span>` : ''}
                </div>
            `;
        });
        
        container.innerHTML = html;
    }
    
    async renderMermaidDiagram(mermaidCode) {
        const container = document.getElementById('mermaidDiagram');
        if (!container || !mermaidCode) return;
        
        try {
            container.innerHTML = '';
            container.textContent = mermaidCode;
            
            if (typeof mermaid !== 'undefined') {
                const isDark = document.body.classList.contains('dark');
                mermaid.initialize({
                    startOnLoad: false,
                    theme: isDark ? 'dark' : 'default',
                    securityLevel: 'loose',
                    flowchart: {
                        useMaxWidth: true,
                        htmlLabels: true,
                        curve: 'basis'
                    }
                });
                
                const { svg } = await mermaid.render('mermaid-svg-' + Date.now(), mermaidCode);
                container.innerHTML = svg;
                
                this.addDiagramTooltips(container);
            }
        } catch (error) {
            console.error('Mermaid render error:', error);
            container.innerHTML = `<pre class="error-text">${this.escapeHtml(mermaidCode)}</pre>`;
        }
    }
    
    addDiagramTooltips(container) {
        if (!this.currentDiagramNodes || this.currentDiagramNodes.length === 0) return;
        
        const nodes = container.querySelectorAll('.node');
        nodes.forEach(node => {
            const textContent = node.textContent?.trim() || '';
            
            const matchedNode = this.currentDiagramNodes.find(n => {
                const label = (n.label || '').replace(/\\n/g, ' ').trim();
                const labelParts = label.split('<br/>')[0].trim();
                return textContent.includes(labelParts) || textContent.includes(n.label);
            });
            
            if (matchedNode?.tooltip) {
                node.style.cursor = 'pointer';
                
                const boundEnter = (e) => {
                    this.showDiagramTooltip(e, matchedNode.tooltip);
                };
                const boundLeave = () => {
                    this.hideDiagramTooltip();
                };
                
                node.removeEventListener('mouseenter', boundEnter);
                node.removeEventListener('mouseleave', boundLeave);
                node.addEventListener('mouseenter', boundEnter);
                node.addEventListener('mouseleave', boundLeave);
            }
        });
    }
    
    showDiagramTooltip(event, text) {
        let tooltip = document.getElementById('diagramTooltip');
        if (!tooltip) {
            tooltip = document.createElement('div');
            tooltip.id = 'diagramTooltip';
            tooltip.className = 'diagram-tooltip';
            document.body.appendChild(tooltip);
        }
        
        tooltip.textContent = text.replace(/\\n/g, '\n');
        tooltip.style.display = 'block';
        tooltip.style.left = event.pageX + 10 + 'px';
        tooltip.style.top = event.pageY + 10 + 'px';
    }
    
    hideDiagramTooltip() {
        const tooltip = document.getElementById('diagramTooltip');
        if (tooltip) {
            tooltip.style.display = 'none';
        }
    }
    
    async regenerateDiagram() {
        if (!this.diagramData && !this.diagramFile) return;
        
        const diagramType = this.currentDiagramType || 'dataflow';
        const mappingName = document.getElementById('diagramMappingSelect')?.value;
        
        if (this.diagramFile) {
            const formData = new FormData();
            formData.append('file', this.diagramFile);
            formData.append('diagram_type', diagramType);
            if (mappingName) formData.append('mapping_name', mappingName);
            
            try {
                const response = await fetch('/api/diagram', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    this.diagramData = result;
                    this.displayDiagram(result);
                }
            } catch (error) {
                this.showToast('Error regenerating diagram', 'error');
            }
        } else if (this.artifactId) {
            try {
                const response = await fetch('/api/diagram/from-artifact', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        artifact_id: this.artifactId,
                        diagram_type: diagramType,
                        mapping_name: mappingName
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    this.diagramData = result;
                    this.displayDiagram(result);
                }
            } catch (error) {
                this.showToast('Error regenerating diagram', 'error');
            }
        }
    }
    
    switchDiagramMapping() {
        if (!this.diagramData?.diagrams) return;
        
        const mappingName = document.getElementById('diagramMappingSelect').value;
        const diagramInfo = this.diagramData.diagrams[mappingName];
        const warningsPanel = document.getElementById('diagramWarnings');
        const warningsText = document.getElementById('diagramWarningsText');
        
        if (diagramInfo) {
            this.currentDiagramNodes = diagramInfo.nodes || [];
            
            if (diagramInfo.mermaid) {
                this.renderMermaidDiagram(diagramInfo.mermaid);
            }
            
            if (diagramInfo.warnings && diagramInfo.warnings.length > 0 && warningsPanel && warningsText) {
                warningsPanel.style.display = 'flex';
                warningsText.textContent = diagramInfo.warnings.join(' | ');
            } else if (warningsPanel) {
                warningsPanel.style.display = 'none';
            }
        }
        
        if (this.diagramData.elements_by_mapping?.[mappingName]) {
            this.displayDiagramElements(this.diagramData.elements_by_mapping[mappingName]);
            this.populateParsedXmlSummary(this.diagramData.elements_by_mapping[mappingName]);
        }
        
        if (this.diagramData.mapping_info_by_mapping?.[mappingName]) {
            const info = this.diagramData.mapping_info_by_mapping[mappingName];
            document.getElementById('diagramMappingName').textContent = info.name || '-';
            document.getElementById('diagramSourceCount').textContent = info.source_count || 0;
            document.getElementById('diagramTargetCount').textContent = info.target_count || 0;
            document.getElementById('diagramTransformCount').textContent = info.transformation_count || 0;
        }
    }
    
    zoomDiagram(delta) {
        this.diagramZoom = Math.max(0.2, Math.min(3, this.diagramZoom + delta));
        const canvas = document.getElementById('diagramCanvas');
        if (canvas) {
            canvas.style.transform = `scale(${this.diagramZoom})`;
            canvas.style.transformOrigin = 'center center';
        }
    }
    
    resetDiagramZoom() {
        this.diagramZoom = 1;
        const canvas = document.getElementById('diagramCanvas');
        if (canvas) {
            canvas.style.transform = 'scale(1)';
        }
    }
    
    downloadDiagram() {
        const svg = document.querySelector('#mermaidDiagram svg');
        if (!svg) {
            this.showToast('No diagram to download', 'warning');
            return;
        }
        
        // Create a canvas to render SVG
        const svgData = new XMLSerializer().serializeToString(svg);
        const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
        const url = URL.createObjectURL(svgBlob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = 'mapping_diagram.svg';
        link.click();
        
        URL.revokeObjectURL(url);
        this.showToast('Diagram downloaded', 'success');
    }
    
    handleImproveXmlDrop(e) {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
        const files = e.dataTransfer.files;
        if (files.length > 0 && files[0].name.toLowerCase().endsWith('.xml')) {
            this.setImproveXmlFile(files[0]);
        } else {
            this.showToast('Please upload an XML file', 'warning');
        }
    }
    
    handleImproveXmlSelect(e) {
        const files = e.target.files;
        if (files.length > 0) {
            this.setImproveXmlFile(files[0]);
        }
    }
    
    setImproveXmlFile(file) {
        this.improveXmlFile = file;
        document.getElementById('xmlFileName').textContent = file.name;
        document.getElementById('xmlDropZone').classList.add('hidden');
        document.getElementById('xmlFileSelected').classList.remove('hidden');
        this.updateImproveAnalyzeBtn();
    }
    
    removeImproveXmlFile() {
        this.improveXmlFile = null;
        document.getElementById('xmlFileInput').value = '';
        document.getElementById('xmlDropZone').classList.remove('hidden');
        document.getElementById('xmlFileSelected').classList.add('hidden');
        this.updateImproveAnalyzeBtn();
    }
    
    handleImprovePysparkDrop(e) {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
        const files = e.dataTransfer.files;
        if (files.length > 0 && files[0].name.toLowerCase().endsWith('.py')) {
            this.setImprovePysparkFile(files[0]);
        } else {
            this.showToast('Please upload a .py file', 'warning');
        }
    }
    
    handleImprovePysparkSelect(e) {
        const files = e.target.files;
        if (files.length > 0) {
            this.setImprovePysparkFile(files[0]);
        }
    }
    
    setImprovePysparkFile(file) {
        this.improvePysparkFile = file;
        document.getElementById('pysparkFileName').textContent = file.name;
        document.getElementById('pysparkDropZone').classList.add('hidden');
        document.getElementById('pysparkFileSelected').classList.remove('hidden');
        this.updateImproveAnalyzeBtn();
    }
    
    removeImprovePysparkFile() {
        this.improvePysparkFile = null;
        document.getElementById('pysparkFileInput').value = '';
        document.getElementById('pysparkDropZone').classList.remove('hidden');
        document.getElementById('pysparkFileSelected').classList.add('hidden');
        this.updateImproveAnalyzeBtn();
    }
    
    updateImproveAnalyzeBtn() {
        const btn = document.getElementById('analyzeQualityBtn');
        if (btn) {
            btn.disabled = !(this.improveXmlFile && this.improvePysparkFile);
        }
    }
    
    async analyzeQuality() {
        if (!this.improveXmlFile || !this.improvePysparkFile) {
            this.showToast('Please upload both XML and PySpark files', 'warning');
            return;
        }
        
        const btn = document.getElementById('analyzeQualityBtn');
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Analyzing...</span>';
        }
        
        try {
            const formData = new FormData();
            formData.append('xml_file', this.improveXmlFile);
            formData.append('pyspark_file', this.improvePysparkFile);
            formData.append('target_platform', document.getElementById('targetPlatform')?.value || 'databricks');
            formData.append('output_format', document.getElementById('outputFormat')?.value || 'delta');
            formData.append('naming_convention', document.getElementById('namingConvention')?.value || 'snake_case');
            
            const response = await fetch('/api/improve-quality', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.improvedCode = result.improved_code;
                this.displayQualityResults(result);
                this.showToast('Analysis complete', 'success');
            } else {
                this.showToast(result.error || 'Analysis failed', 'error');
            }
        } catch (error) {
            this.showToast('Failed to analyze code: ' + error.message, 'error');
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-search"></i> <span>Analyze & Improve Code</span>';
            }
        }
    }
    
    displayQualityResults(result) {
        const resultsDiv = document.getElementById('qualityResults');
        resultsDiv.classList.remove('hidden');
        
        // Store result for later use
        this.qualityResult = result;
        
        // Score with radial gauge
        const scoreValue = document.getElementById('qualityScoreValue');
        const gaugeCircle = document.getElementById('gaugeCircle');
        const scoreDesc = document.getElementById('qualityScoreDesc');
        
        const score = result.quality_score || 0;
        scoreValue.textContent = score;
        
        // Animate the radial gauge
        const circumference = 2 * Math.PI * 54; // r=54
        const offset = circumference - (score / 100) * circumference;
        gaugeCircle.style.strokeDashoffset = offset;
        
        // Set score color class
        let scoreClass = 'score-poor';
        let descText = 'Needs Improvement - Multiple issues found';
        if (score >= 90) {
            scoreClass = 'score-excellent';
            descText = 'Excellent - Ready for production';
        } else if (score >= 70) {
            scoreClass = 'score-good';
            descText = 'Good - Minor improvements recommended';
        } else if (score >= 50) {
            scoreClass = 'score-fair';
            descText = 'Fair - Some issues need attention';
        }
        gaugeCircle.className.baseVal = `gauge-fill ${scoreClass}`;
        scoreDesc.textContent = descText;
        
        // Display score breakdown by category
        this.displayScoreBreakdown(result.score_breakdown);
        
        // Collect all issues for the checks grid (heuristic + server data)
        const allIssues = this.collectAllIssues(result);
        
        // Count issues by severity - combine heuristic + server data
        // Heuristic counts
        const heuristicCritical = allIssues.filter(i => i.severity === 'error' || i.severity === 'critical').length;
        const heuristicWarning = allIssues.filter(i => i.severity === 'warn' || i.severity === 'warning').length;
        const heuristicInfo = allIssues.filter(i => i.severity === 'info').length;
        
        // Server counts (separate from heuristic to avoid double-counting)
        const serverCritical = (result.security_checks || []).filter(c => c.severity === 'critical' || c.status === 'violation').length;
        const serverWarning = (result.warnings?.length || 0) + (result.security_checks || []).filter(c => c.severity === 'warning' || c.severity === 'high').length;
        const serverInfo = (result.manual_review?.length || 0) + (result.performance_hints || []).length;
        
        // Combined counts
        const criticalCount = heuristicCritical + serverCritical;
        const warningCount = heuristicWarning + serverWarning;
        const infoCount = heuristicInfo + serverInfo;
        const fixesCount = result.fixes?.length || 0;
        
        // Stats cards
        document.getElementById('criticalCount').textContent = criticalCount;
        document.getElementById('warningsCount').textContent = warningCount;
        document.getElementById('infoCount').textContent = infoCount;
        document.getElementById('fixesCount').textContent = fixesCount;
        
        // Add server-provided issues to the grid (separate from counts to avoid double-counting)
        const allIssuesWithServer = [...allIssues];
        
        // Add server warnings
        (result.warnings || []).forEach(w => {
            allIssuesWithServer.push({
                type: 'server_warning',
                severity: 'warn',
                title: 'Warning',
                description: w,
                location: 'Code analysis',
                fix: 'Review and address'
            });
        });
        
        // Add manual review items
        (result.manual_review || []).forEach(m => {
            allIssuesWithServer.push({
                type: 'server_manual_review',
                severity: 'info',
                title: 'Manual Review',
                description: m,
                location: 'Code analysis',
                fix: 'Review manually'
            });
        });
        
        // Populate checks grid with all issue cards
        this.displayChecksGrid(allIssuesWithServer);
        
        // Populate top blockers
        this.displayTopBlockers(allIssues, result);
        
        // Setup quality tabs
        this.setupQualityTabs();
        
        // Setup filter bar events
        this.setupFilterBar();
        
        // Setup top bar actions
        this.setupQualityTopBar();
        
        // Improved code
        const codeViewer = document.getElementById('improvedCodeViewer');
        if (codeViewer) {
            codeViewer.innerHTML = `<code>${this.escapeHtml(result.improved_code || '')}</code>`;
        }
        
        // Fixes report
        const fixesList = document.getElementById('fixesList');
        if (fixesList) {
            let html = '';
            
            if (result.fixes && result.fixes.length > 0) {
                html += '<div class="fixes-section"><h3><i class="fas fa-check-circle"></i> Fixed Issues</h3><ul>';
                result.fixes.forEach(fix => {
                    html += `<li class="fix-item fix-success"><i class="fas fa-check"></i> ${this.escapeHtml(fix)}</li>`;
                });
                html += '</ul></div>';
            }
            
            if (result.warnings && result.warnings.length > 0) {
                html += '<div class="fixes-section"><h3><i class="fas fa-exclamation-triangle"></i> Warnings</h3><ul>';
                result.warnings.forEach(warn => {
                    html += `<li class="fix-item fix-warning"><i class="fas fa-exclamation-triangle"></i> ${this.escapeHtml(warn)}</li>`;
                });
                html += '</ul></div>';
            }
            
            if (result.manual_review && result.manual_review.length > 0) {
                html += '<div class="fixes-section"><h3><i class="fas fa-info-circle"></i> Needs Manual Review</h3><ul>';
                result.manual_review.forEach(item => {
                    html += `<li class="fix-item fix-info"><i class="fas fa-info-circle"></i> ${this.escapeHtml(item)}</li>`;
                });
                html += '</ul></div>';
            }
            
            if (!html) {
                html = '<p class="empty-message">No issues found</p>';
            }
            
            fixesList.innerHTML = html;
        }
        
        // Diff view
        const diffViewer = document.getElementById('diffViewer');
        if (diffViewer && result.diff) {
            diffViewer.innerHTML = `<pre class="diff-content">${this.escapeHtml(result.diff)}</pre>`;
        } else if (diffViewer) {
            diffViewer.innerHTML = '<p class="empty-message">Diff view not available</p>';
        }
        
        // Element coverage
        this.displayElementCoverage(result.element_coverage || []);
        
        // Schema validation
        this.displaySchemaValidation(result.schema_validation || []);
        
        // Performance hints
        this.displayPerformanceHints(result.performance_hints || []);
        
        // Security checks
        this.displaySecurityChecks(result.security_checks || []);
    }
    
    displayScoreBreakdown(breakdown) {
        const container = document.getElementById('scoreBreakdownContainer');
        if (!container || !breakdown || !breakdown.categories) {
            return;
        }
        
        const categoryOrder = ['syntax_lint', 'mapping_coverage', 'transformation_fidelity', 'data_quality', 'operational_readiness'];
        const categoryColors = {
            'syntax_lint': '#10b981',
            'mapping_coverage': '#3b82f6',
            'transformation_fidelity': '#8b5cf6',
            'data_quality': '#f59e0b',
            'operational_readiness': '#ef4444'
        };
        
        let html = '<div class="score-breakdown-grid">';
        
        categoryOrder.forEach(key => {
            const cat = breakdown.categories[key];
            if (!cat) return;
            
            const score = cat.score || 0;
            const color = categoryColors[key] || '#6b7280';
            const scoreClass = score >= 90 ? 'excellent' : score >= 70 ? 'good' : score >= 50 ? 'fair' : 'poor';
            
            html += `
                <div class="score-category-card" data-category="${key}">
                    <div class="category-header">
                        <span class="category-label">${this.escapeHtml(cat.label)}</span>
                        <span class="category-weight">${cat.weight}%</span>
                    </div>
                    <div class="category-score-row">
                        <div class="category-score ${scoreClass}">${score}</div>
                        <div class="category-progress-bar">
                            <div class="category-progress-fill" style="width: ${score}%; background-color: ${color}"></div>
                        </div>
                    </div>
                    <div class="category-description">${this.escapeHtml(cat.description)}</div>
                    ${cat.issues && cat.issues.length > 0 ? `
                        <div class="category-issues">
                            <div class="issues-header"><i class="fas fa-exclamation-circle"></i> Issues (${cat.issues.length})</div>
                            <ul class="issues-list">
                                ${cat.issues.slice(0, 3).map(issue => `<li>${this.escapeHtml(issue)}</li>`).join('')}
                                ${cat.issues.length > 3 ? `<li class="more-issues">+${cat.issues.length - 3} more...</li>` : ''}
                            </ul>
                        </div>
                    ` : ''}
                    ${cat.suggestions && cat.suggestions.length > 0 ? `
                        <div class="category-suggestions">
                            <div class="suggestions-header"><i class="fas fa-lightbulb"></i> Suggestions</div>
                            <ul class="suggestions-list">
                                ${cat.suggestions.map(sug => `<li>${this.escapeHtml(sug)}</li>`).join('')}
                            </ul>
                        </div>
                    ` : ''}
                </div>
            `;
        });
        
        html += '</div>';
        container.innerHTML = html;
        container.classList.remove('hidden');
    }
    
    switchNotebookTab(tabName) {
        document.querySelectorAll('.notebook-nav-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.notebookTab === tabName);
        });
        
        const tabMap = {
            'improved-code': 'improvedCodeTab',
            'element-coverage': 'elementCoverageTab',
            'fixes-report': 'fixesReportTab',
            'diff-view': 'diffViewTab'
        };
        
        document.querySelectorAll('.notebook-panel').forEach(panel => {
            panel.classList.toggle('active', panel.id === tabMap[tabName]);
        });
    }
    
    displayElementCoverage(elements) {
        const coverageList = document.getElementById('elementCoverageList');
        const coveredCount = document.getElementById('coveredCount');
        const missingCount = document.getElementById('missingCount');
        
        if (!coverageList) return;
        
        const covered = elements.filter(e => e.covered).length;
        const missing = elements.filter(e => !e.covered).length;
        
        if (coveredCount) coveredCount.textContent = `${covered} covered`;
        if (missingCount) missingCount.textContent = `${missing} missing`;
        
        if (elements.length === 0) {
            coverageList.innerHTML = '<p class="empty-message">No mapping elements analyzed</p>';
            return;
        }
        
        const groups = {};
        elements.forEach(el => {
            const type = el.type || 'Other';
            if (!groups[type]) groups[type] = [];
            groups[type].push(el);
        });
        
        let html = '';
        const groupIcons = {
            'Source': 'fa-database',
            'Target': 'fa-bullseye',
            'Transformation (Source Qualifier)': 'fa-filter',
            'Transformation (Expression)': 'fa-calculator',
            'Transformation (Filter)': 'fa-funnel-dollar',
            'Transformation (Lookup Procedure)': 'fa-search',
            'Transformation (Joiner)': 'fa-link',
            'Transformation (Aggregator)': 'fa-layer-group',
            'Transformation (Sorter)': 'fa-sort-alpha-down',
            'Transformation (Router)': 'fa-code-branch',
            'Transformation (Update Strategy)': 'fa-sync-alt'
        };
        
        for (const [groupType, items] of Object.entries(groups)) {
            const groupCovered = items.filter(i => i.covered).length;
            const groupTotal = items.length;
            const icon = groupIcons[groupType] || 'fa-cog';
            
            html += `<div class="coverage-group">`;
            html += `<div class="coverage-group-header">`;
            html += `<i class="fas ${icon}"></i>`;
            html += `<span>${this.escapeHtml(groupType)}</span>`;
            html += `<span class="group-count">${groupCovered}/${groupTotal}</span>`;
            html += `</div>`;
            html += `<div class="coverage-items">`;
            
            items.forEach(item => {
                const statusClass = item.covered ? 'covered' : 'missing';
                const statusIcon = item.covered ? 'fa-check-circle' : 'fa-times-circle';
                html += `<div class="coverage-item ${statusClass}">`;
                html += `<i class="fas ${statusIcon}"></i>`;
                html += `<span class="item-name">${this.escapeHtml(item.name)}</span>`;
                if (item.fields_count) {
                    html += `<span class="item-fields">${item.fields_count} fields</span>`;
                }
                html += `</div>`;
            });
            
            html += `</div></div>`;
        }
        
        coverageList.innerHTML = html;
    }
    
    switchQualityTab(tabId) {
        document.querySelectorAll('.quality-tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.qualityTab === tabId);
        });
        
        document.querySelectorAll('.quality-tab-content').forEach(content => {
            content.classList.toggle('active', content.id === tabId + 'Tab');
        });
    }
    
    displaySchemaValidation(validations) {
        const container = document.getElementById('schemaValidationContainer');
        if (!container) return;
        
        if (!validations || validations.length === 0) {
            container.innerHTML = '<p class="empty-message">No schema validation issues</p>';
            return;
        }
        
        let html = '<div class="validation-section">';
        html += '<h4><i class="fas fa-table"></i> Schema Validation</h4>';
        html += '<div class="validation-items">';
        
        validations.forEach(v => {
            const hasIssues = v.issues && v.issues.length > 0;
            const statusClass = hasIssues ? 'warning' : 'success';
            const icon = hasIssues ? 'fa-exclamation-triangle' : 'fa-check-circle';
            
            html += `<div class="validation-item ${statusClass}">`;
            html += `<div class="validation-header">`;
            html += `<i class="fas ${icon}"></i>`;
            html += `<strong>${this.escapeHtml(v.target)}.${this.escapeHtml(v.field)}</strong>`;
            html += `<span class="type-badge">${this.escapeHtml(v.informatica_type || 'unknown')}</span>`;
            if (v.precision && v.scale) {
                html += `<span class="precision-badge">(${v.precision},${v.scale})</span>`;
            }
            if (v.nullable === 'NOTNULL' || v.nullable === 'NO') {
                html += `<span class="nullable-badge">NOT NULL</span>`;
            }
            html += `</div>`;
            
            if (v.issues && v.issues.length > 0) {
                html += `<div class="validation-issues">`;
                v.issues.forEach(issue => {
                    html += `<div class="issue-item"><i class="fas fa-times-circle"></i> ${this.escapeHtml(issue)}</div>`;
                });
                html += `</div>`;
            }
            
            if (v.recommendations && v.recommendations.length > 0) {
                html += `<div class="validation-recommendations">`;
                v.recommendations.forEach(rec => {
                    html += `<div class="rec-item"><i class="fas fa-lightbulb"></i> ${this.escapeHtml(rec)}</div>`;
                });
                html += `</div>`;
            }
            
            html += `</div>`;
        });
        
        html += '</div></div>';
        container.innerHTML = html;
    }
    
    displayPerformanceHints(hints) {
        const container = document.getElementById('performanceHintsContainer');
        if (!container) return;
        
        if (!hints || hints.length === 0) {
            container.innerHTML = '<p class="empty-message">No performance hints available</p>';
            return;
        }
        
        let html = '<div class="performance-section">';
        html += '<h4><i class="fas fa-tachometer-alt"></i> Performance Hints</h4>';
        html += '<div class="performance-items">';
        
        const priorityOrder = { 'high': 1, 'medium': 2, 'low': 3 };
        const sortedHints = [...hints].sort((a, b) => 
            (priorityOrder[a.priority] || 3) - (priorityOrder[b.priority] || 3)
        );
        
        sortedHints.forEach(h => {
            const priorityClass = h.priority || 'medium';
            const stateClass = h.current_state === 'implemented' ? 'success' : 
                              h.current_state === 'warning' ? 'warning' : 'info';
            const icon = h.current_state === 'implemented' ? 'fa-check-circle' : 
                        h.current_state === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle';
            
            html += `<div class="performance-item ${stateClass}" data-priority="${priorityClass}">`;
            html += `<div class="perf-header">`;
            html += `<i class="fas ${icon}"></i>`;
            html += `<span class="perf-type">${this.escapeHtml(h.type)}</span>`;
            html += `<span class="perf-element">${this.escapeHtml(h.element)}</span>`;
            html += `<span class="priority-badge priority-${priorityClass}">${priorityClass.toUpperCase()}</span>`;
            html += `</div>`;
            html += `<div class="perf-recommendation">${this.escapeHtml(h.recommendation)}</div>`;
            html += `</div>`;
        });
        
        html += '</div></div>';
        container.innerHTML = html;
    }
    
    displaySecurityChecks(checks) {
        const container = document.getElementById('securityChecksContainer');
        if (!container) return;
        
        if (!checks || checks.length === 0) {
            container.innerHTML = '<p class="empty-message">No security issues detected</p>';
            return;
        }
        
        let html = '<div class="security-section">';
        html += '<h4><i class="fas fa-shield-alt"></i> Security Checks</h4>';
        html += '<div class="security-items">';
        
        const severityOrder = { 'critical': 1, 'high': 2, 'medium': 3, 'low': 4 };
        const sortedChecks = [...checks].sort((a, b) => 
            (severityOrder[a.severity] || 4) - (severityOrder[b.severity] || 4)
        );
        
        sortedChecks.forEach(c => {
            const severityClass = c.severity || 'medium';
            const statusClass = c.status === 'violation' ? 'error' : 
                               c.status === 'unmasked' ? 'warning' :
                               c.status === 'good' ? 'success' : 'info';
            const icon = c.status === 'violation' ? 'fa-times-circle' :
                        c.status === 'unmasked' ? 'fa-eye-slash' :
                        c.status === 'good' ? 'fa-check-circle' : 'fa-info-circle';
            
            html += `<div class="security-item ${statusClass}" data-severity="${severityClass}">`;
            html += `<div class="security-header">`;
            html += `<i class="fas ${icon}"></i>`;
            html += `<span class="security-type">${this.escapeHtml(c.type)}</span>`;
            html += `<span class="security-element">${this.escapeHtml(c.element)}</span>`;
            html += `<span class="security-category">${this.escapeHtml(c.category)}</span>`;
            html += `<span class="severity-badge severity-${severityClass}">${severityClass.toUpperCase()}</span>`;
            html += `</div>`;
            
            if (c.recommendations && c.recommendations.length > 0) {
                html += `<div class="security-recommendations">`;
                c.recommendations.forEach(rec => {
                    html += `<div class="sec-rec-item"><i class="fas fa-arrow-right"></i> ${this.escapeHtml(rec)}</div>`;
                });
                html += `</div>`;
            }
            
            html += `</div>`;
        });
        
        html += '</div></div>';
        container.innerHTML = html;
    }
    
    collectAllIssues(result) {
        const issues = [];
        
        // SQL Not Converted (detect df_sq = df_src and "TODO Translate SQL")
        if (result.improved_code) {
            const code = result.improved_code;
            if (code.includes('df_sq = df_src') || code.includes('TODO Translate SQL') || code.includes('TODO: Translate SQL')) {
                issues.push({
                    type: 'sql_not_converted',
                    severity: 'error',
                    title: 'SQL Not Converted',
                    description: 'Source Qualifier SQL was not translated to PySpark',
                    location: 'mapping_*.py:SQL section',
                    fix: 'Convert SQL SELECT/WHERE/JOIN to DataFrame operations'
                });
            }
        }
        
        // Lookup Not Implemented (detect :LKP references)
        if (result.improved_code && (result.improved_code.includes(':LKP') || result.improved_code.includes('# TODO: Implement lookup'))) {
            issues.push({
                type: 'lookup_not_impl',
                severity: 'error',
                title: 'Lookup Not Implemented',
                description: ':LKP references found without corresponding join implementation',
                location: 'Expression transformations',
                fix: 'Replace :LKP.field with DataFrame join'
            });
        }
        
        // Local Variables Missing (VAR_ without derivation)
        if (result.improved_code) {
            const varMatches = result.improved_code.match(/VAR_\w+/g) || [];
            const uniqueVars = [...new Set(varMatches)];
            uniqueVars.forEach(v => {
                if (!result.improved_code.includes(`${v} =`)) {
                    issues.push({
                        type: 'var_missing',
                        severity: 'warn',
                        title: 'Local Variable Missing',
                        description: `Variable ${v} referenced but not defined`,
                        location: 'Variable definitions',
                        fix: `Add derivation: ${v} = ...`
                    });
                }
            });
        }
        
        // Invalid Spark Expressions (--, bad quoting, unsupported funcs)
        if (result.improved_code) {
            if (result.improved_code.includes('--') && !result.improved_code.includes('# --')) {
                issues.push({
                    type: 'invalid_expr',
                    severity: 'error',
                    title: 'Invalid Spark Expression',
                    description: 'SQL-style comments (--) found in PySpark code',
                    location: 'Expression section',
                    fix: 'Replace -- comments with # Python comments'
                });
            }
        }
        
        // Dead Code / Unused DataFrames
        if (result.improved_code) {
            const dfDefs = result.improved_code.match(/df_\w+\s*=/g) || [];
            dfDefs.forEach(d => {
                const dfName = d.replace(/\s*=/, '').trim();
                const regex = new RegExp(dfName, 'g');
                const matches = result.improved_code.match(regex) || [];
                if (matches.length === 1) {
                    issues.push({
                        type: 'dead_code',
                        severity: 'info',
                        title: 'Unused DataFrame',
                        description: `${dfName} is defined but never used`,
                        location: 'DataFrame definitions',
                        fix: 'Remove or use this DataFrame'
                    });
                }
            });
        }
        
        // Duplicate Reads
        if (result.improved_code) {
            const readMatches = result.improved_code.match(/read\.(?:table|format|parquet|csv)\([^)]+\)/g) || [];
            const readCounts = {};
            readMatches.forEach(r => {
                readCounts[r] = (readCounts[r] || 0) + 1;
            });
            Object.entries(readCounts).forEach(([read, count]) => {
                if (count > 1) {
                    issues.push({
                        type: 'duplicate_read',
                        severity: 'warn',
                        title: 'Duplicate Read',
                        description: `Same source read ${count} times`,
                        location: 'Source reads',
                        fix: 'Read once and cache/reuse DataFrame'
                    });
                }
            });
        }
        
        // Write Semantics (append vs merge/upsert)
        if (result.improved_code && result.improved_code.includes('.mode("overwrite")')) {
            issues.push({
                type: 'write_semantics',
                severity: 'warn',
                title: 'Write Semantics',
                description: 'Using overwrite mode - may lose existing data',
                location: 'Target writes',
                fix: 'Consider using merge/upsert for incremental loads'
            });
        }
        
        // Note: Server-provided warnings, manual_review, security_checks, and performance_hints
        // are counted separately in displayQualityResults to avoid double-counting.
        // Only heuristic issues are returned here.
        
        return issues;
    }
    
    displayChecksGrid(issues) {
        const grid = document.getElementById('checksGrid');
        if (!grid) return;
        
        if (issues.length === 0) {
            grid.innerHTML = '<div class="empty-message" style="padding: 40px; text-align: center;"><i class="fas fa-check-circle" style="font-size: 2rem; color: var(--accent-success); margin-bottom: 10px;"></i><p>No issues detected</p></div>';
            return;
        }
        
        let html = '';
        issues.forEach((issue, idx) => {
            const icon = issue.severity === 'error' ? 'fa-times-circle' : 
                        issue.severity === 'warn' ? 'fa-exclamation-triangle' : 'fa-info-circle';
            
            html += `
                <div class="check-card severity-${issue.severity}" data-issue-idx="${idx}" data-severity="${issue.severity}">
                    <div class="check-severity">
                        <i class="fas ${icon}"></i>
                    </div>
                    <div class="check-content">
                        <div class="check-title">${this.escapeHtml(issue.title)}</div>
                        <div class="check-description">${this.escapeHtml(issue.description)}</div>
                        <div class="check-location">
                            <i class="fas fa-file-code"></i> ${this.escapeHtml(issue.location)}
                        </div>
                    </div>
                    <div class="check-actions">
                        <button class="btn btn-sm btn-primary" onclick="app.applyIssueFix(${idx})">
                            <i class="fas fa-wrench"></i> Apply Fix
                        </button>
                        <button class="btn btn-sm" onclick="app.previewIssueFix(${idx})">
                            <i class="fas fa-eye"></i> Preview
                        </button>
                    </div>
                </div>
            `;
        });
        
        grid.innerHTML = html;
        this.allIssues = issues;
    }
    
    setupQualityTabs() {
        if (this._qualityTabsInitialized) return;
        this._qualityTabsInitialized = true;
        
        document.querySelectorAll('.quality-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const tabName = e.currentTarget.dataset.qualityTab;
                
                // Update tab active state
                document.querySelectorAll('.quality-tab').forEach(t => t.classList.remove('active'));
                e.currentTarget.classList.add('active');
                
                // Show corresponding panel
                document.querySelectorAll('.quality-tab-panel').forEach(p => p.classList.remove('active'));
                const panel = document.getElementById(tabName + 'Panel');
                if (panel) panel.classList.add('active');
            });
        });
    }
    
    setupQualityTopBar() {
        if (this._qualityTopBarInitialized) return;
        this._qualityTopBarInitialized = true;
        
        // Run Checks button
        document.getElementById('runChecksBtn')?.addEventListener('click', () => {
            if (this.qualityResult) {
                const allIssues = this.collectAllIssues(this.qualityResult);
                this.displayChecksGrid(allIssues);
                this.showToast('Checks refreshed', 'success');
            }
        });
        
        // Auto-Fix button
        document.getElementById('autoFixBtn')?.addEventListener('click', () => {
            this.applySelectedAutoFixes();
        });
        
        // Export Patch button
        document.getElementById('exportPatchBtn')?.addEventListener('click', () => {
            this.exportPatch();
        });
        
        // Apply Selected Fixes button (in Auto-Fixes tab)
        document.getElementById('applySelectedFixesBtn')?.addEventListener('click', () => {
            this.applySelectedAutoFixes();
        });
        
        // Preview Fixes button
        document.getElementById('previewFixesBtn')?.addEventListener('click', () => {
            this.showToast('Preview available in Report tab', 'info');
            document.querySelector('[data-quality-tab="report"]')?.click();
        });
    }
    
    applyIssueFix(idx) {
        if (!this.allIssues || !this.allIssues[idx]) return;
        const issue = this.allIssues[idx];
        this.showToast(`Applied fix for: ${issue.title}`, 'success');
    }
    
    previewIssueFix(idx) {
        if (!this.allIssues || !this.allIssues[idx]) return;
        const issue = this.allIssues[idx];
        this.showToast(`Fix: ${issue.fix}`, 'info');
    }
    
    applySelectedAutoFixes() {
        const selectedFixes = [];
        if (document.getElementById('fixIifDecode')?.checked) selectedFixes.push('IIF/DECODE/ISNULL');
        if (document.getElementById('fixLookup')?.checked) selectedFixes.push(':LKP joins');
        if (document.getElementById('fixRownum')?.checked) selectedFixes.push('row_number()');
        if (document.getElementById('fixDedup')?.checked) selectedFixes.push('Deduplicate reads');
        if (document.getElementById('fixSchema')?.checked) selectedFixes.push('Schema casts');
        if (document.getElementById('fixLogging')?.checked) selectedFixes.push('Checkpoint logging');
        
        if (selectedFixes.length > 0) {
            this.showToast(`Applied fixes: ${selectedFixes.join(', ')}`, 'success');
            if (this.improvedCode) {
                this.downloadImprovedCode();
            }
        } else {
            this.showToast('No fixes selected', 'warning');
        }
    }
    
    exportPatch() {
        if (!this.qualityResult) {
            this.showToast('No analysis results to export', 'warning');
            return;
        }
        
        const patch = {
            timestamp: new Date().toISOString(),
            score: this.qualityResult.quality_score,
            fixes: this.qualityResult.fixes || [],
            warnings: this.qualityResult.warnings || [],
            diff: this.qualityResult.diff || ''
        };
        
        const blob = new Blob([JSON.stringify(patch, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'quality_patch.json';
        a.click();
        URL.revokeObjectURL(url);
        
        this.showToast('Patch exported', 'success');
    }
    
    displayTopBlockers(allIssues, result) {
        const container = document.getElementById('topBlockersList');
        if (!container) return;
        
        // Collect top blockers from heuristic issues and server data
        const blockers = [];
        
        // Add critical/error heuristic issues
        allIssues.filter(i => i.severity === 'error' || i.severity === 'critical').forEach(issue => {
            blockers.push({
                severity: 'critical',
                title: issue.title,
                desc: issue.description,
                remediation: issue.fix
            });
        });
        
        // Add server security violations
        (result.security_checks || []).forEach(c => {
            if (c.severity === 'critical' || c.status === 'violation') {
                blockers.push({
                    severity: 'critical',
                    title: c.type,
                    desc: c.element + ' - ' + c.category,
                    remediation: c.recommendations?.[0] || 'Review security settings'
                });
            }
        });
        
        // Add high-severity server warnings
        (result.security_checks || []).forEach(c => {
            if (c.severity === 'high' || c.severity === 'warning') {
                blockers.push({
                    severity: 'warning',
                    title: c.type,
                    desc: c.element + ' - ' + c.category,
                    remediation: c.recommendations?.[0] || 'Review and address'
                });
            }
        });
        
        // Add schema/performance issues as warnings
        (result.schema_validation || []).forEach(v => {
            if (v.issues && v.issues.length > 0) {
                blockers.push({
                    severity: 'warning',
                    title: 'Schema Mismatch',
                    desc: `${v.target}.${v.field} - ${v.issues[0]}`,
                    remediation: v.recommendations?.[0] || 'Review schema definition'
                });
            }
        });
        
        (result.performance_hints || []).forEach(h => {
            if (h.priority === 'high' && h.current_state !== 'implemented') {
                blockers.push({
                    severity: 'warning',
                    title: h.type,
                    desc: h.element + ' - ' + (h.recommendation || '').substring(0, 60) + '...',
                    remediation: h.recommendation
                });
            }
        });
        
        // Limit to top 5 blockers
        const topBlockers = blockers.slice(0, 5);
        
        if (topBlockers.length === 0) {
            container.innerHTML = '<p class="empty-message" style="padding: 16px; text-align: center; color: var(--accent-success);"><i class="fas fa-check-circle"></i> No critical blockers found</p>';
            return;
        }
        
        let html = '';
        topBlockers.forEach(b => {
            const icon = b.severity === 'critical' ? 'fa-times-circle' : 'fa-exclamation-triangle';
            html += `
                <div class="blocker-item ${b.severity}">
                    <div class="blocker-icon"><i class="fas ${icon}"></i></div>
                    <div class="blocker-content">
                        <div class="blocker-title">${this.escapeHtml(b.title)}</div>
                        <div class="blocker-desc">${this.escapeHtml(b.desc)}</div>
                    </div>
                    <div class="blocker-action">
                        <button class="btn btn-sm copy-remediation-btn" data-remediation="${this.escapeHtml(b.remediation)}" onclick="app.copyRemediation(this)">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
    }
    
    copyRemediation(btn) {
        const remediation = btn.getAttribute('data-remediation');
        if (remediation) {
            navigator.clipboard.writeText(remediation).then(() => {
                this.showToast('Remediation copied to clipboard', 'success');
            });
        }
    }
    
    setupFilterBar() {
        // Guard against duplicate binding
        if (this._filterBarInitialized) return;
        this._filterBarInitialized = true;
        
        // Initialize filter state
        this._activeFilter = 'all';
        this._searchQuery = '';
        
        // Filter chips
        document.querySelectorAll('.filter-chip').forEach(chip => {
            chip.addEventListener('click', (e) => {
                document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
                e.currentTarget.classList.add('active');
                this._activeFilter = e.currentTarget.dataset.filter;
                this.applyFilters();
            });
        });
        
        // Search input
        const searchInput = document.getElementById('issueSearchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this._searchQuery = e.target.value.toLowerCase();
                this.applyFilters();
            });
        }
        
        // Auto-fix all button - triggers download of improved code
        const autoFixBtn = document.getElementById('autoFixAllBtn');
        if (autoFixBtn) {
            autoFixBtn.addEventListener('click', () => {
                if (this.improvedCode) {
                    this.downloadImprovedCode();
                } else {
                    this.showToast('No improved code available yet', 'warning');
                }
            });
        }
        
        // Export report button
        const exportBtn = document.getElementById('exportReportBtn');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => {
                this.exportQualityReport();
            });
        }
    }
    
    applyFilters() {
        // Include check cards in the filter
        const items = document.querySelectorAll('.validation-item, .performance-item, .security-item, .check-card');
        const severity = this._activeFilter || 'all';
        const query = this._searchQuery || '';
        
        items.forEach(item => {
            // Check severity filter
            let matchesSeverity = severity === 'all';
            if (!matchesSeverity) {
                const itemSeverity = item.dataset.severity || '';
                const itemClass = item.classList;
                // Map filter values to card severity classes
                matchesSeverity = itemSeverity === severity || 
                    (severity === 'critical' && (itemClass.contains('severity-error') || itemClass.contains('error') || itemSeverity === 'critical' || itemSeverity === 'error')) ||
                    (severity === 'warning' && (itemClass.contains('severity-warn') || itemClass.contains('warning') || itemSeverity === 'warning' || itemSeverity === 'warn' || itemSeverity === 'high')) ||
                    (severity === 'info' && (itemClass.contains('severity-info') || itemClass.contains('info') || itemSeverity === 'medium' || itemSeverity === 'info')) ||
                    (severity === 'success' && (itemClass.contains('success') || itemSeverity === 'low'));
            }
            
            // Check search filter
            const matchesSearch = !query || item.textContent.toLowerCase().includes(query);
            
            // Both must match
            item.style.display = (matchesSeverity && matchesSearch) ? '' : 'none';
        });
    }
    
    exportQualityReport() {
        const reportContent = {
            score: document.getElementById('qualityScoreValue')?.textContent || '0',
            description: document.getElementById('qualityScoreDesc')?.textContent || '',
            criticalCount: document.getElementById('criticalCount')?.textContent || '0',
            warningsCount: document.getElementById('warningsCount')?.textContent || '0',
            infoCount: document.getElementById('infoCount')?.textContent || '0',
            fixesCount: document.getElementById('fixesCount')?.textContent || '0',
            timestamp: new Date().toISOString()
        };
        
        const blob = new Blob([JSON.stringify(reportContent, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'quality_report.json';
        a.click();
        URL.revokeObjectURL(url);
        
        this.showToast('Quality report exported', 'success');
    }
    
    copyImprovedCode() {
        if (this.improvedCode) {
            navigator.clipboard.writeText(this.improvedCode).then(() => {
                this.showToast('Copied to clipboard', 'success');
            });
        } else {
            this.showToast('No code to copy', 'warning');
        }
    }
    
    downloadImprovedCode() {
        if (!this.improvedCode) {
            this.showToast('No code to download', 'warning');
            return;
        }
        
        const filename = this.improvePysparkFile?.name?.replace('.py', '_improved.py') || 'improved_mapping.py';
        const blob = new Blob([this.improvedCode], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        this.showToast('Download started', 'success');
    }
    
    initTheme() {
        const savedTheme = localStorage.getItem('theme') || 'light';
        if (savedTheme === 'dark') {
            document.body.classList.add('dark');
            document.getElementById('themeToggle').innerHTML = '<i class="fas fa-sun"></i>';
        }
    }
    
    toggleTheme() {
        const isDark = document.body.classList.toggle('dark');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
        document.getElementById('themeToggle').innerHTML = isDark ? 
            '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    }
    
    handleDragOver(e) {
        e.preventDefault();
        e.currentTarget.classList.add('dragover');
    }
    
    handleDragLeave(e) {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
    }
    
    handleDrop(e) {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    }
    
    handleFileSelect(e) {
        const files = e.target.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    }
    
    processFile(file) {
        if (!file.name.toLowerCase().endsWith('.xml')) {
            this.showToast('Please select an XML file', 'error');
            return;
        }
        
        this.selectedFile = file;
        
        document.getElementById('fileName').textContent = file.name;
        document.getElementById('fileSize').textContent = this.formatFileSize(file.size);
        document.getElementById('fileInfo').classList.remove('hidden');
        this.updateFileBadges();
        document.getElementById('analyzeBtn').disabled = false;
        
        this.countXmlElements(file);
    }
    
    countXmlElements(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const parser = new DOMParser();
                const xmlDoc = parser.parseFromString(e.target.result, 'text/xml');
                const parserError = xmlDoc.querySelector('parsererror');
                
                if (parserError) {
                    document.getElementById('fileElements').textContent = 'Invalid XML';
                } else {
                    const allElements = xmlDoc.getElementsByTagName('*');
                    const elementCount = allElements.length;
                    document.getElementById('fileElements').textContent = 
                        elementCount.toLocaleString() + ' element' + (elementCount !== 1 ? 's' : '');
                }
            } catch (err) {
                document.getElementById('fileElements').textContent = 'Error parsing';
            }
        };
        reader.readAsText(file);
    }
    
    removeFile() {
        this.selectedFile = null;
        document.getElementById('fileInput').value = '';
        document.getElementById('fileInfo').classList.add('hidden');
        document.getElementById('analyzeBtn').disabled = true;
        this.updateFileBadges();
    }
    
    formatFileSize(bytes) {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    }
    
    async analyzeFile() {
        if (!this.selectedFile) return;
        
        this.setStatus('processing', 'Analyzing...');
        document.getElementById('analyzeBtn').disabled = true;
        
        const formData = new FormData();
        formData.append('file', this.selectedFile);
        
        try {
            const response = await fetch('/api/analyze', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.async && result.job_id) {
                this.showToast(result.message, 'info');
                await this.pollJobStatus(result.job_id);
            } else if (result.success) {
                this.handleAnalysisResult(result);
            } else {
                this.showToast(result.error || 'Analysis failed', 'error');
            }
        } catch (error) {
            console.error('Analysis error:', error, error.message, error.stack);
            this.showToast('Failed to analyze file: ' + (error.message || 'Unknown error'), 'error');
        } finally {
            this.setStatus('ready', 'Ready');
            document.getElementById('analyzeBtn').disabled = false;
        }
    }
    
    async pollJobStatus(jobId) {
        const maxAttempts = 600;
        const pollInterval = 1000;
        let attempts = 0;
        
        const poll = async () => {
            try {
                const response = await fetch(`/api/job/${jobId}/status`);
                const status = await response.json();
                
                if (status.status === 'completed') {
                    this.setStatus('processing', 'Processing complete!');
                    if (status.result) {
                        this.handleAnalysisResult(status.result);
                    }
                    return true;
                } else if (status.status === 'failed') {
                    this.showToast(status.error || 'Processing failed', 'error');
                    return true;
                } else {
                    this.setStatus('processing', `${status.stage} (${status.progress}%)`);
                    attempts++;
                    
                    if (attempts >= maxAttempts) {
                        this.showToast('Processing timeout - please try again', 'error');
                        return true;
                    }
                    
                    await new Promise(resolve => setTimeout(resolve, pollInterval));
                    return poll();
                }
            } catch (error) {
                console.error('Polling error:', error);
                this.showToast('Error checking status', 'error');
                return true;
            }
        };
        
        await poll();
    }
    
    async pollGenerateJobStatus(jobId, mappings) {
        const maxAttempts = 600;
        const pollInterval = 500;
        let attempts = 0;
        
        const poll = async () => {
            try {
                const response = await fetch(`/api/job/${jobId}/status`);
                const status = await response.json();
                
                if (status.status === 'completed') {
                    this.addLog('Generation complete!', 'success', 'Workflow');
                    if (status.result) {
                        return status.result;
                    }
                    return { success: true };
                } else if (status.status === 'failed') {
                    this.addLog(`Generation failed: ${status.error}`, 'error', 'Workflow');
                    return { success: false, error: status.error };
                } else {
                    this.addLog(`${status.stage} (${status.progress}%)`, 'info', 'Workflow');
                    this.updateGenerationStatus('running', `${status.stage} (${status.progress}%)`);
                    
                    const progressPercent = status.progress || 0;
                    const progressFill = document.getElementById('overallProgressFill');
                    if (progressFill) {
                        progressFill.style.width = `${progressPercent}%`;
                    }
                    
                    attempts++;
                    
                    if (attempts >= maxAttempts) {
                        return { success: false, error: 'Processing timeout' };
                    }
                    
                    await new Promise(resolve => setTimeout(resolve, pollInterval));
                    return poll();
                }
            } catch (error) {
                console.error('Polling error:', error);
                return { success: false, error: error.message };
            }
        };
        
        return await poll();
    }
    
    handleAnalysisResult(result) {
        this.artifactId = result.artifact_id;
        this.analysisData = result.analysis;
        this.workflowAnalysis = result.workflow_analysis;
        this.configsData = result.configs || [];
        this.allDollarVariables = result.all_dollar_variables || {};
        this.displayAnalysis(result.analysis);
        this.displayWorkflowAnalysis(result.workflow_analysis);
        this.displayConfigs(this.configsData);
        this.displayConnectors(result.analysis.mappings);
        this.displayPipelineDiagrams(result.analysis.mappings, result.workflow_analysis);
        this.displayParameters(result.analysis.mappings, result.workflow_analysis, result.all_dollar_variables);
        this.displayRawJson(result);
        this.goToStep(2);
        this.showToast('Analysis complete', 'success');
    }
    
    displayAnalysis(analysis) {
        if (!analysis || !analysis.mappings) {
            console.error('Invalid analysis data:', analysis);
            return;
        }
        
        let totalSources = 0;
        let totalTargets = 0;
        let totalTransforms = 0;
        
        analysis.mappings.forEach(mapping => {
            totalSources += (mapping.sources || []).length;
            totalTargets += (mapping.targets || []).length;
            
            const ts = mapping.transform_summary || {};
            totalTransforms += (ts.source_qualifiers || 0) + (ts.expressions || 0) + (ts.filters || 0) + 
                              (ts.joiners || 0) + (ts.lookups || 0) + (ts.stored_procedures || 0) + 
                              (ts.update_strategies || 0) + (ts.aggregators || 0) + (ts.sorters || 0) +
                              (ts.routers || 0) + (ts.unions || 0) + (ts.others || 0);
        });
        
        document.getElementById('mappingCount').textContent = analysis.mapping_count;
        document.getElementById('sourceCount').textContent = totalSources;
        document.getElementById('targetCount').textContent = totalTargets;
        document.getElementById('transformCount').textContent = totalTransforms;
        
        if (analysis.mappings.length > 0) {
            const mapping = analysis.mappings[0];
            this.displayFlow(mapping.flow_text || '');
            this.displaySources(mapping.sources || []);
            this.displayTargets(mapping.targets || []);
            this.displayTransformSummary(mapping.transform_summary || {});
            this.displayAllMappingTransformations(analysis.mappings);
            this.displaySqlQueries(analysis.mappings);
            this.prepareConfigForm(mapping);
        }
    }
    
    displayFlow(flowText) {
        const flowDiagram = document.getElementById('flowDiagram');
        if (!flowDiagram) return;
        
        if (!flowText || flowText === 'No flow detected') {
            flowDiagram.innerHTML = '<p class="text-muted">No flow information available</p>';
            return;
        }
        
        const steps = flowText.split(' -> ');
        let html = '<div class="flow-container">';
        
        steps.forEach((step, index) => {
            const match = step.match(/(.+)\s*\((.+)\)/);
            const name = match ? match[1].trim() : step;
            const type = match ? match[2].trim() : '';
            
            let nodeClass = 'flow-node';
            if (type === 'SRC' || type.includes('Source')) nodeClass += ' source';
            else if (type === 'TGT' || type.includes('Target')) nodeClass += ' target';
            else nodeClass += ' transform';
            
            html += `<div class="${nodeClass}">
                <span class="node-name">${name}</span>
                ${type ? `<span class="node-type">${type}</span>` : ''}
            </div>`;
            
            if (index < steps.length - 1) {
                html += '<i class="fas fa-arrow-right flow-arrow"></i>';
            }
        });
        
        html += '</div>';
        flowDiagram.innerHTML = html;
    }
    
    displaySources(sources) {
        if (sources.length === 0) {
            document.getElementById('sqlSourcesList').innerHTML = '<p class="empty-message">No SQL sources found</p>';
            return;
        }
        
        // Count sources by type
        const fileSources = sources.filter(s => s.type === 'FILE');
        const sqlSources = sources.filter(s => s.type === 'SQL' || s.type === 'UNKNOWN');
        const sfdcSources = sources.filter(s => s.database_type && s.database_type.toLowerCase().includes('salesforce'));
        
        // Update counts
        document.querySelector('#totalSourcesCount .count-value').textContent = sources.length;
        document.querySelector('#fileSourcesCount .count-value').textContent = fileSources.length;
        document.querySelector('#sqlSourcesCount .count-value').textContent = sqlSources.length;
        document.querySelector('#sfdcSourcesCount .count-value').textContent = sfdcSources.length;
        
        // Display file sources
        if (fileSources.length > 0) {
            document.getElementById('fileSourcesList').innerHTML = fileSources.map(source => 
                this.renderSourceCard(source)
            ).join('');
        } else {
            document.getElementById('fileSourcesList').innerHTML = '<p class="empty-message">No file sources found</p>';
        }
        
        // Display SQL sources
        if (sqlSources.length > 0) {
            document.getElementById('sqlSourcesList').innerHTML = sqlSources.map(source => 
                this.renderSourceCard(source)
            ).join('');
        } else {
            document.getElementById('sqlSourcesList').innerHTML = '<p class="empty-message">No SQL sources found</p>';
        }
        
        // Bind expand/collapse events
        setTimeout(() => {
            document.querySelectorAll('.source-card-header').forEach(header => {
                header.addEventListener('click', () => {
                    const card = header.closest('.source-card');
                    card.classList.toggle('expanded');
                });
            });
        }, 100);
    }
    
    renderSourceCard(source) {
        const isStoredProc = source.database_type && source.database_type.toLowerCase().includes('stored');
        const sourceType = isStoredProc ? 'Stored Procedure' : 'Table';
        
        return `
            <div class="source-card" data-testid="source-card-${source.name}">
                <div class="source-card-header">
                    <div class="source-card-title">
                        <span class="source-name">${source.name}</span>
                        <span class="source-type-badge">${sourceType}</span>
                    </div>
                    <button class="expand-btn" data-testid="button-expand-${source.name}">
                        <i class="fas fa-chevron-down"></i>
                    </button>
                </div>
                <div class="source-card-meta">
                    ${source.db_name ? `<span><i class="fas fa-database"></i> Table: ${source.name}</span>` : ''}
                    ${source.db_name ? `<span><i class="fas fa-server"></i> Database: ${source.db_name}</span>` : ''}
                    ${source.database_type ? `<span><i class="fas fa-cog"></i> Type: ${source.database_type}</span>` : ''}
                    ${source.owner_name ? `<span><i class="fas fa-user"></i> Owner: ${source.owner_name}</span>` : ''}
                    <span><i class="fas fa-list"></i> Fields: ${source.field_count}</span>
                </div>
                <div class="source-card-body">
                    ${source.sql_query ? `
                        <div class="source-query-section">
                            <h5><i class="fas fa-code"></i> Source Query:</h5>
                            <pre class="sql-query-code"><code>${this.escapeHtml(source.sql_query)}</code></pre>
                        </div>
                    ` : ''}
                    <div class="source-fields-section">
                        <h5><i class="fas fa-th-list"></i> Source Fields (${source.field_count})</h5>
                        <div class="table-container">
                            <table class="data-table fields-table">
                                <thead>
                                    <tr>
                                        <th>Field Name</th>
                                        <th>Data Type</th>
                                        <th>Precision</th>
                                        <th>Scale</th>
                                        <th>Nullable</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${source.fields && source.fields.length > 0 ? 
                                        source.fields.map(field => `
                                            <tr>
                                                <td><code>${field.name}</code></td>
                                                <td>${field.datatype}</td>
                                                <td>${field.precision}</td>
                                                <td>${field.scale}</td>
                                                <td>${field.nullable ? '<i class="fas fa-check text-success"></i>' : '<i class="fas fa-times text-error"></i>'}</td>
                                            </tr>
                                        `).join('') : 
                                        '<tr><td colspan="5" class="text-center">No fields available</td></tr>'
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    displayTargets(targets) {
        if (targets.length === 0) {
            document.getElementById('sqlTargetsList').innerHTML = '<p class="empty-message">No SQL targets found</p>';
            return;
        }
        
        // Count targets by type
        const fileTargets = targets.filter(t => t.type === 'FILE');
        const sqlTargets = targets.filter(t => t.type === 'SQL' || !t.type);
        const sfdcTargets = targets.filter(t => t.type === 'SFDC');
        
        // Update counts
        document.querySelector('#totalTargetsCount .count-value').textContent = targets.length;
        document.querySelector('#fileTargetsCount .count-value').textContent = fileTargets.length;
        document.querySelector('#sqlTargetsCount .count-value').textContent = sqlTargets.length;
        document.querySelector('#sfdcTargetsCount .count-value').textContent = sfdcTargets.length;
        
        // Display file targets
        if (fileTargets.length > 0) {
            document.getElementById('fileTargetsList').innerHTML = fileTargets.map(target => 
                this.renderTargetCard(target)
            ).join('');
        } else {
            document.getElementById('fileTargetsList').innerHTML = '<p class="empty-message">No file targets found</p>';
        }
        
        // Display SQL targets
        if (sqlTargets.length > 0) {
            document.getElementById('sqlTargetsList').innerHTML = sqlTargets.map(target => 
                this.renderTargetCard(target)
            ).join('');
        } else {
            document.getElementById('sqlTargetsList').innerHTML = '<p class="empty-message">No SQL targets found</p>';
        }
        
        // Display SFDC targets
        if (sfdcTargets.length > 0) {
            document.getElementById('sfdcTargetsList').innerHTML = sfdcTargets.map(target => 
                this.renderTargetCard(target)
            ).join('');
        } else {
            document.getElementById('sfdcTargetsList').innerHTML = '<p class="empty-message">No SFDC targets found</p>';
        }
        
        // Bind expand/collapse events for targets
        setTimeout(() => {
            document.querySelectorAll('.target-card-header').forEach(header => {
                header.addEventListener('click', () => {
                    const card = header.closest('.target-card');
                    card.classList.toggle('expanded');
                });
            });
        }, 100);
    }
    
    renderTargetCard(target) {
        return `
            <div class="target-card" data-testid="target-card-${target.name}">
                <div class="target-card-header">
                    <div class="target-card-title">
                        <span class="target-name">${target.name}</span>
                        <span class="target-type-badge">Table</span>
                    </div>
                    <button class="expand-btn" data-testid="button-expand-target-${target.name}">
                        <i class="fas fa-chevron-down"></i>
                    </button>
                </div>
                <div class="target-card-meta">
                    <span><i class="fas fa-table"></i> Table: ${target.name}</span>
                    <span><i class="fas fa-database"></i> Database: ${target.db_name || 'N/A'}</span>
                    <span><i class="fas fa-cog"></i> Type: ${target.database_type || 'N/A'}</span>
                    <span><i class="fas fa-user"></i> Schema/Owner: ${target.owner_name || 'N/A'}</span>
                    <span><i class="fas fa-list"></i> Fields: ${target.field_count}</span>
                </div>
                <div class="target-pyspark-hint">
                    <i class="fas fa-code"></i>
                    <span>PySpark Write:</span>
                    <code>${target.pyspark_write || `df.write.jdbc(url, '${target.name}', properties)`}</code>
                </div>
                <div class="target-card-body">
                    <div class="target-fields-section">
                        <h5><i class="fas fa-th-list"></i> Target Fields (${target.field_count})</h5>
                        <div class="table-container">
                            <table class="data-table fields-table">
                                <thead>
                                    <tr>
                                        <th>Field Name</th>
                                        <th>Data Type</th>
                                        <th>Precision</th>
                                        <th>Scale</th>
                                        <th>Nullable</th>
                                        <th>Key</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${target.fields && target.fields.length > 0 ? 
                                        target.fields.map(field => `
                                            <tr>
                                                <td><code>${field.name}</code></td>
                                                <td>${field.datatype}</td>
                                                <td>${field.precision}</td>
                                                <td>${field.scale}</td>
                                                <td>${field.nullable ? '<i class="fas fa-check text-success"></i>' : '<i class="fas fa-times text-error"></i>'}</td>
                                                <td>${field.key_type || '-'}</td>
                                            </tr>
                                        `).join('') : 
                                        '<tr><td colspan="6" class="text-center">No fields available</td></tr>'
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    displayTransformSummary(summary) {
        const container = document.getElementById('transformSummary');
        if (!container) return;
        if (!summary) summary = {};
        
        const transforms = [
            { name: 'Source Qualifier', count: summary.source_qualifiers || 0 },
            { name: 'Expression', count: summary.expressions || 0 },
            { name: 'Filter', count: summary.filters || 0 },
            { name: 'Joiner', count: summary.joiners || 0 },
            { name: 'Lookup', count: summary.lookups || 0 },
            { name: 'Stored Procedure', count: summary.stored_procedures || 0 },
            { name: 'Update Strategy', count: summary.update_strategies || 0 },
            { name: 'Aggregator', count: summary.aggregators || 0 },
            { name: 'Sorter', count: summary.sorters || 0 },
            { name: 'Router', count: summary.routers || 0 },
            { name: 'Union', count: summary.unions || 0 },
            { name: 'Other', count: summary.others || 0 }
        ].filter(t => t.count > 0);
        
        const typeClassMap = {
            'Source Qualifier': 'source-qualifier',
            'Expression': 'expression',
            'Filter': 'filter',
            'Joiner': 'joiner',
            'Lookup': 'lookup',
            'Stored Procedure': 'stored-procedure',
            'Update Strategy': 'update-strategy',
            'Aggregator': 'aggregator',
            'Sorter': 'sorter',
            'Router': 'router',
            'Union': 'union',
            'Normalizer': 'normalizer',
            'Sequence': 'sequence',
            'Rank': 'rank',
            'Other': 'other'
        };
        
        const typeIconMap = {
            'Source Qualifier': 'fa-filter',
            'Expression': 'fa-calculator',
            'Filter': 'fa-funnel-dollar',
            'Joiner': 'fa-code-branch',
            'Lookup': 'fa-search',
            'Stored Procedure': 'fa-terminal',
            'Update Strategy': 'fa-exchange-alt',
            'Aggregator': 'fa-layer-group',
            'Sorter': 'fa-sort-amount-down',
            'Router': 'fa-random',
            'Union': 'fa-object-group',
            'Normalizer': 'fa-compress-arrows-alt',
            'Sequence': 'fa-list-ol',
            'Rank': 'fa-medal',
            'Other': 'fa-puzzle-piece'
        };
        
        container.innerHTML = transforms.map(t => `
            <div class="transform-badge ${typeClassMap[t.name] || 'other'}">
                <span class="name"><i class="fas ${typeIconMap[t.name] || 'fa-cog'}"></i>${t.name}</span>
                <span class="count">${t.count}</span>
            </div>
        `).join('');
    }
    
    displayAllMappingTransformations(mappings) {
        const container = document.getElementById('transformationsByMapping');
        if (!container) return;
        
        if (!mappings || mappings.length === 0) {
            container.innerHTML = '<p class="empty-message">No mappings found</p>';
            return;
        }
        
        let html = '';
        
        mappings.forEach((mapping, index) => {
            const transformations = mapping.transformations || [];
            const summary = mapping.transform_summary || {};
            const mappingName = mapping.mapping_name || `Mapping ${index + 1}`;
            
            // Group transformations by type
            const groups = {
                'Source Qualifier': [],
                'Expression': [],
                'Filter': [],
                'Joiner': [],
                'Lookup Procedure': [],
                'Stored Procedure': [],
                'Sorter': [],
                'Aggregator': [],
                'Router': [],
                'Union': [],
                'Update Strategy': [],
                'other': []
            };
            
            transformations.forEach(t => {
                if (groups[t.type] !== undefined) {
                    groups[t.type].push(t);
                } else {
                    groups['other'].push(t);
                }
            });
            
            // Build summary counts
            const countsHtml = [
                { name: 'Source Qualifier', count: summary.source_qualifiers || 0, icon: 'filter' },
                { name: 'Expression', count: summary.expressions || 0, icon: 'calculator' },
                { name: 'Filter', count: summary.filters || 0, icon: 'funnel-dollar' },
                { name: 'Joiner', count: summary.joiners || 0, icon: 'code-branch' },
                { name: 'Lookup', count: summary.lookups || 0, icon: 'search' },
                { name: 'Stored Proc', count: summary.stored_procedures || 0, icon: 'terminal' },
                { name: 'Sorter', count: summary.sorters || 0, icon: 'sort-amount-down' },
                { name: 'Aggregator', count: summary.aggregators || 0, icon: 'layer-group' },
                { name: 'Router', count: summary.routers || 0, icon: 'random' },
                { name: 'Union', count: summary.unions || 0, icon: 'object-group' },
                { name: 'Other', count: summary.others || 0, icon: 'puzzle-piece' }
            ].filter(t => t.count > 0).map(t => `
                <div class="transform-count-item">
                    <i class="fas fa-${t.icon}"></i>
                    <span class="count-value">${t.count}</span>
                    <span class="count-label">${t.name}</span>
                </div>
            `).join('');
            
            html += `
                <div class="mapping-transform-section ${index === 0 ? 'expanded' : ''}" data-testid="mapping-transform-${mappingName}">
                    <div class="mapping-transform-header" data-testid="button-expand-mapping-${mappingName}">
                        <div class="mapping-transform-title">
                            <i class="fas fa-project-diagram"></i>
                            <span class="mapping-name">${mappingName}</span>
                            <span class="transform-total-badge">${transformations.length} transformations</span>
                        </div>
                        <button class="expand-btn">
                            <i class="fas fa-chevron-down"></i>
                        </button>
                    </div>
                    <div class="mapping-transform-body">
                        <div class="transform-counts-row">
                            ${countsHtml || '<span class="text-muted">No transformations</span>'}
                        </div>
                        
                        ${this.renderTransformTypeSection('Source Qualifier', 'filter', groups['Source Qualifier'])}
                        ${this.renderTransformTypeSection('Expression', 'calculator', groups['Expression'])}
                        ${this.renderTransformTypeSection('Filter', 'funnel-dollar', groups['Filter'])}
                        ${this.renderTransformTypeSection('Joiner', 'code-branch', groups['Joiner'])}
                        ${this.renderTransformTypeSection('Lookup', 'search', groups['Lookup Procedure'])}
                        ${this.renderTransformTypeSection('Stored Procedure', 'terminal', groups['Stored Procedure'])}
                        ${this.renderTransformTypeSection('Sorter', 'sort-amount-down', groups['Sorter'])}
                        ${this.renderTransformTypeSection('Aggregator', 'layer-group', groups['Aggregator'])}
                        ${this.renderTransformTypeSection('Router', 'random', groups['Router'])}
                        ${this.renderTransformTypeSection('Union', 'object-group', groups['Union'])}
                        ${this.renderTransformTypeSection('Update Strategy', 'exchange-alt', groups['Update Strategy'])}
                        ${this.renderTransformTypeSection('Other', 'puzzle-piece', groups['other'])}
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
        
        // Bind expand/collapse events for mapping sections
        container.querySelectorAll('.mapping-transform-header').forEach(header => {
            header.addEventListener('click', () => {
                const section = header.closest('.mapping-transform-section');
                section.classList.toggle('expanded');
            });
        });
        
        // Bind expand/collapse events for transform cards
        container.querySelectorAll('.transform-card-header').forEach(header => {
            header.addEventListener('click', (e) => {
                e.stopPropagation();
                const card = header.closest('.transform-card');
                card.classList.toggle('expanded');
            });
        });
        
        // Bind click events for clickable expressions
        container.querySelectorAll('.clickable-expr').forEach(expr => {
            expr.addEventListener('click', (e) => {
                e.stopPropagation();
                const fullExpr = expr.getAttribute('data-full-expr');
                if (fullExpr) {
                    this.showExpressionPopup(fullExpr);
                }
            });
        });
    }
    
    showExpressionPopup(expression) {
        // Remove any existing popup
        const existingPopup = document.querySelector('.expr-popup-overlay');
        if (existingPopup) {
            existingPopup.remove();
        }
        
        const popupHtml = `
            <div class="expr-popup-overlay" data-testid="popup-expression-overlay">
                <div class="expr-popup" data-testid="popup-expression">
                    <div class="expr-popup-header">
                        <h4><i class="fas fa-code"></i> Full Expression</h4>
                        <button class="expr-popup-close" data-testid="button-close-popup">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="expr-popup-content">
                        <code>${this.escapeHtml(expression)}</code>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', popupHtml);
        
        // Bind close events
        const overlay = document.querySelector('.expr-popup-overlay');
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                overlay.remove();
            }
        });
        
        document.querySelector('.expr-popup-close').addEventListener('click', () => {
            overlay.remove();
        });
        
        // Close on Escape key
        const escHandler = (e) => {
            if (e.key === 'Escape') {
                overlay.remove();
                document.removeEventListener('keydown', escHandler);
            }
        };
        document.addEventListener('keydown', escHandler);
    }
    
    renderTransformTypeSection(title, icon, transforms) {
        if (!transforms || transforms.length === 0) return '';
        
        return `
            <div class="transform-type-section">
                <h4 class="transform-type-title">
                    <i class="fas fa-${icon}"></i>
                    ${title}
                    <span class="count-badge">${transforms.length}</span>
                </h4>
                <div class="transform-cards">
                    ${transforms.map(t => this.renderTransformCard(t)).join('')}
                </div>
            </div>
        `;
    }
    
    renderTransformCard(transform) {
        const typeIcons = {
            'Source Qualifier': 'filter',
            'Expression': 'calculator',
            'Filter': 'funnel-dollar',
            'Joiner': 'code-branch',
            'Lookup Procedure': 'search',
            'Stored Procedure': 'terminal',
            'Sorter': 'sort-amount-down',
            'Aggregator': 'layer-group',
            'Router': 'random',
            'Union': 'object-group',
            'Update Strategy': 'exchange-alt'
        };
        
        const icon = typeIcons[transform.type] || 'puzzle-piece';
        const fieldCount = transform.field_count || (transform.fields ? transform.fields.length : 0);
        const showAllFields = fieldCount <= 50;
        const displayFields = showAllFields ? (transform.fields || []) : (transform.fields || []).slice(0, 30);
        const remainingFields = showAllFields ? 0 : fieldCount - 30;
        
        return `
            <div class="transform-card" data-testid="transform-card-${transform.name}">
                <div class="transform-card-header">
                    <div class="transform-card-title">
                        <i class="fas fa-${icon}"></i>
                        <span class="transform-name" title="${this.escapeHtml(transform.name)}">${transform.name}</span>
                        <span class="transform-type-badge">${transform.type}</span>
                    </div>
                    <button class="expand-btn" data-testid="button-expand-transform-${transform.name}">
                        <i class="fas fa-chevron-down"></i>
                    </button>
                </div>
                <div class="transform-card-meta">
                    <span><i class="fas fa-list"></i> Fields: ${fieldCount}</span>
                    ${transform.description ? `<span title="${this.escapeHtml(transform.description)}"><i class="fas fa-info-circle"></i> ${this.truncateText(transform.description, 50)}</span>` : ''}
                </div>
                <div class="transform-pyspark-hint">
                    <i class="fas fa-code"></i>
                    <span>PySpark:</span>
                    <code title="${this.escapeHtml(transform.pyspark_equivalent || '')}">${transform.pyspark_equivalent || 'N/A'}</code>
                </div>
                <div class="transform-card-body">
                    <div class="transform-fields-section">
                        <h5><i class="fas fa-th-list"></i> Fields (${fieldCount})</h5>
                        <div class="table-container scrollable-table">
                            <table class="data-table fields-table">
                                <thead>
                                    <tr>
                                        <th>Field Name</th>
                                        <th>Data Type</th>
                                        <th>Port Type</th>
                                        <th>Expression</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${displayFields.length > 0 ? 
                                        displayFields.map(field => {
                                            const expr = field.expression ? String(field.expression) : '';
                                            const truncatedExpr = expr.length > 60 ? expr.substring(0, 60) + '...' : expr;
                                            return `
                                            <tr>
                                                <td><code title="${this.escapeHtml(field.name)}">${field.name}</code></td>
                                                <td title="${field.datatype || ''}">${field.datatype || '-'}</td>
                                                <td title="${field.port_type || ''}">${field.port_type || '-'}</td>
                                                <td class="expression-cell">
                                                    ${expr ? `
                                                        <div class="expression-value clickable-expr" 
                                                             title="${this.escapeHtml(expr)}"
                                                             data-full-expr="${this.escapeHtml(expr)}"
                                                             data-testid="expr-${field.name}">
                                                            <code>${this.escapeHtml(truncatedExpr)}</code>
                                                            ${expr.length > 60 ? '<i class="fas fa-expand-alt expand-icon"></i>' : ''}
                                                        </div>
                                                    ` : '-'}
                                                </td>
                                            </tr>
                                        `}).join('') : 
                                        '<tr><td colspan="4" class="text-center">No fields available</td></tr>'
                                    }
                                    ${remainingFields > 0 ? `
                                        <tr class="more-fields-row">
                                            <td colspan="4" class="text-center text-muted">
                                                <i class="fas fa-ellipsis-h"></i> 
                                                ${remainingFields} more fields not shown
                                            </td>
                                        </tr>
                                    ` : ''}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    truncateText(text, maxLength) {
        if (!text) return '';
        return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
    }
    
    displaySqlQueries(mappings) {
        const container = document.getElementById('sqlQueriesByMapping');
        if (!container) return;
        
        if (!mappings || mappings.length === 0) {
            container.innerHTML = '<p class="empty-message">No mappings found</p>';
            return;
        }
        
        let html = '';
        
        mappings.forEach((mapping, index) => {
            const sqlAnalysis = mapping.sql_analysis || {};
            const mappingName = mapping.mapping_name || `Mapping ${index + 1}`;
            
            const tables = sqlAnalysis.tables || [];
            const selectQueries = sqlAnalysis.select_queries || [];
            const storedProcedures = sqlAnalysis.stored_procedures || [];
            const lookupQueries = sqlAnalysis.lookup_queries || [];
            const filterConditions = sqlAnalysis.filter_conditions || [];
            const prePostSql = sqlAnalysis.pre_post_sql || [];
            
            const totalElements = tables.length + selectQueries.length + storedProcedures.length + 
                                  lookupQueries.length + filterConditions.length + prePostSql.length;
            
            html += `
                <div class="mapping-sql-section ${index === 0 ? 'expanded' : ''}" data-testid="mapping-sql-${mappingName}">
                    <div class="mapping-sql-header" data-testid="button-expand-sql-${mappingName}">
                        <div class="mapping-sql-title">
                            <i class="fas fa-project-diagram"></i>
                            <span class="mapping-name">${mappingName}</span>
                            <span class="sql-total-badge">${totalElements} SQL elements</span>
                        </div>
                        <button class="expand-btn">
                            <i class="fas fa-chevron-down"></i>
                        </button>
                    </div>
                    <div class="mapping-sql-body">
                        ${this.renderSqlTablesSection(tables)}
                        ${this.renderSelectQueriesSection(selectQueries)}
                        ${this.renderStoredProceduresSection(storedProcedures)}
                        ${this.renderLookupQueriesSection(lookupQueries)}
                        ${this.renderFilterConditionsSection(filterConditions)}
                        ${this.renderPrePostSqlSection(prePostSql)}
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
        
        // Bind expand/collapse events for mapping sections
        container.querySelectorAll('.mapping-sql-header').forEach(header => {
            header.addEventListener('click', () => {
                const section = header.closest('.mapping-sql-section');
                section.classList.toggle('expanded');
            });
        });
        
        // Bind click events for clickable SQL code
        container.querySelectorAll('.clickable-sql').forEach(sqlEl => {
            sqlEl.addEventListener('click', (e) => {
                e.stopPropagation();
                const fullSql = sqlEl.getAttribute('data-full-sql');
                if (fullSql) {
                    this.showSqlPopup(fullSql, sqlEl.getAttribute('data-sql-title') || 'SQL Query');
                }
            });
        });
    }
    
    renderSqlTablesSection(tables) {
        if (!tables || tables.length === 0) return '';
        
        // Group tables by type
        const sourcesTables = tables.filter(t => t.type === 'SOURCE');
        const targetsTables = tables.filter(t => t.type === 'TARGET');
        const lookupTables = tables.filter(t => t.type === 'LOOKUP');
        
        return `
            <div class="sql-section">
                <h4 class="sql-section-title">
                    <i class="fas fa-table"></i>
                    Tables
                    <span class="count-badge">${tables.length}</span>
                </h4>
                <div class="table-container scrollable-table">
                    <table class="data-table sql-table">
                        <thead>
                            <tr>
                                <th>Table Name</th>
                                <th>Type</th>
                                <th>Owner</th>
                                <th>Database</th>
                                <th>DB Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${tables.map(table => `
                                <tr>
                                    <td><code title="${this.escapeHtml(table.name)}">${table.name}</code></td>
                                    <td><span class="type-badge type-${table.type.toLowerCase()}">${table.type}</span></td>
                                    <td title="${table.owner || ''}">${table.owner || '-'}</td>
                                    <td title="${table.database || ''}">${table.database || '-'}</td>
                                    <td title="${table.database_type || ''}">${table.database_type || '-'}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }
    
    renderSelectQueriesSection(queries) {
        if (!queries || queries.length === 0) return '';
        
        return `
            <div class="sql-section">
                <h4 class="sql-section-title">
                    <i class="fas fa-search"></i>
                    SELECT Queries
                    <span class="count-badge">${queries.length}</span>
                </h4>
                <div class="sql-queries-list">
                    ${queries.map(query => `
                        <div class="sql-query-card">
                            <div class="sql-query-header">
                                <div class="sql-query-info">
                                    <span class="sql-query-name">${query.name}</span>
                                    <span class="sql-query-type-badge">${query.type}</span>
                                </div>
                            </div>
                            <div class="sql-query-content clickable-sql" 
                                 data-full-sql="${this.escapeHtml(query.query)}"
                                 data-sql-title="${this.escapeHtml(query.name)}"
                                 data-testid="sql-query-${query.name}">
                                <pre><code>${this.escapeHtml(this.truncateText(query.query, 500))}</code></pre>
                                ${query.query.length > 500 ? '<div class="click-to-expand"><i class="fas fa-expand-alt"></i> Click to view full query</div>' : ''}
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    renderStoredProceduresSection(procedures) {
        if (!procedures || procedures.length === 0) return '';
        
        return `
            <div class="sql-section">
                <h4 class="sql-section-title">
                    <i class="fas fa-terminal"></i>
                    Stored Procedures
                    <span class="count-badge">${procedures.length}</span>
                </h4>
                <div class="sql-queries-list">
                    ${procedures.map(sp => `
                        <div class="sql-query-card stored-proc">
                            <div class="sql-query-header">
                                <div class="sql-query-info">
                                    <span class="sql-query-name">${sp.name}</span>
                                    <span class="sql-query-type-badge">${sp.type}</span>
                                </div>
                                <span class="transformation-ref">Transformation: ${sp.transformation}</span>
                            </div>
                            <div class="sql-query-content ${sp.call_text !== 'No call text defined' ? 'clickable-sql' : ''}"
                                 ${sp.call_text !== 'No call text defined' ? `data-full-sql="${this.escapeHtml(sp.call_text)}" data-sql-title="${this.escapeHtml(sp.name)}"` : ''}
                                 data-testid="sp-${sp.name}">
                                <pre><code>${sp.call_text !== 'No call text defined' ? this.escapeHtml(this.truncateText(sp.call_text, 300)) : '<span class="text-muted">No call text defined</span>'}</code></pre>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    renderLookupQueriesSection(queries) {
        if (!queries || queries.length === 0) return '';
        
        return `
            <div class="sql-section">
                <h4 class="sql-section-title">
                    <i class="fas fa-search-plus"></i>
                    Lookup Queries
                    <span class="count-badge">${queries.length}</span>
                </h4>
                <div class="sql-queries-list">
                    ${queries.map(query => `
                        <div class="sql-query-card lookup">
                            <div class="sql-query-header">
                                <div class="sql-query-info">
                                    <span class="sql-query-name">${query.name}</span>
                                    <span class="sql-query-type-badge">${query.type}</span>
                                </div>
                                ${query.table ? `<span class="table-ref"><i class="fas fa-table"></i> ${query.table}</span>` : ''}
                            </div>
                            <div class="sql-query-content clickable-sql"
                                 data-full-sql="${this.escapeHtml(query.query)}"
                                 data-sql-title="${this.escapeHtml(query.name)}"
                                 data-testid="lookup-${query.name}">
                                <pre><code>${this.escapeHtml(this.truncateText(query.query, 400))}</code></pre>
                                ${query.query.length > 400 ? '<div class="click-to-expand"><i class="fas fa-expand-alt"></i> Click to view full query</div>' : ''}
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    renderFilterConditionsSection(filters) {
        if (!filters || filters.length === 0) return '';
        
        return `
            <div class="sql-section">
                <h4 class="sql-section-title">
                    <i class="fas fa-filter"></i>
                    Filter Conditions
                    <span class="count-badge">${filters.length}</span>
                </h4>
                <div class="sql-queries-list">
                    ${filters.map(filter => `
                        <div class="sql-query-card filter">
                            <div class="sql-query-header">
                                <div class="sql-query-info">
                                    <span class="sql-query-name">${filter.name}</span>
                                    <span class="sql-query-type-badge">${filter.type}</span>
                                </div>
                            </div>
                            <div class="sql-query-content" data-testid="filter-${filter.name}">
                                <pre><code>${this.escapeHtml(filter.condition)}</code></pre>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    renderPrePostSqlSection(sqlList) {
        if (!sqlList || sqlList.length === 0) {
            return `
                <div class="sql-section">
                    <h4 class="sql-section-title">
                        <i class="fas fa-code"></i>
                        Pre/Post SQL
                    </h4>
                    <p class="empty-message">No Pre/Post SQL found</p>
                </div>
            `;
        }
        
        return `
            <div class="sql-section">
                <h4 class="sql-section-title">
                    <i class="fas fa-code"></i>
                    Pre/Post SQL
                    <span class="count-badge">${sqlList.length}</span>
                </h4>
                <div class="sql-queries-list">
                    ${sqlList.map(sql => `
                        <div class="sql-query-card prepost">
                            <div class="sql-query-header">
                                <div class="sql-query-info">
                                    <span class="sql-query-name">${sql.name}</span>
                                    <span class="sql-query-type-badge">${sql.type}</span>
                                </div>
                            </div>
                            <div class="sql-query-content clickable-sql"
                                 data-full-sql="${this.escapeHtml(sql.sql)}"
                                 data-sql-title="${this.escapeHtml(sql.name + ' - ' + sql.type)}"
                                 data-testid="prepost-${sql.name}">
                                <pre><code>${this.escapeHtml(this.truncateText(sql.sql, 300))}</code></pre>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    showSqlPopup(sql, title) {
        // Remove any existing popup
        const existingPopup = document.querySelector('.expr-popup-overlay');
        if (existingPopup) {
            existingPopup.remove();
        }
        
        const popupHtml = `
            <div class="expr-popup-overlay" data-testid="popup-sql-overlay">
                <div class="expr-popup sql-popup" data-testid="popup-sql">
                    <div class="expr-popup-header">
                        <h4><i class="fas fa-database"></i> ${this.escapeHtml(title)}</h4>
                        <button class="expr-popup-close" data-testid="button-close-sql-popup">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="expr-popup-content sql-popup-content">
                        <pre><code>${this.escapeHtml(sql)}</code></pre>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', popupHtml);
        
        // Bind close events
        const overlay = document.querySelector('.expr-popup-overlay');
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                overlay.remove();
            }
        });
        
        document.querySelector('.expr-popup-close').addEventListener('click', () => {
            overlay.remove();
        });
        
        // Close on Escape key
        const escHandler = (e) => {
            if (e.key === 'Escape') {
                overlay.remove();
                document.removeEventListener('keydown', escHandler);
            }
        };
        document.addEventListener('keydown', escHandler);
    }
    
    displayConfigs(configs) {
        const container = document.getElementById('configsContainer');
        if (!container) return;
        
        if (!configs || configs.length === 0) {
            container.innerHTML = '<p class="empty-message">No configurations found in this XML file</p>';
            return;
        }
        
        let html = '';
        
        configs.forEach((config, index) => {
            const attributes = config.attributes || [];
            
            // Group attributes by category
            const categories = {
                'Memory & Performance': [],
                'Logging': [],
                'Error Handling': [],
                'Partitioning': [],
                'Date/Time': [],
                'Other': []
            };
            
            attributes.forEach(attr => {
                const name = attr.name.toLowerCase();
                if (name.includes('memory') || name.includes('buffer') || name.includes('cache') || name.includes('pipeline') || name.includes('optimization')) {
                    categories['Memory & Performance'].push(attr);
                } else if (name.includes('log') || name.includes('tracing') || name.includes('save session')) {
                    categories['Logging'].push(attr);
                } else if (name.includes('error') || name.includes('stop') || name.includes('recovery')) {
                    categories['Error Handling'].push(attr);
                } else if (name.includes('partition') || name.includes('grid')) {
                    categories['Partitioning'].push(attr);
                } else if (name.includes('date') || name.includes('time') || name.includes('timestamp')) {
                    categories['Date/Time'].push(attr);
                } else {
                    categories['Other'].push(attr);
                }
            });
            
            html += `
                <div class="config-section ${index === 0 ? 'expanded' : ''}" data-testid="config-${config.name}">
                    <div class="config-header" data-testid="button-expand-config-${config.name}">
                        <div class="config-title">
                            <i class="fas fa-cog"></i>
                            <span class="config-name">${this.escapeHtml(config.name)}</span>
                            ${config.is_default ? '<span class="default-badge">Default</span>' : ''}
                            <span class="attr-count-badge">${attributes.length} attributes</span>
                        </div>
                        <button class="expand-btn">
                            <i class="fas fa-chevron-down"></i>
                        </button>
                    </div>
                    <div class="config-body">
                        ${config.description ? `<p class="config-description"><i class="fas fa-info-circle"></i> ${this.escapeHtml(config.description)}</p>` : ''}
                        ${config.version ? `<p class="config-version">Version: ${this.escapeHtml(config.version)}</p>` : ''}
                        
                        ${Object.entries(categories).map(([category, attrs]) => {
                            if (attrs.length === 0) return '';
                            return `
                                <div class="config-category">
                                    <h4 class="category-title">
                                        <i class="fas ${this.getCategoryIcon(category)}"></i>
                                        ${category}
                                        <span class="count-badge">${attrs.length}</span>
                                    </h4>
                                    <div class="table-container scrollable-table">
                                        <table class="data-table config-table">
                                            <thead>
                                                <tr>
                                                    <th>Attribute</th>
                                                    <th>Value</th>
                                                    <th>Description</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                ${attrs.map(attr => `
                                                    <tr>
                                                        <td><code title="${this.escapeHtml(attr.name)}">${this.escapeHtml(attr.name)}</code></td>
                                                        <td>
                                                            ${attr.value ? 
                                                                `<span class="attr-value" title="${this.escapeHtml(attr.value)}">${this.escapeHtml(this.truncateText(attr.value, 50))}</span>` : 
                                                                '<span class="text-muted">-</span>'
                                                            }
                                                        </td>
                                                        <td>
                                                            ${attr.description ? 
                                                                `<span class="attr-desc" title="${this.escapeHtml(attr.description)}">${this.escapeHtml(attr.description)}</span>` : 
                                                                '<span class="text-muted">-</span>'
                                                            }
                                                        </td>
                                                    </tr>
                                                `).join('')}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
        
        // Bind expand/collapse events
        container.querySelectorAll('.config-header').forEach(header => {
            header.addEventListener('click', () => {
                const section = header.closest('.config-section');
                section.classList.toggle('expanded');
            });
        });
    }
    
    getCategoryIcon(category) {
        const icons = {
            'Memory & Performance': 'fa-microchip',
            'Logging': 'fa-file-alt',
            'Error Handling': 'fa-exclamation-triangle',
            'Partitioning': 'fa-th-large',
            'Date/Time': 'fa-clock',
            'Other': 'fa-cog'
        };
        return icons[category] || 'fa-cog';
    }
    
    displayConnectors(mappings) {
        const container = document.getElementById('connectorsContainer');
        if (!container) return;
        
        if (!mappings || mappings.length === 0) {
            container.innerHTML = '<p class="empty-message">No mappings found</p>';
            return;
        }
        
        let html = '';
        
        mappings.forEach((mapping, index) => {
            const connAnalysis = mapping.connectors_analysis || {};
            const connectors = connAnalysis.connectors || [];
            const summary = connAnalysis.summary || {};
            const bySource = connAnalysis.by_source_instance || {};
            const mappingName = mapping.mapping_name || `Mapping ${index + 1}`;
            const totalCount = connAnalysis.total_count || connectors.length;
            
            html += `
                <div class="connector-mapping-section ${index === 0 ? 'expanded' : ''}" data-testid="connector-mapping-${mappingName}">
                    <div class="connector-mapping-header" data-testid="button-expand-connector-${mappingName}">
                        <div class="connector-mapping-title">
                            <i class="fas fa-project-diagram"></i>
                            <span class="mapping-name">${this.escapeHtml(mappingName)}</span>
                            <span class="connector-count-badge">${totalCount} connectors</span>
                        </div>
                        <button class="expand-btn">
                            <i class="fas fa-chevron-down"></i>
                        </button>
                    </div>
                    <div class="connector-mapping-body">
                        ${this.renderConnectorSummary(summary)}
                        ${this.renderConnectorsBySource(bySource)}
                        ${this.renderConnectorsTable(connectors)}
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
        
        // Bind expand/collapse events
        container.querySelectorAll('.connector-mapping-header').forEach(header => {
            header.addEventListener('click', () => {
                const section = header.closest('.connector-mapping-section');
                section.classList.toggle('expanded');
            });
        });
        
        // Bind source instance expand/collapse
        container.querySelectorAll('.source-instance-header').forEach(header => {
            header.addEventListener('click', (e) => {
                e.stopPropagation();
                const section = header.closest('.source-instance-section');
                section.classList.toggle('expanded');
            });
        });
    }
    
    renderConnectorSummary(summary) {
        if (!summary) return '';
        
        const items = [
            { label: 'Source → SQ', count: summary.source_to_sq || 0, icon: 'fa-database', color: 'success' },
            { label: 'SQ → Transform', count: summary.sq_to_transform || 0, icon: 'fa-cogs', color: 'info' },
            { label: 'Transform → Transform', count: summary.transform_to_transform || 0, icon: 'fa-exchange-alt', color: 'warning' },
            { label: 'Transform → Target', count: summary.transform_to_target || 0, icon: 'fa-bullseye', color: 'primary' }
        ].filter(item => item.count > 0);
        
        if (items.length === 0) return '';
        
        return `
            <div class="connector-summary">
                <h4 class="connector-section-title">
                    <i class="fas fa-chart-bar"></i>
                    Flow Summary
                </h4>
                <div class="connector-summary-cards">
                    ${items.map(item => `
                        <div class="summary-card summary-card-${item.color}">
                            <div class="summary-card-icon">
                                <i class="fas ${item.icon}"></i>
                            </div>
                            <div class="summary-card-content">
                                <span class="summary-card-count">${item.count}</span>
                                <span class="summary-card-label">${item.label}</span>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    renderConnectorsBySource(bySource) {
        if (!bySource || Object.keys(bySource).length === 0) return '';
        
        const sources = Object.entries(bySource);
        
        return `
            <div class="connectors-by-source">
                <h4 class="connector-section-title">
                    <i class="fas fa-sitemap"></i>
                    Connections by Source Instance
                    <span class="count-badge">${sources.length} sources</span>
                </h4>
                <div class="source-instances-list">
                    ${sources.map(([sourceName, data], idx) => `
                        <div class="source-instance-section ${idx === 0 ? 'expanded' : ''}" data-testid="source-instance-${sourceName}">
                            <div class="source-instance-header">
                                <div class="source-instance-info">
                                    <i class="fas fa-arrow-right"></i>
                                    <span class="source-name">${this.escapeHtml(sourceName)}</span>
                                    <span class="instance-type-badge">${this.escapeHtml(data.type || 'Unknown')}</span>
                                    <span class="connection-count">${data.connections.length} outbound</span>
                                </div>
                                <button class="expand-btn">
                                    <i class="fas fa-chevron-down"></i>
                                </button>
                            </div>
                            <div class="source-instance-body">
                                <div class="table-container scrollable-table">
                                    <table class="data-table connector-table">
                                        <thead>
                                            <tr>
                                                <th>From Field</th>
                                                <th></th>
                                                <th>To Instance</th>
                                                <th>To Field</th>
                                                <th>To Type</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${data.connections.map(conn => `
                                                <tr>
                                                    <td><code title="${this.escapeHtml(conn.field)}">${this.escapeHtml(conn.field)}</code></td>
                                                    <td><i class="fas fa-long-arrow-alt-right connector-arrow"></i></td>
                                                    <td><strong title="${this.escapeHtml(conn.to_instance)}">${this.escapeHtml(conn.to_instance)}</strong></td>
                                                    <td><code title="${this.escapeHtml(conn.to_field)}">${this.escapeHtml(conn.to_field)}</code></td>
                                                    <td><span class="instance-type-badge small">${this.escapeHtml(conn.to_type || 'Unknown')}</span></td>
                                                </tr>
                                            `).join('')}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    renderConnectorsTable(connectors) {
        if (!connectors || connectors.length === 0) return '';
        
        return `
            <div class="all-connectors">
                <h4 class="connector-section-title">
                    <i class="fas fa-list"></i>
                    All Connectors
                    <span class="count-badge">${connectors.length}</span>
                </h4>
                <div class="table-container scrollable-table">
                    <table class="data-table connector-table full-connector-table">
                        <thead>
                            <tr>
                                <th>From Instance</th>
                                <th>From Type</th>
                                <th>From Field</th>
                                <th></th>
                                <th>To Instance</th>
                                <th>To Type</th>
                                <th>To Field</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${connectors.map(conn => `
                                <tr>
                                    <td><strong title="${this.escapeHtml(conn.from_instance)}">${this.escapeHtml(this.truncateText(conn.from_instance, 30))}</strong></td>
                                    <td><span class="instance-type-badge small">${this.escapeHtml(conn.from_type || 'Unknown')}</span></td>
                                    <td><code title="${this.escapeHtml(conn.from_field)}">${this.escapeHtml(this.truncateText(conn.from_field, 25))}</code></td>
                                    <td><i class="fas fa-long-arrow-alt-right connector-arrow"></i></td>
                                    <td><strong title="${this.escapeHtml(conn.to_instance)}">${this.escapeHtml(this.truncateText(conn.to_instance, 30))}</strong></td>
                                    <td><span class="instance-type-badge small">${this.escapeHtml(conn.to_type || 'Unknown')}</span></td>
                                    <td><code title="${this.escapeHtml(conn.to_field)}">${this.escapeHtml(this.truncateText(conn.to_field, 25))}</code></td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }
    
    displayPipelineDiagrams(mappings, workflowAnalysis) {
        const pipelineContainer = document.getElementById('pipelineDiagramsContainer');
        const workflowContainer = document.getElementById('workflowDiagramContainer');
        
        // Render mapping pipeline diagrams
        if (pipelineContainer) {
            if (!mappings || mappings.length === 0) {
                pipelineContainer.innerHTML = '<p class="empty-message">No mappings found</p>';
            } else {
                let html = '';
                mappings.forEach((mapping, index) => {
                    html += this.renderMappingPipelineDiagram(mapping, index);
                });
                pipelineContainer.innerHTML = html;
            }
        }
        
        // Render workflow diagram
        if (workflowContainer) {
            if (!workflowAnalysis || !workflowAnalysis.tasks || workflowAnalysis.tasks.length === 0) {
                workflowContainer.innerHTML = '<p class="empty-message">No workflow data available</p>';
            } else {
                workflowContainer.innerHTML = this.renderWorkflowDiagram(workflowAnalysis);
            }
        }
    }
    
    displayParameters(mappings, workflowAnalysis, allDollarVariables) {
        const container = document.getElementById('parametersContainer');
        if (!container) return;
        
        let allSessionVars = [];
        let allPmVars = [];
        let allMappingVars = [];
        let allWorkflowVars = [];
        let allPrmFiles = [];
        
        if (allDollarVariables) {
            if (allDollarVariables.session_variables) allSessionVars.push(...allDollarVariables.session_variables);
            if (allDollarVariables.pm_variables) allPmVars.push(...allDollarVariables.pm_variables);
            if (allDollarVariables.mapping_variables) allMappingVars.push(...allDollarVariables.mapping_variables);
            if (allDollarVariables.workflow_variables) allWorkflowVars.push(...allDollarVariables.workflow_variables);
        }
        
        if (mappings && mappings.length > 0) {
            mappings.forEach(mapping => {
                const params = mapping.parameters || {};
                if (params.session_variables) allSessionVars.push(...params.session_variables);
                if (params.pm_variables) allPmVars.push(...params.pm_variables);
                if (params.mapping_variables) allMappingVars.push(...params.mapping_variables);
                if (params.workflow_variables) allWorkflowVars.push(...params.workflow_variables);
                if (params.parameter_files) allPrmFiles.push(...params.parameter_files);
            });
        }
        
        if (workflowAnalysis && workflowAnalysis.workflow_variables && workflowAnalysis.workflow_variables.length > 0) {
            workflowAnalysis.workflow_variables.forEach(wfVar => {
                allWorkflowVars.push({
                    name: wfVar.name,
                    type: "Workflow Variable",
                    datatype: wfVar.datatype || "string",
                    default_value: wfVar.default_value || "N/A",
                    pyspark_equivalent: wfVar.pyspark_equivalent || "Airflow Variable / Databricks parameter"
                });
            });
        }
        
        // Remove duplicates
        allSessionVars = this.uniqueByName(allSessionVars);
        allPmVars = this.uniqueByName(allPmVars);
        allMappingVars = this.uniqueByName(allMappingVars);
        allWorkflowVars = this.uniqueByName(allWorkflowVars);
        allPrmFiles = this.uniqueByValue(allPrmFiles);
        
        // Update stats
        document.getElementById('sessionVarCount').textContent = allSessionVars.length;
        document.getElementById('pmVarCount').textContent = allPmVars.length;
        document.getElementById('prmFileCount').textContent = allPrmFiles.length;
        
        const totalParams = allSessionVars.length + allPmVars.length + allMappingVars.length + allWorkflowVars.length + allPrmFiles.length;
        
        if (totalParams === 0) {
            container.innerHTML = '<p class="empty-message">No parameters found in this mapping</p>';
            return;
        }
        
        let html = '<div class="parameters-sections">';
        
        // Session Variables ($$)
        if (allSessionVars.length > 0) {
            html += `
                <div class="param-section">
                    <h4 class="param-section-title">
                        <i class="fas fa-dollar-sign"></i>
                        Session Variables ($$)
                        <span class="count-badge">${allSessionVars.length}</span>
                    </h4>
                    <div class="param-table-container">
                        <table class="data-table param-table">
                            <thead>
                                <tr>
                                    <th>Variable Name</th>
                                    <th>Type</th>
                                    <th>PySpark Equivalent</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${allSessionVars.map(v => `
                                    <tr>
                                        <td><code class="param-name session-var">${this.escapeHtml(v.name)}</code></td>
                                        <td>${this.escapeHtml(v.type)}</td>
                                        <td><code class="pyspark-equiv">${this.escapeHtml(v.pyspark_equivalent)}</code></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
        }
        
        // PM Variables ($PM)
        if (allPmVars.length > 0) {
            html += `
                <div class="param-section">
                    <h4 class="param-section-title">
                        <i class="fas fa-cog"></i>
                        PowerCenter Variables ($PM)
                        <span class="count-badge">${allPmVars.length}</span>
                    </h4>
                    <div class="param-table-container">
                        <table class="data-table param-table">
                            <thead>
                                <tr>
                                    <th>Variable Name</th>
                                    <th>Type</th>
                                    <th>PySpark Equivalent</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${allPmVars.map(v => `
                                    <tr>
                                        <td><code class="param-name pm-var">${this.escapeHtml(v.name)}</code></td>
                                        <td>${this.escapeHtml(v.type)}</td>
                                        <td><code class="pyspark-equiv">${this.escapeHtml(v.pyspark_equivalent)}</code></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
        }
        
        // Mapping Variables ($$)
        if (allMappingVars.length > 0) {
            html += `
                <div class="param-section">
                    <h4 class="param-section-title">
                        <i class="fas fa-map"></i>
                        Mapping Variables ($$)
                        <span class="count-badge">${allMappingVars.length}</span>
                    </h4>
                    <div class="param-table-container">
                        <table class="data-table param-table">
                            <thead>
                                <tr>
                                    <th>Variable Name</th>
                                    <th>Data Type</th>
                                    <th>Default Value</th>
                                    <th>PySpark Equivalent</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${allMappingVars.map(v => `
                                    <tr>
                                        <td><code class="param-name mapping-var">${this.escapeHtml(v.name)}</code></td>
                                        <td>${this.escapeHtml(v.datatype || v.type || 'string')}</td>
                                        <td><code>${this.escapeHtml(v.default_value || 'N/A')}</code></td>
                                        <td><code class="pyspark-equiv">${this.escapeHtml(v.pyspark_equivalent)}</code></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
        }
        
        // Workflow Variables ($$)
        if (allWorkflowVars.length > 0) {
            html += `
                <div class="param-section">
                    <h4 class="param-section-title">
                        <i class="fas fa-project-diagram"></i>
                        Workflow Variables ($$)
                        <span class="count-badge">${allWorkflowVars.length}</span>
                    </h4>
                    <div class="param-table-container">
                        <table class="data-table param-table">
                            <thead>
                                <tr>
                                    <th>Variable Name</th>
                                    <th>Data Type</th>
                                    <th>Default Value</th>
                                    <th>PySpark Equivalent</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${allWorkflowVars.map(v => `
                                    <tr>
                                        <td><code class="param-name workflow-var">${this.escapeHtml(v.name)}</code></td>
                                        <td>${this.escapeHtml(v.datatype || v.type || 'string')}</td>
                                        <td><code>${this.escapeHtml(v.default_value || 'N/A')}</code></td>
                                        <td><code class="pyspark-equiv">${this.escapeHtml(v.pyspark_equivalent)}</code></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
        }
        
        // Parameter Files (.prm)
        if (allPrmFiles.length > 0) {
            html += `
                <div class="param-section">
                    <h4 class="param-section-title">
                        <i class="fas fa-file-alt"></i>
                        Parameter Files (.prm)
                        <span class="count-badge">${allPrmFiles.length}</span>
                    </h4>
                    <div class="param-table-container">
                        <table class="data-table param-table">
                            <thead>
                                <tr>
                                    <th>Attribute</th>
                                    <th>File Path</th>
                                    <th>Source</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${allPrmFiles.map(f => `
                                    <tr>
                                        <td>${this.escapeHtml(f.name)}</td>
                                        <td><code class="param-name prm-file">${this.escapeHtml(f.value)}</code></td>
                                        <td>${this.escapeHtml(f.source)}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
        }
        
        html += '</div>';
        container.innerHTML = html;
    }
    
    uniqueByName(arr) {
        const seen = new Set();
        return arr.filter(item => {
            if (seen.has(item.name)) return false;
            seen.add(item.name);
            return true;
        });
    }
    
    uniqueByValue(arr) {
        const seen = new Set();
        return arr.filter(item => {
            if (seen.has(item.value)) return false;
            seen.add(item.value);
            return true;
        });
    }
    
    renderMappingPipelineDiagram(mapping, index) {
        const mainFlow = mapping.main_flow || [];
        const flowText = mapping.flow_text || '';
        const mappingName = mapping.mapping_name || `Mapping ${index + 1}`;
        const connectors = mapping.connectors || [];
        
        // Build flow nodes from main_flow
        let flowNodes = [];
        if (mainFlow.length > 0) {
            flowNodes = mainFlow.map(step => ({
                name: step.instance_name,
                type: step.instance_type,
                shortType: this.getShortType(step.instance_type)
            }));
        } else if (flowText) {
            const parts = flowText.split(' -> ');
            flowNodes = parts.map(part => {
                const match = part.match(/^(.+?)\s*\((.+?)\)$/);
                if (match) {
                    return { name: match[1], type: match[2], shortType: match[2] };
                }
                return { name: part, type: 'Unknown', shortType: '?' };
            });
        }
        
        if (flowNodes.length === 0) {
            return `
                <div class="pipeline-mapping-card" data-testid="pipeline-${mappingName}">
                    <div class="pipeline-mapping-header">
                        <i class="fas fa-project-diagram"></i>
                        <span class="mapping-name">${this.escapeHtml(mappingName)}</span>
                    </div>
                    <div class="pipeline-diagram-empty">
                        <p>No pipeline flow detected for this mapping</p>
                    </div>
                </div>
            `;
        }
        
        // Build detailed flow graph from connectors
        const flowGraph = this.buildFlowGraph(flowNodes, connectors);
        const nodeStats = this.getNodeStats(flowNodes);
        
        return `
            <div class="pipeline-mapping-card detailed" data-testid="pipeline-${mappingName}">
                <div class="pipeline-mapping-header">
                    <i class="fas fa-project-diagram"></i>
                    <span class="mapping-name">${this.escapeHtml(mappingName)}</span>
                    <div class="pipeline-stats">
                        <span class="stat-item sources"><i class="fas fa-database"></i> ${nodeStats.sources}</span>
                        <span class="stat-item transforms"><i class="fas fa-cogs"></i> ${nodeStats.transforms}</span>
                        <span class="stat-item targets"><i class="fas fa-bullseye"></i> ${nodeStats.targets}</span>
                    </div>
                </div>
                <div class="pipeline-diagram-wrapper detailed-view">
                    ${this.renderDetailedFlowDiagram(flowNodes, connectors)}
                </div>
                <div class="pipeline-legend">
                    <span class="legend-title">Legend:</span>
                    <div class="legend-items">
                        <div class="legend-item"><span class="legend-icon node-source"><i class="fas fa-database"></i></span> Source/SQ</div>
                        <div class="legend-item"><span class="legend-icon node-transform"><i class="fas fa-code"></i></span> Expression</div>
                        <div class="legend-item"><span class="legend-icon node-update"><i class="fas fa-edit"></i></span> Update Strategy</div>
                        <div class="legend-item"><span class="legend-icon node-lookup"><i class="fas fa-search"></i></span> Lookup</div>
                        <div class="legend-item"><span class="legend-icon node-filter"><i class="fas fa-filter"></i></span> Filter</div>
                        <div class="legend-item"><span class="legend-icon node-union"><i class="fas fa-compress-arrows-alt"></i></span> Union</div>
                        <div class="legend-item"><span class="legend-icon node-router"><i class="fas fa-random"></i></span> Router</div>
                        <div class="legend-item"><span class="legend-icon node-joiner"><i class="fas fa-code-branch"></i></span> Joiner</div>
                        <div class="legend-item"><span class="legend-icon node-aggregator"><i class="fas fa-layer-group"></i></span> Aggregator</div>
                        <div class="legend-item"><span class="legend-icon node-target"><i class="fas fa-bullseye"></i></span> Target</div>
                    </div>
                </div>
                <div class="pipeline-flow-text">
                    <span class="flow-label">Flow Path:</span>
                    <code>${this.escapeHtml(flowText || 'No flow text')}</code>
                </div>
            </div>
        `;
    }
    
    getNodeStats(flowNodes) {
        let sources = 0, transforms = 0, targets = 0;
        flowNodes.forEach(n => {
            if (this.isSourceType(n.type)) sources++;
            else if (this.isTargetType(n.type)) targets++;
            else transforms++;
        });
        return { sources, transforms, targets };
    }
    
    renderDetailedFlowDiagram(flowNodes, connectors) {
        // Build a node map for quick lookup
        const nodeMap = {};
        flowNodes.forEach(n => { nodeMap[n.name] = n; });
        
        // Build adjacency lists from connectors
        const outgoing = {};
        const incoming = {};
        
        connectors.forEach(c => {
            if (!outgoing[c.from_instance]) outgoing[c.from_instance] = new Set();
            outgoing[c.from_instance].add(c.to_instance);
            
            if (!incoming[c.to_instance]) incoming[c.to_instance] = new Set();
            incoming[c.to_instance].add(c.from_instance);
        });
        
        // Identify sources (no incoming), targets (no outgoing), and transforms
        const sourceNodes = [];
        const targetNodes = [];
        const transformNodes = [];
        
        flowNodes.forEach(n => {
            const hasIncoming = incoming[n.name] && incoming[n.name].size > 0;
            const hasOutgoing = outgoing[n.name] && outgoing[n.name].size > 0;
            
            if (!hasIncoming && hasOutgoing) {
                sourceNodes.push(n);
            } else if (hasIncoming && !hasOutgoing) {
                targetNodes.push(n);
            } else if (hasIncoming || hasOutgoing) {
                transformNodes.push(n);
            }
        });
        
        // Build flow chains for visualization
        const flowChains = this.buildFlowChains(flowNodes, connectors);
        
        return `
            <div class="detailed-flow-container graph-view">
                ${flowChains.map((chain, idx) => this.renderFlowChain(chain, idx, flowChains.length)).join('')}
            </div>
        `;
    }
    
    buildFlowChains(flowNodes, connectors) {
        // Build adjacency from connectors
        const outgoing = {};
        const incoming = {};
        const nodeMap = {};
        
        flowNodes.forEach(n => { nodeMap[n.name] = n; });
        
        connectors.forEach(c => {
            if (!outgoing[c.from_instance]) outgoing[c.from_instance] = [];
            outgoing[c.from_instance].push(c.to_instance);
            
            if (!incoming[c.to_instance]) incoming[c.to_instance] = [];
            incoming[c.to_instance].push(c.from_instance);
        });
        
        // Find source nodes (no incoming connections)
        const sources = flowNodes.filter(n => !incoming[n.name] || incoming[n.name].length === 0);
        
        // Build chains starting from each source
        const chains = [];
        const visited = new Set();
        
        sources.forEach(source => {
            const chain = [];
            const queue = [source.name];
            
            while (queue.length > 0) {
                const nodeName = queue.shift();
                if (visited.has(nodeName)) continue;
                visited.add(nodeName);
                
                const node = nodeMap[nodeName];
                if (node) {
                    const nextNodes = outgoing[nodeName] || [];
                    chain.push({
                        node: node,
                        outputs: nextNodes.map(n => nodeMap[n]).filter(Boolean)
                    });
                    
                    nextNodes.forEach(next => {
                        if (!visited.has(next)) {
                            queue.push(next);
                        }
                    });
                }
            }
            
            if (chain.length > 0) {
                chains.push(chain);
            }
        });
        
        // If no chains found, create a single chain from all nodes in order
        if (chains.length === 0 && flowNodes.length > 0) {
            chains.push(flowNodes.map(n => ({ node: n, outputs: [] })));
        }
        
        return chains;
    }
    
    renderFlowChain(chain, chainIndex, totalChains) {
        if (chain.length === 0) return '';
        
        const pathInfo = this.getFlowPathInfo(chain);
        const nodeCount = chain.length;
        
        return `
            <div class="flow-chain vertical" data-chain="${chainIndex}" style="--path-color: ${pathInfo.color}">
                <div class="chain-header-wrapper">
                    <div class="chain-header-badge" style="background: linear-gradient(135deg, ${pathInfo.color}, ${pathInfo.colorDark})">
                        <i class="${pathInfo.icon}"></i>
                    </div>
                    <div class="chain-header-content">
                        <span class="chain-header-title">${pathInfo.name}</span>
                        <span class="chain-header-stats">${nodeCount} step${nodeCount !== 1 ? 's' : ''}</span>
                    </div>
                </div>
                <div class="chain-nodes-vertical">
                    ${chain.map((item, idx) => this.renderChainNodeVertical(item.node, item.outputs, idx === chain.length - 1, idx)).join('')}
                </div>
            </div>
        `;
    }
    
    getFlowPathInfo(chain) {
        const types = chain.map(item => item.node.type);
        
        const hasLookup = types.some(t => t === 'Lookup Procedure');
        const hasUnion = types.some(t => t === 'Union');
        const hasRouter = types.some(t => t === 'Router');
        const hasJoiner = types.some(t => t === 'Joiner');
        const hasAggregator = types.some(t => t === 'Aggregator');
        const hasFilter = types.some(t => t === 'Filter');
        const hasUpdateStrategy = types.some(t => t === 'Update Strategy');
        
        if (hasLookup) {
            return { name: 'Lookup', icon: 'fas fa-search', color: '#8b5cf6', colorDark: '#7c3aed' };
        } else if (hasUnion) {
            return { name: 'Union', icon: 'fas fa-compress-arrows-alt', color: '#14b8a6', colorDark: '#0d9488' };
        } else if (hasRouter) {
            return { name: 'Router', icon: 'fas fa-random', color: '#ec4899', colorDark: '#db2777' };
        } else if (hasJoiner) {
            return { name: 'Joiner', icon: 'fas fa-code-branch', color: '#a855f7', colorDark: '#9333ea' };
        } else if (hasAggregator) {
            return { name: 'Aggregator', icon: 'fas fa-layer-group', color: '#22c55e', colorDark: '#16a34a' };
        } else if (hasFilter) {
            return { name: 'Filter', icon: 'fas fa-filter', color: '#f97316', colorDark: '#ea580c' };
        } else if (hasUpdateStrategy) {
            return { name: 'Update', icon: 'fas fa-check-double', color: '#06b6d4', colorDark: '#0891b2' };
        } else {
            return { name: 'Pipeline', icon: 'fas fa-project-diagram', color: '#3b82f6', colorDark: '#2563eb' };
        }
    }
    
    renderChainNodeVertical(node, outputs, isLast, index) {
        const colorClass = this.getNodeColorClass(node.type);
        const icon = this.getNodeIcon(node.type);
        const shortType = this.getShortType(node.type);
        const stepNum = index + 1;
        
        return `
            <div class="chain-node-wrapper-vertical">
                <div class="chain-node-vertical ${colorClass}" title="${this.escapeHtml(node.name)}&#10;Type: ${this.escapeHtml(node.type)}">
                    <div class="node-step-number">${stepNum}</div>
                    <div class="chain-node-icon-vertical">${icon}</div>
                    <div class="chain-node-info-vertical">
                        <span class="chain-node-type-vertical">${this.escapeHtml(shortType)}</span>
                        <span class="chain-node-name-vertical">${this.escapeHtml(this.truncateText(node.name, 30))}</span>
                    </div>
                    <div class="chain-node-fulltype">${this.escapeHtml(node.type)}</div>
                </div>
                ${!isLast ? `
                    <div class="chain-connector-vertical">
                        <svg width="24" height="40" viewBox="0 0 24 40">
                            <defs>
                                <marker id="arrowhead-v-${node.name.replace(/[^a-zA-Z0-9]/g, '')}" markerWidth="8" markerHeight="6" refX="3" refY="3" orient="auto">
                                    <polygon points="0 0, 6 3, 0 6" fill="#3b82f6"/>
                                </marker>
                            </defs>
                            <line x1="12" y1="0" x2="12" y2="35" stroke="#3b82f6" stroke-width="2" marker-end="url(#arrowhead-v-${node.name.replace(/[^a-zA-Z0-9]/g, '')})"/>
                        </svg>
                    </div>
                ` : ''}
            </div>
        `;
    }
    
    groupTransformsByType(transforms) {
        const groups = {};
        const typeOrder = ['Source Qualifier', 'Expression', 'Lookup Procedure', 'Update Strategy', 'Filter', 'Router', 'Union', 'Joiner', 'Aggregator', 'Sorter', 'Sequence Generator', 'Normalizer', 'Stored Procedure'];
        
        transforms.forEach(t => {
            const type = t.type || 'Other';
            if (!groups[type]) groups[type] = [];
            groups[type].push(t);
        });
        
        // Sort groups by type order
        const sortedGroups = [];
        typeOrder.forEach(type => {
            if (groups[type]) {
                sortedGroups.push({ type, nodes: groups[type] });
                delete groups[type];
            }
        });
        // Add remaining groups
        Object.keys(groups).forEach(type => {
            sortedGroups.push({ type, nodes: groups[type] });
        });
        
        return sortedGroups;
    }
    
    renderTransformGroupsDetailed(transformGroups) {
        if (transformGroups.length === 0) return '<p class="empty-message">No transformations</p>';
        
        return transformGroups.map((group, groupIdx) => {
            const hasNext = groupIdx < transformGroups.length - 1;
            return `
                <div class="transform-group">
                    <div class="transform-group-header">
                        <span class="group-icon ${this.getNodeColorClass(group.type)}">${this.getNodeIcon(group.type)}</span>
                        <span class="group-type">${group.type}</span>
                        <span class="group-count">${group.nodes.length}</span>
                    </div>
                    <div class="transform-group-nodes">
                        ${group.nodes.map(node => this.renderDetailedNode(node)).join('')}
                    </div>
                </div>
                ${hasNext ? `
                    <div class="transform-group-connector">
                        <i class="fas fa-arrow-down"></i>
                    </div>
                ` : ''}
            `;
        }).join('');
    }
    
    renderDetailedNode(node) {
        const colorClass = this.getNodeColorClass(node.type);
        const icon = this.getNodeIcon(node.type);
        const shortType = this.getShortType(node.type);
        
        return `
            <div class="detailed-node ${colorClass}" title="${this.escapeHtml(node.name)}&#10;Type: ${this.escapeHtml(node.type)}">
                <div class="detailed-node-icon">${icon}</div>
                <div class="detailed-node-info">
                    <span class="detailed-node-type">${this.escapeHtml(shortType)}</span>
                    <span class="detailed-node-name">${this.escapeHtml(this.truncateText(node.name, 22))}</span>
                </div>
            </div>
        `;
    }
    
    buildFlowGraph(flowNodes, connectors) {
        const nodeMap = {};
        flowNodes.forEach(node => {
            nodeMap[node.name] = { ...node, inputs: [], outputs: [] };
        });
        
        connectors.forEach(conn => {
            if (nodeMap[conn.from_instance]) {
                nodeMap[conn.from_instance].outputs.push(conn.to_instance);
            }
            if (nodeMap[conn.to_instance]) {
                nodeMap[conn.to_instance].inputs.push(conn.from_instance);
            }
        });
        
        return nodeMap;
    }
    
    renderVerticalNode(node, category) {
        const colorClass = this.getNodeColorClass(node.type);
        return `
            <div class="pipeline-node-vertical ${colorClass}" title="${this.escapeHtml(node.name)} (${this.escapeHtml(node.type)})">
                <div class="node-icon-vertical">${this.getNodeIcon(node.type)}</div>
                <div class="node-content-vertical">
                    <span class="node-type-vertical">${this.escapeHtml(node.shortType)}</span>
                    <span class="node-name-vertical">${this.escapeHtml(this.truncateText(node.name, 25))}</span>
                </div>
            </div>
        `;
    }
    
    renderTransformationsFlow(transforms, connectorMap) {
        if (transforms.length === 0) return '';
        
        return transforms.map((node, idx) => {
            const colorClass = this.getNodeColorClass(node.type);
            const hasNext = idx < transforms.length - 1;
            return `
                <div class="transform-flow-item">
                    <div class="pipeline-node-vertical ${colorClass}" title="${this.escapeHtml(node.name)} (${this.escapeHtml(node.type)})">
                        <div class="node-icon-vertical">${this.getNodeIcon(node.type)}</div>
                        <div class="node-content-vertical">
                            <span class="node-type-vertical">${this.escapeHtml(node.shortType)}</span>
                            <span class="node-name-vertical">${this.escapeHtml(this.truncateText(node.name, 25))}</span>
                        </div>
                    </div>
                    ${hasNext ? `
                        <div class="transform-connector">
                            <i class="fas fa-arrow-down"></i>
                        </div>
                    ` : ''}
                </div>
            `;
        }).join('');
    }
    
    buildConnectorMap(connectors) {
        const map = {};
        connectors.forEach(conn => {
            if (!map[conn.from_instance]) map[conn.from_instance] = [];
            map[conn.from_instance].push(conn.to_instance);
        });
        return map;
    }
    
    isSourceType(type) {
        const sourceTypes = ['Source Qualifier', 'Source Definition', 'Source', 'SQ', 'Flat File Source', 'Application Source Qualifier'];
        return sourceTypes.some(t => type.toLowerCase().includes(t.toLowerCase()));
    }
    
    isTargetType(type) {
        const targetTypes = ['Target Definition', 'Target', 'TGT', 'Flat File Target'];
        return targetTypes.some(t => type.toLowerCase().includes(t.toLowerCase()));
    }
    
    renderWorkflowDiagram(workflowAnalysis) {
        const tasks = workflowAnalysis.tasks || [];
        const workflows = workflowAnalysis.workflows || [];
        const sessions = workflowAnalysis.sessions || [];
        const schedulers = workflowAnalysis.schedulers || [];
        const workflowVariables = workflowAnalysis.workflow_variables || [];
        
        const workflowName = workflows.length > 0 ? workflows[0].name : 'Workflow';
        const workflowDesc = workflows.length > 0 ? workflows[0].description : '';
        
        // Create session lookup by name for mapping info
        const sessionMap = {};
        sessions.forEach(s => { sessionMap[s.name] = s; });
        
        // Create task nodes with session details
        const taskNodes = tasks.filter(t => t.type !== 'Start').map(task => {
            const sessionInfo = sessionMap[task.name] || sessionMap[task.name.replace('s_', '')] || null;
            return {
                name: task.name,
                type: task.type,
                pyspark: task.pyspark_equivalent || 'PySpark Task',
                mapping: sessionInfo ? sessionInfo.mapping_name : null,
                transformCount: sessionInfo ? sessionInfo.transformation_count : 0
            };
        });
        
        // Render workflow variables section
        const variablesHtml = workflowVariables.length > 0 ? `
            <div class="workflow-detail-section">
                <div class="workflow-detail-header">
                    <i class="fas fa-code"></i>
                    <span>Workflow Variables (${workflowVariables.length})</span>
                </div>
                <div class="workflow-variables-list">
                    ${workflowVariables.map(v => `
                        <div class="workflow-variable-item">
                            <span class="var-name">${this.escapeHtml(v.name)}</span>
                            <span class="var-type">${this.escapeHtml(v.datatype)}</span>
                            <span class="var-default" title="Default: ${this.escapeHtml(v.default_value || 'N/A')}">${this.escapeHtml(this.truncateText(v.default_value || 'N/A', 30))}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : '';
        
        // Render scheduler section
        const schedulerHtml = schedulers.length > 0 ? `
            <div class="workflow-detail-section">
                <div class="workflow-detail-header">
                    <i class="fas fa-clock"></i>
                    <span>Scheduler</span>
                </div>
                <div class="scheduler-details">
                    ${schedulers.map(s => `
                        <div class="scheduler-item">
                            <div class="scheduler-main">
                                <span class="scheduler-name">${this.escapeHtml(s.name)}</span>
                                <span class="scheduler-type-badge ${this.getScheduleTypeClass(s.schedule_type)}">${this.escapeHtml(s.schedule_type || 'ONDEMAND')}</span>
                                ${s.reusable ? '<span class="reusable-badge">Reusable</span>' : ''}
                            </div>
                            ${s.start_date || s.end_date ? `
                                <div class="scheduler-dates">
                                    ${s.start_date ? `<span><i class="fas fa-calendar-alt"></i> Start: ${this.escapeHtml(s.start_date)}</span>` : ''}
                                    ${s.end_date ? `<span><i class="fas fa-calendar-times"></i> End: ${this.escapeHtml(s.end_date)}</span>` : ''}
                                </div>
                            ` : ''}
                            ${s.repeat_interval ? `<div class="scheduler-interval"><i class="fas fa-sync"></i> Repeat: ${this.escapeHtml(s.repeat_interval)}</div>` : ''}
                            <div class="scheduler-pyspark"><i class="fas fa-arrow-right"></i> ${this.escapeHtml(s.pyspark_equivalent)}</div>
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : '';
        
        // Render sessions with mapping names section
        const sessionsHtml = sessions.length > 0 ? `
            <div class="workflow-detail-section">
                <div class="workflow-detail-header">
                    <i class="fas fa-cogs"></i>
                    <span>Sessions (${sessions.length})</span>
                </div>
                <div class="sessions-list">
                    ${sessions.map(s => `
                        <div class="session-detail-item">
                            <div class="session-header-row">
                                <span class="session-name">${this.escapeHtml(s.name)}</span>
                                ${s.is_valid ? '<span class="valid-badge">Valid</span>' : '<span class="invalid-badge">Invalid</span>'}
                            </div>
                            <div class="session-mapping-row">
                                <i class="fas fa-project-diagram"></i>
                                <span class="mapping-name-ref">${this.escapeHtml(s.mapping_name || 'No mapping')}</span>
                                <span class="transform-count">${s.transformation_count || 0} transformations</span>
                            </div>
                            ${(s.pre_session_components && s.pre_session_components.length > 0) || 
                              (s.post_success_components && s.post_success_components.length > 0) || 
                              (s.post_failure_components && s.post_failure_components.length > 0) ? `
                                <div class="session-components">
                                    ${s.pre_session_components && s.pre_session_components.length > 0 ? `
                                        <span class="component-badge pre"><i class="fas fa-play"></i> Pre: ${s.pre_session_components.length}</span>
                                    ` : ''}
                                    ${s.post_success_components && s.post_success_components.length > 0 ? `
                                        <span class="component-badge success"><i class="fas fa-check"></i> Post-Success: ${s.post_success_components.length}</span>
                                    ` : ''}
                                    ${s.post_failure_components && s.post_failure_components.length > 0 ? `
                                        <span class="component-badge failure"><i class="fas fa-times"></i> Post-Failure: ${s.post_failure_components.length}</span>
                                    ` : ''}
                                </div>
                            ` : ''}
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : '';
        
        if (tasks.length === 0 && sessions.length === 0) {
            return '<p class="empty-message">No workflow data available</p>';
        }
        
        return `
            <div class="workflow-diagram-card detailed">
                <div class="workflow-diagram-header">
                    <i class="fas fa-sitemap"></i>
                    <span class="workflow-name">${this.escapeHtml(workflowName)}</span>
                    <span class="task-count">${taskNodes.length} tasks</span>
                </div>
                ${workflowDesc ? `<div class="workflow-description"><i class="fas fa-info-circle"></i> ${this.escapeHtml(workflowDesc)}</div>` : ''}
                
                <div class="workflow-details-container">
                    ${schedulerHtml}
                    ${variablesHtml}
                    ${sessionsHtml}
                </div>
                
                <div class="workflow-flow-section">
                    <div class="workflow-flow-header">
                        <i class="fas fa-stream"></i>
                        <span>Task Flow</span>
                    </div>
                    <div class="workflow-flow-diagram">
                        <div class="workflow-start-node">
                            <i class="fas fa-play-circle"></i>
                            <span>Start</span>
                        </div>
                        <div class="workflow-arrow"><i class="fas fa-arrow-down"></i></div>
                        ${taskNodes.map((task, idx) => `
                            <div class="workflow-task-node ${task.mapping ? 'has-mapping' : ''}" title="${this.escapeHtml(task.pyspark)}">
                                <div class="task-icon">${this.getTaskIcon(task.type)}</div>
                                <div class="task-content">
                                    <span class="task-type">${this.escapeHtml(task.type)}</span>
                                    <span class="task-name">${this.escapeHtml(task.name)}</span>
                                    ${task.mapping ? `<span class="task-mapping"><i class="fas fa-link"></i> ${this.escapeHtml(this.truncateText(task.mapping, 40))}</span>` : ''}
                                    ${task.transformCount > 0 ? `<span class="task-transforms">${task.transformCount} transforms</span>` : ''}
                                </div>
                            </div>
                            <div class="workflow-arrow"><i class="fas fa-arrow-down"></i></div>
                        `).join('')}
                        <div class="workflow-end-node">
                            <i class="fas fa-stop-circle"></i>
                            <span>End</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    getScheduleTypeClass(scheduleType) {
        const typeMap = {
            'ONDEMAND': 'schedule-ondemand',
            'DAILY': 'schedule-daily',
            'WEEKLY': 'schedule-weekly',
            'MONTHLY': 'schedule-monthly',
            'HOURLY': 'schedule-hourly',
            'CUSTOMIZED': 'schedule-custom'
        };
        return typeMap[scheduleType] || 'schedule-default';
    }
    
    displayRawJson(result) {
        this.fullJsonData = result;
        this.currentJsonTab = 'analysis';
        
        // Store separate JSON sections
        this.jsonSections = {
            analysis: result.analysis || {},
            workflow: result.workflow_analysis || {},
            full: result
        };
        
        // Set up JSON tab handlers
        document.querySelectorAll('.json-tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.json-tab-btn').forEach(b => b.classList.remove('active'));
                e.target.closest('.json-tab-btn').classList.add('active');
                this.currentJsonTab = e.target.closest('.json-tab-btn').dataset.jsonTab;
                this.renderJsonViewer();
            });
        });
        
        // Copy button
        const copyBtn = document.getElementById('copyJsonBtn');
        if (copyBtn) {
            copyBtn.addEventListener('click', () => {
                const jsonData = JSON.stringify(this.jsonSections[this.currentJsonTab], null, 2);
                navigator.clipboard.writeText(jsonData).then(() => {
                    this.showToast('JSON copied to clipboard', 'success');
                }).catch(() => {
                    this.showToast('Failed to copy', 'error');
                });
            });
        }
        
        // Download button
        const downloadBtn = document.getElementById('downloadJsonBtn');
        if (downloadBtn) {
            downloadBtn.addEventListener('click', () => {
                const jsonData = JSON.stringify(this.jsonSections[this.currentJsonTab], null, 2);
                const blob = new Blob([jsonData], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `parsed_${this.currentJsonTab}_${Date.now()}.json`;
                a.click();
                URL.revokeObjectURL(url);
                this.showToast('JSON downloaded', 'success');
            });
        }
        
        // Expand/Collapse button
        this.jsonExpanded = false;
        const expandBtn = document.getElementById('expandCollapseBtn');
        if (expandBtn) {
            expandBtn.addEventListener('click', () => {
                this.jsonExpanded = !this.jsonExpanded;
                expandBtn.innerHTML = this.jsonExpanded 
                    ? '<i class="fas fa-compress-alt"></i> Collapse All'
                    : '<i class="fas fa-expand-alt"></i> Expand All';
                this.renderJsonViewer();
            });
        }
        
        this.renderJsonViewer();
    }
    
    renderJsonViewer() {
        const viewer = document.getElementById('jsonViewer');
        if (!viewer) return;
        
        const data = this.jsonSections[this.currentJsonTab];
        const depth = this.jsonExpanded ? 100 : 2;
        
        viewer.innerHTML = `<code>${this.syntaxHighlightJson(data, depth)}</code>`;
    }
    
    syntaxHighlightJson(obj, maxDepth = 2, currentDepth = 0, indent = 0) {
        if (obj === null) return '<span class="json-null">null</span>';
        if (obj === undefined) return '<span class="json-undefined">undefined</span>';
        
        const indentStr = '  '.repeat(indent);
        const type = typeof obj;
        
        if (type === 'string') {
            const escaped = this.escapeHtml(obj);
            const truncated = escaped.length > 100 ? escaped.substring(0, 100) + '...' : escaped;
            return `<span class="json-string">"${truncated}"</span>`;
        }
        if (type === 'number') return `<span class="json-number">${obj}</span>`;
        if (type === 'boolean') return `<span class="json-boolean">${obj}</span>`;
        
        if (Array.isArray(obj)) {
            if (obj.length === 0) return '<span class="json-bracket">[]</span>';
            if (currentDepth >= maxDepth) {
                return `<span class="json-bracket">[</span><span class="json-collapsed" title="Click to expand">...${obj.length} items</span><span class="json-bracket">]</span>`;
            }
            
            let html = '<span class="json-bracket">[</span>\n';
            obj.forEach((item, idx) => {
                html += indentStr + '  ' + this.syntaxHighlightJson(item, maxDepth, currentDepth + 1, indent + 1);
                if (idx < obj.length - 1) html += ',';
                html += '\n';
            });
            html += indentStr + '<span class="json-bracket">]</span>';
            return html;
        }
        
        if (type === 'object') {
            const keys = Object.keys(obj);
            if (keys.length === 0) return '<span class="json-bracket">{}</span>';
            if (currentDepth >= maxDepth) {
                return `<span class="json-bracket">{</span><span class="json-collapsed" title="Click to expand">...${keys.length} keys</span><span class="json-bracket">}</span>`;
            }
            
            let html = '<span class="json-bracket">{</span>\n';
            keys.forEach((key, idx) => {
                html += indentStr + '  <span class="json-key">"' + this.escapeHtml(key) + '"</span>: ';
                html += this.syntaxHighlightJson(obj[key], maxDepth, currentDepth + 1, indent + 1);
                if (idx < keys.length - 1) html += ',';
                html += '\n';
            });
            html += indentStr + '<span class="json-bracket">}</span>';
            return html;
        }
        
        return String(obj);
    }
    
    openXmlDocsModal() {
        const modal = document.getElementById('xmlDocsModal');
        const container = document.getElementById('xmlDocsMain');
        
        if (modal && container) {
            container.innerHTML = this.getXmlDocsContent();
            modal.classList.add('open');
            document.body.style.overflow = 'hidden';
            
            // Smooth scroll for nav links inside modal
            setTimeout(() => {
                document.querySelectorAll('#xmlDocsModal .docs-nav-link').forEach(link => {
                    link.addEventListener('click', (e) => {
                        e.preventDefault();
                        const targetId = link.getAttribute('href').substring(1);
                        const target = document.getElementById(targetId);
                        if (target) {
                            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }
                    });
                });
            }, 100);
        }
    }
    
    closeXmlDocsModal() {
        const modal = document.getElementById('xmlDocsModal');
        if (modal) {
            modal.classList.remove('open');
            document.body.style.overflow = '';
        }
    }
    
    openPySparkGuideModal() {
        const modal = document.getElementById('pysparkGuideModal');
        const container = document.getElementById('pysparkGuideMain');
        
        if (modal && container) {
            container.innerHTML = this.getPySparkGuideContent();
            modal.classList.add('open');
            document.body.style.overflow = 'hidden';
            
            setTimeout(() => {
                document.querySelectorAll('#pysparkGuideModal .docs-nav-link').forEach(link => {
                    link.addEventListener('click', (e) => {
                        e.preventDefault();
                        const targetId = link.getAttribute('href').substring(1);
                        const target = document.getElementById(targetId);
                        if (target) {
                            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }
                    });
                });
            }, 100);
        }
    }
    
    closePySparkGuideModal() {
        const modal = document.getElementById('pysparkGuideModal');
        if (modal) {
            modal.classList.remove('open');
            document.body.style.overflow = '';
        }
    }
    
    getPySparkGuideContent() {
        return `
            <div class="doc-section" id="guide-overview">
                <h3 class="doc-section-title"><i class="fas fa-info-circle"></i> Overview</h3>
                <p class="doc-intro">This guide explains how the Informatica to PySpark Converter (Version 4.0) transforms each Informatica PowerCenter component into equivalent PySpark code with MSSQL connectivity.</p>
                <div class="doc-description">
                    <strong>Key Features:</strong>
                    <ul>
                        <li>MSSQL for both source and target databases</li>
                        <li>Connection name mapping (CDM_PRE_LANDING → msscdm_dev, etc.)</li>
                        <li>Fixed target database: <code>msscdm_dev3</code></li>
                        <li>YAML config with <code>\${VAR:default}</code> environment variable syntax</li>
                        <li>Dynamic partitioning for optimal performance</li>
                        <li>40+ Informatica function translations</li>
                    </ul>
                </div>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Component</th><th>PySpark Equivalent</th><th>Notes</th></tr></thead>
                        <tbody>
                            <tr><td>Mapping</td><td>Self-contained .py file</td><td>Complete ETL with embedded utilities</td></tr>
                            <tr><td>Session</td><td>config_*.yml</td><td>YAML configuration with env vars</td></tr>
                            <tr><td>Workflow</td><td>workflow.py</td><td>Orchestration script</td></tr>
                            <tr><td>Source</td><td>read_source(query)</td><td>MSSQL JDBC reader</td></tr>
                            <tr><td>Target</td><td>safe_write_jdbc()</td><td>MSSQL JDBC writer to msscdm_dev3</td></tr>
                            <tr><td>Lookup</td><td>read_lookup(query)</td><td>Cached lookup with left join</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="guide-architecture">
                <h3 class="doc-section-title"><i class="fas fa-sitemap"></i> Generated Code Architecture</h3>
                <p class="doc-description">Each mapping generates a self-contained Python file with embedded utilities - no external lib/ folder required.</p>
                <div class="doc-hierarchy-tree">
<pre class="hierarchy-code">generated_output/
├── mapping_*.py           # Self-contained PySpark mapping
├── config_*.yml           # YAML config with \${VAR:default} syntax
├── workflow.py            # Orchestration script
├── *_pyspark.zip          # Downloadable package
└── report.json            # Conversion report</pre>
                </div>
                <h4 class="doc-subtitle">Connection Database Mapping</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Connection Name → Database Resolution
CONNECTION_DB_MAPPING = {
    "CDM_PRE_LANDING": "msscdm_dev",
    "CDM_PRE_LANDING_INV": "msscdm_inv",
    "CDM_LANDING": "cmx_ors_10_3",
    "CDM_LANDING_INV": "cmx_ors_inv"
}

# Target database is always fixed
database_name_target = "msscdm_dev3"</pre>
                </div>
                <h4 class="doc-subtitle">Configuration File Pattern</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># config_mapping_name.yml
connections:
  CDM_PRE_LANDING:
    host: "\${MSSQL_HOST:localhost}"
    database: "msscdm_dev"
    user: "\${MSSQL_USER:sa}"
    password: "\${MSSQL_PASSWORD}"
    driver_jar: "\${MSSQL_DRIVER_JAR:/opt/drivers/mssql-jdbc.jar}"

spark:
  config:
    spark.driver.memory: "16g"
    spark.executor.memory: "16g"

params:
  SRC_SYSTEM_NM: "SSC"</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-sources">
                <h3 class="doc-section-title"><i class="fas fa-database"></i> Source Definition Conversion</h3>
                <p class="doc-description">Informatica SOURCE elements are converted to MSSQL JDBC readers using the <code>read_source()</code> helper function.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Connection Name</th><th>Resolved Database</th></tr></thead>
                        <tbody>
                            <tr><td>CDM_PRE_LANDING</td><td>msscdm_dev</td></tr>
                            <tr><td>CDM_PRE_LANDING_INV</td><td>msscdm_inv</td></tr>
                            <tr><td>CDM_LANDING</td><td>cmx_ors_10_3</td></tr>
                            <tr><td>CDM_LANDING_INV</td><td>cmx_ors_inv</td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Generated Code Pattern</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Helper function in generated code
def read_source(query: str) -> DataFrame:
    """Read from MSSQL source database."""
    return spark.read.format("jdbc").options(
        url=jdbc_url_source,
        driver="com.microsoft.sqlserver.jdbc.SQLServerDriver",
        user=user,
        password=password,
        query=query,
        fetchsize="10000"
    ).load()

# Usage in mapping
df_SQ_Customer = read_source("""
    SELECT CUSTOMER_ID, CUSTOMER_NAME, STATUS
    FROM dbo.CUSTOMER
    WHERE STATUS = 'ACTIVE'
""")</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-targets">
                <h3 class="doc-section-title"><i class="fas fa-bullseye"></i> Target Definition Conversion</h3>
                <p class="doc-description">All targets write to the fixed database <code>msscdm_dev3</code> using the <code>safe_write_jdbc()</code> function with dynamic partitioning.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Feature</th><th>Implementation</th></tr></thead>
                        <tbody>
                            <tr><td>Target Database</td><td><code>msscdm_dev3</code> (fixed)</td></tr>
                            <tr><td>Empty Dataset Handling</td><td>Gracefully skips write if 0 rows</td></tr>
                            <tr><td>Dynamic Partitioning</td><td><code>smart_repartition()</code> optimizes partitions</td></tr>
                            <tr><td>CREATE TABLE</td><td>MSSQL-standard DDL syntax</td></tr>
                            <tr><td>Pre/Post SQL</td><td><code>execute_pre_sql()</code> / <code>execute_post_sql()</code></td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Generated Code Pattern</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Dynamic partitioning for optimal writes
def smart_repartition(df, target_partitions=20, min_rows=1000):
    row_count = df.count()
    if row_count == 0:
        return df  # Skip repartition for empty
    optimal = max(1, min(target_partitions, row_count // min_rows))
    return df.coalesce(optimal) if optimal < df.rdd.getNumPartitions() else df.repartition(optimal)

# Safe write with empty dataset handling
def safe_write_jdbc(df, table_name, mode="append"):
    if df.count() == 0:
        print(f"No data to write to {table_name}")
        return
    smart_repartition(df).write.format("jdbc").options(
        url=jdbc_url_target,  # Always msscdm_dev3
        dbtable=table_name,
        driver="com.microsoft.sqlserver.jdbc.SQLServerDriver"
    ).mode(mode).save()</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-sq">
                <h3 class="doc-section-title"><i class="fas fa-filter"></i> Source Qualifier Conversion</h3>
                <p class="doc-description">Source Qualifier transformations handle SQL overrides, joins between sources, and filtering at the source level.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>SQ Feature</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td>SQL Query Override</td><td><code>.option("query", "SELECT ... FROM ...")</code></td></tr>
                            <tr><td>Filter Condition</td><td><code>.option("query", "SELECT * FROM t WHERE ...")</code></td></tr>
                            <tr><td>Source Join</td><td>Push down join in query or separate join operation</td></tr>
                            <tr><td>Distinct</td><td><code>.distinct()</code></td></tr>
                            <tr><td>Sorted Ports</td><td><code>.orderBy(...)</code> (if needed downstream)</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="guide-expression">
                <h3 class="doc-section-title"><i class="fas fa-calculator"></i> Expression Transformation</h3>
                <p class="doc-description">40+ Informatica functions are automatically translated to PySpark equivalents.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Category</th><th>Informatica Functions</th><th>PySpark Equivalent</th></tr></thead>
                        <tbody>
                            <tr><td>Conditional</td><td><code>IIF, DECODE, NVL, NVL2</code></td><td><code>when().otherwise(), coalesce()</code></td></tr>
                            <tr><td>String</td><td><code>SUBSTR, LTRIM, RTRIM, INITCAP, REVERSE, CHR, ASCII</code></td><td><code>substring(), trim(), initcap(), reverse()</code></td></tr>
                            <tr><td>Date/Time</td><td><code>TO_DATE, SYSDATE, ADD_TO_DATE, DATE_COMPARE, GET_DATE_PART</code></td><td><code>to_date(), current_timestamp(), expr()</code></td></tr>
                            <tr><td>Math</td><td><code>ROUND, TRUNC, ABS, MOD, SIN, COS, TAN, RAND</code></td><td><code>round(), trunc(), abs(), mod(), sin(), rand()</code></td></tr>
                            <tr><td>Window</td><td><code>CUME, MOVINGSUM, MOVINGAVG</code></td><td><code>sum().over(), avg().over()</code></td></tr>
                            <tr><td>Error</td><td><code>ERROR, ABORT</code></td><td><code>raise_error()</code></td></tr>
                            <tr><td>Type</td><td><code>TO_CHAR, TO_INTEGER, TO_DECIMAL</code></td><td><code>cast()</code></td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Example Conversions</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># IIF with nested conditions
# Informatica: IIF(STATUS='A', 'Active', IIF(STATUS='P', 'Pending', 'Unknown'))
when(col("STATUS") == "A", "Active")
    .when(col("STATUS") == "P", "Pending")
    .otherwise("Unknown")

# ADD_TO_DATE (date arithmetic)
# Informatica: ADD_TO_DATE(START_DATE, 'MM', 3)
col("START_DATE") + expr("make_interval(0, 3)")  # Add 3 months

# DECODE
# Informatica: DECODE(TYPE, 'A', 'Alpha', 'B', 'Beta', 'Unknown')
when(col("TYPE") == "A", "Alpha")
    .when(col("TYPE") == "B", "Beta")
    .otherwise("Unknown")

# Window functions (require ORDER BY)
# Informatica: CUME(AMOUNT)
sum("AMOUNT").over(Window.orderBy(lit(1)).rowsBetween(Window.unboundedPreceding, 0))</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-filter">
                <h3 class="doc-section-title"><i class="fas fa-funnel-dollar"></i> Filter Transformation</h3>
                <p class="doc-description">Filter transformations are directly converted to PySpark filter() or where() operations.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Filter</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td><code>FILTER_CONDITION = STATUS = 'A'</code></td><td><code>df.filter(col("STATUS") == "A")</code></td></tr>
                            <tr><td><code>AMOUNT > 1000 AND REGION = 'US'</code></td><td><code>df.filter((col("AMOUNT") > 1000) & (col("REGION") == "US"))</code></td></tr>
                            <tr><td><code>ISNULL(FIELD) = FALSE</code></td><td><code>df.filter(col("FIELD").isNotNull())</code></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="guide-lookup">
                <h3 class="doc-section-title"><i class="fas fa-search"></i> Lookup Transformation</h3>
                <p class="doc-description">Lookup transformations are converted to left joins with the lookup table/DataFrame.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Lookup</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td>Lookup Table</td><td>Read as separate DataFrame</td></tr>
                            <tr><td>Lookup Condition</td><td>Join condition in <code>.join()</code></td></tr>
                            <tr><td>Return Ports</td><td>Selected columns from lookup DataFrame</td></tr>
                            <tr><td>Default Value</td><td><code>coalesce(lookup_col, lit(default))</code></td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Example Conversion</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Informatica Lookup: LKP_PRODUCT on PRODUCT_ID
df_product = spark.read.format("jdbc")...  # Lookup source

df = df.join(
    df_product.select("PRODUCT_ID", "PRODUCT_NAME", "CATEGORY"),
    on="PRODUCT_ID",
    how="left"
)</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-joiner">
                <h3 class="doc-section-title"><i class="fas fa-code-branch"></i> Joiner Transformation</h3>
                <p class="doc-description">Joiner transformations are converted to PySpark join operations with the specified join type.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Join Type</th><th>PySpark Join Type</th></tr></thead>
                        <tbody>
                            <tr><td>Normal (Inner)</td><td><code>how="inner"</code></td></tr>
                            <tr><td>Master Outer</td><td><code>how="left"</code></td></tr>
                            <tr><td>Detail Outer</td><td><code>how="right"</code></td></tr>
                            <tr><td>Full Outer</td><td><code>how="outer"</code></td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Example Conversion</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Informatica Joiner: JNR_ORDER_CUSTOMER (Master Outer)
df_result = df_orders.join(
    df_customers,
    on=df_orders["CUSTOMER_ID"] == df_customers["CUST_ID"],
    how="left"
)</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-aggregator">
                <h3 class="doc-section-title"><i class="fas fa-layer-group"></i> Aggregator Transformation</h3>
                <p class="doc-description">Aggregator transformations are converted to PySpark groupBy() with aggregate functions.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Aggregate</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td>Group By Ports</td><td><code>.groupBy("col1", "col2")</code></td></tr>
                            <tr><td><code>SUM(AMOUNT)</code></td><td><code>.agg(sum("AMOUNT"))</code></td></tr>
                            <tr><td><code>COUNT(*)</code></td><td><code>.agg(count("*"))</code></td></tr>
                            <tr><td><code>AVG(VALUE)</code></td><td><code>.agg(avg("VALUE"))</code></td></tr>
                            <tr><td><code>MAX/MIN</code></td><td><code>.agg(max("col"), min("col"))</code></td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Example Conversion</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Informatica Aggregator: AGG_SALES_BY_REGION
df_agg = df.groupBy("REGION", "PRODUCT_CATEGORY").agg(
    sum("SALES_AMOUNT").alias("TOTAL_SALES"),
    count("ORDER_ID").alias("ORDER_COUNT"),
    avg("UNIT_PRICE").alias("AVG_PRICE")
)</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-sorter">
                <h3 class="doc-section-title"><i class="fas fa-sort"></i> Sorter Transformation</h3>
                <p class="doc-description">Sorter transformations are converted to PySpark orderBy() operations.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Sorter</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td>Sort Key (Ascending)</td><td><code>.orderBy(col("column").asc())</code></td></tr>
                            <tr><td>Sort Key (Descending)</td><td><code>.orderBy(col("column").desc())</code></td></tr>
                            <tr><td>Multiple Keys</td><td><code>.orderBy(col("c1").asc(), col("c2").desc())</code></td></tr>
                            <tr><td>Distinct</td><td><code>.dropDuplicates()</code></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="guide-router">
                <h3 class="doc-section-title"><i class="fas fa-random"></i> Router Transformation</h3>
                <p class="doc-description">Router transformations split data into multiple output groups based on conditions, converted to multiple filtered DataFrames.</p>
                <h4 class="doc-subtitle">Example Conversion</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Informatica Router: RTR_BY_STATUS with groups
# Group1: STATUS = 'ACTIVE'
# Group2: STATUS = 'PENDING'  
# Default: all others

df_active = df.filter(col("STATUS") == "ACTIVE")
df_pending = df.filter(col("STATUS") == "PENDING")
df_default = df.filter(~col("STATUS").isin(["ACTIVE", "PENDING"]))</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-update">
                <h3 class="doc-section-title"><i class="fas fa-edit"></i> Update Strategy Transformation</h3>
                <p class="doc-description">Update Strategy determines insert/update/delete behavior, converted to appropriate write modes or merge operations.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Update Strategy</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td><code>DD_INSERT</code></td><td><code>.mode("append")</code></td></tr>
                            <tr><td><code>DD_UPDATE</code></td><td>Delta MERGE or custom upsert</td></tr>
                            <tr><td><code>DD_DELETE</code></td><td>Delta DELETE or flag-based</td></tr>
                            <tr><td><code>DD_REJECT</code></td><td>Filter out rejected rows</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="guide-sequence">
                <h3 class="doc-section-title"><i class="fas fa-hashtag"></i> Sequence Generator</h3>
                <p class="doc-description">Sequence Generator creates unique IDs, converted to monotonically_increasing_id() or row_number().</p>
                <h4 class="doc-subtitle">Example Conversion</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Informatica Sequence: SEQ_CUSTOMER_KEY
from pyspark.sql.window import Window

df = df.withColumn("CUSTOMER_KEY", 
    monotonically_increasing_id() + lit(start_value)
)

# Or with row_number for deterministic sequence
window = Window.orderBy("CUSTOMER_ID")
df = df.withColumn("CUSTOMER_KEY", row_number().over(window))</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-workflow">
                <h3 class="doc-section-title"><i class="fas fa-stream"></i> Workflow Orchestration</h3>
                <p class="doc-description">Informatica Workflows are converted to orchestration configurations for Airflow, Databricks Workflows, or similar tools.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Component</th><th>Orchestration Equivalent</th></tr></thead>
                        <tbody>
                            <tr><td>Workflow</td><td>DAG / Job Cluster</td></tr>
                            <tr><td>Session</td><td>Task / Job</td></tr>
                            <tr><td>Scheduler</td><td>Cron trigger / Schedule</td></tr>
                            <tr><td>Decision Task</td><td>Branch operator / Condition</td></tr>
                            <tr><td>Email Task</td><td>Notification task</td></tr>
                            <tr><td>Worklet</td><td>Sub-DAG / Task Group</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }
    
    getXmlDocsContent() {
        return `
            <div class="doc-section" id="doc-overview">
                <h3 class="doc-section-title"><i class="fas fa-info-circle"></i> Overview</h3>
                <p class="doc-intro">This reference documents how each Informatica Workflow XML element is used and its importance during the process of parsing and converting into PySpark code.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead>
                            <tr><th>Element (Tag)</th><th>XML Path</th><th>Use / Purpose</th></tr>
                        </thead>
                        <tbody>
                            <tr><td><code>REPOSITORY</code></td><td>//REPOSITORY</td><td>Root of the XML structure; contains metadata about the repository itself.</td></tr>
                            <tr><td><code>FOLDER</code></td><td>//FOLDER</td><td>Contains all mappings, sources, targets, transformations. Acts like a project workspace.</td></tr>
                            <tr><td><code>SOURCE</code></td><td>//SOURCE</td><td>Defines the structure of the source table/file. Required for reading data in PySpark.</td></tr>
                            <tr><td><code>SOURCEFIELD</code></td><td>//SOURCE/SOURCEFIELD</td><td>Provides schema/column details of the source. Used to define Spark DataFrame schema.</td></tr>
                            <tr><td><code>TARGET</code></td><td>//TARGET</td><td>Defines the destination structure for writing data. Important for JDBC writes.</td></tr>
                            <tr><td><code>TARGETFIELD</code></td><td>//TARGET/TARGETFIELD</td><td>Field-level metadata for the target table. Used to match and validate output schema.</td></tr>
                            <tr><td><code>TRANSFORMATION</code></td><td>//TRANSFORMATION</td><td>Main logic units like Expression, Lookup, Filter, etc. These drive the PySpark logic generation.</td></tr>
                            <tr><td><code>TRANSFORMFIELD</code></td><td>//TRANSFORMFIELD</td><td>Defines columns and logic inside each transformation (e.g., derived fields, expressions).</td></tr>
                            <tr><td><code>INSTANCE</code></td><td>//INSTANCE</td><td>Represents instantiations of transformations, sources, or targets in a mapping.</td></tr>
                            <tr><td><code>CONNECTOR</code></td><td>//CONNECTOR</td><td>Links the fields from one instance to another (data lineage). Guides PySpark chaining/join logic.</td></tr>
                            <tr><td><code>MAPPING</code></td><td>//MAPPING</td><td>Container that holds one complete ETL logic from source to target. This is converted to PySpark.</td></tr>
                            <tr><td><code>WORKFLOW</code></td><td>//WORKFLOW</td><td>Defines the orchestration (control flow) of mappings and sessions. Useful for DAG sequencing.</td></tr>
                            <tr><td><code>SESSION</code></td><td>//SESSION</td><td>Execution context for a mapping. Contains parameter values and runtime configuration.</td></tr>
                            <tr><td><code>TABLEATTRIBUTE</code></td><td>//TABLEATTRIBUTE</td><td>Contains custom SQL overrides, Pre/Post SQL commands, partitioning details.</td></tr>
                            <tr><td><code>METADATAEXTENSION</code></td><td>//METADATAEXTENSION</td><td>Extra properties, annotations or lineage info. Useful for custom logic injection.</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-hierarchy">
                <h3 class="doc-section-title"><i class="fas fa-sitemap"></i> XML Hierarchy Structure</h3>
                <div class="doc-hierarchy-tree">
<pre class="hierarchy-code">&lt;REPOSITORY&gt;
  ├── &lt;FOLDER&gt;
  │     ├── &lt;SOURCE&gt;
  │     │     └── &lt;SOURCEFIELD /&gt;
  │     ├── &lt;TARGET&gt;
  │     │     └── &lt;TARGETFIELD /&gt;
  │     ├── &lt;TRANSFORMATION&gt;
  │     │     ├── &lt;TRANSFORMFIELD /&gt;
  │     │     └── &lt;TABLEATTRIBUTE /&gt;
  │     ├── &lt;INSTANCE /&gt;
  │     ├── &lt;CONNECTOR /&gt;
  │     ├── &lt;MAPPING /&gt;
  │     ├── &lt;SESSION /&gt;
  │     ├── &lt;WORKFLOW /&gt;
  │     └── &lt;METADATAEXTENSION /&gt;
  └── &lt;/FOLDER&gt;
&lt;/REPOSITORY&gt;</pre>
                </div>
            </div>
            
            <div class="doc-section" id="doc-repository">
                <h3 class="doc-section-title"><i class="fas fa-database"></i> &lt;REPOSITORY&gt; Tag</h3>
                <p class="doc-description">Root of the XML structure; contains metadata about the repository itself.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"Domain_repo"</td><td>Name of the Informatica repository</td></tr>
                            <tr><td><code>VERSION</code></td><td>"181"</td><td>Version of the repository for compatibility</td></tr>
                            <tr><td><code>CODEPAGE</code></td><td>"UTF-8"</td><td>Character encoding used</td></tr>
                            <tr><td><code>DATABASETYPE</code></td><td>"Oracle"</td><td>Type of database being used</td></tr>
                            <tr><td><code>OWNER</code></td><td>"Administrator"</td><td>Owner of the repository</td></tr>
                            <tr><td><code>SHARED</code></td><td>"YES" / "NO"</td><td>Whether repository is shared between projects</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-folder">
                <h3 class="doc-section-title"><i class="fas fa-folder"></i> &lt;FOLDER&gt; Tag</h3>
                <p class="doc-description">Contains all mappings, sources, targets, transformations. Acts like a project workspace.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"Sales"</td><td>Name of the folder/project</td></tr>
                            <tr><td><code>GROUP</code></td><td>"Development"</td><td>Logical grouping or team associated</td></tr>
                            <tr><td><code>OWNER</code></td><td>"Administrator"</td><td>Person or user account that owns the folder</td></tr>
                            <tr><td><code>SHARED</code></td><td>"YES" / "NO"</td><td>Whether shared across multiple users</td></tr>
                            <tr><td><code>DESCRIPTION</code></td><td>"ETL jobs for Sales"</td><td>Optional documentation</td></tr>
                            <tr><td><code>VERSIONNUMBER</code></td><td>"1"</td><td>Internal version tracking</td></tr>
                            <tr><td><code>ISVALID</code></td><td>"YES"</td><td>Folder structure validity</td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Child Elements</h4>
                <div class="doc-child-elements">
                    <span class="doc-child mandatory">SOURCE</span>
                    <span class="doc-child mandatory">TARGET</span>
                    <span class="doc-child mandatory">TRANSFORMATION</span>
                    <span class="doc-child mandatory">MAPPING</span>
                    <span class="doc-child optional">SESSION</span>
                    <span class="doc-child optional">WORKFLOW</span>
                    <span class="doc-child optional">TABLEATTRIBUTE</span>
                </div>
            </div>
            
            <div class="doc-section" id="doc-source">
                <h3 class="doc-section-title"><i class="fas fa-table"></i> &lt;SOURCE&gt; Tag</h3>
                <p class="doc-description">Defines the structure of the source table/file, including DB type and owner. Required for reading data in PySpark.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"SRC_CUSTOMER"</td><td>Logical name of the source in the mapping</td></tr>
                            <tr><td><code>DATABASETYPE</code></td><td>"Oracle", "FlatFile"</td><td>Type of database or source system. Important for JDBC configs</td></tr>
                            <tr><td><code>DBDNAME</code></td><td>"ORCL_DB_DEFN"</td><td>Database definition name used by Informatica</td></tr>
                            <tr><td><code>OBJECTTYPE</code></td><td>"TABLE", "VIEW"</td><td>Type of source object</td></tr>
                            <tr><td><code>OWNERNAME</code></td><td>"dbo", "admin"</td><td>Schema or owner of the source object</td></tr>
                            <tr><td><code>BUSINESSNAME</code></td><td>"Customer Table"</td><td>Optional business-friendly name</td></tr>
                            <tr><td><code>DESCRIPTION</code></td><td>"Source customer table"</td><td>Human-readable description</td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Child Element: &lt;SOURCEFIELD&gt;</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"CUSTOMER_ID"</td><td>Name of the source field (column)</td></tr>
                            <tr><td><code>DATATYPE</code></td><td>"decimal", "string"</td><td>Data type of the field. Maps to Spark SQL types</td></tr>
                            <tr><td><code>PRECISION</code></td><td>"10"</td><td>Total number of digits (for numeric types)</td></tr>
                            <tr><td><code>SCALE</code></td><td>"0"</td><td>Number of digits after decimal point</td></tr>
                            <tr><td><code>NULLABLE</code></td><td>"NULL", "NOTNULL"</td><td>Whether field can have NULL values</td></tr>
                            <tr><td><code>KEYTYPE</code></td><td>"PRIMARY", "NOT A KEY"</td><td>Primary key indicator</td></tr>
                            <tr><td><code>FIELDNUMBER</code></td><td>"1", "2"</td><td>Position of field in source definition</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-target">
                <h3 class="doc-section-title"><i class="fas fa-bullseye"></i> &lt;TARGET&gt; Tag</h3>
                <p class="doc-description">Defines the destination structure for writing data. Important for JDBC writes in PySpark.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"TGT_CUSTOMER"</td><td>Logical name of the target table or file</td></tr>
                            <tr><td><code>DATABASETYPE</code></td><td>"Oracle", "SQL Server"</td><td>Type of target system. Important for JDBC driver</td></tr>
                            <tr><td><code>DBDNAME</code></td><td>"ORCL_DB_DEFN"</td><td>Database definition name</td></tr>
                            <tr><td><code>OBJECTTYPE</code></td><td>"TABLE", "FILE"</td><td>Type of target object</td></tr>
                            <tr><td><code>OWNERNAME</code></td><td>"dbo"</td><td>Schema/owner of the target</td></tr>
                            <tr><td><code>TABLEOPTIONS</code></td><td>"TRUNCATE"</td><td>How table should be handled before loading</td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Child Element: &lt;TARGETFIELD&gt;</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"CUSTOMER_ID"</td><td>Name of the target column</td></tr>
                            <tr><td><code>DATATYPE</code></td><td>"decimal", "string"</td><td>Data type. Maps to Spark SQL types</td></tr>
                            <tr><td><code>PRECISION</code></td><td>"10"</td><td>Total digits for numeric values</td></tr>
                            <tr><td><code>SCALE</code></td><td>"0"</td><td>Decimal digits</td></tr>
                            <tr><td><code>KEYTYPE</code></td><td>"PRIMARY"</td><td>Primary key indicator</td></tr>
                            <tr><td><code>NULLABLE</code></td><td>"NULL"</td><td>Whether null values allowed</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-transformation">
                <h3 class="doc-section-title"><i class="fas fa-cogs"></i> &lt;TRANSFORMATION&gt; Tag</h3>
                <p class="doc-description">Main logic units like Expression, Lookup, Filter, etc. These drive the PySpark logic generation.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"EXP_CUST_FULLNAME"</td><td>Logical name of the transformation</td></tr>
                            <tr><td><code>TYPE</code></td><td>"Expression", "Lookup", "Filter"</td><td>Type of transformation logic. Essential for PySpark mapping</td></tr>
                            <tr><td><code>REUSABLE</code></td><td>"YES" / "NO"</td><td>Whether transformation is reusable across mappings</td></tr>
                            <tr><td><code>DESCRIPTION</code></td><td>"Concatenates first and last name"</td><td>Optional description</td></tr>
                            <tr><td><code>TRANSFORMATION_SCOPE</code></td><td>"ROW", "ALLINPUT"</td><td>Scope: per row or across all input</td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Child Element: &lt;TRANSFORMFIELD&gt;</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"FULLNAME"</td><td>Name of the port (field)</td></tr>
                            <tr><td><code>DATATYPE</code></td><td>"string", "decimal"</td><td>Data type of the port</td></tr>
                            <tr><td><code>PORTTYPE</code></td><td>"INPUT", "OUTPUT", "VARIABLE"</td><td>Port direction</td></tr>
                            <tr><td><code>EXPRESSION</code></td><td>"FNAME || ' ' || LNAME"</td><td>Transformation expression logic</td></tr>
                            <tr><td><code>PRECISION</code></td><td>"100"</td><td>Max length or digits</td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Transformation Types</h4>
                <div class="doc-transform-types">
                    <span class="transform-type expression">Expression</span>
                    <span class="transform-type filter">Filter</span>
                    <span class="transform-type lookup">Lookup</span>
                    <span class="transform-type joiner">Joiner</span>
                    <span class="transform-type aggregator">Aggregator</span>
                    <span class="transform-type router">Router</span>
                    <span class="transform-type sorter">Sorter</span>
                    <span class="transform-type update">Update Strategy</span>
                    <span class="transform-type sequence">Sequence Generator</span>
                    <span class="transform-type normalizer">Normalizer</span>
                    <span class="transform-type sq">Source Qualifier</span>
                </div>
            </div>
            
            <div class="doc-section" id="doc-mapping">
                <h3 class="doc-section-title"><i class="fas fa-project-diagram"></i> &lt;MAPPING&gt; Tag</h3>
                <p class="doc-description">Container that holds one complete ETL logic from source to target. This is what will be converted to PySpark.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"m_customer_load"</td><td>Name of the mapping</td></tr>
                            <tr><td><code>DESCRIPTION</code></td><td>"Load customer data"</td><td>Mapping description</td></tr>
                            <tr><td><code>ISVALID</code></td><td>"YES"</td><td>Validation status</td></tr>
                            <tr><td><code>VERSIONNUMBER</code></td><td>"1"</td><td>Version number</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-workflow">
                <h3 class="doc-section-title"><i class="fas fa-stream"></i> &lt;WORKFLOW&gt; Tag</h3>
                <p class="doc-description">Defines the orchestration (control flow) of mappings and sessions. Useful for DAG sequencing.</p>
                <h4 class="doc-subtitle">PySpark Equivalent: Databricks Workflow / Airflow DAG</h4>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"wf_daily_load"</td><td>Workflow name</td></tr>
                            <tr><td><code>DESCRIPTION</code></td><td>"Daily ETL workflow"</td><td>Description</td></tr>
                            <tr><td><code>SCHEDULERNAME</code></td><td>"Scheduler"</td><td>Associated scheduler</td></tr>
                            <tr><td><code>SUSPEND_ON_ERROR</code></td><td>"YES"</td><td>Error handling behavior</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-session">
                <h3 class="doc-section-title"><i class="fas fa-play-circle"></i> &lt;SESSION&gt; Tag</h3>
                <p class="doc-description">Execution context for a mapping. Contains parameter values and runtime configuration. May provide Pre/Post SQL.</p>
                <h4 class="doc-subtitle">PySpark Equivalent: PySpark Script/Notebook Task</h4>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"s_customer_load"</td><td>Session name</td></tr>
                            <tr><td><code>MAPPINGNAME</code></td><td>"m_customer_load"</td><td>Associated mapping</td></tr>
                            <tr><td><code>ISVALID</code></td><td>"YES"</td><td>Validation status</td></tr>
                            <tr><td><code>REUSABLE</code></td><td>"NO"</td><td>Whether session is reusable</td></tr>
                            <tr><td><code>SORTORDER</code></td><td>"Binary"</td><td>Sort order for session data</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-instance">
                <h3 class="doc-section-title"><i class="fas fa-cube"></i> &lt;INSTANCE&gt; Tag</h3>
                <p class="doc-description">Represents instantiations of transformations, sources, or targets in a mapping. Helps trace data flow.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"SRC_CUSTOMER_inst"</td><td>Instance name</td></tr>
                            <tr><td><code>TYPE</code></td><td>"SOURCE", "TARGET", "TRANSFORMATION"</td><td>Type of instance</td></tr>
                            <tr><td><code>TRANSFORMATION_NAME</code></td><td>"EXP_CALC"</td><td>Reference to transformation</td></tr>
                            <tr><td><code>TRANSFORMATION_TYPE</code></td><td>"Expression"</td><td>Type of referenced transformation</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-connector">
                <h3 class="doc-section-title"><i class="fas fa-link"></i> &lt;CONNECTOR&gt; Tag</h3>
                <p class="doc-description">Links the fields from one instance to another (data lineage). Guides PySpark chaining/join logic.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>FROMINSTANCE</code></td><td>"SQ_CUSTOMER"</td><td>Source instance name</td></tr>
                            <tr><td><code>FROMINSTANCETYPE</code></td><td>"Source Qualifier"</td><td>Source instance type</td></tr>
                            <tr><td><code>FROMFIELD</code></td><td>"CUSTOMER_ID"</td><td>Source field name</td></tr>
                            <tr><td><code>TOINSTANCE</code></td><td>"EXP_TRANSFORM"</td><td>Target instance name</td></tr>
                            <tr><td><code>TOINSTANCETYPE</code></td><td>"Expression"</td><td>Target instance type</td></tr>
                            <tr><td><code>TOFIELD</code></td><td>"IN_CUSTOMER_ID"</td><td>Target field name</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-tableattribute">
                <h3 class="doc-section-title"><i class="fas fa-sliders-h"></i> &lt;TABLEATTRIBUTE&gt; Tag</h3>
                <p class="doc-description">Contains custom SQL overrides, Pre/Post SQL commands, partitioning details. Important for JDBC query overrides.</p>
                <h4 class="doc-subtitle">Common NAME Values</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>NAME</th><th>Context</th><th>Purpose</th></tr></thead>
                        <tbody>
                            <tr><td><code>Sql Query</code></td><td>&lt;SOURCE&gt;</td><td>SQL override to replace default query</td></tr>
                            <tr><td><code>Pre SQL</code></td><td>&lt;TARGET&gt; / &lt;SESSION&gt;</td><td>Statements to execute before data load</td></tr>
                            <tr><td><code>Post SQL</code></td><td>&lt;TARGET&gt; / &lt;SESSION&gt;</td><td>Statements to execute after data load</td></tr>
                            <tr><td><code>Truncate Target Table</code></td><td>&lt;TARGET&gt;</td><td>Whether to truncate target before inserting</td></tr>
                            <tr><td><code>Update Strategy Expression</code></td><td>&lt;TRANSFORMATION&gt;</td><td>Insert/Update/Delete logic</td></tr>
                            <tr><td><code>Sorted Input</code></td><td>&lt;LOOKUP&gt; / &lt;AGGREGATOR&gt;</td><td>Performance optimization flag</td></tr>
                            <tr><td><code>Lookup condition</code></td><td>&lt;LOOKUP&gt;</td><td>Join condition for lookup transformation</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }
    
    getShortType(typeStr) {
        const typeMap = {
            'Source Qualifier': 'SQ',
            'Expression': 'EXP',
            'Filter': 'FIL',
            'Lookup Procedure': 'LKP',
            'Stored Procedure': 'SP',
            'Update Strategy': 'UPD',
            'Aggregator': 'AGG',
            'Joiner': 'JNR',
            'Router': 'RTR',
            'Sorter': 'SRT',
            'Union': 'UN',
            'Sequence Generator': 'SEQ',
            'Normalizer': 'NRM',
            'Source Definition': 'SRC',
            'Target Definition': 'TGT',
            'SOURCE': 'SRC',
            'TARGET': 'TGT'
        };
        return typeMap[typeStr] || (typeStr ? typeStr.substring(0, 3).toUpperCase() : '?');
    }
    
    getNodeColorClass(typeStr) {
        const colorMap = {
            'Source Qualifier': 'node-source',
            'Source Definition': 'node-source',
            'SOURCE': 'node-source',
            'Target Definition': 'node-target',
            'TARGET': 'node-target',
            'Expression': 'node-transform',
            'Filter': 'node-filter',
            'Lookup Procedure': 'node-lookup',
            'Stored Procedure': 'node-sp',
            'Joiner': 'node-joiner',
            'Aggregator': 'node-aggregator',
            'Sorter': 'node-sorter',
            'Router': 'node-router',
            'Update Strategy': 'node-update',
            'Union': 'node-union',
            'Sequence Generator': 'node-sequence',
            'Normalizer': 'node-normalizer'
        };
        return colorMap[typeStr] || 'node-default';
    }
    
    getNodeIcon(typeStr) {
        const iconMap = {
            'Source Qualifier': '<i class="fas fa-database"></i>',
            'Source Definition': '<i class="fas fa-folder-open"></i>',
            'SOURCE': '<i class="fas fa-folder-open"></i>',
            'Target Definition': '<i class="fas fa-bullseye"></i>',
            'TARGET': '<i class="fas fa-bullseye"></i>',
            'Expression': '<i class="fas fa-function"></i>',
            'Filter': '<i class="fas fa-filter"></i>',
            'Lookup Procedure': '<i class="fas fa-search"></i>',
            'Stored Procedure': '<i class="fas fa-terminal"></i>',
            'Joiner': '<i class="fas fa-code-branch"></i>',
            'Aggregator': '<i class="fas fa-layer-group"></i>',
            'Sorter': '<i class="fas fa-sort-amount-down"></i>',
            'Router': '<i class="fas fa-random"></i>',
            'Update Strategy': '<i class="fas fa-check-double"></i>',
            'Union': '<i class="fas fa-compress-arrows-alt"></i>',
            'Sequence Generator': '<i class="fas fa-hashtag"></i>',
            'Normalizer': '<i class="fas fa-arrows-alt-v"></i>'
        };
        return iconMap[typeStr] || '<i class="fas fa-cog"></i>';
    }
    
    getTaskIcon(typeStr) {
        const iconMap = {
            'Session': '<i class="fas fa-play"></i>',
            'Command': '<i class="fas fa-terminal"></i>',
            'Email': '<i class="fas fa-envelope"></i>',
            'Decision': '<i class="fas fa-question-circle"></i>',
            'Assignment': '<i class="fas fa-equals"></i>',
            'Timer': '<i class="fas fa-clock"></i>',
            'Event Wait': '<i class="fas fa-hourglass-half"></i>',
            'Event Raise': '<i class="fas fa-bolt"></i>'
        };
        return iconMap[typeStr] || '<i class="fas fa-tasks"></i>';
    }
    
    displayWorkflowAnalysis(workflowAnalysis) {
        if (!workflowAnalysis) return;
        
        // Display orchestration mapping table
        const orchestrationBody = document.getElementById('orchestrationTableBody');
        if (workflowAnalysis.orchestration_mapping && workflowAnalysis.orchestration_mapping.length > 0) {
            orchestrationBody.innerHTML = workflowAnalysis.orchestration_mapping.map(item => `
                <tr>
                    <td><strong>${item.element}</strong></td>
                    <td><span class="count-badge">${item.count}</span></td>
                    <td><span class="pyspark-equivalent">${item.pyspark_equivalent}</span></td>
                    <td class="notes-cell">${item.notes}</td>
                </tr>
            `).join('');
        } else {
            orchestrationBody.innerHTML = '<tr><td colspan="4" class="text-center">No orchestration elements found</td></tr>';
        }
        
        // Display workflows
        const workflowsList = document.getElementById('workflowsList');
        if (workflowAnalysis.workflows && workflowAnalysis.workflows.length > 0) {
            workflowsList.innerHTML = workflowAnalysis.workflows.map(wf => `
                <div class="workflow-card">
                    <div class="workflow-card-header">
                        <span class="workflow-name">${wf.name}</span>
                        <div class="workflow-badges">
                            <span class="status-badge ${wf.is_valid ? 'valid' : 'invalid'}">
                                ${wf.is_valid ? 'Valid' : 'Invalid'}
                            </span>
                            ${wf.is_restartable ? '<span class="status-badge restartable">Restartable</span>' : ''}
                        </div>
                    </div>
                    <div class="workflow-card-body">
                        <div class="pyspark-mapping">
                            <i class="fas fa-arrow-right"></i>
                            <span class="pyspark-equivalent">${wf.pyspark_equivalent}</span>
                        </div>
                        <p class="workflow-note">Map to job definition with retry policies and scheduling</p>
                    </div>
                </div>
            `).join('');
        } else {
            workflowsList.innerHTML = '<p class="empty-message">No workflows found</p>';
        }
        
        // Display tasks
        const tasksBody = document.getElementById('tasksTableBody');
        if (workflowAnalysis.tasks && workflowAnalysis.tasks.length > 0) {
            tasksBody.innerHTML = workflowAnalysis.tasks.map(task => `
                <tr>
                    <td><strong>${task.name}</strong></td>
                    <td><span class="type-badge task">${task.type}</span></td>
                    <td><span class="pyspark-equivalent">${task.pyspark_equivalent}</span></td>
                    <td class="notes-cell">${task.description || 'Custom implementation required'}</td>
                </tr>
            `).join('');
        } else {
            tasksBody.innerHTML = '<tr><td colspan="4" class="text-center">No tasks found</td></tr>';
        }
        
        // Display task dependencies
        const dependenciesList = document.getElementById('dependenciesList');
        if (workflowAnalysis.task_dependencies && workflowAnalysis.task_dependencies.length > 0) {
            dependenciesList.innerHTML = workflowAnalysis.task_dependencies.map(dep => `
                <div class="dependency-item">
                    <span class="task-name from">${dep.from_task}</span>
                    <i class="fas fa-arrow-right"></i>
                    <span class="task-name to">${dep.to_task}</span>
                    <div class="pyspark-equivalent-inline">
                        PySpark: <code>${dep.from_task} >> ${dep.to_task}</code>
                    </div>
                </div>
            `).join('');
        } else {
            dependenciesList.innerHTML = '<p class="empty-message">No task dependencies found</p>';
        }
        
        // Display schedulers
        const schedulersList = document.getElementById('schedulersList');
        if (workflowAnalysis.schedulers && workflowAnalysis.schedulers.length > 0) {
            schedulersList.innerHTML = workflowAnalysis.schedulers.map(sched => `
                <div class="scheduler-card">
                    <div class="scheduler-header">${sched.name}</div>
                    <div class="scheduler-details">
                        <span>Type: ${sched.type || 'N/A'}</span>
                        <span>Start: ${sched.start_time || 'N/A'}</span>
                        <span>Interval: ${sched.interval || 'N/A'}</span>
                    </div>
                    <div class="pyspark-mapping">
                        <i class="fas fa-arrow-right"></i>
                        <span class="pyspark-equivalent">${sched.pyspark_equivalent}</span>
                    </div>
                </div>
            `).join('');
        } else {
            schedulersList.innerHTML = '<p class="empty-message">No schedulers found</p>';
        }
        
        // Display workflow variables
        const variablesBody = document.getElementById('variablesTableBody');
        if (workflowAnalysis.workflow_variables && workflowAnalysis.workflow_variables.length > 0) {
            variablesBody.innerHTML = workflowAnalysis.workflow_variables.map(variable => `
                <tr>
                    <td><code>${variable.name}</code></td>
                    <td>${variable.datatype}</td>
                    <td>${variable.default_value}</td>
                    <td><span class="pyspark-equivalent">${variable.pyspark_equivalent}</span></td>
                </tr>
            `).join('');
        } else {
            variablesBody.innerHTML = '<tr><td colspan="4" class="text-center">No workflow variables found</td></tr>';
        }
    }
    
    prepareConfigForm(mapping) {
        if (!this.configTabsInitialized) {
            this.initConfigTabs();
            this.configTabsInitialized = true;
        }
        this.resetConfigTabs();
        this.renderMappingsConfig();
        this.updateConfigSummary(mapping);
    }
    
    initConfigTabs() {
        document.querySelectorAll('.config-tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const tabName = btn.dataset.configTab;
                
                document.querySelectorAll('.config-tab-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                document.querySelectorAll('.config-tab-content').forEach(content => {
                    content.classList.remove('active');
                });
                
                const tabId = `config${tabName.charAt(0).toUpperCase() + tabName.slice(1)}Tab`;
                const tabContent = document.getElementById(tabId);
                if (tabContent) tabContent.classList.add('active');
            });
        });
        
        const addConnBtn = document.getElementById('addGlobalConnectionBtn');
        if (addConnBtn) {
            addConnBtn.addEventListener('click', () => this.showAddGlobalConnectionForm());
        }
    }
    
    resetConfigTabs() {
        document.querySelectorAll('.config-tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.config-tab-content').forEach(c => c.classList.remove('active'));
        
        const mappingsTab = document.querySelector('[data-config-tab="mappings"]');
        const mappingsContent = document.getElementById('configMappingsTab');
        if (mappingsTab) mappingsTab.classList.add('active');
        if (mappingsContent) mappingsContent.classList.add('active');
    }
    
    renderGlobalConnections() {
        const container = document.getElementById('globalConnectionsList');
        if (!container) return;
        
        const connections = this.getConnections();
        
        if (connections.length === 0) {
            container.innerHTML = '<p class="empty-message">No global connections defined yet. Add a connection to get started.</p>';
            return;
        }
        
        container.innerHTML = connections.map((conn, index) => `
            <div class="global-connection-card" data-connection-id="${conn.id}" data-testid="global-conn-${index}">
                <div class="connection-card-header">
                    <div class="connection-icon">
                        <i class="fas fa-database"></i>
                    </div>
                    <div class="connection-info">
                        <div class="connection-name">${this.escapeHtml(conn.name)}</div>
                        <div class="connection-meta">
                            <span class="connection-type-badge">${this.escapeHtml(conn.dbType || 'Database')}</span>
                            ${conn.host ? `<span class="connection-host">${this.escapeHtml(conn.host)}</span>` : ''}
                        </div>
                    </div>
                    <div class="connection-actions">
                        <button type="button" class="btn btn-icon btn-ghost edit-connection-btn" data-conn-id="${conn.id}" data-testid="edit-conn-${index}">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button type="button" class="btn btn-icon btn-ghost delete-connection-btn" data-conn-id="${conn.id}" data-testid="delete-conn-${index}">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
        
        this.bindGlobalConnectionEvents();
    }
    
    bindGlobalConnectionEvents() {
        document.querySelectorAll('.delete-connection-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const connId = e.currentTarget.dataset.connId;
                this.deleteGlobalConnection(connId);
            });
        });
        
        document.querySelectorAll('.edit-connection-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const connId = e.currentTarget.dataset.connId;
                this.editGlobalConnection(connId);
            });
        });
    }
    
    saveNewGlobalConnection(modal) {
        const name = document.getElementById('newConnName').value.trim();
        const dbType = document.getElementById('newConnDbType').value;
        const jdbcUrl = document.getElementById('newConnJdbc').value.trim();
        const username = document.getElementById('newConnUser').value.trim();
        const password = document.getElementById('newConnPassword').value;
        const host = document.getElementById('newConnHost').value.trim();
        const port = document.getElementById('newConnPort').value.trim();
        
        if (!name || !jdbcUrl) {
            this.showNotification('Please fill in the required fields', 'error');
            return;
        }
        
        const connections = this.getConnections();
        const newConn = {
            id: 'conn_' + Date.now(),
            name,
            dbType,
            jdbcUrl,
            username,
            password,
            host,
            port
        };
        
        connections.push(newConn);
        this.saveConnections(connections);
        
        modal.remove();
        this.renderGlobalConnections();
        this.renderMappingsConfig();
        this.showNotification('Connection saved successfully', 'success');
    }
    
    deleteGlobalConnection(connId) {
        const connections = this.getConnections().filter(c => c.id !== connId);
        this.saveConnections(connections);
        this.renderGlobalConnections();
        this.renderMappingsConfig();
    }
    
    editGlobalConnection(connId) {
        const conn = this.getConnections().find(c => c.id === connId);
        if (!conn) return;
        
        this.showAddGlobalConnectionForm(connId);
    }
    
    showAddGlobalConnectionForm(editConnId = null) {
        const existingModal = document.getElementById('addConnectionModal');
        if (existingModal) existingModal.remove();
        
        const conn = editConnId ? this.getConnections().find(c => c.id === editConnId) : null;
        const isEdit = !!conn;
        
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'addConnectionModal';
        modal.innerHTML = `
            <div class="modal-content connection-modal">
                <div class="modal-header">
                    <h3><i class="fas fa-${isEdit ? 'edit' : 'plug'}"></i> ${isEdit ? 'Edit' : 'Add Global'} Connection</h3>
                    <button type="button" class="modal-close-btn" data-testid="close-modal">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="config-field-group">
                        <label class="config-field-label">Connection Name <span class="required">*</span></label>
                        <input type="text" class="config-input" id="newConnName" placeholder="e.g., Production Oracle DB" value="${conn?.name || ''}" data-testid="input-conn-name">
                    </div>
                    <div class="config-field-group">
                        <label class="config-field-label">Database Type <span class="required">*</span></label>
                        <select class="config-select" id="newConnDbType" data-testid="select-conn-type">
                            <option value="Oracle" ${conn?.dbType === 'Oracle' ? 'selected' : ''}>Oracle</option>
                            <option value="SQL Server" ${conn?.dbType === 'SQL Server' ? 'selected' : ''}>SQL Server</option>
                            <option value="PostgreSQL" ${conn?.dbType === 'PostgreSQL' ? 'selected' : ''}>PostgreSQL</option>
                            <option value="MySQL" ${conn?.dbType === 'MySQL' ? 'selected' : ''}>MySQL</option>
                            <option value="DB2" ${conn?.dbType === 'DB2' ? 'selected' : ''}>DB2</option>
                            <option value="Teradata" ${conn?.dbType === 'Teradata' ? 'selected' : ''}>Teradata</option>
                            <option value="Snowflake" ${conn?.dbType === 'Snowflake' ? 'selected' : ''}>Snowflake</option>
                            <option value="Other" ${conn?.dbType === 'Other' ? 'selected' : ''}>Other</option>
                        </select>
                    </div>
                    <div class="config-field-group">
                        <label class="config-field-label">JDBC URL <span class="required">*</span></label>
                        <input type="text" class="config-input" id="newConnJdbc" placeholder="jdbc:oracle:thin:@host:port:sid" value="${conn?.jdbcUrl || ''}" data-testid="input-conn-jdbc">
                    </div>
                    <div class="config-row">
                        <div class="config-field-group">
                            <label class="config-field-label">Username</label>
                            <input type="text" class="config-input" id="newConnUser" placeholder="Username" value="${conn?.username || ''}" data-testid="input-conn-user">
                        </div>
                        <div class="config-field-group">
                            <label class="config-field-label">Password</label>
                            <input type="password" class="config-input" id="newConnPassword" placeholder="Password" value="${conn?.password || ''}" data-testid="input-conn-password">
                        </div>
                    </div>
                    <div class="config-row">
                        <div class="config-field-group">
                            <label class="config-field-label">Host</label>
                            <input type="text" class="config-input" id="newConnHost" placeholder="hostname" value="${conn?.host || ''}" data-testid="input-conn-host">
                        </div>
                        <div class="config-field-group">
                            <label class="config-field-label">Port</label>
                            <input type="text" class="config-input" id="newConnPort" placeholder="1521" value="${conn?.port || ''}" data-testid="input-conn-port">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="cancelAddConn" data-testid="button-cancel-conn">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveNewConn" data-testid="button-save-conn">
                        <i class="fas fa-save"></i> ${isEdit ? 'Update' : 'Save'} Connection
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        const closeModal = () => modal.remove();
        modal.querySelector('.modal-close-btn').addEventListener('click', closeModal);
        modal.querySelector('#cancelAddConn').addEventListener('click', closeModal);
        modal.querySelector('#saveNewConn').addEventListener('click', () => {
            if (isEdit) {
                this.deleteGlobalConnection(editConnId);
            }
            this.saveNewGlobalConnection(modal);
        });
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
    }
    
    renderMappingsConfig() {
        const container = document.getElementById('mappingsConfigContainer');
        if (!container) return;
        
        const mappings = this.analysisData?.mappings || [];
        
        if (mappings.length === 0) {
            container.innerHTML = '<p class="empty-message">No mappings detected in this XML</p>';
            return;
        }
        
        container.innerHTML = mappings.map((mapping, mIndex) => {
            const sources = mapping.sources || [];
            const targets = mapping.targets || [];
            
            return `
                <div class="mapping-config-section" data-mapping-index="${mIndex}" data-mapping-name="${mapping.name}" data-testid="mapping-section-${mIndex}">
                    <div class="mapping-section-header" data-testid="mapping-header-${mIndex}">
                        <div class="mapping-header-info">
                            <i class="fas fa-project-diagram"></i>
                            <span class="mapping-name">${this.escapeHtml(mapping.name)}</span>
                            <span class="mapping-counts">
                                <span class="count-badge sources">${sources.length} sources</span>
                                <span class="count-badge targets">${targets.length} targets</span>
                            </span>
                        </div>
                        <div class="mapping-header-toggle">
                            <i class="fas fa-chevron-down"></i>
                        </div>
                    </div>
                    <div class="mapping-section-body">
                        <div class="mapping-sources-section">
                            <h4 class="subsection-title"><i class="fas fa-database"></i> Sources</h4>
                            <div class="mapping-sources-list" id="mappingSources-${mIndex}">
                                ${this.renderMappingSourceCards(sources, mIndex)}
                            </div>
                        </div>
                        <div class="mapping-targets-section">
                            <h4 class="subsection-title"><i class="fas fa-bullseye"></i> Targets</h4>
                            <div class="mapping-targets-list" id="mappingTargets-${mIndex}">
                                ${this.renderMappingTargetCards(targets, mIndex)}
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
        
        this.bindMappingConfigEvents();
    }
    
    renderMappingSourceCards(sources, mappingIndex) {
        if (!sources || sources.length === 0) {
            return '<p class="empty-message">No sources in this mapping</p>';
        }
        
        const globalConnections = this.getConnections();
        
        return sources.map((source, sIndex) => {
            const isFile = source.type !== 'SQL';
            const typeClass = isFile ? 'file-type' : 'sql-type';
            const typeIcon = isFile ? 'fa-file-alt' : 'fa-database';
            const format = source.format || source.db_type || 'Unknown';
            const uniqueId = `m${mappingIndex}_s${sIndex}`;
            
            return `
                <div class="source-config-card compact pending" data-mapping-index="${mappingIndex}" data-source-index="${sIndex}" data-source-name="${source.name}" data-testid="source-card-${uniqueId}">
                    <div class="source-card-header" data-testid="source-header-${uniqueId}">
                        <div class="source-type-icon ${typeClass}">
                            <i class="fas ${typeIcon}"></i>
                        </div>
                        <div class="source-card-info">
                            <div class="source-card-name">${this.escapeHtml(source.name)}</div>
                            <div class="source-card-meta">
                                <span class="source-type-badge ${isFile ? 'file' : 'sql'}">${isFile ? 'File' : 'SQL'}</span>
                                <span class="source-format-badge">${this.escapeHtml(format)}</span>
                            </div>
                        </div>
                        <span class="source-status-badge pending">
                            <i class="fas fa-exclamation-circle"></i> Pending
                        </span>
                        <div class="source-card-toggle">
                            <i class="fas fa-chevron-down"></i>
                        </div>
                    </div>
                    <div class="source-card-body">
                        ${isFile ? this.renderMappingFileSourceFields(source, uniqueId) : this.renderMappingSqlSourceFields(source, uniqueId, globalConnections)}
                    </div>
                </div>
            `;
        }).join('');
    }
    
    renderMappingFileSourceFields(source, uniqueId) {
        return `
            <div class="source-config-fields">
                <div class="config-field-group">
                    <label class="config-field-label">Location <span class="required">*</span></label>
                    <div class="config-radio-group">
                        <label class="config-radio-label">
                            <input type="radio" name="source-location-${uniqueId}" value="local" checked> Local/HDFS
                        </label>
                        <label class="config-radio-label">
                            <input type="radio" name="source-location-${uniqueId}" value="s3"> S3
                        </label>
                        <label class="config-radio-label">
                            <input type="radio" name="source-location-${uniqueId}" value="adls"> ADLS
                        </label>
                    </div>
                </div>
                <div class="config-field-group">
                    <label class="config-field-label">File Path <span class="required">*</span></label>
                    <input type="text" class="config-input source-path" data-source="${source.name}" 
                           placeholder="/path/to/file.csv or s3://bucket/path" data-testid="input-path-${uniqueId}">
                </div>
                <div class="config-row">
                    <div class="config-field-group">
                        <label class="config-field-label">Format</label>
                        <select class="config-select source-format" data-source="${source.name}" data-testid="select-format-${uniqueId}">
                            <option value="csv" ${source.format === 'csv' ? 'selected' : ''}>CSV</option>
                            <option value="parquet" ${source.format === 'parquet' ? 'selected' : ''}>Parquet</option>
                            <option value="json" ${source.format === 'json' ? 'selected' : ''}>JSON</option>
                            <option value="orc" ${source.format === 'orc' ? 'selected' : ''}>ORC</option>
                        </select>
                    </div>
                    <div class="config-field-group">
                        <label class="config-field-label">Delimiter</label>
                        <input type="text" class="config-input source-delimiter" value="${source.delimiter || ','}" data-testid="input-delimiter-${uniqueId}">
                    </div>
                </div>
            </div>
        `;
    }
    
    renderMappingSqlSourceFields(source, uniqueId, globalConnections) {
        const hasGlobalConnections = globalConnections.length > 0;
        const connectionOptions = globalConnections.map(conn => 
            `<option value="${conn.id}">${conn.name} (${conn.dbType})</option>`
        ).join('');
        
        return `
            <div class="source-config-fields">
                <div class="config-field-group">
                    <label class="config-field-label">Connection Level</label>
                    <div class="connection-level-toggle">
                        <label class="config-radio-label">
                            <input type="radio" name="conn-level-${uniqueId}" value="global" ${hasGlobalConnections ? 'checked' : ''} class="conn-level-radio" data-testid="radio-global-${uniqueId}">
                            Use Global Connection
                        </label>
                        <label class="config-radio-label">
                            <input type="radio" name="conn-level-${uniqueId}" value="mapping" ${!hasGlobalConnections ? 'checked' : ''} class="conn-level-radio" data-testid="radio-mapping-${uniqueId}">
                            Mapping-Specific
                        </label>
                    </div>
                </div>
                
                <div class="global-conn-section" id="globalConn-${uniqueId}" style="${hasGlobalConnections ? '' : 'display:none;'}">
                    <div class="config-field-group">
                        <label class="config-field-label">Select Connection <span class="required">*</span></label>
                        <select class="config-select source-connection-select" data-source="${source.name}" data-testid="select-conn-${uniqueId}">
                            <option value="">-- Select Connection --</option>
                            ${connectionOptions}
                        </select>
                    </div>
                </div>
                
                <div class="mapping-conn-section" id="mappingConn-${uniqueId}" style="${hasGlobalConnections ? 'display:none;' : ''}">
                    <div class="config-field-group">
                        <label class="config-field-label">JDBC URL <span class="required">*</span></label>
                        <input type="text" class="config-input source-jdbc-url" placeholder="jdbc:oracle:thin:@host:port:sid" data-testid="input-jdbc-${uniqueId}">
                    </div>
                    <div class="config-row">
                        <div class="config-field-group">
                            <label class="config-field-label">Username</label>
                            <input type="text" class="config-input source-username" placeholder="Username" data-testid="input-user-${uniqueId}">
                        </div>
                        <div class="config-field-group">
                            <label class="config-field-label">Password</label>
                            <input type="password" class="config-input source-password" placeholder="Password" data-testid="input-pass-${uniqueId}">
                        </div>
                    </div>
                </div>
                
                <div class="config-row">
                    <div class="config-field-group">
                        <label class="config-field-label">Schema</label>
                        <input type="text" class="config-input source-schema" value="${source.owner || ''}" placeholder="Schema" data-testid="input-schema-${uniqueId}">
                    </div>
                    <div class="config-field-group">
                        <label class="config-field-label">Table</label>
                        <input type="text" class="config-input source-table" value="${source.table_name || source.name}" placeholder="Table" data-testid="input-table-${uniqueId}">
                    </div>
                </div>
            </div>
        `;
    }
    
    renderMappingTargetCards(targets, mappingIndex) {
        if (!targets || targets.length === 0) {
            return '<p class="empty-message">No targets in this mapping</p>';
        }
        
        const globalConnections = this.getConnections();
        
        return targets.map((target, tIndex) => {
            const isSqlTarget = this.isTargetSqlType(target);
            const typeClass = isSqlTarget ? 'sql-type' : 'file-type';
            const typeIcon = isSqlTarget ? 'fa-database' : 'fa-file-export';
            const dbType = target.db_type || target.database_type || '';
            const uniqueId = `m${mappingIndex}_t${tIndex}`;
            
            return `
                <div class="target-config-card compact pending" data-mapping-index="${mappingIndex}" data-target-index="${tIndex}" data-target-name="${target.name}" data-target-type="${isSqlTarget ? 'sql' : 'file'}" data-testid="target-card-${uniqueId}">
                    <div class="target-card-header" data-testid="target-header-${uniqueId}">
                        <div class="target-type-icon ${typeClass}">
                            <i class="fas ${typeIcon}"></i>
                        </div>
                        <div class="target-card-info">
                            <div class="target-card-name">${this.escapeHtml(target.name)}</div>
                            <div class="target-card-meta">
                                <span class="target-type-badge ${isSqlTarget ? 'sql' : 'file'}">${isSqlTarget ? 'SQL' : 'File'}</span>
                                ${dbType ? `<span class="source-format-badge">${this.escapeHtml(dbType)}</span>` : ''}
                            </div>
                        </div>
                        <span class="target-status-badge pending">
                            <i class="fas fa-exclamation-circle"></i> Pending
                        </span>
                        <div class="target-card-toggle">
                            <i class="fas fa-chevron-down"></i>
                        </div>
                    </div>
                    <div class="target-card-body">
                        ${isSqlTarget ? this.renderMappingSqlTargetFields(target, uniqueId, globalConnections) : this.renderMappingFileTargetFields(target, uniqueId)}
                    </div>
                </div>
            `;
        }).join('');
    }
    
    renderMappingFileTargetFields(target, uniqueId) {
        return `
            <div class="target-config-fields">
                <div class="config-field-group">
                    <label class="config-field-label">Output Format</label>
                    <select class="config-select target-format" data-testid="select-format-${uniqueId}">
                        <option value="delta">Delta</option>
                        <option value="parquet">Parquet</option>
                        <option value="csv">CSV</option>
                    </select>
                </div>
                <div class="config-field-group">
                    <label class="config-field-label">Output Path <span class="required">*</span></label>
                    <input type="text" class="config-input target-path" placeholder="/output/path" data-testid="input-path-${uniqueId}">
                </div>
                <div class="config-row">
                    <div class="config-field-group">
                        <label class="config-field-label">Write Mode</label>
                        <select class="config-select target-mode" data-testid="select-mode-${uniqueId}">
                            <option value="overwrite">Overwrite</option>
                            <option value="append">Append</option>
                            <option value="merge">Merge</option>
                        </select>
                    </div>
                    <div class="config-field-group">
                        <label class="config-field-label">Partition By</label>
                        <input type="text" class="config-input target-partition" placeholder="col1, col2" data-testid="input-partition-${uniqueId}">
                    </div>
                </div>
            </div>
        `;
    }
    
    renderMappingSqlTargetFields(target, uniqueId, globalConnections) {
        const hasGlobalConnections = globalConnections.length > 0;
        const connectionOptions = globalConnections.map(conn => 
            `<option value="${conn.id}">${conn.name} (${conn.dbType})</option>`
        ).join('');
        
        return `
            <div class="target-config-fields">
                <div class="config-field-group">
                    <label class="config-field-label">Connection Level</label>
                    <div class="connection-level-toggle">
                        <label class="config-radio-label">
                            <input type="radio" name="target-conn-level-${uniqueId}" value="global" ${hasGlobalConnections ? 'checked' : ''} class="target-conn-level-radio" data-testid="radio-global-${uniqueId}">
                            Use Global Connection
                        </label>
                        <label class="config-radio-label">
                            <input type="radio" name="target-conn-level-${uniqueId}" value="mapping" ${!hasGlobalConnections ? 'checked' : ''} class="target-conn-level-radio" data-testid="radio-mapping-${uniqueId}">
                            Mapping-Specific
                        </label>
                    </div>
                </div>
                
                <div class="global-conn-section" id="targetGlobalConn-${uniqueId}" style="${hasGlobalConnections ? '' : 'display:none;'}">
                    <div class="config-field-group">
                        <label class="config-field-label">Select Connection <span class="required">*</span></label>
                        <select class="config-select target-connection-select" data-target="${target.name}" data-testid="select-conn-${uniqueId}">
                            <option value="">-- Select Connection --</option>
                            ${connectionOptions}
                        </select>
                    </div>
                </div>
                
                <div class="mapping-conn-section" id="targetMappingConn-${uniqueId}" style="${hasGlobalConnections ? 'display:none;' : ''}">
                    <div class="config-field-group">
                        <label class="config-field-label">JDBC URL <span class="required">*</span></label>
                        <input type="text" class="config-input target-jdbc-url" placeholder="jdbc:oracle:thin:@host:port:sid" data-testid="input-jdbc-${uniqueId}">
                    </div>
                    <div class="config-row">
                        <div class="config-field-group">
                            <label class="config-field-label">Username</label>
                            <input type="text" class="config-input target-username" placeholder="Username" data-testid="input-user-${uniqueId}">
                        </div>
                        <div class="config-field-group">
                            <label class="config-field-label">Password</label>
                            <input type="password" class="config-input target-password" placeholder="Password" data-testid="input-pass-${uniqueId}">
                        </div>
                    </div>
                </div>
                
                <div class="config-row">
                    <div class="config-field-group">
                        <label class="config-field-label">Schema</label>
                        <input type="text" class="config-input target-schema" value="${target.owner || ''}" placeholder="Schema" data-testid="input-schema-${uniqueId}">
                    </div>
                    <div class="config-field-group">
                        <label class="config-field-label">Table <span class="required">*</span></label>
                        <input type="text" class="config-input target-table" value="${target.table_name || target.name}" placeholder="Table" data-testid="input-table-${uniqueId}">
                    </div>
                </div>
                
                <div class="config-field-group">
                    <label class="config-field-label">Write Mode</label>
                    <select class="config-select target-mode" data-testid="select-mode-${uniqueId}">
                        <option value="overwrite">Overwrite</option>
                        <option value="append">Append</option>
                        <option value="merge">Merge</option>
                    </select>
                </div>
            </div>
        `;
    }
    
    bindMappingConfigEvents() {
        document.querySelectorAll('.mapping-section-header').forEach(header => {
            header.addEventListener('click', () => {
                const section = header.closest('.mapping-config-section');
                section.classList.toggle('collapsed');
            });
        });
        
        document.querySelectorAll('.source-card-header').forEach(header => {
            header.addEventListener('click', () => {
                const card = header.closest('.source-config-card');
                card.classList.toggle('expanded');
            });
        });
        
        document.querySelectorAll('.target-card-header').forEach(header => {
            header.addEventListener('click', () => {
                const card = header.closest('.target-config-card');
                card.classList.toggle('expanded');
            });
        });
        
        document.querySelectorAll('.conn-level-radio').forEach(radio => {
            radio.addEventListener('change', (e) => {
                const card = e.target.closest('.source-config-card');
                const uniqueId = card.dataset.mappingIndex + '_s' + card.dataset.sourceIndex;
                const globalSection = document.getElementById(`globalConn-m${uniqueId.replace('_s', '_s')}`);
                const mappingSection = document.getElementById(`mappingConn-m${uniqueId.replace('_s', '_s')}`);
                
                if (!globalSection || !mappingSection) return;
                
                if (e.target.value === 'global') {
                    globalSection.style.display = '';
                    mappingSection.style.display = 'none';
                } else {
                    globalSection.style.display = 'none';
                    mappingSection.style.display = '';
                }
                this.updateSourceCardStatus(card);
            });
        });
        
        document.querySelectorAll('.target-conn-level-radio').forEach(radio => {
            radio.addEventListener('change', (e) => {
                const card = e.target.closest('.target-config-card');
                const uniqueId = `m${card.dataset.mappingIndex}_t${card.dataset.targetIndex}`;
                const globalSection = document.getElementById(`targetGlobalConn-${uniqueId}`);
                const mappingSection = document.getElementById(`targetMappingConn-${uniqueId}`);
                
                if (!globalSection || !mappingSection) return;
                
                if (e.target.value === 'global') {
                    globalSection.style.display = '';
                    mappingSection.style.display = 'none';
                } else {
                    globalSection.style.display = 'none';
                    mappingSection.style.display = '';
                }
                this.updateTargetCardStatus(card);
            });
        });
        
        document.querySelectorAll('.source-config-card .config-input, .source-config-card .config-select').forEach(input => {
            input.addEventListener('change', (e) => {
                this.updateSourceCardStatus(e.target.closest('.source-config-card'));
            });
        });
        
        document.querySelectorAll('.target-config-card .config-input, .target-config-card .config-select').forEach(input => {
            input.addEventListener('change', (e) => {
                this.updateTargetCardStatus(e.target.closest('.target-config-card'));
            });
        });
    }
    
    updateConfigSummary(mapping) {
        // Configuration summary bar has been removed - no action needed
    }
    
    countConfiguredItems() {
        let count = 0;
        document.querySelectorAll('.source-config-card').forEach(card => {
            if (card.classList.contains('configured')) count++;
        });
        document.querySelectorAll('.target-config-card').forEach(card => {
            if (card.classList.contains('configured')) count++;
        });
        return count;
    }
    
    renderSourceCards(mapping) {
        const container = document.getElementById('sourceCardsContainer');
        if (!mapping.sources || mapping.sources.length === 0) {
            container.innerHTML = '<p class="empty-message">No sources detected in this mapping</p>';
            return;
        }
        
        container.innerHTML = mapping.sources.map((source, index) => {
            const isFile = source.type !== 'SQL';
            const typeClass = isFile ? 'file-type' : 'sql-type';
            const typeIcon = isFile ? 'fa-file-alt' : 'fa-database';
            const typeBadge = isFile ? 'file' : 'sql';
            const format = source.format || source.db_type || 'Unknown';
            
            return `
                <div class="source-config-card pending" data-source-index="${index}" data-source-name="${source.name}" data-testid="source-card-${index}">
                    <div class="source-card-header" data-testid="source-card-header-${index}">
                        <div class="source-type-icon ${typeClass}">
                            <i class="fas ${typeIcon}"></i>
                        </div>
                        <div class="source-card-info">
                            <div class="source-card-name">${this.escapeHtml(source.name)}</div>
                            <div class="source-card-meta">
                                <span class="source-type-badge ${typeBadge}">${isFile ? 'File' : 'SQL'}</span>
                                <span class="source-format-badge">${this.escapeHtml(format)}</span>
                            </div>
                        </div>
                        <span class="source-status-badge pending">
                            <i class="fas fa-exclamation-circle"></i> Pending
                        </span>
                        <div class="source-card-toggle">
                            <i class="fas fa-chevron-down"></i>
                        </div>
                    </div>
                    <div class="source-card-body">
                        ${isFile ? this.renderFileSourceFields(source, index) : this.renderSqlSourceFields(source, index)}
                    </div>
                </div>
            `;
        }).join('');
        
        this.bindSourceCardEvents();
    }
    
    renderFileSourceFields(source, index) {
        return `
            <div class="source-config-fields">
                <div class="config-field-group">
                    <label class="config-field-label">Location <span class="required">*</span></label>
                    <div class="config-radio-group">
                        <label class="config-radio-label">
                            <input type="radio" name="source-location-${index}" value="local" checked data-testid="radio-source-local-${index}">
                            Local/HDFS
                        </label>
                        <label class="config-radio-label">
                            <input type="radio" name="source-location-${index}" value="s3" data-testid="radio-source-s3-${index}">
                            S3
                        </label>
                        <label class="config-radio-label">
                            <input type="radio" name="source-location-${index}" value="adls" data-testid="radio-source-adls-${index}">
                            ADLS
                        </label>
                    </div>
                </div>
                
                <div class="config-field-group">
                    <label class="config-field-label">File Path <span class="required">*</span></label>
                    <input type="text" class="config-input source-path" data-source="${source.name}" 
                           placeholder="/path/to/file.csv or s3://bucket/path" data-testid="input-source-path-${index}">
                    <span class="config-input-hint">Enter the full path to the source file</span>
                </div>
                
                <div class="config-row">
                    <div class="config-field-group">
                        <label class="config-field-label">Format <span class="required">*</span></label>
                        <select class="config-select source-format" data-source="${source.name}" data-testid="select-source-format-${index}">
                            <option value="csv" ${source.format === 'csv' ? 'selected' : ''}>CSV</option>
                            <option value="parquet" ${source.format === 'parquet' ? 'selected' : ''}>Parquet</option>
                            <option value="dat" ${source.format === 'dat' ? 'selected' : ''}>DAT (Fixed Width)</option>
                            <option value="json" ${source.format === 'json' ? 'selected' : ''}>JSON</option>
                            <option value="orc" ${source.format === 'orc' ? 'selected' : ''}>ORC</option>
                        </select>
                    </div>
                    <div class="config-field-group">
                        <label class="config-field-label">Delimiter</label>
                        <input type="text" class="config-input source-delimiter" data-source="${source.name}" 
                               value="${source.delimiter || ','}" placeholder="," data-testid="input-source-delimiter-${index}">
                    </div>
                </div>
                
                <div class="config-optional-fields">
                    <div class="config-optional-title">Optional Settings</div>
                    <div class="config-row">
                        <div class="config-field-group">
                            <label class="config-field-label">Header Row</label>
                            <select class="config-select source-header" data-source="${source.name}" data-testid="select-source-header-${index}">
                                <option value="true">Yes (First Row is Header)</option>
                                <option value="false">No (No Header)</option>
                            </select>
                        </div>
                        <div class="config-field-group">
                            <label class="config-field-label">Encoding</label>
                            <select class="config-select source-encoding" data-source="${source.name}" data-testid="select-source-encoding-${index}">
                                <option value="UTF-8">UTF-8</option>
                                <option value="ISO-8859-1">ISO-8859-1</option>
                                <option value="Windows-1252">Windows-1252</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    renderSqlSourceFields(source, index) {
        const storedConnections = this.getConnections();
        const hasConnections = storedConnections.length > 0;
        const connectionOptions = storedConnections.map(conn => 
            `<option value="${conn.id}">${conn.name} (${conn.dbType})</option>`
        ).join('');
        
        const showDetailsImmediately = !hasConnections;
        
        return `
            <div class="source-config-fields">
                ${hasConnections ? `
                <div class="config-field-group">
                    <label class="config-field-label">Connection <span class="required">*</span></label>
                    <select class="config-select source-connection-select" data-source="${source.name}" data-testid="select-source-connection-${index}">
                        <option value="">-- Select Saved Connection --</option>
                        ${connectionOptions}
                        <option value="new">+ Enter Connection Details...</option>
                    </select>
                    <span class="config-input-hint">Select from saved connections or enter details manually</span>
                </div>
                ` : `
                <div class="config-field-group">
                    <span class="config-input-hint" style="margin-bottom: 8px; display: block;"><i class="fas fa-info-circle"></i> No saved connections found. Enter connection details below.</span>
                </div>
                `}
                
                <div class="sql-connection-details" id="sqlDetails-${index}" style="${showDetailsImmediately ? 'display: block;' : 'display: none;'}">
                    <div class="config-field-group">
                        <label class="config-field-label">JDBC URL <span class="required">*</span></label>
                        <input type="text" class="config-input source-jdbc-url" data-source="${source.name}" 
                               placeholder="jdbc:oracle:thin:@host:port:sid" data-testid="input-source-jdbc-${index}">
                    </div>
                    
                    <div class="config-row">
                        <div class="config-field-group">
                            <label class="config-field-label">Username</label>
                            <input type="text" class="config-input source-username" data-source="${source.name}" 
                                   placeholder="Database username" data-testid="input-source-username-${index}">
                        </div>
                        <div class="config-field-group">
                            <label class="config-field-label">Password</label>
                            <input type="password" class="config-input source-password" data-source="${source.name}" 
                                   placeholder="Database password" data-testid="input-source-password-${index}">
                        </div>
                    </div>
                    
                    <div class="config-row">
                        <div class="config-field-group">
                            <label class="config-field-label">Schema</label>
                            <input type="text" class="config-input source-schema" data-source="${source.name}" 
                                   value="${source.owner || ''}" placeholder="Schema name" data-testid="input-source-schema-${index}">
                        </div>
                        <div class="config-field-group">
                            <label class="config-field-label">Table</label>
                            <input type="text" class="config-input source-table" data-source="${source.name}" 
                                   value="${source.table_name || source.name}" placeholder="Table name" data-testid="input-source-table-${index}">
                        </div>
                    </div>
                </div>
                
                <div class="config-optional-fields">
                    <div class="config-optional-title">Query Options</div>
                    <div class="config-field-group">
                        <label class="config-field-label">Custom SQL Query (Optional)</label>
                        <textarea class="config-input source-custom-query" data-source="${source.name}" 
                                  placeholder="SELECT * FROM table WHERE ..." rows="3" data-testid="textarea-source-query-${index}"></textarea>
                        <span class="config-input-hint">Override the default table read with a custom query</span>
                    </div>
                </div>
            </div>
        `;
    }
    
    renderTargetCards(mapping) {
        const container = document.getElementById('targetCardsContainer');
        if (!mapping.targets || mapping.targets.length === 0) {
            container.innerHTML = '<p class="empty-message">No targets detected in this mapping</p>';
            return;
        }
        
        container.innerHTML = mapping.targets.map((target, index) => {
            const isSqlTarget = this.isTargetSqlType(target);
            const typeClass = isSqlTarget ? 'sql-type' : 'file-type';
            const typeIcon = isSqlTarget ? 'fa-database' : 'fa-file-export';
            const typeBadge = isSqlTarget ? 'SQL' : 'File';
            const dbType = target.db_type || target.database_type || '';
            
            return `
                <div class="target-config-card pending" data-target-index="${index}" data-target-name="${target.name}" data-target-type="${isSqlTarget ? 'sql' : 'file'}" data-testid="target-card-${index}">
                    <div class="target-card-header" data-testid="target-card-header-${index}">
                        <div class="target-type-icon ${typeClass}">
                            <i class="fas ${typeIcon}"></i>
                        </div>
                        <div class="target-card-info">
                            <div class="target-card-name">${this.escapeHtml(target.name)}</div>
                            <div class="target-card-meta">
                                <span class="target-type-badge ${isSqlTarget ? 'sql' : 'file'}">${typeBadge}</span>
                                ${dbType ? `<span class="source-format-badge">${this.escapeHtml(dbType)}</span>` : ''}
                            </div>
                        </div>
                        <span class="target-status-badge pending">
                            <i class="fas fa-exclamation-circle"></i> Pending
                        </span>
                        <div class="target-card-toggle">
                            <i class="fas fa-chevron-down"></i>
                        </div>
                    </div>
                    <div class="target-card-body">
                        ${isSqlTarget ? this.renderSqlTargetFields(target, index) : this.renderFileTargetFields(target, index)}
                    </div>
                </div>
            `;
        }).join('');
        
        this.bindTargetCardEvents();
    }
    
    isTargetSqlType(target) {
        if (target.type === 'SQL') return true;
        if (target.db_type || target.database_type) return true;
        const dbTypes = ['Oracle', 'SQL Server', 'DB2', 'Sybase', 'Teradata', 'PostgreSQL', 'MySQL', 'Netezza', 'Greenplum', 'ODBC'];
        const targetType = (target.type || '').toLowerCase();
        const dbTypeVal = (target.db_type || target.database_type || '').toLowerCase();
        return dbTypes.some(db => targetType.includes(db.toLowerCase()) || dbTypeVal.includes(db.toLowerCase()));
    }
    
    renderSqlTargetFields(target, index) {
        const storedConnections = this.getConnections();
        const hasConnections = storedConnections.length > 0;
        const connectionOptions = storedConnections.map(conn => 
            `<option value="${conn.id}">${conn.name} (${conn.dbType})</option>`
        ).join('');
        
        return `
            <div class="target-config-fields">
                ${hasConnections ? `
                <div class="config-field-group">
                    <label class="config-field-label">Connection <span class="required">*</span></label>
                    <select class="config-select target-connection-select" data-target="${target.name}" data-testid="select-target-connection-${index}">
                        <option value="">-- Select Saved Connection --</option>
                        ${connectionOptions}
                        <option value="new">+ Enter Connection Details...</option>
                    </select>
                    <span class="config-input-hint">Select from saved connections or enter details manually</span>
                </div>
                ` : `
                <div class="config-field-group">
                    <span class="config-input-hint" style="margin-bottom: 8px; display: block;"><i class="fas fa-info-circle"></i> No saved connections found. Enter connection details below.</span>
                </div>
                `}
                
                <div class="target-connection-details" id="targetConnDetails-${index}" style="${hasConnections ? 'display: none;' : 'display: block;'}">
                    <div class="config-field-group">
                        <label class="config-field-label">JDBC URL <span class="required">*</span></label>
                        <input type="text" class="config-input target-jdbc-url" data-target="${target.name}" 
                               placeholder="jdbc:oracle:thin:@host:port:sid" data-testid="input-target-jdbc-${index}">
                    </div>
                    
                    <div class="config-row">
                        <div class="config-field-group">
                            <label class="config-field-label">Username</label>
                            <input type="text" class="config-input target-username" data-target="${target.name}" 
                                   placeholder="Database username" data-testid="input-target-username-${index}">
                        </div>
                        <div class="config-field-group">
                            <label class="config-field-label">Password</label>
                            <input type="password" class="config-input target-password" data-target="${target.name}" 
                                   placeholder="Database password" data-testid="input-target-password-${index}">
                        </div>
                    </div>
                </div>
                
                <div class="config-row">
                    <div class="config-field-group">
                        <label class="config-field-label">Schema</label>
                        <input type="text" class="config-input target-schema" data-target="${target.name}" 
                               value="${target.owner || ''}" placeholder="Schema name" data-testid="input-target-schema-${index}">
                    </div>
                    <div class="config-field-group">
                        <label class="config-field-label">Table <span class="required">*</span></label>
                        <input type="text" class="config-input target-table" data-target="${target.name}" 
                               value="${target.table_name || target.name}" placeholder="Table name" data-testid="input-target-table-${index}">
                    </div>
                </div>
                
                <div class="config-field-group">
                    <label class="config-field-label">Write Mode <span class="required">*</span></label>
                    <select class="config-select target-mode" data-target="${target.name}" data-testid="select-target-mode-${index}">
                        <option value="append">Append</option>
                        <option value="overwrite">Overwrite (Truncate + Insert)</option>
                        <option value="error">Error if exists</option>
                        <option value="ignore">Ignore</option>
                    </select>
                </div>
            </div>
        `;
    }
    
    renderFileTargetFields(target, index) {
        return `
            <div class="target-config-fields">
                <div class="config-row">
                    <div class="config-field-group">
                        <label class="config-field-label">Output Format <span class="required">*</span></label>
                        <select class="config-select target-format" data-target="${target.name}" data-testid="select-target-format-${index}">
                            <option value="delta">Delta</option>
                            <option value="parquet">Parquet</option>
                            <option value="csv">CSV</option>
                        </select>
                    </div>
                    <div class="config-field-group">
                        <label class="config-field-label">Write Mode <span class="required">*</span></label>
                        <select class="config-select target-mode" data-target="${target.name}" data-testid="select-target-mode-${index}">
                            <option value="append">Append</option>
                            <option value="overwrite">Overwrite</option>
                            <option value="error">Error if exists</option>
                            <option value="ignore">Ignore</option>
                        </select>
                    </div>
                </div>
                
                <div class="config-field-group">
                    <label class="config-field-label">Destination Path <span class="required">*</span></label>
                    <input type="text" class="config-input target-path" data-target="${target.name}" 
                           placeholder="/path/to/output or s3://bucket/path" data-testid="input-target-path-${index}">
                </div>
                
                <div class="config-optional-fields">
                    <div class="config-optional-title">Optional Settings</div>
                    <div class="config-row">
                        <div class="config-field-group">
                            <label class="config-field-label">Partition Columns</label>
                            <input type="text" class="config-input target-partitions" data-target="${target.name}" 
                                   placeholder="date_col, region" data-testid="input-target-partitions-${index}">
                            <span class="config-input-hint">Comma-separated column names for partitioning</span>
                        </div>
                        <div class="config-field-group">
                            <label class="config-field-label">Compression</label>
                            <select class="config-select target-compression" data-target="${target.name}" data-testid="select-target-compression-${index}">
                                <option value="snappy">Snappy (Default)</option>
                                <option value="gzip">GZIP</option>
                                <option value="lz4">LZ4</option>
                                <option value="none">None</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    bindSourceCardEvents() {
        document.querySelectorAll('.source-card-header').forEach(header => {
            header.addEventListener('click', () => {
                const card = header.closest('.source-config-card');
                card.classList.toggle('expanded');
            });
        });
        
        document.querySelectorAll('.source-connection-select').forEach(select => {
            select.addEventListener('change', (e) => {
                const index = e.target.closest('.source-config-card').dataset.sourceIndex;
                const detailsDiv = document.getElementById(`sqlDetails-${index}`);
                
                if (e.target.value === 'new') {
                    detailsDiv.style.display = 'block';
                } else {
                    detailsDiv.style.display = 'none';
                }
                
                this.updateSourceCardStatus(e.target.closest('.source-config-card'));
            });
        });
        
        document.querySelectorAll('.source-config-card .config-input, .source-config-card .config-select').forEach(input => {
            input.addEventListener('change', (e) => {
                this.updateSourceCardStatus(e.target.closest('.source-config-card'));
            });
        });
    }
    
    bindTargetCardEvents() {
        document.querySelectorAll('.target-card-header').forEach(header => {
            header.addEventListener('click', () => {
                const card = header.closest('.target-config-card');
                card.classList.toggle('expanded');
            });
        });
        
        document.querySelectorAll('.target-connection-select').forEach(select => {
            select.addEventListener('change', (e) => {
                const index = e.target.closest('.target-config-card').dataset.targetIndex;
                const detailsDiv = document.getElementById(`targetConnDetails-${index}`);
                
                if (e.target.value === 'new' || e.target.value === '') {
                    if (detailsDiv) detailsDiv.style.display = 'block';
                } else {
                    if (detailsDiv) detailsDiv.style.display = 'none';
                }
                
                this.updateTargetCardStatus(e.target.closest('.target-config-card'));
            });
        });
        
        document.querySelectorAll('.target-config-card .config-input, .target-config-card .config-select').forEach(input => {
            input.addEventListener('change', (e) => {
                this.updateTargetCardStatus(e.target.closest('.target-config-card'));
            });
        });
    }
    
    updateSourceCardStatus(card) {
        const pathInput = card.querySelector('.source-path');
        const connectionSelect = card.querySelector('.source-connection-select');
        const jdbcUrlInput = card.querySelector('.source-jdbc-url');
        const sqlDetailsDiv = card.querySelector('.sql-connection-details');
        
        let isConfigured = false;
        
        if (pathInput && pathInput.value.trim()) {
            isConfigured = true;
        } else if (connectionSelect && connectionSelect.value && connectionSelect.value !== 'new' && connectionSelect.value !== '') {
            isConfigured = true;
        } else if (sqlDetailsDiv && sqlDetailsDiv.style.display !== 'none' && jdbcUrlInput && jdbcUrlInput.value.trim()) {
            isConfigured = true;
        } else if (!connectionSelect && jdbcUrlInput && jdbcUrlInput.value.trim()) {
            isConfigured = true;
        }
        
        const statusBadge = card.querySelector('.source-status-badge');
        if (isConfigured) {
            card.classList.remove('pending');
            card.classList.add('configured');
            statusBadge.classList.remove('pending');
            statusBadge.classList.add('configured');
            statusBadge.innerHTML = '<i class="fas fa-check-circle"></i> Configured';
        } else {
            card.classList.remove('configured');
            card.classList.add('pending');
            statusBadge.classList.remove('configured');
            statusBadge.classList.add('pending');
            statusBadge.innerHTML = '<i class="fas fa-exclamation-circle"></i> Pending';
        }
        
        this.updateConfigProgressCounts();
    }
    
    updateTargetCardStatus(card) {
        const isSqlTarget = card.dataset.targetType === 'sql';
        let isConfigured = false;
        
        if (isSqlTarget) {
            const tableInput = card.querySelector('.target-table');
            const connectionSelect = card.querySelector('.target-connection-select');
            const jdbcUrlInput = card.querySelector('.target-jdbc-url');
            
            const hasTable = tableInput && tableInput.value.trim();
            const hasConnection = connectionSelect && connectionSelect.value && connectionSelect.value !== 'new' && connectionSelect.value !== '';
            const hasJdbcUrl = jdbcUrlInput && jdbcUrlInput.value.trim();
            
            isConfigured = hasTable && (hasConnection || hasJdbcUrl);
        } else {
            const pathInput = card.querySelector('.target-path');
            isConfigured = pathInput && pathInput.value.trim();
        }
        
        const statusBadge = card.querySelector('.target-status-badge');
        if (isConfigured) {
            card.classList.remove('pending');
            card.classList.add('configured');
            statusBadge.classList.remove('pending');
            statusBadge.classList.add('configured');
            statusBadge.innerHTML = '<i class="fas fa-check-circle"></i> Configured';
        } else {
            card.classList.remove('configured');
            card.classList.add('pending');
            statusBadge.classList.remove('configured');
            statusBadge.classList.add('pending');
            statusBadge.innerHTML = '<i class="fas fa-exclamation-circle"></i> Pending';
        }
        
        this.updateConfigProgressCounts();
    }
    
    updateConfigProgressCounts() {
        // Configuration summary bar has been removed - no action needed
    }
    
    addConnection() {
        const alias = document.getElementById('dbAlias').value.trim();
        const type = document.getElementById('dbType').value;
        const host = document.getElementById('dbHost').value.trim();
        const port = document.getElementById('dbPort').value.trim();
        const dbName = document.getElementById('dbName').value.trim();
        
        if (!alias) {
            this.showToast('Please enter a connection alias', 'warning');
            return;
        }
        
        this.userConfig.db_connections[alias] = {
            type: type,
            host: host || '${DB_HOST}',
            port: port || '1433',
            database: dbName || 'database_name',
            user: '${DB_USER}',
            password: '${DB_PASSWORD}'
        };
        
        this.renderConnections();
        
        document.getElementById('dbAlias').value = '';
        document.getElementById('dbHost').value = '';
        document.getElementById('dbPort').value = '';
        document.getElementById('dbName').value = '';
        
        this.showToast(`Connection "${alias}" added`, 'success');
    }
    
    renderConnections() {
        const list = document.getElementById('connectionsList');
        const connections = Object.entries(this.userConfig.db_connections);
        
        if (connections.length === 0) {
            list.innerHTML = '';
            return;
        }
        
        list.innerHTML = connections.map(([alias, config]) => `
            <div class="connection-item">
                <div class="connection-info">
                    <i class="fas fa-plug"></i>
                    <span><strong>${alias}</strong> - ${config.type} (${config.host}:${config.port})</span>
                </div>
                <button class="icon-btn" onclick="app.removeConnection('${alias}')" data-testid="button-remove-connection-${alias}">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');
    }
    
    removeConnection(alias) {
        delete this.userConfig.db_connections[alias];
        this.renderConnections();
        this.showToast(`Connection "${alias}" removed`, 'success');
    }
    
    collectConfig() {
        this.userConfig.sources = [];
        this.userConfig.targets = [];
        this.userConfig.connection_mappings = {};
        this.userConfig.options = {};
        
        if (this.analysisData && this.analysisData.mappings.length > 0) {
            const mapping = this.analysisData.mappings[0];
            
            mapping.sources.forEach(source => {
                const config = {
                    source_name: source.name,
                    source_type: source.type
                };
                
                if (source.type === 'SQL') {
                    const connInput = document.querySelector(`.source-connection[data-source="${source.name}"]`);
                    config.connection_alias = connInput ? connInput.value : source.db_name;
                } else {
                    const formatSelect = document.querySelector(`.source-format[data-source="${source.name}"]`);
                    const pathInput = document.querySelector(`.source-path[data-source="${source.name}"]`);
                    const locationRadio = document.querySelector(`input[name="location-${source.name}"]:checked`);
                    
                    config.file_format = formatSelect ? formatSelect.value : 'csv';
                    config.file_path = pathInput ? pathInput.value : '';
                    config.file_location = locationRadio ? locationRadio.value : 'local';
                }
                
                this.userConfig.sources.push(config);
            });
            
            mapping.targets.forEach(target => {
                const formatSelect = document.querySelector(`.target-format[data-target="${target.name}"]`);
                const modeSelect = document.querySelector(`.target-mode[data-target="${target.name}"]`);
                const pathInput = document.querySelector(`.target-path[data-target="${target.name}"]`);
                
                this.userConfig.targets.push({
                    target_name: target.name,
                    output_format: formatSelect ? formatSelect.value : 'delta',
                    write_mode: modeSelect ? modeSelect.value : 'append',
                    destination_path: pathInput ? pathInput.value : '',
                    table_name: target.name
                });
            });
        }
        
        document.querySelectorAll('.connection-mapping-select').forEach(select => {
            const itemType = select.dataset.itemType;
            const itemName = select.dataset.itemName;
            const connectionId = select.value;
            
            if (connectionId) {
                const storedConnections = this.getConnections();
                const connection = storedConnections.find(c => c.id === connectionId);
                if (connection) {
                    this.userConfig.connection_mappings[`${itemType}:${itemName}`] = {
                        connection_id: connectionId,
                        connection_name: connection.name,
                        db_type: connection.dbType,
                        jdbc_url: connection.jdbcUrl,
                        schema: connection.schema
                    };
                }
            }
        });
        
        const optOrchestration = document.getElementById('optGenerateOrchestration');
        const optDelta = document.getElementById('optUseDeltaFormat');
        const optBroadcast = document.getElementById('optBroadcastLookups');
        const optTests = document.getElementById('optGenerateTests');
        
        this.userConfig.options = {
            generate_orchestration: optOrchestration ? optOrchestration.checked : true,
            use_delta_format: optDelta ? optDelta.checked : true,
            broadcast_lookups: optBroadcast ? optBroadcast.checked : true,
            generate_tests: optTests ? optTests.checked : false
        };
    }
    
    // Navigate to Generate Page (Step 4)
    goToGeneratePage() {
        try {
            if (!this.analysisData || !this.analysisData.mappings) {
                this.showToast('No analysis data available', 'error');
                return;
            }
            
            this.collectConfig();
            this.generationState = {
                mappings: [],
                currentIndex: -1,
                completed: 0,
                failed: 0,
                isRunning: false,
                logs: [],
                logsByComponent: {
                    all: [],
                    config: [],
                    workflow: []
                },
                currentLogFilter: 'all',
                auditTrail: []
            };
            
            // Navigate to step 4
            this.goToStep(4);
            
            // Populate all left tabs
            this.populateGenerateMappingList();
            this.populateGenerateWorkflowList();
            this.populateGenerateConfigView();
            this.resetGenerateUI();
            
            // Update log filter dropdown with mapping options
            this.updateLogFilterDropdown();
            
            // Reset right tabs to default state
            this.resetRightTabsPanels();
        } catch (error) {
            console.error('Error navigating to generate page:', error);
            this.showToast('Error: ' + error.message, 'error');
        }
    }
    
    // Tab switching for left panel (Mapping, Workflow, Config)
    switchGenLeftTab(tabName) {
        document.querySelectorAll('.gen-left-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.genLeftTab === tabName);
        });
        
        document.querySelectorAll('.gen-left-tab-panel').forEach(panel => {
            panel.classList.remove('active');
        });
        
        const panelMap = {
            'mapping': 'genLeftMappingPanel',
            'workflow': 'genLeftWorkflowPanel',
            'config': 'genLeftConfigPanel'
        };
        
        const panelId = panelMap[tabName];
        if (panelId) {
            document.getElementById(panelId).classList.add('active');
        }
    }
    
    // Tab switching for right panel (Logs, Code, Validation, Flow, Audit, Lineage)
    switchGenRightTab(tabName) {
        document.querySelectorAll('.gen-right-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.genRightTab === tabName);
        });
        
        document.querySelectorAll('.gen-right-tab-panel').forEach(panel => {
            panel.classList.remove('active');
        });
        
        const panelMap = {
            'logs': 'genRightLogsPanel',
            'code': 'genRightCodePanel',
            'validation': 'genRightValidationPanel',
            'flow': 'genRightFlowPanel',
            'audit': 'genRightAuditPanel',
            'lineage': 'genRightLineagePanel',
            'summary': 'genRightSummaryPanel'
        };
        
        const panelId = panelMap[tabName];
        if (panelId) {
            document.getElementById(panelId).classList.add('active');
        }
    }
    
    // Populate workflow list in left panel
    populateGenerateWorkflowList() {
        const listEl = document.getElementById('generateWorkflowList');
        const countEl = document.getElementById('genWorkflowCount');
        // workflowAnalysis is an object with .workflows array inside
        const workflows = (this.workflowAnalysis && this.workflowAnalysis.workflows) || [];
        
        countEl.textContent = workflows.length;
        
        if (workflows.length === 0) {
            listEl.innerHTML = `
                <div class="gen-empty-state">
                    <i class="fas fa-info-circle"></i>
                    <span>No workflow information available</span>
                </div>
            `;
            return;
        }
        
        listEl.innerHTML = workflows.map((wf, idx) => {
            const name = wf.workflow_name || wf.name || `Workflow_${idx + 1}`;
            const sessionCount = (wf.sessions || []).length;
            
            return `
                <div class="mapping-select-item" data-workflow-index="${idx}">
                    <div class="mapping-select-info">
                        <div class="mapping-select-name">${this.escapeHtml(name)}</div>
                        <div class="mapping-select-meta">
                            <span class="meta-badge">${sessionCount} sessions</span>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }
    
    // Populate config view in left panel
    populateGenerateConfigView() {
        const container = document.getElementById('generateConfigView');
        const config = this.userConfig || {};
        
        let html = '<div class="gen-config-sections">';
        
        // Database Connections
        const connections = config.db_connections || {};
        const connCount = Object.keys(connections).length;
        html += `
            <div class="gen-config-section">
                <div class="gen-config-section-header">
                    <i class="fas fa-database"></i>
                    <span>Database Connections</span>
                    <span class="gen-count-badge">${connCount}</span>
                </div>
                <div class="gen-config-section-content">
        `;
        
        if (connCount > 0) {
            for (const [name, conn] of Object.entries(connections)) {
                html += `
                    <div class="gen-config-item">
                        <span class="config-item-name">${this.escapeHtml(name)}</span>
                        <span class="config-item-value">${this.escapeHtml(conn.db_type || 'Unknown')}</span>
                    </div>
                `;
            }
        } else {
            html += '<div class="gen-config-empty">No connections configured</div>';
        }
        
        html += '</div></div>';
        
        // Sources Configuration
        const sources = config.sources || [];
        html += `
            <div class="gen-config-section">
                <div class="gen-config-section-header">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Sources</span>
                    <span class="gen-count-badge">${sources.length}</span>
                </div>
                <div class="gen-config-section-content">
        `;
        
        if (sources.length > 0) {
            sources.forEach(src => {
                html += `
                    <div class="gen-config-item">
                        <span class="config-item-name">${this.escapeHtml(src.name || 'Unknown')}</span>
                        <span class="config-item-value">${this.escapeHtml(src.connection_type || src.type || 'DB')}</span>
                    </div>
                `;
            });
        } else {
            html += '<div class="gen-config-empty">No sources configured</div>';
        }
        
        html += '</div></div>';
        
        // Targets Configuration
        const targets = config.targets || [];
        html += `
            <div class="gen-config-section">
                <div class="gen-config-section-header">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Targets</span>
                    <span class="gen-count-badge">${targets.length}</span>
                </div>
                <div class="gen-config-section-content">
        `;
        
        if (targets.length > 0) {
            targets.forEach(tgt => {
                html += `
                    <div class="gen-config-item">
                        <span class="config-item-name">${this.escapeHtml(tgt.name || 'Unknown')}</span>
                        <span class="config-item-value">${this.escapeHtml(tgt.connection_type || tgt.type || 'DB')}</span>
                    </div>
                `;
            });
        } else {
            html += '<div class="gen-config-empty">No targets configured</div>';
        }
        
        html += '</div></div>';
        
        // Options
        const options = config.options || {};
        html += `
            <div class="gen-config-section">
                <div class="gen-config-section-header">
                    <i class="fas fa-sliders-h"></i>
                    <span>Options</span>
                </div>
                <div class="gen-config-section-content">
                    <div class="gen-config-item">
                        <span class="config-item-name">Generate Orchestration</span>
                        <span class="config-item-value">${options.generate_orchestration !== false ? 'Yes' : 'No'}</span>
                    </div>
                    <div class="gen-config-item">
                        <span class="config-item-name">Use Delta Format</span>
                        <span class="config-item-value">${options.use_delta_format !== false ? 'Yes' : 'No'}</span>
                    </div>
                    <div class="gen-config-item">
                        <span class="config-item-name">Broadcast Lookups</span>
                        <span class="config-item-value">${options.broadcast_lookups !== false ? 'Yes' : 'No'}</span>
                    </div>
                </div>
            </div>
        `;
        
        html += '</div>';
        container.innerHTML = html;
    }
    
    // Reset right tabs to placeholder states
    resetRightTabsPanels() {
        // Reset code tab
        document.getElementById('genCodeFileSelect').innerHTML = '<option value="">Select a file...</option>';
        document.getElementById('genCodeContainer').innerHTML = `
            <div class="gen-code-placeholder">
                <i class="fas fa-file-code"></i>
                <span>Select a file from the dropdown to view code</span>
            </div>
        `;
        
        // Reset validation tab
        document.getElementById('genValidationContainer').innerHTML = `
            <div class="gen-validation-placeholder">
                <i class="fas fa-clipboard-check"></i>
                <span>Validation results will appear after generation...</span>
            </div>
        `;
        
        // Reset flow tab
        document.getElementById('genFlowContainer').innerHTML = `
            <div class="gen-flow-placeholder">
                <i class="fas fa-project-diagram"></i>
                <span>Data flow summary will appear after generation...</span>
            </div>
        `;
        
        // Reset audit tab
        document.getElementById('genAuditContainer').innerHTML = `
            <div class="gen-audit-placeholder">
                <i class="fas fa-clipboard-list"></i>
                <span>Audit trail will appear after generation...</span>
            </div>
        `;
        
        // Reset lineage tab
        document.getElementById('genLineageContainer').innerHTML = `
            <div class="gen-lineage-placeholder">
                <i class="fas fa-sitemap"></i>
                <span>Data lineage will appear after generation...</span>
            </div>
        `;
        
        // Reset summary tab
        document.getElementById('genSummaryContainer').innerHTML = `
            <div class="gen-summary-placeholder">
                <i class="fas fa-list-alt"></i>
                <span>Data flow summary will appear after generation...</span>
            </div>
        `;
        document.getElementById('summaryMappingSelect').innerHTML = '<option value="">Select a mapping...</option>';
    }
    
    // Populate all right tabs after generation completes
    populateRightTabsAfterGeneration() {
        const result = this.generationState.result;
        if (!result) return;
        
        // Populate code file dropdown
        this.populateCodeFileSelect(result.files || []);
        
        // Populate validation tab
        this.populateValidation(result.reports || []);
        
        // Populate flow summary tab
        this.populateFlowSummary(result.reports || []);
        
        // Populate audit trail tab
        this.populateAuditTrail();
        
        // Populate lineage tab
        this.populateLineage(result.reports || []);
        
        // Populate summary tab
        this.populateSummary();
    }
    
    // Populate code file dropdown
    populateCodeFileSelect(files) {
        const select = document.getElementById('genCodeFileSelect');
        select.innerHTML = '<option value="">Select a file...</option>';
        
        files.forEach(file => {
            const option = document.createElement('option');
            option.value = file.filename;
            option.textContent = file.filename;
            select.appendChild(option);
        });
    }
    
    // Load file code into code container
    async loadGeneratedFileCode(filename) {
        const container = document.getElementById('genCodeContainer');
        
        if (!filename) {
            container.innerHTML = `
                <div class="gen-code-placeholder">
                    <i class="fas fa-file-code"></i>
                    <span>Select a file from the dropdown to view code</span>
                </div>
            `;
            return;
        }
        
        container.innerHTML = `
            <div class="gen-code-placeholder">
                <i class="fas fa-spinner fa-spin"></i>
                <span>Loading ${filename}...</span>
            </div>
        `;
        
        try {
            const response = await fetch(`/api/artifact/${this.artifactId}/file/${filename}`);
            const data = await response.json();
            
            if (data.success && data.content) {
                const highlighted = this.highlightPythonCode(data.content);
                container.innerHTML = `<pre class="gen-code-pre">${highlighted}</pre>`;
            } else {
                container.innerHTML = `
                    <div class="gen-code-placeholder">
                        <i class="fas fa-exclamation-triangle"></i>
                        <span>Failed to load file: ${data.error || 'Unknown error'}</span>
                    </div>
                `;
            }
        } catch (error) {
            container.innerHTML = `
                <div class="gen-code-placeholder">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>Error loading file: ${error.message}</span>
                </div>
            `;
        }
    }
    
    // Simple Python syntax highlighting
    highlightPythonCode(code) {
        let escaped = this.escapeHtml(code);
        
        // Keywords
        const keywords = ['def', 'class', 'import', 'from', 'return', 'if', 'elif', 'else', 'for', 'while', 'try', 'except', 'finally', 'with', 'as', 'lambda', 'yield', 'raise', 'pass', 'break', 'continue', 'True', 'False', 'None', 'and', 'or', 'not', 'in', 'is'];
        keywords.forEach(kw => {
            const regex = new RegExp(`\\b(${kw})\\b`, 'g');
            escaped = escaped.replace(regex, '<span class="py-keyword">$1</span>');
        });
        
        // Strings (simple approach)
        escaped = escaped.replace(/(["'])(?:(?=(\\?))\2.)*?\1/g, '<span class="py-string">$&</span>');
        
        // Comments
        escaped = escaped.replace(/(#.*)$/gm, '<span class="py-comment">$1</span>');
        
        // Functions
        escaped = escaped.replace(/\b(\w+)\s*\(/g, '<span class="py-function">$1</span>(');
        
        return escaped;
    }
    
    // Copy generated code to clipboard
    copyGeneratedCode() {
        const container = document.getElementById('genCodeContainer');
        const pre = container.querySelector('.gen-code-pre');
        
        if (pre) {
            const text = pre.innerText;
            navigator.clipboard.writeText(text).then(() => {
                this.showToast('Code copied to clipboard', 'success');
            }).catch(() => {
                this.showToast('Failed to copy code', 'error');
            });
        }
    }
    
    // Populate validation tab
    populateValidation(reports) {
        const container = document.getElementById('genValidationContainer');
        
        let totalErrors = 0;
        let totalWarnings = 0;
        let totalSuccess = 0;
        let allItems = [];
        
        reports.forEach(report => {
            const errors = report.errors || [];
            const warnings = report.warnings || [];
            
            totalErrors += errors.length;
            totalWarnings += warnings.length;
            
            if (errors.length === 0 && warnings.length === 0) {
                totalSuccess++;
                allItems.push({
                    type: 'success',
                    title: report.mapping_name,
                    desc: 'Converted successfully with no issues'
                });
            }
            
            errors.forEach(e => {
                allItems.push({
                    type: 'error',
                    title: `${report.mapping_name}: ${e.type || 'Error'}`,
                    desc: e.message
                });
            });
            
            warnings.forEach(w => {
                allItems.push({
                    type: 'warning',
                    title: `${report.mapping_name}: ${w.type || 'Warning'}`,
                    desc: w.message
                });
            });
        });
        
        let html = `
            <div class="validation-summary">
                <div class="validation-stat success">
                    <span class="validation-stat-value">${totalSuccess}</span>
                    <span class="validation-stat-label">Clean</span>
                </div>
                <div class="validation-stat warning">
                    <span class="validation-stat-value">${totalWarnings}</span>
                    <span class="validation-stat-label">Warnings</span>
                </div>
                <div class="validation-stat error">
                    <span class="validation-stat-value">${totalErrors}</span>
                    <span class="validation-stat-label">Errors</span>
                </div>
            </div>
            <div class="validation-items">
        `;
        
        allItems.forEach(item => {
            const iconClass = item.type === 'success' ? 'fa-check' : (item.type === 'warning' ? 'fa-exclamation-triangle' : 'fa-times');
            html += `
                <div class="validation-item">
                    <div class="validation-item-icon ${item.type}">
                        <i class="fas ${iconClass}"></i>
                    </div>
                    <div class="validation-item-content">
                        <div class="validation-item-title">${this.escapeHtml(item.title)}</div>
                        <div class="validation-item-desc">${this.escapeHtml(item.desc)}</div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        container.innerHTML = html;
    }
    
    // Populate flow summary tab
    populateFlowSummary(reports) {
        const container = document.getElementById('genFlowContainer');
        
        if (reports.length === 0) {
            container.innerHTML = `
                <div class="gen-flow-placeholder">
                    <i class="fas fa-project-diagram"></i>
                    <span>No flow data available</span>
                </div>
            `;
            return;
        }
        
        let html = '';
        
        reports.forEach(report => {
            const steps = report.transformation_order || [];
            
            html += `
                <div class="flow-mapping-section">
                    <div class="flow-mapping-header">
                        <i class="fas fa-project-diagram"></i>
                        ${this.escapeHtml(report.mapping_name)}
                    </div>
                    <div class="flow-steps">
            `;
            
            if (steps.length > 0) {
                steps.forEach((step, idx) => {
                    html += `
                        <div class="flow-step">
                            <div class="flow-step-num">${idx + 1}</div>
                            <div class="flow-step-content">
                                <div class="flow-step-type">${this.escapeHtml(step.type || 'Transform')}</div>
                                <div class="flow-step-name">${this.escapeHtml(step.name || step)}</div>
                            </div>
                        </div>
                    `;
                });
            } else {
                html += '<div class="gen-config-empty">No transformation steps recorded</div>';
            }
            
            html += '</div></div>';
        });
        
        container.innerHTML = html;
    }
    
    // Add audit trail entry
    addAuditEntry(action, detail) {
        if (!this.generationState.auditTrail) {
            this.generationState.auditTrail = [];
        }
        
        this.generationState.auditTrail.push({
            action,
            detail,
            timestamp: new Date()
        });
    }
    
    // Populate audit trail tab
    populateAuditTrail() {
        const container = document.getElementById('genAuditContainer');
        const entries = this.generationState.auditTrail || [];
        
        if (entries.length === 0) {
            // Generate default audit entries from generation state
            const defaultEntries = [
                { action: 'Generation Started', detail: 'PySpark code generation initiated', timestamp: new Date(Date.now() - 5000) },
                { action: 'Configuration Applied', detail: 'User configuration loaded and applied', timestamp: new Date(Date.now() - 4000) },
                { action: 'Mappings Processed', detail: `${(this.analysisData?.mappings || []).length} mappings converted`, timestamp: new Date(Date.now() - 2000) },
                { action: 'Generation Complete', detail: 'All files generated successfully', timestamp: new Date() }
            ];
            
            this.generationState.auditTrail = defaultEntries;
        }
        
        const trail = this.generationState.auditTrail;
        
        let html = '<div class="audit-timeline">';
        
        trail.forEach(entry => {
            const time = entry.timestamp.toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            });
            
            html += `
                <div class="audit-entry">
                    <div class="audit-entry-header">
                        <span class="audit-entry-action">${this.escapeHtml(entry.action)}</span>
                        <span class="audit-entry-time">${time}</span>
                    </div>
                    <div class="audit-entry-detail">${this.escapeHtml(entry.detail)}</div>
                </div>
            `;
        });
        
        html += '</div>';
        container.innerHTML = html;
    }
    
    // Populate lineage tab
    populateLineage(reports) {
        const container = document.getElementById('genLineageContainer');
        
        if (reports.length === 0) {
            container.innerHTML = `
                <div class="gen-lineage-placeholder">
                    <i class="fas fa-sitemap"></i>
                    <span>No lineage data available</span>
                </div>
            `;
            return;
        }
        
        let html = '<div class="lineage-diagram">';
        
        reports.forEach(report => {
            const sources = report.sources || [];
            const targets = report.targets || [];
            const mappingName = report.mapping_name;
            
            html += `
                <div class="lineage-row">
                    <div class="lineage-sources">
            `;
            
            if (sources.length > 0) {
                sources.forEach(src => {
                    html += `<div class="lineage-node source">${this.escapeHtml(src.name || src)}</div>`;
                });
            } else {
                html += `<div class="lineage-node source">Sources</div>`;
            }
            
            html += `
                    </div>
                    <div class="lineage-arrow"><i class="fas fa-arrow-right"></i></div>
                    <div class="lineage-node transform">${this.escapeHtml(mappingName)}</div>
                    <div class="lineage-arrow"><i class="fas fa-arrow-right"></i></div>
                    <div class="lineage-targets">
            `;
            
            if (targets.length > 0) {
                targets.forEach(tgt => {
                    html += `<div class="lineage-node target">${this.escapeHtml(tgt.name || tgt)}</div>`;
                });
            } else {
                html += `<div class="lineage-node target">Targets</div>`;
            }
            
            html += `
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        container.innerHTML = html;
    }
    
    // Populate summary tab with data flow summary
    populateSummary() {
        const summaries = this.generationState?.summaries || {};
        const select = document.getElementById('summaryMappingSelect');
        const container = document.getElementById('genSummaryContainer');
        
        const mappingNames = Object.keys(summaries);
        
        if (mappingNames.length === 0) {
            container.innerHTML = `
                <div class="gen-summary-placeholder">
                    <i class="fas fa-list-alt"></i>
                    <span>No summary data available</span>
                </div>
            `;
            return;
        }
        
        // Populate mapping dropdown
        select.innerHTML = '<option value="">Select a mapping...</option>';
        mappingNames.forEach(name => {
            const option = document.createElement('option');
            option.value = name;
            option.textContent = name;
            select.appendChild(option);
        });
        
        // Auto-select first mapping
        if (mappingNames.length > 0) {
            select.value = mappingNames[0];
            this.renderSummaryForMapping(mappingNames[0]);
        }
    }
    
    // Render summary for a specific mapping
    renderSummaryForMapping(mappingName) {
        const container = document.getElementById('genSummaryContainer');
        const summaries = this.generationState?.summaries || {};
        const summary = summaries[mappingName];
        
        if (!summary) {
            container.innerHTML = `
                <div class="gen-summary-placeholder">
                    <i class="fas fa-list-alt"></i>
                    <span>Select a mapping to view its summary</span>
                </div>
            `;
            return;
        }
        
        const sources = summary.sources || [];
        const targets = summary.targets || [];
        const transformCounts = summary.transform_counts || {};
        const connectorCount = summary.connector_count || 0;
        
        // Build text-based summary
        let lines = [];
        lines.push('============================================================');
        lines.push('DATA FLOW SUMMARY');
        lines.push('============================================================');
        lines.push('');
        
        // Sources
        lines.push(`SOURCES (${sources.length}):`);
        sources.forEach(src => {
            const conn = src.connection ? ` [${src.connection}]` : '';
            lines.push(`  - ${src.name}${conn}`);
        });
        lines.push('');
        
        // Targets
        lines.push(`TARGETS (${targets.length}):`);
        targets.forEach(tgt => {
            const conn = tgt.connection ? ` [${tgt.connection}]` : '';
            lines.push(`  - ${tgt.name}${conn}`);
        });
        lines.push('');
        
        // Transformations
        const totalTransforms = Object.values(transformCounts).reduce((a, b) => a + b, 0);
        lines.push(`TRANSFORMATIONS (${totalTransforms}):`);
        Object.entries(transformCounts).sort((a, b) => a[0].localeCompare(b[0])).forEach(([type, count]) => {
            lines.push(`  - ${type}: ${count}`);
        });
        lines.push('');
        
        // Connectors
        lines.push(`CONNECTORS: ${connectorCount} data flows`);
        lines.push('');
        lines.push('============================================================');
        
        container.innerHTML = `<pre class="summary-text-output">${this.escapeHtml(lines.join('\n'))}</pre>`;
    }
    
    // Back to step 3 from generate page - resets state if needed
    backFromGeneratePage() {
        if (this.generationState && this.generationState.isRunning) {
            if (!confirm('Generation is in progress. Are you sure you want to go back?')) {
                return;
            }
            this.generationState.isRunning = false;
        }
        this.goToStep(3);
    }
    
    populateGenerateMappingList() {
        const listEl = document.getElementById('generateMappingList');
        const countEl = document.getElementById('genMappingCount');
        const mappings = this.analysisData.mappings || [];
        
        if (countEl) countEl.textContent = mappings.length;
        
        if (mappings.length === 0) {
            listEl.innerHTML = '<div class="gen-empty-state"><i class="fas fa-info-circle"></i><span>No mappings found</span></div>';
            return;
        }
        
        listEl.innerHTML = mappings.map((mapping, idx) => {
            const name = mapping.mapping_name || `Mapping_${idx + 1}`;
            const sourceCount = (mapping.sources || []).length;
            const targetCount = (mapping.targets || []).length;
            const transformCount = (mapping.transformations || []).length;
            
            return `
                <div class="mapping-select-item" data-mapping-index="${idx}" data-testid="mapping-item-${idx}">
                    <div class="mapping-select-info">
                        <div class="mapping-select-name">${this.escapeHtml(name)}</div>
                        <div class="mapping-select-meta">
                            <span class="meta-badge">${sourceCount} sources</span>
                            <span class="meta-badge">${targetCount} targets</span>
                            <span class="meta-badge">${transformCount} transforms</span>
                        </div>
                    </div>
                    <span class="mapping-status-badge pending" data-testid="status-mapping-${idx}">Pending</span>
                </div>
            `;
        }).join('');
    }
    
    resetGenerateUI() {
        // Reset progress
        document.getElementById('progressCount').textContent = '0 / 0';
        document.getElementById('overallProgressFill').style.width = '0%';
        
        // Reset status badges
        document.querySelectorAll('.mapping-status-badge').forEach(badge => {
            badge.textContent = 'Pending';
            badge.className = 'mapping-status-badge pending';
        });
        
        // Clear logs
        this.clearLogs();
        
        // Reset buttons
        document.getElementById('startGenerateBtn').classList.remove('hidden');
        document.getElementById('downloadGeneratedBtn').classList.add('hidden');
        document.getElementById('newConversionBtn').classList.add('hidden');
        
        // Reset status
        this.updateGenerationStatus('ready', 'Ready');
    }
    
    clearLogs() {
        const logsContainer = document.getElementById('logsContainer');
        logsContainer.innerHTML = `
            <div class="log-placeholder">
                <i class="fas fa-info-circle"></i>
                <span>Logs will appear here when generation starts...</span>
            </div>
        `;
        
        // Reset log storage
        if (this.generationState) {
            this.generationState.logsByComponent = {
                all: [],
                config: [],
                workflow: []
            };
            this.generationState.currentLogFilter = 'all';
        }
        
        // Reset filter dropdown
        const logFilterSelect = document.getElementById('logFilterSelect');
        if (logFilterSelect) {
            logFilterSelect.value = 'all';
        }
    }
    
    addLog(message, type = 'info', component = null, errorDetails = null) {
        const logsContainer = document.getElementById('logsContainer');
        
        // Remove placeholder if present
        const placeholder = logsContainer.querySelector('.log-placeholder');
        if (placeholder) placeholder.remove();
        
        const timestamp = new Date().toLocaleTimeString('en-US', { 
            hour12: false, 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit' 
        });
        
        // Determine component key for storage - normalize to snake_case
        let componentKey = 'workflow'; // Default to workflow for general logs
        let displayComponent = component;
        
        if (component) {
            const lowerComp = component.toLowerCase();
            if (lowerComp === 'config') {
                componentKey = 'config';
            } else if (lowerComp === 'workflow') {
                componentKey = 'workflow';
            } else if (lowerComp.startsWith('mapping_')) {
                // Extract mapping name after "Mapping_" prefix
                const mappingName = component.substring(8); // Remove "Mapping_" prefix
                componentKey = 'mapping_' + mappingName.toLowerCase().replace(/\s+/g, '_');
                displayComponent = mappingName; // Show just the mapping name in display
            }
        }
        
        // Create log entry object
        const logData = {
            timestamp,
            message,
            type,
            component: displayComponent,
            componentKey,
            errorDetails
        };
        
        // Store in component-specific log
        if (this.generationState && this.generationState.logsByComponent) {
            // Add to 'all' logs
            this.generationState.logsByComponent.all.push(logData);
            
            // Add to component-specific log
            if (componentKey === 'config' || componentKey === 'workflow') {
                this.generationState.logsByComponent[componentKey].push(logData);
            } else if (componentKey.startsWith('mapping_')) {
                if (!this.generationState.logsByComponent[componentKey]) {
                    this.generationState.logsByComponent[componentKey] = [];
                }
                this.generationState.logsByComponent[componentKey].push(logData);
            }
        }
        
        // Check if we should display this log based on current filter
        const currentFilter = this.generationState?.currentLogFilter || 'all';
        const shouldDisplay = currentFilter === 'all' || currentFilter === componentKey;
        
        if (shouldDisplay) {
            this.renderLogEntry(logData, logsContainer);
        }
    }
    
    renderLogEntry(logData, container) {
        const logEntry = document.createElement('div');
        logEntry.className = `log-entry ${logData.type}`;
        logEntry.dataset.component = logData.componentKey;
        
        let content = `<span class="log-timestamp">[${logData.timestamp}]</span>`;
        if (logData.component) {
            content += `<span class="log-component">[${logData.component}]</span> `;
        }
        content += logData.message;
        
        if (logData.errorDetails) {
            content += `<span class="error-details">${logData.errorDetails}</span>`;
        }
        
        logEntry.innerHTML = content;
        container.appendChild(logEntry);
        
        // Auto-scroll to bottom
        container.scrollTop = container.scrollHeight;
    }
    
    filterLogs(filterValue) {
        if (this.generationState) {
            this.generationState.currentLogFilter = filterValue;
        }
        
        const logsContainer = document.getElementById('logsContainer');
        logsContainer.innerHTML = '';
        
        // Get logs for the selected filter
        const logs = this.generationState?.logsByComponent?.[filterValue] || 
                     this.generationState?.logsByComponent?.all || [];
        
        if (logs.length === 0) {
            logsContainer.innerHTML = `
                <div class="log-placeholder">
                    <i class="fas fa-info-circle"></i>
                    <span>No logs for this filter...</span>
                </div>
            `;
            return;
        }
        
        // Render all logs for this filter
        logs.forEach(logData => {
            this.renderLogEntry(logData, logsContainer);
        });
    }
    
    processStructuredLogs(logs) {
        const logsContainer = document.getElementById('logsContainer');
        if (!logs || !logs.all) return;
        
        // Ensure logsByComponent is initialized
        if (!this.generationState) {
            this.generationState = {};
        }
        if (!this.generationState.logsByComponent) {
            this.generationState.logsByComponent = {
                all: [],
                config: [],
                workflow: []
            };
        }
        
        // Process all log entries from backend
        logs.all.forEach(entry => {
            // Map backend log entry to frontend format
            const timestamp = entry.timestamp || new Date().toLocaleTimeString('en-US', { hour12: false });
            const status = entry.status || 'info';
            const type = status === 'success' ? 'success' : (status === 'warning' ? 'warning' : (status === 'error' ? 'error' : 'info'));
            
            // Determine component key for storage
            let componentKey = 'workflow';
            let displayComponent = null;
            
            if (entry.mapping_name) {
                componentKey = 'mapping_' + entry.mapping_name.toLowerCase().replace(/\s+/g, '_');
                displayComponent = entry.mapping_name;
            } else if (entry.stage === 'config') {
                componentKey = 'config';
                displayComponent = 'Config';
            } else if (entry.stage === 'workflow') {
                componentKey = 'workflow';
                displayComponent = 'Workflow';
            }
            
            // Build the message
            let message = '';
            if (entry.element_type && entry.element_name) {
                message = `[${entry.element_type}] ${entry.element_name}: ${entry.action}`;
            } else {
                message = entry.action || 'Processing...';
            }
            
            // Add details if available
            let errorDetails = null;
            if (entry.details) {
                errorDetails = entry.details;
            }
            if (entry.data) {
                if (entry.data.original && entry.data.translated) {
                    errorDetails = `Original: ${entry.data.original}\nTranslated: ${entry.data.translated}`;
                }
            }
            
            // Create log data object
            const logData = {
                timestamp,
                message,
                type,
                component: displayComponent,
                componentKey,
                errorDetails
            };
            
            // Store in component-specific logs
            if (this.generationState && this.generationState.logsByComponent) {
                this.generationState.logsByComponent.all.push(logData);
                
                if (componentKey === 'config' || componentKey === 'workflow') {
                    this.generationState.logsByComponent[componentKey].push(logData);
                } else if (componentKey.startsWith('mapping_')) {
                    if (!this.generationState.logsByComponent[componentKey]) {
                        this.generationState.logsByComponent[componentKey] = [];
                    }
                    this.generationState.logsByComponent[componentKey].push(logData);
                }
            }
            
            // Check if we should display this log based on current filter
            const currentFilter = this.generationState?.currentLogFilter || 'all';
            const shouldDisplay = currentFilter === 'all' || currentFilter === componentKey;
            
            if (shouldDisplay) {
                this.renderLogEntry(logData, logsContainer);
            }
        });
    }
    
    updateLogFilterDropdown() {
        const logFilterSelect = document.getElementById('logFilterSelect');
        if (!logFilterSelect) return;
        
        // Keep the static options (All, Config, Workflow) and add mapping options
        const existingMappingOptions = logFilterSelect.querySelectorAll('option[data-mapping]');
        existingMappingOptions.forEach(opt => opt.remove());
        
        // Add mapping options based on analysisData
        const mappings = this.analysisData?.mappings || [];
        mappings.forEach((mapping, index) => {
            const option = document.createElement('option');
            // Use mapping_name which is the actual field from analysis
            const mappingName = mapping.mapping_name || mapping.name || `Mapping_${index + 1}`;
            const key = `mapping_${mappingName.toLowerCase().replace(/\s+/g, '_')}`;
            option.value = key;
            option.textContent = `Mapping: ${mappingName}`;
            option.dataset.mapping = 'true';
            logFilterSelect.appendChild(option);
        });
    }
    
    updateGenerationStatus(status, text) {
        const badge = document.getElementById('generationStatusBadge');
        badge.dataset.status = status;
        badge.querySelector('.status-text').textContent = text;
    }
    
    updateMappingStatus(index, status) {
        const badge = document.querySelector(`[data-mapping-index="${index}"] .mapping-status-badge`);
        if (badge) {
            badge.textContent = status.charAt(0).toUpperCase() + status.slice(1);
            badge.className = `mapping-status-badge ${status}`;
        }
    }
    
    updateProgress(completed, total) {
        document.getElementById('progressCount').textContent = `${completed} / ${total}`;
        const percent = total > 0 ? (completed / total) * 100 : 0;
        document.getElementById('overallProgressFill').style.width = `${percent}%`;
    }
    
    async startGeneration() {
        // Get all mappings - backend generates all, selection is for future use
        const mappings = this.analysisData.mappings || [];
        const totalMappings = mappings.length;
        
        if (totalMappings === 0) {
            this.showToast('No mappings available to generate', 'warning');
            return;
        }
        
        this.generationState.isRunning = true;
        this.generationState.completed = 0;
        this.generationState.failed = 0;
        this.generationState.result = null;
        
        // Update UI - mark all as running
        document.getElementById('startGenerateBtn').disabled = true;
        this.updateGenerationStatus('running', 'Generating...');
        this.clearLogs();
        this.addLog('Starting PySpark code generation...', 'info', 'Workflow');
        this.addLog(`Processing ${totalMappings} mapping(s)...`, 'info', 'Workflow');
        
        // Mark all mappings as running
        for (let i = 0; i < totalMappings; i++) {
            this.updateMappingStatus(i, 'running');
            const mappingName = mappings[i].mapping_name || `Mapping_${i + 1}`;
            this.addLog(`Processing: ${mappingName}`, 'info', `Mapping_${mappingName}`);
        }
        
        this.addLog('Sending generation request to server...', 'info', 'Workflow');
        
        try {
            const response = await fetch('/api/generate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    artifact_id: this.artifactId,
                    config: this.userConfig,
                    async: false
                })
            });
            
            let result = await response.json();
            
            if (result.success) {
                this.generationState.result = result.result;
                this.generationState.summaries = result.summaries || {};
                
                // Parse per-mapping status from reports
                let successCount = 0;
                let warningCount = 0;
                let failCount = 0;
                const reports = (result.result && result.result.reports) || [];
                
                // Create a map of mapping names to their report status
                const reportStatusMap = {};
                reports.forEach(report => {
                    reportStatusMap[report.mapping_name] = {
                        status: report.status || 'success',
                        errors: report.errors || [],
                        warnings: report.warnings || []
                    };
                });
                
                // Store per-mapping results for Step 4
                this.generationState.mappingResults = [];
                
                // Update each mapping status based on its report
                for (let i = 0; i < totalMappings; i++) {
                    const mappingName = mappings[i].mapping_name || `Mapping_${i + 1}`;
                    const reportInfo = reportStatusMap[mappingName];
                    
                    if (reportInfo) {
                        // Check report status: "success", "partial", "needs_review"
                        // - "partial" = actual conversion failure (mark as failed)
                        // - "needs_review" = code generated but has quality issues (mark as warning/needs_review)
                        // - "success" = clean generation
                        const hasErrors = reportInfo.errors.length > 0;
                        const hasWarnings = reportInfo.warnings.length > 0;
                        const isPartialFailure = reportInfo.status === 'partial';
                        const needsReview = reportInfo.status === 'needs_review';
                        
                        const componentName = `Mapping_${mappingName}`;
                        if (isPartialFailure) {
                            // Actual conversion failure - code may not work
                            this.updateMappingStatus(i, 'failed');
                            failCount++;
                            this.generationState.mappingResults.push({ name: mappingName, status: 'failed' });
                            const errorDetailsArr = reportInfo.errors.map(e => e.message).join('\n');
                            this.addLog(`Conversion failed`, 'error', componentName, errorDetailsArr);
                        } else if (needsReview || hasErrors) {
                            // Code generated but needs manual review (quality gate issues)
                            this.updateMappingStatus(i, 'done');
                            warningCount++;
                            this.generationState.mappingResults.push({ name: mappingName, status: 'needs_review' });
                            const allIssues = [...reportInfo.errors.map(e => e.message), ...reportInfo.warnings.map(w => w.message)].join('\n');
                            this.addLog(`Needs review`, 'warning', componentName, allIssues || null);
                        } else if (hasWarnings) {
                            // Minor warnings only
                            this.updateMappingStatus(i, 'done');
                            warningCount++;
                            this.generationState.mappingResults.push({ name: mappingName, status: 'warning' });
                            const warningDetails = reportInfo.warnings.map(w => w.message).join('\n');
                            this.addLog(`Generated with warnings`, 'warning', componentName, warningDetails || null);
                        } else {
                            // Clean success
                            this.updateMappingStatus(i, 'done');
                            successCount++;
                            this.generationState.mappingResults.push({ name: mappingName, status: 'success' });
                            this.addLog(`Generated successfully`, 'success', componentName);
                        }
                    } else {
                        // No report found - assume success
                        this.updateMappingStatus(i, 'done');
                        successCount++;
                        this.generationState.mappingResults.push({ name: mappingName, status: 'success' });
                        this.addLog(`Generated`, 'success', `Mapping_${mappingName}`);
                    }
                }
                
                // Progress shows only fully successful mappings
                this.generationState.completed = successCount;
                this.generationState.failed = failCount;
                const processedCount = successCount + warningCount + failCount;
                this.updateProgress(processedCount, totalMappings);
                
                // Process and display structured logs from backend
                if (result.logs && result.logs.all) {
                    this.processStructuredLogs(result.logs);
                }
                
                // Log file generation results
                if (result.result && result.result.files) {
                    this.addLog('Generated files:', 'info', 'Config');
                    result.result.files.forEach(file => {
                        this.addLog(`  ${file.filename}`, 'success', 'Config');
                    });
                }
                
                let summaryMsg = `Generation complete: ${successCount} successful`;
                if (warningCount > 0) summaryMsg += `, ${warningCount} need review`;
                if (failCount > 0) summaryMsg += `, ${failCount} failed`;
                this.addLog(summaryMsg, failCount > 0 ? 'error' : (warningCount > 0 ? 'warning' : 'success'), 'Workflow');
                
                // Store summary counts for Step 4
                this.generationState.summary = {
                    successCount,
                    warningCount,
                    failCount,
                    total: totalMappings
                };
                
                // Update modal status based on overall results
                // failCount = actual conversion failures (partial status)
                // warningCount = needs_review or has warnings (code generated but needs attention)
                if (failCount > 0) {
                    this.updateGenerationStatus('error', 'Failed');
                    this.showToast('Some mappings failed to convert', 'error');
                } else if (warningCount > 0) {
                    this.updateGenerationStatus('warning', 'Needs Review');
                    this.showToast('Code generated - review items flagged for attention', 'warning');
                } else {
                    this.updateGenerationStatus('completed', 'Completed');
                    this.showToast('Code generation completed successfully', 'success');
                }
                
                document.getElementById('startGenerateBtn').classList.add('hidden');
                document.getElementById('downloadGeneratedBtn').classList.remove('hidden');
                document.getElementById('newConversionBtn').classList.remove('hidden');
                
                // Populate right tabs with generation results
                this.populateRightTabsAfterGeneration();
                
            } else {
                throw new Error(result.error || 'Generation failed');
            }
        } catch (error) {
            // Mark all as failed on error
            for (let i = 0; i < totalMappings; i++) {
                this.updateMappingStatus(i, 'failed');
            }
            this.generationState.failed = totalMappings;
            this.updateProgress(0, totalMappings);
            
            this.addLog(`Generation failed`, 'error', 'Workflow', error.message);
            this.addLog('You can:', 'info', 'Workflow');
            this.addLog('  - Check your configuration settings', 'info', 'Workflow');
            this.addLog('  - Verify the XML file is valid', 'info', 'Workflow');
            this.addLog('  - Click "Start Generating" to retry', 'info', 'Workflow');
            this.updateGenerationStatus('error', 'Failed');
            this.showToast('Generation failed: ' + error.message, 'error');
        }
        
        this.generationState.isRunning = false;
        document.getElementById('startGenerateBtn').disabled = false;
    }
    
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    // Handler for download button on generate page
    downloadGeneratedCode() {
        if (this.generationState && this.generationState.result) {
            const artifactId = this.generationState.result.artifact_id;
            if (artifactId) {
                window.location.href = `/api/artifact/${artifactId}/download`;
            } else {
                this.showToast('No artifact available for download', 'error');
            }
        }
    }
    
    async generateCode() {
        // This is now handled by goToGeneratePage and startGeneration
        this.goToGeneratePage();
    }
    
    animateProgress() {
        const progressFill = document.getElementById('progressFill');
        const progressText = document.getElementById('progressText');
        
        const steps = [
            { progress: 20, text: 'Parsing mapping...' },
            { progress: 40, text: 'Building transformation graph...' },
            { progress: 60, text: 'Generating PySpark code...' },
            { progress: 80, text: 'Creating configuration files...' },
            { progress: 100, text: 'Finalizing...' }
        ];
        
        let stepIndex = 0;
        const interval = setInterval(() => {
            if (stepIndex < steps.length) {
                progressFill.style.width = steps[stepIndex].progress + '%';
                progressText.textContent = steps[stepIndex].text;
                stepIndex++;
            } else {
                clearInterval(interval);
            }
        }, 400);
    }
    
    displayGenerationResult(result) {
        document.getElementById('generationStatus').classList.add('hidden');
        document.getElementById('generationResult').classList.remove('hidden');
        
        document.getElementById('filesGenerated').textContent = result.files.length;
        
        // Calculate average coverage
        let coverage = 100;
        if (result.reports && result.reports.length > 0) {
            const totalCoverage = result.reports.reduce((sum, r) => sum + (r.coverage_percent || 100), 0);
            coverage = totalCoverage / result.reports.length;
        }
        document.getElementById('coveragePercent').textContent = coverage.toFixed(0);
        
        // Show summary if available
        const summaryEl = document.getElementById('generationSummary');
        if (summaryEl && this.generationState && this.generationState.summary) {
            const s = this.generationState.summary;
            if (s.failCount > 0 || s.warningCount > 0) {
                let summaryHtml = '<div class="generation-summary-alert">';
                summaryHtml += '<i class="fas fa-info-circle"></i> ';
                summaryHtml += `${s.successCount} mapping(s) generated successfully`;
                if (s.warningCount > 0) summaryHtml += `, ${s.warningCount} need review`;
                if (s.failCount > 0) summaryHtml += `, ${s.failCount} failed`;
                summaryHtml += '</div>';
                summaryEl.innerHTML = summaryHtml;
                summaryEl.classList.remove('hidden');
            } else {
                summaryEl.classList.add('hidden');
            }
        }
        
        // Store result for tab content loading
        this.currentGenerationResult = result;
        
        // Setup tab switching
        this.setupResultTabs();
        
        // Populate mappings tab
        this.populateMappingsTab(result);
        
        // Load workflow and config content
        this.loadWorkflowContent(result);
        this.loadConfigContent(result);
    }
    
    setupResultTabs() {
        // Guard to prevent duplicate event listeners
        if (this.resultTabsInitialized) return;
        this.resultTabsInitialized = true;
        
        const tabBtns = document.querySelectorAll('.result-tab-btn');
        tabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const tabName = btn.dataset.tab;
                
                // Update active button
                tabBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                // Update active content
                document.querySelectorAll('.result-tab-content').forEach(c => c.classList.remove('active'));
                document.getElementById(`${tabName}TabContent`).classList.add('active');
            });
        });
    }
    
    populateMappingsTab(result) {
        const mappingFiles = result.files.filter(f => f.filename.startsWith('mapping_'));
        const mappingsList = document.getElementById('mappingsList');
        
        // Update tab count
        document.getElementById('mappingsTabCount').textContent = mappingFiles.length;
        
        // Build report lookup
        const reportMap = {};
        if (result.reports) {
            result.reports.forEach(r => {
                reportMap[r.mapping_name] = r;
            });
        }
        
        // Get status from generation state
        const statusMap = {};
        if (this.generationState && this.generationState.mappingResults) {
            this.generationState.mappingResults.forEach(mr => {
                statusMap[mr.name] = mr.status;
            });
        }
        
        mappingsList.innerHTML = mappingFiles.map((file, idx) => {
            const mappingName = file.filename.replace('mapping_', '').replace('.py', '');
            const report = reportMap[mappingName] || {};
            const status = statusMap[mappingName] || 'success';
            
            // Determine status pill
            let statusPillClass = 'success';
            let statusPillText = 'Success';
            let statusIcon = 'check-circle';
            if (status === 'failed') {
                statusPillClass = 'error';
                statusPillText = 'Failed';
                statusIcon = 'times-circle';
            } else if (status === 'needs_review' || status === 'warning') {
                statusPillClass = 'warning';
                statusPillText = 'Needs Review';
                statusIcon = 'exclamation-triangle';
            }
            
            // Build log categories from report
            const logCategories = this.buildMappingLogCategories(report, mappingName);
            
            return `
                <div class="mapping-card" id="mappingCard${idx}" data-testid="mapping-card-${mappingName}">
                    <div class="mapping-card-header" onclick="app.toggleMappingCard(${idx})">
                        <div class="mapping-card-title">
                            <i class="fas fa-code-branch"></i>
                            <h3>${mappingName}</h3>
                        </div>
                        <div class="mapping-card-meta">
                            <span class="mapping-status-pill ${statusPillClass}">
                                <i class="fas fa-${statusIcon}"></i>
                                ${statusPillText}
                            </span>
                            <i class="fas fa-chevron-down mapping-expand-icon"></i>
                        </div>
                    </div>
                    <div class="mapping-card-body">
                        <div class="mapping-tabs">
                            <button class="mapping-tab-btn active" data-mapping="${idx}" data-subtab="code" onclick="app.switchMappingSubTab(${idx}, 'code')">
                                <i class="fas fa-file-code"></i> PySpark Code
                            </button>
                            <button class="mapping-tab-btn" data-mapping="${idx}" data-subtab="logs" onclick="app.switchMappingSubTab(${idx}, 'logs')">
                                <i class="fas fa-list-alt"></i> Conversion Log
                                ${logCategories.issueCount > 0 ? `<span class="log-count-badge warning">${logCategories.issueCount}</span>` : ''}
                            </button>
                        </div>
                        <div class="mapping-tab-content active" id="mappingCode${idx}">
                            <div class="code-viewer-header">
                                <div class="code-viewer-title">
                                    <i class="fas fa-fire"></i>
                                    <span>${file.filename}</span>
                                </div>
                                <button class="btn btn-sm btn-icon" onclick="app.copyMappingCode(${idx})" title="Copy to clipboard">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                            <pre class="code-viewer-content" id="mappingCodeContent${idx}"><code>Loading...</code></pre>
                        </div>
                        <div class="mapping-tab-content" id="mappingLogs${idx}">
                            ${logCategories.html}
                        </div>
                    </div>
                </div>
            `;
        }).join('');
        
        // Load code for each mapping
        mappingFiles.forEach((file, idx) => {
            this.loadMappingCode(file.filename, idx);
        });
    }
    
    buildMappingLogCategories(report, mappingName) {
        let html = '<div class="mapping-log-section">';
        let issueCount = 0;
        
        // Sources category
        const sources = report.sources || [];
        if (sources.length > 0) {
            html += `
                <div class="log-category">
                    <div class="log-category-header sources">
                        <i class="fas fa-database"></i>
                        <span>Sources</span>
                        <span class="log-count-badge info">${sources.length}</span>
                    </div>
                    <div class="log-entries">
                        ${sources.map(s => `
                            <div class="log-entry info">
                                <i class="fas fa-table"></i>
                                <span>${s.name} (${s.type || 'table'})</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }
        
        // Transformations category
        const transformations = report.transformations || [];
        if (transformations.length > 0) {
            html += `
                <div class="log-category">
                    <div class="log-category-header transformations">
                        <i class="fas fa-random"></i>
                        <span>Transformations</span>
                        <span class="log-count-badge info">${transformations.length}</span>
                    </div>
                    <div class="log-entries">
                        ${transformations.map(t => `
                            <div class="log-entry success">
                                <i class="fas fa-${this.getTransformIcon(t.type)}"></i>
                                <span>${t.name} <span style="opacity: 0.7">(${t.type})</span></span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }
        
        // Targets category
        const targets = report.targets || [];
        if (targets.length > 0) {
            html += `
                <div class="log-category">
                    <div class="log-category-header targets">
                        <i class="fas fa-bullseye"></i>
                        <span>Targets</span>
                        <span class="log-count-badge info">${targets.length}</span>
                    </div>
                    <div class="log-entries">
                        ${targets.map(t => `
                            <div class="log-entry success">
                                <i class="fas fa-table"></i>
                                <span>${t.name} (${t.type || 'table'})</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }
        
        // Issues category (warnings + errors)
        const warnings = report.warnings || [];
        const errors = report.errors || [];
        const manualItems = report.manual_items || [];
        const allIssues = [...errors, ...warnings, ...manualItems];
        issueCount = allIssues.length;
        
        if (allIssues.length > 0) {
            html += `
                <div class="log-category">
                    <div class="log-category-header issues">
                        <i class="fas fa-exclamation-triangle"></i>
                        <span>Issues & Notes</span>
                        <span class="log-count-badge warning">${allIssues.length}</span>
                    </div>
                    <div class="log-entries">
                        ${errors.map(e => `
                            <div class="log-entry error">
                                <i class="fas fa-times-circle"></i>
                                <div class="log-entry-content">
                                    <span class="log-message">${e.message}</span>
                                    ${e.details ? `<span class="log-details">${e.details}</span>` : ''}
                                </div>
                            </div>
                        `).join('')}
                        ${warnings.map(w => `
                            <div class="log-entry warning">
                                <i class="fas fa-exclamation-triangle"></i>
                                <div class="log-entry-content">
                                    <span class="log-message">${w.message}</span>
                                    ${w.details ? `<span class="log-details">${w.details}</span>` : ''}
                                </div>
                            </div>
                        `).join('')}
                        ${manualItems.map(m => `
                            <div class="log-entry info">
                                <i class="fas fa-info-circle"></i>
                                <div class="log-entry-content">
                                    <span class="log-message">${m.message}</span>
                                    ${m.details ? `<span class="log-details">${m.details}</span>` : ''}
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }
        
        // If no log entries at all
        if (sources.length === 0 && transformations.length === 0 && targets.length === 0 && allIssues.length === 0) {
            html += `
                <div class="log-entry success">
                    <i class="fas fa-check-circle"></i>
                    <span>Mapping converted successfully with no issues</span>
                </div>
            `;
        }
        
        html += '</div>';
        return { html, issueCount };
    }
    
    getTransformIcon(type) {
        const icons = {
            'Expression': 'function',
            'Filter': 'filter',
            'Lookup Procedure': 'search',
            'Joiner': 'code-branch',
            'Aggregator': 'layer-group',
            'Sorter': 'sort',
            'Router': 'route',
            'Union': 'object-group',
            'Update Strategy': 'edit',
            'Source Qualifier': 'database',
            'Mapplet': 'puzzle-piece'
        };
        return icons[type] || 'cog';
    }
    
    toggleMappingCard(idx) {
        const card = document.getElementById(`mappingCard${idx}`);
        card.classList.toggle('expanded');
    }
    
    switchMappingSubTab(mappingIdx, tabName) {
        const card = document.getElementById(`mappingCard${mappingIdx}`);
        
        // Update tab buttons
        card.querySelectorAll('.mapping-tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.subtab === tabName);
        });
        
        // Update tab content
        card.querySelectorAll('.mapping-tab-content').forEach(content => {
            content.classList.remove('active');
        });
        
        if (tabName === 'code') {
            document.getElementById(`mappingCode${mappingIdx}`).classList.add('active');
        } else {
            document.getElementById(`mappingLogs${mappingIdx}`).classList.add('active');
        }
    }
    
    async loadMappingCode(filename, idx) {
        try {
            const response = await fetch(`/api/artifact/${this.currentArtifactId}/file/${filename}`);
            if (response.ok) {
                const data = await response.json();
                document.getElementById(`mappingCodeContent${idx}`).innerHTML = `<code>${this.escapeHtml(data.content)}</code>`;
            }
        } catch (error) {
            console.error('Error loading mapping code:', error);
        }
    }
    
    async copyMappingCode(idx) {
        const codeEl = document.getElementById(`mappingCodeContent${idx}`);
        const code = codeEl.textContent;
        try {
            await navigator.clipboard.writeText(code);
            this.showToast('Code copied to clipboard', 'success');
        } catch (error) {
            this.showToast('Failed to copy code', 'error');
        }
    }
    
    async loadWorkflowContent(result) {
        const workflowFile = result.files.find(f => f.filename === 'workflow_orchestration.py');
        const codeEl = document.getElementById('workflowCodeContent');
        
        if (workflowFile) {
            try {
                const response = await fetch(`/api/artifact/${this.currentArtifactId}/file/${workflowFile.filename}`);
                if (response.ok) {
                    const data = await response.json();
                    codeEl.innerHTML = `<code>${this.escapeHtml(data.content)}</code>`;
                } else {
                    codeEl.innerHTML = `<code class="empty-state">Failed to load workflow content</code>`;
                }
            } catch (error) {
                console.error('Error loading workflow:', error);
                codeEl.innerHTML = `<code class="empty-state">Error loading workflow content</code>`;
            }
        } else {
            codeEl.innerHTML = `<code class="empty-state">Workflow orchestration was not generated.\nEnable "Generate Workflow Orchestration" option to include this file.</code>`;
        }
        
        // Setup copy button (only once)
        const copyBtn = document.getElementById('copyWorkflowBtn');
        if (copyBtn && !copyBtn.dataset.bound) {
            copyBtn.dataset.bound = 'true';
            copyBtn.addEventListener('click', async () => {
                const code = document.getElementById('workflowCodeContent').textContent;
                try {
                    await navigator.clipboard.writeText(code);
                    this.showToast('Workflow code copied', 'success');
                } catch (error) {
                    this.showToast('Failed to copy', 'error');
                }
            });
        }
    }
    
    async loadConfigContent(result) {
        const configFile = result.files.find(f => f.filename === 'config.yml');
        const codeEl = document.getElementById('configCodeContent');
        
        if (configFile) {
            try {
                const response = await fetch(`/api/artifact/${this.currentArtifactId}/file/${configFile.filename}`);
                if (response.ok) {
                    const data = await response.json();
                    codeEl.innerHTML = `<code>${this.escapeHtml(data.content)}</code>`;
                } else {
                    codeEl.innerHTML = `<code class="empty-state">Failed to load configuration content</code>`;
                }
            } catch (error) {
                console.error('Error loading config:', error);
                codeEl.innerHTML = `<code class="empty-state">Error loading configuration content</code>`;
            }
        } else {
            codeEl.innerHTML = `<code class="empty-state">Configuration file was not generated.</code>`;
        }
        
        // Setup copy button (only once)
        const copyBtn = document.getElementById('copyConfigBtn');
        if (copyBtn && !copyBtn.dataset.bound) {
            copyBtn.dataset.bound = 'true';
            copyBtn.addEventListener('click', async () => {
                const code = document.getElementById('configCodeContent').textContent;
                try {
                    await navigator.clipboard.writeText(code);
                    this.showToast('Config copied', 'success');
                } catch (error) {
                    this.showToast('Failed to copy', 'error');
                }
            });
        }
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    getFileIcon(fileType) {
        const icons = {
            python: 'file-code',
            yaml: 'file-alt',
            json: 'file-alt'
        };
        return icons[fileType] || 'file';
    }
    
    
    async viewFile(filename) {
        try {
            const response = await fetch(`/api/artifact/${this.artifactId}/file/${filename}`);
            const result = await response.json();
            
            if (result.success) {
                document.getElementById('codeModalTitle').textContent = filename;
                document.getElementById('codeContent').textContent = result.content;
                document.getElementById('codeModal').classList.add('active');
            } else {
                this.showToast('Failed to load file', 'error');
            }
        } catch (error) {
            console.error('Error loading file:', error);
            this.showToast('Failed to load file', 'error');
        }
    }
    
    closeModal() {
        document.getElementById('codeModal').classList.remove('active');
    }
    
    copyCode() {
        const code = document.getElementById('codeContent').textContent;
        navigator.clipboard.writeText(code).then(() => {
            this.showToast('Code copied to clipboard', 'success');
        }).catch(() => {
            this.showToast('Failed to copy code', 'error');
        });
    }
    
    downloadZip() {
        if (!this.artifactId) return;
        
        window.location.href = `/api/artifact/${this.artifactId}/download`;
    }
    
    switchTab(tabName) {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabName);
        });
        
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.toggle('active', content.id === tabName + 'Tab');
        });
    }
    
    switchEtlSubTab(tabName) {
        document.querySelectorAll('.etl-sub-tab').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.etlTab === tabName);
        });
        
        const tabIdMap = {
            'sources': 'etlSourcesContent',
            'targets': 'etlTargetsContent',
            'transforms': 'etlTransformsContent'
        };
        
        document.querySelectorAll('.etl-sub-content').forEach(content => {
            content.classList.toggle('active', content.id === tabIdMap[tabName]);
        });
    }
    
    switchConfigSubTab(tabName) {
        document.querySelectorAll('.config-sub-tab').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.configTab === tabName);
        });
        
        const tabIdMap = {
            'sqlqueries': 'configSqlqueriesContent',
            'configs': 'configConfigsContent',
            'connectors': 'configConnectorsContent'
        };
        
        document.querySelectorAll('.config-sub-content').forEach(content => {
            content.classList.toggle('active', content.id === tabIdMap[tabName]);
        });
    }
    
    goToStep(step) {
        for (let i = 1; i < step; i++) {
            document.querySelector(`.step-item[data-step="${i}"]`).classList.add('completed');
        }
        
        document.querySelectorAll('.step-item').forEach(item => {
            const itemStep = parseInt(item.dataset.step);
            item.classList.toggle('active', itemStep === step);
        });
        
        document.querySelectorAll('.step-panel').forEach(panel => {
            panel.classList.remove('active');
        });
        document.getElementById(`step${step}Panel`).classList.add('active');
        
        // Toggle generate-mode class on content-area for full-width layout
        const contentArea = document.querySelector('.content-area');
        if (contentArea) {
            contentArea.classList.toggle('generate-mode', step === 4);
        }
        
        this.updateFileBadges();
        
        this.currentStep = step;
    }
    
    updateFileBadges() {
        const fileName = this.selectedFile ? this.selectedFile.name : '';
        
        const badges = [
            { id: 'step2FileName', badgeId: 'step2FileBadge' },
            { id: 'step3FileName', badgeId: 'step3FileBadge' },
            { id: 'step4FileName', badgeId: 'step4FileBadge' }
        ];
        
        badges.forEach(({ id, badgeId }) => {
            const nameEl = document.getElementById(id);
            const badgeEl = document.getElementById(badgeId);
            if (nameEl && badgeEl) {
                if (fileName) {
                    nameEl.textContent = fileName;
                    if (badgeId == 'step2FileBadge') {
                        badgeEl.style.display = 'block';
                    }
                    else {
                        badgeEl.style.display = 'inline-flex';
                    }
                
                   
                } else {
                    badgeEl.style.display = 'none';
                }
            }
        });
    }
    
    startOver() {
        this.currentStep = 1;
        this.artifactId = null;
        this.analysisData = null;
        this.selectedFile = null;
        this.userConfig = {
            sources: [],
            targets: [],
            db_connections: {}
        };
        
        document.getElementById('fileInput').value = '';
        document.getElementById('fileInfo').classList.add('hidden');
        document.getElementById('analyzeBtn').disabled = true;
        
        document.querySelectorAll('.step-item').forEach(item => {
            item.classList.remove('active', 'completed');
        });
        document.querySelector('.step-item[data-step="1"]').classList.add('active');
        
        document.querySelectorAll('.step-panel').forEach(panel => {
            panel.classList.remove('active');
        });
        document.getElementById('step1Panel').classList.add('active');
    }
    
    startNewConversion() {
        // Refresh the page to start a completely new conversion
        window.location.reload();
    }
    
    setStatus(status, text) {
        const badge = document.getElementById('statusBadge');
        badge.dataset.status = status;
        badge.querySelector('.status-text').textContent = text;
    }
    
    showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        const icons = {
            success: 'check-circle',
            error: 'times-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        
        toast.innerHTML = `
            <i class="fas fa-${icons[type]} toast-icon"></i>
            <span class="toast-message">${message}</span>
            <button class="toast-close" onclick="this.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.remove();
        }, 5000);
    }
}

const app = new App();
