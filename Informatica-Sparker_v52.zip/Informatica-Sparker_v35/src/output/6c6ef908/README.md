# m_landing_brightscope_advisor_external_id_delta - PySpark Conversion

This code was auto-generated from Informatica PowerCenter XML by the Informatica to PySpark Converter.

## 1. Environment Variables Setup

### PowerShell
```powershell
# Required environment variables (MSSQL for both source and target)
$env:MSSQL_HOST='your_server.com\INSTANCE'
$env:MSSQL_USER='spark_user'
$env:MSSQL_PASSWORD='your_mssql_password'
$env:MSSQL_DRIVER_JAR='C:/Drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
$env:SRC_SYSTEM_NM='SSC'
$env:ENV_NAME='development'
$env:LOG_LEVEL='INFO'
```

### Bash/Linux
```bash
# Required environment variables (MSSQL for both source and target)
export MSSQL_HOST='your_server.com\INSTANCE'
export MSSQL_USER='spark_user'
export MSSQL_PASSWORD='your_mssql_password'
export MSSQL_DRIVER_JAR='/opt/drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
export SRC_SYSTEM_NM='SSC'
export ENV_NAME='development'
export LOG_LEVEL='INFO'
```

## 2. Target Table Schema

### Target: C_LDG_PARTY_EXTERNAL_ID (Database: msscdm_dev3)

```sql
-- MSSQL CREATE TABLE syntax
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C_LDG_PARTY_EXTERNAL_ID]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[C_LDG_PARTY_EXTERNAL_ID] (
        [SRC_ROWID] BIGINT IDENTITY(1,1) NOT NULL,
        [CREATED_DATE] DATETIME2 NULL,
        [CREATED_BY] NVARCHAR(50) NULL,
        [LAST_UPDATED_DATE] DATETIME2 NULL,
        [LAST_UPDATED_BY] NVARCHAR(50) NULL,
        [DELETED_INDICATOR] NCHAR(1) NULL,
        [SOURCE_EXTENAL_IDENTIFIER_ID] NVARCHAR(255) NULL,
        [SOURCE_PARTY_ID] NVARCHAR(255) NULL,
        [EXTERNAL_IDENTIFIER_TYPE_ID] BIGINT NULL,
        [EXTERNAL_IDENTIFIER_VALUE] NVARCHAR(32) NULL,
        [SOURCE_SYSTEM] NVARCHAR(50) NULL,
        [PARENT_SOURCE_SYSTEM] NVARCHAR(50) NULL,
        [DEFERRED_OWNERSHIP_IND] NCHAR(1) NULL,
        [EXT_IDENTIFIER_STATUS_IND] NCHAR(1) NULL,
        [SURV_ASST_CODE_C] NVARCHAR(3) NULL
    )
END
```

## 3. What is $$SRC_SYSTEM_NM?

`$$SRC_SYSTEM_NM` is an Informatica runtime parameter used in mapping/workflow sessions.

**How to find the value:**
1. Open Workflow Manager
2. Open the workflow
3. In the Session task -> Properties / Config Object, check the Parameter File path
4. Open that `.par` file and search for `SRC_SYSTEM_NM`

In this config, the default is set to `SSC`. Override via environment variable if needed:
```powershell
$env:SRC_SYSTEM_NM='YOUR_VALUE'
```

## 4. How to Run

### Quick Run (config in same folder)
```bash
python m_landing_brightscope_advisor_external_id_delta.py
```

### With custom config path
```powershell
$env:CONFIG_PATH='C:\path\to\config_m_landing_brightscope_advisor_external_id_delta.yml'
python m_landing_brightscope_advisor_external_id_delta.py
```

## 5. Files Generated

- `m_landing_brightscope_advisor_external_id_delta.py` - Main PySpark mapping code
- `config_m_landing_brightscope_advisor_external_id_delta.yml` - Configuration file with environment variables
- `README.md` - This documentation file

## 6. Notes

- Passwords with special characters (like `$`, `@`, `*`) must use single quotes in PowerShell
- The `SRC_ROWID` column is typically set as IDENTITY in MSSQL if not mapped from source
- Target database is fixed as msscdm_dev3
- Review and test the generated code before production use
