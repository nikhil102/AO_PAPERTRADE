"""Workflow Builder - converts workflow XML to Job DAG orchestration."""
from typing import Dict, List, Any, Optional
from .ir import WorkflowDAG, WorkflowSession
from .models import MappingDefinition


class WorkflowBuilder:
    """Builds workflow orchestration DAG from parsed workflow data."""
    
    def __init__(self, workflow_data: Dict[str, Any], mappings: List[MappingDefinition]):
        self.workflow_data = workflow_data
        self.mappings = mappings
        self.mapping_map = {m.name: m for m in mappings}
    
    def build(self) -> Optional[WorkflowDAG]:
        """Build WorkflowDAG from workflow data."""
        if not self.workflow_data:
            return None
        
        workflow_name = self.workflow_data.get("workflow_name", "workflow")
        
        dag = WorkflowDAG(workflow_name=workflow_name)
        
        sessions = self.workflow_data.get("sessions", [])
        for session_data in sessions:
            session = self._build_session(session_data)
            dag.add_session(session)
        
        tasks = self.workflow_data.get("tasks", [])
        for task_data in tasks:
            if task_data.get("type") == "SESSION":
                continue
            session = self._build_task(task_data)
            dag.add_session(session)
        
        dag.execution_order = self._determine_execution_order(dag)
        
        dag.variables = self._extract_variables()
        
        return dag
    
    def _build_session(self, session_data: Dict[str, Any]) -> WorkflowSession:
        """Build WorkflowSession from session data."""
        name = session_data.get("name", "")
        mapping_name = session_data.get("mapping_name", "")
        
        session = WorkflowSession(
            name=name,
            session_type="session",
            mapping_name=mapping_name
        )
        
        components = session_data.get("components", [])
        for comp in components:
            comp_type = comp.get("type", "")
            
            if comp_type == "Pre Session Command":
                sql = comp.get("value", "")
                if sql:
                    session.pre_sql.append(sql)
            elif comp_type == "Post Session Command":
                sql = comp.get("value", "")
                if sql:
                    session.post_sql.append(sql)
            elif comp_type == "Pre Session SQL":
                sql = comp.get("sql", "")
                if sql:
                    session.pre_sql.append(sql)
            elif comp_type == "Post Session SQL":
                sql = comp.get("sql", "")
                if sql:
                    session.post_sql.append(sql)
        
        attrs = session_data.get("attributes", {})
        for key, value in attrs.items():
            session.parameters[key] = value
        
        return session
    
    def _build_task(self, task_data: Dict[str, Any]) -> WorkflowSession:
        """Build WorkflowSession from non-session task."""
        name = task_data.get("name", "")
        task_type = task_data.get("type", "COMMAND").lower()
        
        session = WorkflowSession(
            name=name,
            session_type=task_type
        )
        
        if task_type == "command":
            cmd = task_data.get("command", "")
            session.parameters["command"] = cmd
        
        return session
    
    def _determine_execution_order(self, dag: WorkflowDAG) -> List[str]:
        """Determine execution order from links/dependencies."""
        order = []
        links = self.workflow_data.get("links", [])
        
        deps = {}
        for session in dag.sessions:
            deps[session.name] = []
        
        for link in links:
            from_task = link.get("from_task", "")
            to_task = link.get("to_task", "")
            condition = link.get("condition", "")
            
            if to_task in deps:
                deps[to_task].append(from_task)
                
            for session in dag.sessions:
                if session.name == to_task:
                    session.dependencies.append(from_task)
                    if "fail" in condition.lower():
                        session.on_failure.append(from_task)
                    else:
                        session.on_success.append(from_task)
        
        visited = set()
        temp_order = []
        
        def visit(name):
            if name in visited:
                return
            visited.add(name)
            for dep in deps.get(name, []):
                if dep not in visited:
                    visit(dep)
            temp_order.append(name)
        
        for session in dag.sessions:
            visit(session.name)
        
        return temp_order
    
    def _extract_variables(self) -> Dict[str, str]:
        """Extract workflow variables."""
        variables = {}
        
        attrs = self.workflow_data.get("attributes", {})
        for key, value in attrs.items():
            if key.startswith("$$") or key.startswith("$"):
                variables[key] = str(value)
        
        return variables
    
    def generate_orchestration_code(self, dag: WorkflowDAG) -> str:
        """Generate PySpark orchestration code from DAG."""
        lines = []
        
        lines.append('"""')
        lines.append(f'Workflow Orchestration: {dag.workflow_name}')
        lines.append('Auto-generated by Informatica XML to PySpark Converter')
        lines.append('"""')
        lines.append('')
        lines.append('from pyspark.sql import SparkSession')
        lines.append('import yaml')
        lines.append('import logging')
        lines.append('from datetime import datetime')
        lines.append('')
        lines.append('')
        lines.append('logging.basicConfig(level=logging.INFO)')
        lines.append('logger = logging.getLogger(__name__)')
        lines.append('')
        lines.append('')
        lines.append('class WorkflowContext:')
        lines.append('    """Context for workflow execution."""')
        lines.append('    def __init__(self, spark: SparkSession, config: dict):')
        lines.append('        self.spark = spark')
        lines.append('        self.config = config')
        lines.append('        self.variables = {}')
        lines.append('        self.row_counts = {}')
        lines.append('        self.status = {}')
        lines.append('')
        lines.append('')
        
        for session in dag.sessions:
            lines.extend(self._generate_session_function(session))
            lines.append('')
        
        lines.append('')
        lines.append('def main():')
        lines.append('    """Main workflow entry point."""')
        lines.append(f'    spark = SparkSession.builder.appName("{dag.workflow_name}").getOrCreate()')
        lines.append('    ')
        lines.append('    with open("config.yaml", "r") as f:')
        lines.append('        config = yaml.safe_load(f)')
        lines.append('    ')
        lines.append('    ctx = WorkflowContext(spark, config)')
        lines.append('    ')
        lines.append(f'    logger.info("Starting workflow: {dag.workflow_name}")')
        lines.append('    start_time = datetime.now()')
        lines.append('    ')
        
        for session_name in dag.execution_order:
            session = next((s for s in dag.sessions if s.name == session_name), None)
            if session:
                lines.append(f'    # Execute: {session_name}')
                lines.append(f'    try:')
                lines.append(f'        ctx.status["{session_name}"] = run_{self._safe_name(session_name)}(ctx)')
                lines.append(f'        logger.info(f"{session_name} completed with status: {{ctx.status[\'{session_name}\']}}")')
                lines.append(f'    except Exception as e:')
                lines.append(f'        ctx.status["{session_name}"] = "FAILED"')
                lines.append(f'        logger.error(f"{session_name} failed: {{e}}")')
                lines.append(f'        raise')
                lines.append('    ')
        
        lines.append('    end_time = datetime.now()')
        lines.append('    duration = (end_time - start_time).total_seconds()')
        lines.append(f'    logger.info(f"Workflow {dag.workflow_name} completed in {{duration:.2f}} seconds")')
        lines.append('    ')
        lines.append('    spark.stop()')
        lines.append('    return ctx.status')
        lines.append('')
        lines.append('')
        lines.append('if __name__ == "__main__":')
        lines.append('    main()')
        
        return '\n'.join(lines)
    
    def _generate_session_function(self, session: WorkflowSession) -> List[str]:
        """Generate function for a session."""
        lines = []
        safe_name = self._safe_name(session.name)
        
        lines.append(f'def run_{safe_name}(ctx: WorkflowContext) -> str:')
        lines.append(f'    """Execute session: {session.name}"""')
        lines.append(f'    logger.info("Starting session: {session.name}")')
        lines.append('    ')
        
        if session.pre_sql:
            lines.append('    # Pre-session SQL')
            for i, sql in enumerate(session.pre_sql):
                escaped_sql = sql.replace('"', '\\"').replace('\n', ' ')
                lines.append(f'    # Pre-SQL {i+1}: {escaped_sql[:50]}...')
        
        if session.session_type == "session" and session.mapping_name:
            lines.append(f'    # Run mapping: {session.mapping_name}')
            lines.append(f'    from job_{session.mapping_name} import main as run_mapping')
            lines.append(f'    run_mapping()')
        elif session.session_type == "command":
            cmd = session.parameters.get("command", "")
            lines.append(f'    # Execute command')
            lines.append(f'    import subprocess')
            lines.append(f'    subprocess.run("{cmd}", shell=True, check=True)')
        else:
            lines.append(f'    # TODO: Implement {session.session_type} logic')
            lines.append(f'    pass')
        
        if session.post_sql:
            lines.append('    ')
            lines.append('    # Post-session SQL')
            for i, sql in enumerate(session.post_sql):
                escaped_sql = sql.replace('"', '\\"').replace('\n', ' ')
                lines.append(f'    # Post-SQL {i+1}: {escaped_sql[:50]}...')
        
        lines.append('    ')
        lines.append('    return "SUCCESS"')
        
        return lines
    
    def _safe_name(self, name: str) -> str:
        """Convert name to safe Python identifier."""
        import re
        safe = re.sub(r'[^a-zA-Z0-9_]', '_', name)
        if safe[0].isdigit():
            safe = '_' + safe
        return safe.lower()
