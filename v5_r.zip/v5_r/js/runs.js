// ADLC Runs & Logs History Controller

let activeFilter = 'all';
let searchQuery = '';

document.addEventListener('DOMContentLoaded', () => {
  renderRuns();
  setupFilters();
  setupSearch();
  checkDeepLink();
});

// Render runs database items
function renderRuns() {
  const tbody = document.getElementById('runs-table-tbody');
  if (!tbody) return;
  
  const runs = db.getRuns();
  
  // Filter runs
  const filtered = runs.filter(run => {
    const matchesFilter = activeFilter === 'all' || run.status === activeFilter;
    const matchesSearch = run.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          run.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          run.triggeredBy.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });
  
  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding: 32px; color:var(--color-text-muted);">No execution runs match your criteria.</td></tr>`;
    return;
  }
  
  tbody.innerHTML = filtered.map(run => {
    let statusClass = 'success';
    if (run.status === 'failed') statusClass = 'danger';
    if (run.status === 'running') statusClass = 'warning';
    
    return `
      <tr style="cursor:pointer;" onclick="openDrawer('${run.id}')">
        <td style="font-weight: 700; font-family: monospace; color: var(--color-primary);">${run.id}</td>
        <td style="font-weight: 500;">${run.name}</td>
        <td style="color: var(--color-text-muted);">${run.date}</td>
        <td>${run.duration}</td>
        <td style="font-weight: 600;">${run.cost}</td>
        <td>
          <span class="status-badge ${statusClass}">${run.status}</span>
        </td>
        <td style="color: var(--color-text-muted); font-size:13px;">${run.triggeredBy}</td>
        <td style="text-align:right;">
          <button class="btn btn-secondary btn-sm" onclick="event.stopPropagation(); openDrawer('${run.id}')">View Logs</button>
        </td>
      </tr>
    `;
  }).join('');
}

// Filter tabs clicking triggers
function setupFilters() {
  const filterBtns = document.querySelectorAll('.runs-filters .btn-filter');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeFilter = btn.getAttribute('data-filter');
      renderRuns();
    });
  });
}

// Search input mapping
function setupSearch() {
  const searchBar = document.getElementById('runs-search-bar');
  if (searchBar) {
    searchBar.addEventListener('input', (e) => {
      searchQuery = e.target.value;
      renderRuns();
    });
  }
}

// Check if URL parameters deep links to a specific run
function checkDeepLink() {
  const params = new URLSearchParams(window.location.search);
  if (params.has('runId')) {
    const runId = params.get('runId');
    setTimeout(() => {
      openDrawer(runId);
    }, 400);
  }
}

// Open log details drawer
function openDrawer(runId) {
  const drawer = document.getElementById('run-details-drawer');
  if (!drawer) return;
  
  const runs = db.getRuns();
  const run = runs.find(r => r.id === runId);
  if (!run) {
    showToast(`Run ${runId} not found in historical records.`, 'error');
    return;
  }
  
  // Fill details
  document.getElementById('drawer-run-id').textContent = run.id;
  document.getElementById('drawer-run-name').textContent = run.name;
  document.getElementById('drawer-duration').textContent = run.duration;
  document.getElementById('drawer-cost').textContent = run.cost;
  document.getElementById('drawer-triggered-by').textContent = run.triggeredBy;
  document.getElementById('drawer-date').textContent = run.date;
  
  // Status badge style
  const statusBadge = document.getElementById('drawer-status-badge');
  if (statusBadge) {
    let badgeClass = 'success';
    if (run.status === 'failed') badgeClass = 'danger';
    if (run.status === 'running') badgeClass = 'warning';
    
    statusBadge.className = `status-badge ${badgeClass}`;
    statusBadge.textContent = run.status;
  }
  
  // Logs stream mock generation
  const logsContainer = document.getElementById('drawer-logs-console');
  if (logsContainer) {
    if (run.status === 'failed') {
      logsContainer.innerHTML = `
<span style="color:#94a3b8;">[${run.date}:01]</span> <span style="color:#a855f7;">INFO: [Analyst]</span> Objective extracted successfully.
<span style="color:#94a3b8;">[${run.date}:02]</span> <span style="color:#a855f7;">INFO: [Validator]</span> Validating connector access rights...
<span style="color:#94a3b8;">[${run.date}:03]</span> <span style="color:#a855f7;">INFO: [Validator]</span> Connection verified for Databricks cluster.
<span style="color:#94a3b8;">[${run.date}:05]</span> <span style="color:#a855f7;">INFO: [PlanBuilder]</span> Setup automation manifest: databricks_monitoring.yaml
<span style="color:#94a3b8;">[${run.date}:08]</span> <span style="color:#f43f5e;">ERROR: [Executor]</span> Action failed at step 4 (Write access verification failed).
<span style="color:#94a3b8;">[${run.date}:09]</span> <span style="color:#a855f7;">INFO: [Auditor]</span> Initiating automated rollback triggers...
<span style="color:#94a3b8;">[${run.date}:11]</span> <span style="color:#22c55e;">SUCCESS: [Auditor]</span> Workspace restored to safe configuration state.
      `;
    } else if (run.status === 'running') {
      logsContainer.innerHTML = `
<span style="color:#94a3b8;">[${run.date}:01]</span> <span style="color:#a855f7;">INFO: [Analyst]</span> Objective extracted successfully.
<span style="color:#94a3b8;">[${run.date}:02]</span> <span style="color:#a855f7;">INFO: [Validator]</span> Validating target connector tokens...
<span style="color:#94a3b8;">[${run.date}:04]</span> <span style="color:#eab308;">WARN: [Validator]</span> Token expires in 12 hours. Proceeding...
<span style="color:#94a3b8;">[${run.date}:05]</span> <span style="color:#a855f7;">INFO: [Executor]</span> Executing target plan manifest: AWS stage bucket provisioning...
      `;
    } else {
      logsContainer.innerHTML = `
<span style="color:#94a3b8;">[${run.date}:01]</span> <span style="color:#a855f7;">INFO: [Analyst]</span> Objective extracted successfully.
<span style="color:#94a3b8;">[${run.date}:03]</span> <span style="color:#a855f7;">INFO: [Validator]</span> Validating connector access rights... OK.
<span style="color:#94a3b8;">[${run.date}:04]</span> <span style="color:#a855f7;">INFO: [Discovery]</span> Database schemas catalog mapped successfully.
<span style="color:#94a3b8;">[${run.date}:06]</span> <span style="color:#a855f7;">INFO: [PlanBuilder]</span> Automation manifest yaml blueprint generated.
<span style="color:#94a3b8;">[${run.date}:10]</span> <span style="color:#a855f7;">INFO: [Executor]</span> Creating staging integration link. Response status: 201 Created.
<span style="color:#94a3b8;">[${run.date}:14]</span> <span style="color:#22c55e;">SUCCESS: [Executor]</span> Process completed successfully in ${run.duration}.
<span style="color:#94a3b8;">[${run.date}:15]</span> <span style="color:#a855f7;">INFO: [Auditor]</span> Audited cost logs archived: ${run.cost} consumed.
      `;
    }
  }
  
  // Artifacts generation
  const artifactsContainer = document.getElementById('drawer-artifacts-list');
  if (artifactsContainer) {
    if (run.status === 'failed') {
      artifactsContainer.innerHTML = `<span style="font-size:12px; color:var(--color-text-muted); font-style:italic;">No output artifacts generated due to execution fail.</span>`;
    } else {
      const sanitizedId = run.id.toLowerCase();
      artifactsContainer.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; border:1px solid var(--color-border); border-radius:var(--border-radius-sm); padding:10px 14px; font-size:13px; background-color:var(--bg-main);">
          <span>📄 adlc-audit-${sanitizedId}.json</span>
          <button class="btn btn-secondary btn-sm" onclick="showToast('Downloading artifact audit json...', 'success')">Download</button>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; border:1px solid var(--color-border); border-radius:var(--border-radius-sm); padding:10px 14px; font-size:13px; background-color:var(--bg-main);">
          <span>📄 report-diagnostics-${sanitizedId}.pdf</span>
          <button class="btn btn-secondary btn-sm" onclick="showToast('Downloading artifact PDF report...', 'success')">Download</button>
        </div>
      `;
    }
  }
  
  drawer.classList.add('active');
}

function closeDrawer() {
  const drawer = document.getElementById('run-details-drawer');
  if (drawer) drawer.classList.remove('active');
  
  // Clean URL parameters if deep linked
  const url = new URL(window.location);
  if (url.searchParams.has('runId')) {
    url.searchParams.delete('runId');
    window.history.pushState({}, '', url);
  }
}
