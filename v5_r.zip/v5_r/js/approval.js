// ADLC Approval Center Controller

document.addEventListener('DOMContentLoaded', () => {
  renderApprovals();
});

function renderApprovals() {
  const container = document.getElementById('approvals-cards-container');
  if (!container) return;
  
  const approvals = db.getApprovals();
  
  if (approvals.length === 0) {
    container.innerHTML = `
      <div style="text-align:center; padding: 60px 24px; background-color: var(--bg-card); border: 1px solid var(--color-border); border-radius: var(--border-radius); max-width: 600px; margin: 40px auto; box-shadow: var(--shadow-sm);">
        <div style="font-size: 48px; margin-bottom: 16px;">🎉</div>
        <h2 style="font-size: 20px; font-weight:700; margin-bottom: 6px;">All Approvals Cleared</h2>
        <p style="color: var(--color-text-muted); font-size:14px;">There are no pending execution requests requiring manual authorization at this time.</p>
        <button class="btn btn-primary" style="margin-top: 20px;" onclick="navigateTo('ai-chat.html')">Create New Automation</button>
      </div>
    `;
    return;
  }
  
  container.innerHTML = approvals.map(app => {
    let riskClass = 'warning';
    if (app.riskLevel === 'high' || app.riskLevel === 'critical') riskClass = 'danger';
    if (app.riskLevel === 'low') riskClass = 'success';
    
    return `
      <div class="card" id="approval-card-${app.id}" style="margin-bottom: 24px;">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:12px;">
          <div>
            <div style="display:flex; align-items:center; gap:10px; margin-bottom:6px;">
              <span style="font-family:monospace; font-weight:700; font-size:13px; color:var(--color-primary);">${app.id}</span>
              <span class="status-badge ${riskClass}" style="font-size:10px; font-weight:700; text-transform:uppercase;">${app.riskLevel} Risk</span>
              <span class="status-badge info" style="font-size:10px; font-weight:700;">${app.env}</span>
            </div>
            <h3 style="font-size:18px; font-weight:700; margin-bottom:8px;">${app.requirement}</h3>
          </div>
          
          <div style="font-size:12px; color:var(--color-text-muted); text-align:right;">
            <div>Requested by: <strong>${app.requestor}</strong></div>
            <div style="margin-top:2px;">Created: ${app.created}</div>
          </div>
        </div>
        
        <div class="approval-card-details">
          <div>
            <strong style="font-size:13px; display:block; margin-bottom:6px; color:var(--color-text-dark)">Automation Plan Summary:</strong>
            <p style="font-size:13px; color:var(--color-text-muted); line-height:1.5;">${app.summary}</p>
          </div>
          
          <div style="background-color: var(--bg-main); border:1px solid var(--color-border); border-radius: var(--border-radius-sm); padding:12px; font-size:12px;">
            <div style="margin-bottom:6px;"><strong>Target Systems:</strong> ${app.systems.join(', ')}</div>
            <div style="margin-bottom:6px;"><strong>Est. Cloud Cost:</strong> $0.25 - $0.50</div>
            <div><strong>Rollback:</strong> Automatic (cloud state)</div>
          </div>
        </div>
        
        <div class="approval-action-bar">
          <button class="btn btn-secondary" onclick="requestChanges('${app.id}')">Request Changes</button>
          <button class="btn btn-danger" onclick="rejectApproval('${app.id}')">Reject Plan</button>
          <button class="btn btn-success" onclick="approveApproval('${app.id}')">Approve & Execute</button>
        </div>
      </div>
    `;
  }).join('');
}

function approveApproval(id) {
  const approvals = db.getApprovals();
  const app = approvals.find(a => a.id === id);
  if (!app) return;
  
  // 1. Remove from approvals
  db.removeApproval(id);
  
  // 2. Add run log in history
  const runId = `RUN-${Math.floor(Math.random()*9000 + 1000)}`;
  const run = {
    id: runId,
    name: app.requirement,
    date: new Date().toISOString().replace('T', ' ').substring(0, 16),
    duration: '2m 10s',
    cost: '$0.35',
    status: 'success',
    triggeredBy: `${app.requestor} (Auth)`
  };
  db.addRun(run);
  
  showToast(`Authorized authorization ${id}. Run triggered as ${runId}`, 'success');
  renderApprovals();
}

function rejectApproval(id) {
  if (!confirm(`Are you sure you want to reject and cancel authorization request ${id}?`)) return;
  
  db.removeApproval(id);
  showToast(`Orchestration plan ${id} rejected and cancelled.`, 'error');
  renderApprovals();
}

function requestChanges(id) {
  const note = prompt('Specify plan adjustment details:');
  if (note === null) return; // cancel
  
  db.removeApproval(id);
  showToast(`Change requests logged for ${id}: "${note}"`, 'warning');
  renderApprovals();
}
