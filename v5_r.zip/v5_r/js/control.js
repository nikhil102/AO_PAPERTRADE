// ADLC Control Panel Controller

let metricsInterval = null;

document.addEventListener('DOMContentLoaded', () => {
  renderControlState();
  startMetricsSimulation();
});

// Render the entire Control page components
function renderControlState() {
  const control = db.getControl();
  if (!control) return;

  // 1. Render Whitelisted IPs
  renderIPWhitelist(control.whitelistIPs || []);

  // 2. Render Engine Status Card
  updateEngineStatusCard(control.engineStatus);

  // 3. Render Gauges and Stats
  updateGauges(control.cpu, control.mem);
  document.getElementById('stat-threads').textContent = control.threads || 4;
  document.getElementById('stat-sandboxes').textContent = control.sandboxes || 12;
}

// Render IP whitelist badges list
function renderIPWhitelist(ips) {
  const container = document.getElementById('ip-whitelist-container');
  if (!container) return;

  if (ips.length === 0) {
    container.innerHTML = `<span style="font-size:12px; color:var(--color-text-muted); font-style:italic;">No IP whitelists rules configured. All ports restricted.</span>`;
    return;
  }

  container.innerHTML = ips.map((ip, idx) => `
    <span style="display:inline-flex; align-items:center; gap:6px; background:rgba(79, 99, 246, 0.08); border:1px solid rgba(79, 99, 246, 0.15); color:var(--color-primary); font-family:monospace; font-size:12px; font-weight:700; padding:6px 12px; border-radius:4px;" class="ip-badge-item">
      🌐 ${ip}
      <button style="background:transparent; border:none; color:var(--color-error); cursor:pointer; font-weight:700; font-size:14px; margin-left:4px; line-height:1;" onclick="removeIPAddress(${idx})">&times;</button>
    </span>
  `).join('');
}

// Add a new IP address
function submitNewIP() {
  const input = document.getElementById('input-new-ip');
  if (!input) return;

  const value = input.value.trim();
  if (!value) {
    showToast('Please enter an IP address.', 'warning');
    return;
  }

  // IPv4 validation regex
  const ipRegex = /^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (!ipRegex.test(value)) {
    showToast('Invalid IPv4 address format.', 'error');
    return;
  }

  const control = db.getControl();
  if (!control.whitelistIPs) control.whitelistIPs = [];

  if (control.whitelistIPs.includes(value)) {
    showToast('IP address is already whitelisted.', 'warning');
    return;
  }

  control.whitelistIPs.push(value);
  db.saveControl(control);
  input.value = '';
  renderControlState();
  showToast(`Security rule added: ${value} whitelisted`, 'success');
}

// Remove an IP address
function removeIPAddress(index) {
  const control = db.getControl();
  if (!control.whitelistIPs) return;

  const removed = control.whitelistIPs.splice(index, 1);
  db.saveControl(control);
  renderControlState();
  showToast(`IP Whitelist rule removed: ${removed[0]}`, 'info');
}

// Update the layout styles for Engine status card
function updateEngineStatusCard(status) {
  const card = document.getElementById('engine-status-console-card');
  const txt = document.getElementById('engine-status-text');
  const dot = document.getElementById('engine-status-dot');
  const btn = document.getElementById('btn-engine-toggle');

  if (!card || !txt || !dot || !btn) return;

  if (status === 'Running') {
    card.style.borderLeftColor = 'var(--color-success)';
    card.style.backgroundColor = 'rgba(16, 185, 129, 0.02)';
    txt.innerHTML = `<span class="status-dot success" id="engine-status-dot"></span>Running`;
    btn.textContent = 'Pause Engine';
    btn.className = 'btn btn-danger btn-sm';
  } else {
    card.style.borderLeftColor = 'var(--color-warning)';
    card.style.backgroundColor = 'rgba(245, 158, 11, 0.02)';
    txt.innerHTML = `<span class="status-dot orange" id="engine-status-dot"></span>Paused`;
    btn.textContent = 'Resume Engine';
    btn.className = 'btn btn-success btn-sm';
  }
}

// Toggle Engine status between Running and Paused
function toggleEngineState() {
  const control = db.getControl();
  if (!control) return;

  const currentStatus = control.engineStatus;
  const nextStatus = currentStatus === 'Running' ? 'Paused' : 'Running';

  control.engineStatus = nextStatus;
  db.saveControl(control);

  updateEngineStatusCard(nextStatus);
  showToast(`Orchestration Engine ${nextStatus === 'Running' ? 'resumed operational queues ✓' : 'paused in memory buffer ⚠️'}`, nextStatus === 'Running' ? 'success' : 'warning');
}

// Render dynamic radial gauges for CPU and Memory
function updateGauges(cpu, mem) {
  const cpuRing = document.getElementById('gauge-cpu-ring');
  const memRing = document.getElementById('gauge-mem-ring');
  const cpuVal = document.getElementById('gauge-cpu-val');
  const memVal = document.getElementById('gauge-mem-val');

  const circleLength = 251.2; // 2 * PI * r (r=40)

  if (cpuRing && cpuVal) {
    const offset = circleLength * (1 - cpu / 100);
    cpuRing.style.strokeDashoffset = offset;
    cpuVal.textContent = `${cpu}%`;
  }

  if (memRing && memVal) {
    const offset = circleLength * (1 - mem / 100);
    memRing.style.strokeDashoffset = offset;
    memVal.textContent = `${mem}%`;
  }
}

// Simulates real-time system metrics fluctuations
function startMetricsSimulation() {
  if (metricsInterval) clearInterval(metricsInterval);

  metricsInterval = setInterval(() => {
    const control = db.getControl();
    if (!control) return;

    // Fluctuates between 15% and 38%
    const cpuChange = Math.floor(Math.random() * 7) - 3; // -3% to +3%
    let newCpu = (control.cpu || 24) + cpuChange;
    if (newCpu < 12) newCpu = 12;
    if (newCpu > 40) newCpu = 40;

    // Fluctuates between 45% and 52%
    const memChange = Math.floor(Math.random() * 3) - 1; // -1% to +1%
    let newMem = (control.mem || 48) + memChange;
    if (newMem < 44) newMem = 44;
    if (newMem > 53) newMem = 53;

    control.cpu = newCpu;
    control.mem = newMem;
    
    // Don't save to storage to avoid redundant disk writes, just update display dynamically
    updateGauges(newCpu, newMem);
  }, 3000);
}

// Clean sandboxes mocks
function triggerPurgeSandboxes() {
  showToast('Initiating workspace sandbox diagnostics purge...', 'info');
  
  setTimeout(() => {
    showToast('Purging 12 stale container sandboxes...', 'info');
    setTimeout(() => {
      // update stats count
      const statSandboxes = document.getElementById('stat-sandboxes');
      if (statSandboxes) statSandboxes.textContent = '0';
      
      const control = db.getControl();
      control.sandboxes = 0;
      db.saveControl(control);

      showToast('Purged sandbox containers. Recovered 4.2GB memory quota.', 'success');
    }, 1200);
  }, 800);
}

// Telemetry Cache sync mocks
function triggerCacheSync() {
  showToast('Initiating handshake sync with cloud integrations...', 'info');
  
  setTimeout(() => {
    showToast('Cache table schema synchronized. Telemetry healthy.', 'success');
  }, 1000);
}

// Modal secrets rotations
function openSecretsModal() {
  const modal = document.getElementById('secrets-modal');
  if (modal) modal.classList.add('active');
}

function closeSecretsModal() {
  const modal = document.getElementById('secrets-modal');
  if (modal) modal.classList.remove('active');
}

function submitSecretsRotation() {
  closeSecretsModal();
  showToast('Generating new cryptographic salts...', 'info');
  setTimeout(() => {
    showToast('Workspace credentials signature rotated successfully!', 'success');
  }, 1000);
}

// Drawer clusters diagnostics logs
function openControlDrawer() {
  const drawer = document.getElementById('control-details-drawer');
  const logs = document.getElementById('drawer-control-logs');

  if (!drawer || !logs) return;

  logs.innerHTML = `
<span style="color:#6b7280;">[SYSTEM] ENGINE DAEMON ONLINE • IDLE</span>
<span style="color:#6b7280;">[SYSTEM] Monitoring active cluster loops...</span>
  `;

  drawer.classList.add('active');
}

function closeControlDrawer() {
  const drawer = document.getElementById('control-details-drawer');
  if (drawer) drawer.classList.remove('active');
}

// Mocks cluster audit stdout diagnostics logs
function refreshClusterDiagnostics() {
  const btn = document.getElementById('btn-refresh-cluster-diagnostics');
  const logs = document.getElementById('drawer-control-logs');

  if (!btn || !logs) return;

  btn.textContent = 'Auditing...';
  btn.disabled = true;

  logs.innerHTML = `<span style="color:#38bdf8;">[INIT] Handshake verification request sent to Docker Daemon...</span>`;
  logs.scrollTop = logs.scrollHeight;

  setTimeout(() => {
    logs.innerHTML += `<br><span style="color:#38bdf8;">[DOCKER] Scanning 4 container services: adlc-api, adlc-runner, adlc-cache, adlc-db</span>`;
    logs.scrollTop = logs.scrollHeight;

    setTimeout(() => {
      logs.innerHTML += `<br><span style="color:#10b981;">[DOCKER] Gateway cluster checked: state=HEALTHY nodes=1 memory=124MB</span>`;
      logs.scrollTop = logs.scrollHeight;

      setTimeout(() => {
        logs.innerHTML += `<br><span style="color:#10b981;">[DOCKER] Runner sandbox checked: state=HEALTHY active_containers=12 memory=840MB</span>`;
        logs.scrollTop = logs.scrollHeight;

        setTimeout(() => {
          logs.innerHTML += `<br><span style="color:#10b981;">[DOCKER] Cache & database nodes check checked: state=HEALTHY schema=VERIFIED</span>`;
          logs.scrollTop = logs.scrollHeight;

          setTimeout(() => {
            logs.innerHTML += `<br><br><span style="color:#10b981; font-weight:700;">[AUDIT] CLUSTER DIAGNOSTICS COMPLETED. 4/4 SERVICES COMPLIANT ✓</span>`;
            logs.scrollTop = logs.scrollHeight;
            showToast('Cluster diagnostics compliance verified.', 'success');
            
            btn.textContent = 'Run Telemetry Audit';
            btn.disabled = false;
          }, 800);
        }, 500);
      }, 500);
    }, 500);
  }, 800);
}
