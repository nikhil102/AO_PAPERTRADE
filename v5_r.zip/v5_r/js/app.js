// ADLC Global Shared Application JavaScript

// 1. DATABASE & INITIAL DATA LOAD
const INITIAL_CONNECTORS = [
  // Cloud
  { id: 'aws', name: 'AWS', category: 'cloud', status: 'Connected', env: 'All', authType: 'IAM Role', scopes: ['ec2:*', 's3:*', 'iam:CreatePolicy'], permission: 'Required access available' },
  { id: 'gcp', name: 'GCP', category: 'cloud', status: 'Needs Auth', env: 'DEV', authType: 'OAuth 2.0', scopes: ['compute.admin', 'storage.objectAdmin'], permission: 'Auth token expired' },
  { id: 'azure', name: 'Azure', category: 'cloud', status: 'Not Connected', env: 'UAT', authType: 'Service Principal', scopes: ['Contributor'], permission: 'No credentials configured' },
  { id: 'digitalocean', name: 'DigitalOcean', category: 'cloud', status: 'Not Connected', env: 'All', authType: 'API Key', scopes: ['read', 'write'], permission: 'No credentials configured' },
  { id: 'heroku', name: 'Heroku', category: 'cloud', status: 'Not Connected', env: 'DEV', authType: 'API Token', scopes: ['write'], permission: 'No credentials configured' },
  // Data Platform
  { id: 'databricks', name: 'Databricks', category: 'data platform', status: 'Connected', env: 'All', authType: 'Personal Access Token', scopes: ['jobs:run', 'clusters:modify'], permission: 'Required access available' },
  { id: 'snowflake', name: 'Snowflake', category: 'data platform', status: 'Connected', env: 'All', authType: 'OAuth / KeyPair', scopes: ['SYSADMIN', 'USERADMIN'], permission: 'Required access available' },
  { id: 'airflow', name: 'Airflow', category: 'data platform', status: 'Connected', env: 'DEV', authType: 'Basic Auth', scopes: ['dag:run', 'dag:read'], permission: 'Required access available' },
  { id: 'dbt', name: 'dbt Cloud', category: 'data platform', status: 'Connected', env: 'All', authType: 'Service Token', scopes: ['job:trigger', 'job:read'], permission: 'Required access available' },
  { id: 'spark', name: 'Apache Spark', category: 'data platform', status: 'Not Connected', env: 'UAT', authType: 'None', scopes: [], permission: 'No credentials configured' },
  { id: 'kafka', name: 'Apache Kafka', category: 'data platform', status: 'Not Connected', env: 'PROD', authType: 'SASL/SCRAM', scopes: ['topic:read', 'topic:write'], permission: 'No credentials configured' },
  // Ticketing
  { id: 'jira', name: 'Jira', category: 'ticketing', status: 'Connected', env: 'All', authType: 'API Token', scopes: ['issue:write', 'project:read'], permission: 'Required access available' },
  { id: 'servicenow', name: 'ServiceNow', category: 'ticketing', status: 'Needs Auth', env: 'PROD', authType: 'OAuth 2.0', scopes: ['itil', 'rest_service'], permission: 'Auth credentials expired' },
  { id: 'pagerduty', name: 'PagerDuty', category: 'ticketing', status: 'Not Connected', env: 'All', authType: 'API Key', scopes: ['write'], permission: 'No credentials configured' },
  { id: 'zendesk', name: 'Zendesk', category: 'ticketing', status: 'Not Connected', env: 'All', authType: 'OAuth 2.0', scopes: ['tickets:write'], permission: 'No credentials configured' },
  // DevOps
  { id: 'github', name: 'GitHub', category: 'devops', status: 'Connected', env: 'All', authType: 'GitHub App / PAT', scopes: ['repo', 'workflow'], permission: 'Required access available' },
  { id: 'gitlab', name: 'GitLab', category: 'devops', status: 'Not Connected', env: 'All', authType: 'Personal Access Token', scopes: ['api'], permission: 'No credentials configured' },
  { id: 'jenkins', name: 'Jenkins', category: 'devops', status: 'Not Connected', env: 'DEV', authType: 'User API Token', scopes: ['job/build'], permission: 'No credentials configured' },
  { id: 'terraform', name: 'Terraform Cloud', category: 'devops', status: 'Connected', env: 'All', authType: 'Team API Token', scopes: ['runs:write', 'workspaces:read'], permission: 'Required access available' },
  { id: 'circleci', name: 'CircleCI', category: 'devops', status: 'Not Connected', env: 'All', authType: 'User Token', scopes: ['project'], permission: 'No credentials configured' },
  { id: 'argocd', name: 'ArgoCD', category: 'devops', status: 'Not Connected', env: 'All', authType: 'Auth Token', scopes: ['sync'], permission: 'No credentials configured' },
  // Collaboration
  { id: 'slack', name: 'Slack', category: 'collaboration', status: 'Connected', env: 'All', authType: 'OAuth Token', scopes: ['chat:write', 'incoming-webhook'], permission: 'Required access available' },
  { id: 'teams', name: 'Microsoft Teams', category: 'collaboration', status: 'Connected', env: 'All', authType: 'Webhook / OAuth', scopes: ['Group.ReadWrite.All'], permission: 'Required access available' },
  { id: 'confluence', name: 'Confluence', category: 'collaboration', status: 'Connected', env: 'All', authType: 'API Token', scopes: ['space:read', 'content:write'], permission: 'Required access available' },
  { id: 'notion', name: 'Notion', category: 'collaboration', status: 'Not Connected', env: 'All', authType: 'Integration Token', scopes: ['read', 'write'], permission: 'No credentials configured' },
  { id: 'zoom', name: 'Zoom', category: 'collaboration', status: 'Not Connected', env: 'All', authType: 'OAuth', scopes: ['meeting:write'], permission: 'No credentials configured' },
  // Monitoring
  { id: 'datadog', name: 'Datadog', category: 'monitoring', status: 'Connected', env: 'All', authType: 'API/APP Keys', scopes: ['metrics:read', 'events:write'], permission: 'Required access available' },
  { id: 'splunk', name: 'Splunk', category: 'monitoring', status: 'Not Connected', env: 'PROD', authType: 'Token', scopes: ['search'], permission: 'No credentials configured' },
  { id: 'prometheus', name: 'Prometheus', category: 'monitoring', status: 'Not Connected', env: 'All', authType: 'None', scopes: [], permission: 'No credentials configured' },
  { id: 'grafana', name: 'Grafana', category: 'monitoring', status: 'Not Connected', env: 'All', authType: 'API Key', scopes: ['viewer'], permission: 'No credentials configured' },
  // Database
  { id: 'postgresql', name: 'PostgreSQL', category: 'database', status: 'Connected', env: 'All', authType: 'Database Credentials', scopes: ['SELECT', 'INSERT', 'UPDATE'], permission: 'Required access available' },
  { id: 'sqlserver', name: 'SQL Server', category: 'database', status: 'Not Connected', env: 'All', authType: 'SQL Auth', scopes: [], permission: 'No credentials configured' },
  { id: 'oracle', name: 'Oracle', category: 'database', status: 'Not Connected', env: 'All', authType: 'TNS', scopes: [], permission: 'No credentials configured' },
  { id: 'mongodb', name: 'MongoDB', category: 'database', status: 'Not Connected', env: 'All', authType: 'URI Connection', scopes: [], permission: 'No credentials configured' },
  { id: 'redis', name: 'Redis', category: 'database', status: 'Not Connected', env: 'All', authType: 'Password', scopes: [], permission: 'No credentials configured' },
  { id: 'mysql', name: 'MySQL', category: 'database', status: 'Not Connected', env: 'All', authType: 'DB Auth', scopes: [], permission: 'No credentials configured' },
  // BI
  { id: 'powerbi', name: 'Power BI', category: 'bi', status: 'Not Connected', env: 'All', authType: 'AAD Token', scopes: [], permission: 'No credentials configured' },
  { id: 'tableau', name: 'Tableau', category: 'bi', status: 'Not Connected', env: 'All', authType: 'Personal Token', scopes: [], permission: 'No credentials configured' },
  { id: 'metabase', name: 'Metabase', category: 'bi', status: 'Not Connected', env: 'All', authType: 'API Key', scopes: [], permission: 'No credentials configured' },
  { id: 'looker', name: 'Looker', category: 'bi', status: 'Not Connected', env: 'All', authType: 'Client ID/Secret', scopes: [], permission: 'No credentials configured' },
  // Business Apps
  { id: 'salesforce', name: 'Salesforce', category: 'business apps', status: 'Not Connected', env: 'All', authType: 'OAuth Web Flow', scopes: [], permission: 'No credentials configured' },
  { id: 'workday', name: 'Workday', category: 'business apps', status: 'Not Connected', env: 'All', authType: 'Web Services', scopes: [], permission: 'No credentials configured' },
  { id: 'hubspot', name: 'HubSpot', category: 'business apps', status: 'Not Connected', env: 'All', authType: 'OAuth', scopes: [], permission: 'No credentials configured' },
  { id: 'stripe', name: 'Stripe', category: 'business apps', status: 'Not Connected', env: 'All', authType: 'Rest API Key', scopes: [], permission: 'No credentials configured' }
];

const INITIAL_RUNS = [
  { id: 'RUN-4820', name: 'AWS S3 Stage Bucket Setup', date: '2026-06-19 18:22', duration: '4m 12s', cost: '$0.42', status: 'success', triggeredBy: 'NK (Chat)' },
  { id: 'RUN-4819', name: 'Audit BigQuery Tables & Mail Alert', date: '2026-06-19 14:10', duration: '1m 45s', cost: '$0.18', status: 'success', triggeredBy: 'NK (Chat)' },
  { id: 'RUN-4818', name: 'Databricks Job Fail Monitoring System', date: '2026-06-19 09:30', duration: '12m 10s', cost: '$1.45', status: 'failed', triggeredBy: 'System Cron' },
  { id: 'RUN-4817', name: 'PostgreSQL DB Column Replication Test', date: '2026-06-18 22:05', duration: '2m 15s', cost: '$0.08', status: 'success', triggeredBy: 'NK (Command)' },
  { id: 'RUN-4816', name: 'Clean stale GCP Staging tables', date: '2026-06-18 12:44', duration: '3m 50s', cost: '$0.75', status: 'success', triggeredBy: 'NK (Chat)' }
];

const INITIAL_APPROVALS = [
  {
    id: 'APP-921',
    requirement: 'Snowflake stage bucket sync & link to data warehouses.',
    summary: 'Provisioning automated staging workflows from primary AWS S3 storage buckets directly to Snowflake databases for schema loading.',
    riskLevel: 'high',
    systems: ['AWS', 'Snowflake'],
    requestor: 'NK (Dev)',
    env: 'DEV',
    created: '2026-06-19 20:45'
  },
  {
    id: 'APP-920',
    requirement: 'Databricks job monitoring and fail log mapping to Jira.',
    summary: 'Create active polling on Databricks clusters and automatically map job failure payloads to developer Jira queues.',
    riskLevel: 'medium',
    systems: ['Databricks', 'Jira'],
    requestor: 'NK (Automation)',
    env: 'DEV',
    created: '2026-06-19 19:15'
  }
];

const INITIAL_AGENTS = [
  { id: 'req-analyst', name: 'Requirement Analyst Agent', role: 'Extracts objective, systems, actions, and constraints from natural language inputs.', status: 'Active', model: 'Gemini 1.5 Pro', connectors: ['confluence', 'jira'], runsCount: 342, successRate: '99%', avgLatency: '1.2s' },
  { id: 'conn-validator', name: 'Connector Validator Agent', role: 'Validates credentials, permissions, and active configurations on system endpoints.', status: 'Active', model: 'Gemini 3.5 Flash', connectors: ['aws', 'gcp', 'snowflake', 'postgresql'], runsCount: 298, successRate: '100%', avgLatency: '0.8s' },
  { id: 'plan-builder', name: 'Plan Builder Agent', role: 'Generates structured automation blueprints and execution manifests.', status: 'Active', model: 'Gemini 1.5 Pro', connectors: ['github', 'terraform'], runsCount: 312, successRate: '97%', avgLatency: '1.5s' },
  { id: 'risk-impact', name: 'Risk & Impact Agent', role: 'Assesses security risks, system dependencies, pricing footprint, and rollbacks.', status: 'Active', model: 'Gemini 3.5 Flash', connectors: ['slack', 'datadog'], runsCount: 304, successRate: '99%', avgLatency: '0.9s' },
  { id: 'execution-engine', name: 'Execution Agent', role: 'Orchestrates approved execution blueprints on cloud infrastructure.', status: 'Active', model: 'Claude 3.5 Sonnet', connectors: ['aws', 'snowflake', 'jira', 'slack'], runsCount: 145, successRate: '96%', avgLatency: '3.2s' },
  { id: 'audit-logs', name: 'Audit & Logs Agent', role: 'Monitors runtime status, logs, and creates analytical execution metrics reports.', status: 'Active', model: 'Gemini 3.5 Flash', connectors: ['datadog', 'slack'], runsCount: 184, successRate: '100%', avgLatency: '1.4s' }
];

const INITIAL_CONTROL = {
  engineStatus: 'Running',
  cpu: 24,
  mem: 48,
  threads: 4,
  sandboxes: 12,
  whitelistIPs: ['10.0.4.1', '192.168.10.82', '54.210.12.9']
};

const INITIAL_KNOWLEDGE = [
  {
    id: 'kb-1',
    title: 'AWS Stage Setup Guide',
    type: 'confluence',
    source: 'https://confluence.adlc.ai/display/DEVOPS/AWS+Stage+Setup+Guide',
    category: 'Infrastructure',
    dateAdded: '2026-06-18 10:30',
    lastSynced: '2026-06-20 09:15',
    projects: ['AWS & Snowflake Stage'],
    content: `h1. AWS Stage Setup Guide\n\nThis guide outlines the standard configuration rules for setting up AWS S3 staging buckets linked to Snowflake databases.\n\nh2. Bucket Conventions\n* All stage buckets must follow the pattern: \`adlc-[project]-staging-[env]\`\n* SSE-S3 encryption must be enabled at all times.\n* Public access blocks must be active.\n\nh2. IAM Setup\nEnsure the storage integration IAM role has the following actions allowed on the target bucket:\n# \`s3:GetObject\`\n# \`s3:GetObjectVersion\`\n# \`s3:ListBucket\`\n# \`s3:PutObject\``
  },
  {
    id: 'kb-2',
    title: 'snowflake_schema.sql',
    type: 'file',
    source: '/workspace/db/snowflake_schema.sql',
    category: 'Database Schema',
    dateAdded: '2026-06-19 11:20',
    lastSynced: '2026-06-20 12:40',
    projects: ['AWS & Snowflake Stage', 'PostgreSQL DB Column Replication Test'],
    content: `-- Snowflake Schema definition for ADLC staging
CREATE OR REPLACE TABLE dev_db.staging.customer_activity (
    activity_id VARCHAR(50) NOT NULL,
    customer_id VARCHAR(50) NOT NULL,
    action_type VARCHAR(100),
    payload VARIANT,
    created_at TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
);

-- Access grants
GRANT SELECT, INSERT, UPDATE ON TABLE dev_db.staging.customer_activity TO ROLE SYSADMIN;`
  },
  {
    id: 'kb-3',
    title: 'Databricks Log Mapping Policy',
    type: 'confluence',
    source: 'https://confluence.adlc.ai/pages/viewpage.action?pageId=891042',
    category: 'Standard Operating Procedures',
    dateAdded: '2026-06-19 14:15',
    lastSynced: '2026-06-20 18:30',
    projects: ['Databricks Fail-Safe'],
    content: `h1. Databricks Log Mapping Policy\n\nThis policy defines the severity mappings between Databricks cluster runtime errors and Jira ticket priority levels.\n\nh2. Error Mappings\n* *Fatal exception / OutOfMemoryError*: Map to **High Priority** / Critical alert.\n* *Job Timeout*: Map to **Medium Priority**.\n* *User cancelled job*: Map to **Low Priority**.\n\nh2. Jira Fields\n* Project: OPS\n* Component: Data-Pipeline\n* Label: databricks-alert`
  },
  {
    id: 'kb-4',
    title: 'GCP Staging Cleanup Policy',
    type: 'guideline',
    source: 'Manual Text Input',
    category: 'Governance & Compliance',
    dateAdded: '2026-06-18 16:50',
    lastSynced: 'Manual (Not Checked)',
    projects: ['Clean stale GCP Staging tables'],
    content: `ADLC GOVERNANCE POLICY: GCP STAGING CLEANUP

1. Storage Lifecycle Rules:
- Staging BigQuery tables without partition updates for 14 days must be deleted automatically.
- GCS staging buckets must be configured with a 30-day lifecycle delete policy for temporary artifacts.

2. Slack Alerts:
- Before executing a cleanup job, the execution agent must broadcast the proposed table purge list to #ops-alerts.
- A 1-hour delay must follow before executing the actual purge command to allow operator overrides.`
  }
];

const INITIAL_BUDGET = {
  limitCap: 5000,
  spentCloud: 4514.80,
  alertThreshold: 90
};

// Initialize localStorage if not present
function dbInit() {
  if (!localStorage.getItem('adlc_connectors')) {
    localStorage.setItem('adlc_connectors', JSON.stringify(INITIAL_CONNECTORS));
  }
  if (!localStorage.getItem('adlc_runs')) {
    localStorage.setItem('adlc_runs', JSON.stringify(INITIAL_RUNS));
  }
  if (!localStorage.getItem('adlc_approvals')) {
    localStorage.setItem('adlc_approvals', JSON.stringify(INITIAL_APPROVALS));
  }
  if (!localStorage.getItem('adlc_agents')) {
    localStorage.setItem('adlc_agents', JSON.stringify(INITIAL_AGENTS));
  }
  if (!localStorage.getItem('adlc_control')) {
    localStorage.setItem('adlc_control', JSON.stringify(INITIAL_CONTROL));
  }
  if (!localStorage.getItem('adlc_knowledge')) {
    localStorage.setItem('adlc_knowledge', JSON.stringify(INITIAL_KNOWLEDGE));
  }
  if (!localStorage.getItem('adlc_budget')) {
    localStorage.setItem('adlc_budget', JSON.stringify(INITIAL_BUDGET));
  }
  if (!localStorage.getItem('adlc_theme')) {
    localStorage.setItem('adlc_theme', 'light');
  }
  if (!localStorage.getItem('adlc_env')) {
    localStorage.setItem('adlc_env', 'DEV');
  }
}

dbInit();

const db = {
  getConnectors: () => JSON.parse(localStorage.getItem('adlc_connectors')),
  saveConnectors: (data) => localStorage.setItem('adlc_connectors', JSON.stringify(data)),
  
  getRuns: () => JSON.parse(localStorage.getItem('adlc_runs')),
  saveRuns: (data) => localStorage.setItem('adlc_runs', JSON.stringify(data)),
  addRun: (run) => {
    const runs = db.getRuns();
    runs.unshift(run);
    db.saveRuns(runs);
  },
  
  getApprovals: () => JSON.parse(localStorage.getItem('adlc_approvals')),
  saveApprovals: (data) => localStorage.setItem('adlc_approvals', JSON.stringify(data)),
  removeApproval: (id) => {
    const approvals = db.getApprovals();
    const filtered = approvals.filter(app => app.id !== id);
    db.saveApprovals(filtered);
    updateSidebarBadges();
  },

  getAgents: () => JSON.parse(localStorage.getItem('adlc_agents')),
  saveAgents: (data) => localStorage.setItem('adlc_agents', JSON.stringify(data)),
  addAgent: (agent) => {
    const agents = db.getAgents();
    agents.push(agent);
    db.saveAgents(agents);
  },

  getControl: () => JSON.parse(localStorage.getItem('adlc_control')),
  saveControl: (data) => localStorage.setItem('adlc_control', JSON.stringify(data)),

  getKnowledge: () => JSON.parse(localStorage.getItem('adlc_knowledge')),
  saveKnowledge: (data) => localStorage.setItem('adlc_knowledge', JSON.stringify(data)),
  addKnowledge: (doc) => {
    const kb = db.getKnowledge();
    kb.push(doc);
    db.saveKnowledge(kb);
  },

  getBudget: () => JSON.parse(localStorage.getItem('adlc_budget')),
  saveBudget: (data) => localStorage.setItem('adlc_budget', JSON.stringify(data))
};

// 2. LAYOUT & INTERACTIVE HANDLERS
document.addEventListener('DOMContentLoaded', () => {
  setupSidebar();
  setupHeader();
  applyTheme();
  updateSidebarBadges();
  highlightActiveMenu();
});

// Sidebar Collapse / Mobile drawer
function setupSidebar() {
  const sidebar = document.getElementById('sidebar');
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');
  
  // Ensure the sidebar is always fully open and clean up state preferences
  if (sidebar) {
    sidebar.classList.remove('collapsed');
    localStorage.removeItem('adlc_sidebar_collapsed');
  }
  
  if (mobileMenuBtn && sidebar) {
    mobileMenuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      sidebar.classList.toggle('mobile-active');
    });

    // Close mobile drawer when clicking outside
    document.addEventListener('click', (e) => {
      if (sidebar.classList.contains('mobile-active') && !sidebar.contains(e.target) && e.target !== mobileMenuBtn) {
        sidebar.classList.remove('mobile-active');
      }
    });
  }
}

// Header Actions (Dark mode, environment, alerts)
function setupHeader() {
  const envSelector = document.getElementById('header-env-selector');
  const themeToggle = document.getElementById('theme-toggle-btn');
  
  if (envSelector) {
    // Load initial
    envSelector.value = localStorage.getItem('adlc_env') || 'DEV';
    envSelector.addEventListener('change', (e) => {
      const selectedEnv = e.target.value;
      localStorage.setItem('adlc_env', selectedEnv);
      showToast(`Environment switched to: ${selectedEnv}`, 'info');
      // Trigger dynamic page updates if listener functions exist
      if (typeof window.onEnvChange === 'function') {
        window.onEnvChange(selectedEnv);
      }
    });
  }
  
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const currentTheme = localStorage.getItem('adlc_theme');
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      localStorage.setItem('adlc_theme', newTheme);
      applyTheme();
      showToast(`Theme switched to ${newTheme} mode`, 'success');
    });
  }
}

// Apply theme helper
function applyTheme() {
  const currentTheme = localStorage.getItem('adlc_theme');
  const body = document.body;
  const themeToggle = document.getElementById('theme-toggle-btn');
  
  if (currentTheme === 'dark') {
    body.classList.add('dark');
    if (themeToggle) {
      // Set Sun Icon
      themeToggle.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="5"></circle>
          <line x1="12" y1="1" x2="12" y2="3"></line>
          <line x1="12" y1="21" x2="12" y2="23"></line>
          <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
          <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
          <line x1="1" y1="12" x2="3" y2="12"></line>
          <line x1="21" y1="12" x2="23" y2="12"></line>
          <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
          <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
        </svg>
      `;
    }
  } else {
    body.classList.remove('dark');
    if (themeToggle) {
      // Set Moon Icon
      themeToggle.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
        </svg>
      `;
    }
  }
}

// Update badges on sidebar navigation in real-time
function updateSidebarBadges() {
  const approvalsCount = db.getApprovals().length;
  const runs = db.getRuns();
  const runningRunsCount = runs.filter(run => run.status === 'running').length;
  const runsCount = runningRunsCount > 0 ? runningRunsCount : 1; // display runs count or 1

  const approvalBadge = document.getElementById('badge-approvals');
  const runsBadge = document.getElementById('badge-runs');
  const costsBadge = document.getElementById('badge-costs');
  
  if (approvalBadge) {
    approvalBadge.textContent = approvalsCount;
    approvalBadge.style.display = approvalsCount > 0 ? 'inline-block' : 'none';
  }
  
  if (runsBadge) {
    runsBadge.textContent = runsCount;
    runsBadge.className = runningRunsCount > 0 ? 'menu-badge warning' : 'menu-badge';
  }

  const budget = db.getBudget();
  if (costsBadge && budget) {
    const runsSum = runs.reduce((acc, run) => {
      const val = parseFloat(run.cost.replace('$', ''));
      return acc + (isNaN(val) ? 0 : val);
    }, 0);
    const totalSpent = budget.spentCloud + runsSum;
    const limit = budget.limitCap;
    const thresholdPercentage = budget.alertThreshold;
    const percentage = (totalSpent / limit) * 100;
    
    if (percentage >= thresholdPercentage) {
      costsBadge.style.display = 'inline-block';
    } else {
      costsBadge.style.display = 'none';
    }
  }
}

// Highlight active sidebar item by checking path name
function highlightActiveMenu() {
  const path = window.location.pathname;
  const pageName = path.substring(path.lastIndexOf('/') + 1) || 'index.html';
  
  const menuLinks = document.querySelectorAll('.menu-item');
  menuLinks.forEach(link => {
    link.classList.remove('active');
    const href = link.getAttribute('onclick');
    if (href && href.includes(pageName)) {
      link.classList.add('active');
    }
  });
}

// Navigation Helper
function navigateTo(page) {
  window.location.href = page;
}

// Toast Notifications Helper
function showToast(message, type = 'info') {
  const toastContainer = document.getElementById('toast-container') || createToastContainer();
  
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.style.cssText = `
    background-color: var(--bg-card);
    border-left: 4px solid var(--color-primary);
    box-shadow: var(--shadow-lg);
    border-radius: var(--border-radius-sm);
    padding: 12px 20px;
    margin-top: 8px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 13px;
    font-weight: 500;
    pointer-events: auto;
    animation: slideUp 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    border: 1px solid var(--color-border);
  `;
  
  // Set icon or color based on type
  if (type === 'success') {
    toast.style.borderLeftColor = 'var(--color-success)';
  } else if (type === 'warning') {
    toast.style.borderLeftColor = 'var(--color-warning)';
  } else if (type === 'error') {
    toast.style.borderLeftColor = 'var(--color-error)';
  } else if (type === 'info') {
    toast.style.borderLeftColor = 'var(--color-secondary)';
  }
  
  toast.innerHTML = `
    <span>${message}</span>
    <button style="background:transparent; border:none; color:var(--color-text-muted); cursor:pointer; font-size:16px; margin-left:auto;" onclick="this.parentElement.remove()">&times;</button>
  `;
  
  toastContainer.appendChild(toast);
  
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

function createToastContainer() {
  const container = document.createElement('div');
  container.id = 'toast-container';
  container.style.cssText = `
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 2000;
    pointer-events: none;
    max-width: 320px;
    display: flex;
    flex-direction: column;
  `;
  document.body.appendChild(container);
  return container;
}
