// ADLC AI Automation Workspace Simulation Controller

let chatState = {
  currentScenario: 'general',
  step: 1, // stepper step
  attachedFile: null,
  activeThinkingElement: null,
  connectorResolveCallback: null,
  planData: null
};

// Available scenarios
const SCENARIOS = {
  'AWS & Snowflake Stage': {
    id: 'aws_snowflake',
    prompt: 'Create stage bucket and link data warehouses.',
    systems: ['AWS', 'Snowflake'],
    question: 'Which cloud staging environment should this Snowflake link run in?',
    replies: ['DEV', 'UAT', 'PROD'],
    risk: 'medium',
    plan: {
      goal: 'Provision staging bucket sync and bind schema to Snowflake warehouse.',
      systems: 'AWS S3, Snowflake Warehouse',
      trigger: 'Manual API Trigger / Chat Authorization',
      actions: [
        'Initialize AWS S3 stage bucket "adlc-snowflake-staging-dev"',
        'Configure Snowflake Integration Storage Object referencing AWS S3 ARN',
        'Bind auto-ingest Snowpipe listening to S3 Event Alerts',
        'Verify schema data sync via test execution'
      ],
      output: 'Active stage bucket link, automated schema loader pipeline.',
      risk: 'Medium (Write Access Required)',
      duration: '3 mins',
      tokens: '4,200',
      cost: '$0.45'
    },
    agents: [
      { name: 'Requirement Analyst Agent', responsibility: 'Extracts Objective, systems, actions and constraints.', input: 'Natural Language prompt', output: 'JSON specification', status: 'Completed', duration: '2s' },
      { name: 'Clarification Agent', responsibility: 'Asks missing details before planning.', input: 'Incomplete scope parameters', output: 'Environment parameters confirmed', status: 'Completed', duration: '1s' },
      { name: 'Connector Validator Agent', responsibility: 'Checks app connections, tokens and permissions.', input: 'AWS, Snowflake access', output: 'Active session tokens verified', status: 'Completed', duration: '3s' },
      { name: 'Discovery Agent', responsibility: 'Reads metadata, jobs, buckets, or databases.', input: 'Snowflake connection metadata', output: 'Schema structures identified', status: 'Completed', duration: '4s' },
      { name: 'Plan Builder Agent', responsibility: 'Creates step-by-step automation plan.', input: 'Discovery & validation payloads', output: 'AWS-Snowflake YAML manifest', status: 'Completed', duration: '3s' },
      { name: 'Risk & Impact Agent', responsibility: 'Identifies affected systems, cost, and rollback details.', input: 'Plan manifest', output: 'Risk & rollback metadata', status: 'Completed', duration: '2s' },
      { name: 'Approval Agent', responsibility: 'Prepares approval request and agreement.', input: 'Full plan analysis', output: 'Interactive modal specs', status: 'Completed', duration: '1s' },
      { name: 'Execution Agent', responsibility: 'Executes approved changes only after authorization.', input: 'Approved YAML blueprint', output: 'Resource instances, active sync API', status: 'Pending', duration: '5s' },
      { name: 'Audit & Logs Agent', responsibility: 'Captures logs, outputs, and artifacts.', input: 'Runtime stream', output: 'Logs table, downloadable reports', status: 'Pending', duration: '2s' }
    ],
    impact: {
      affected: ['AWS IAM Policy', 'AWS S3 Staging', 'Snowflake Integration Storage'],
      type: 'Create Resources & Update Config',
      risk: 'Medium',
      costCloud: '$0.45 / run',
      costToken: '4,200 tokens ($0.08)',
      costDuration: '2.5 minutes',
      security: 'Requires AWS S3 write and Snowflake storage integration privileges.',
      rollback: 'AWS S3 bucket can be automatically removed; Snowflake storage integrations must be manually unlinked if deleted.',
      executionId: 'RUN-4821',
      environment: 'DEV'
    }
  },

  'Databricks Fail-Safe': {
    id: 'databricks_jira',
    prompt: 'Monitor Databricks jobs and map fail logs to Jira.',
    systems: ['Databricks', 'Jira'],
    question: 'Should ADLC create a Jira ticket on all job failures or only high-priority jobs?',
    replies: ['All Failures', 'High-Priority Only', 'Only critical clusters'],
    risk: 'medium',
    plan: {
      goal: 'Link Databricks webhook event triggers to developer Jira queue tickets.',
      systems: 'Databricks Clusters, Jira Ticketing API',
      trigger: 'Databricks Job Fail Event Webhook',
      actions: [
        'Register alert webhook listener endpoint on ADLC Engine',
        'Configure Databricks Notification Alert System pointing to webhook',
        'Map error diagnostics payload to Jira schema payload mapping',
        'Inject credentials to create Jira issue tickets inside project "OPS"'
      ],
      output: 'Active Jira logging fail-safe webhook',
      risk: 'Medium (Alerting Setup)',
      duration: '2 mins',
      tokens: '3,800',
      cost: '$0.15'
    },
    agents: [
      { name: 'Requirement Analyst Agent', responsibility: 'Extracts Objective, systems, actions and constraints.', input: 'Natural Language prompt', output: 'JSON specification', status: 'Completed', duration: '2s' },
      { name: 'Clarification Agent', responsibility: 'Asks missing details before planning.', input: 'Incomplete scope parameters', output: 'Priority filter parameter confirmed', status: 'Completed', duration: '1s' },
      { name: 'Connector Validator Agent', responsibility: 'Checks app connections, tokens and permissions.', input: 'Databricks, Jira access', output: 'Active session tokens verified', status: 'Completed', duration: '2s' },
      { name: 'Discovery Agent', responsibility: 'Reads metadata, jobs, buckets, or databases.', input: 'Databricks job scheduler API', output: 'Cluster log specifications', status: 'Completed', duration: '3s' },
      { name: 'Plan Builder Agent', responsibility: 'Creates step-by-step automation plan.', input: 'Discovery & validation payloads', output: 'Integration webhook configurations', status: 'Completed', duration: '3s' },
      { name: 'Risk & Impact Agent', responsibility: 'Identifies affected systems, cost, and rollback details.', input: 'Plan manifest', output: 'Risk & rollback metadata', status: 'Completed', duration: '2s' },
      { name: 'Approval Agent', responsibility: 'Prepares approval request and agreement.', input: 'Full plan analysis', output: 'Interactive modal specs', status: 'Completed', duration: '1s' },
      { name: 'Execution Agent', responsibility: 'Executes approved changes only after authorization.', input: 'Approved YAML blueprint', output: 'Webhook triggers registered', status: 'Pending', duration: '4s' },
      { name: 'Audit & Logs Agent', responsibility: 'Captures logs, outputs, and artifacts.', input: 'Runtime stream', output: 'Logs table, downloadable reports', status: 'Pending', duration: '2s' }
    ],
    impact: {
      affected: ['Databricks Alert Trigger Settings', 'Jira Issue Schema Settings'],
      type: 'External Integration & Read/Write Config',
      risk: 'Medium',
      costCloud: '$0.15 / alert run',
      costToken: '3,800 tokens ($0.076)',
      costDuration: '1.8 minutes',
      security: 'Access tokens required for Databricks API and Jira Cloud Project Admin.',
      rollback: 'Webhooks can be automatically removed; tickets generated in Jira remain and must be manually purged.',
      executionId: 'RUN-4822',
      environment: 'DEV'
    }
  },

  'BigQuery Cost Analysis': {
    id: 'bigquery_cost',
    prompt: 'Audit cost statements and draft emails.',
    systems: ['GCP', 'Slack'],
    question: 'Which environment should this BigQuery audit analyze?',
    replies: ['DEV', 'PROD', 'All Environments'],
    risk: 'low',
    plan: {
      goal: 'Analyze BigQuery usage costs and broadcast reports to Slack alerts.',
      systems: 'GCP BigQuery Metadata, Slack Channel Webhook',
      trigger: 'On-Demand / Scheduled Cron',
      actions: [
        'Query BigQuery INFORMATION_SCHEMA.JOBS_BY_PROJECT usage logs',
        'Calculate cost totals using standard GCP partition metrics',
        'Draft email summary report detailing highest spending queries',
        'Send summary alert card to developer slack channel #ops-costs'
      ],
      output: 'BigQuery Cost audit report, automated Slack notification.',
      risk: 'Low (Read-Only queries, Slack broadcast)',
      duration: '1.5 mins',
      tokens: '5,100',
      cost: '$0.05'
    },
    agents: [
      { name: 'Requirement Analyst Agent', responsibility: 'Extracts Objective, systems, actions and constraints.', input: 'Natural Language prompt', output: 'JSON specification', status: 'Completed', duration: '2s' },
      { name: 'Clarification Agent', responsibility: 'Asks missing details before planning.', input: 'Incomplete scope parameters', output: 'Environment parameter confirmed', status: 'Completed', duration: '1s' },
      { name: 'Connector Validator Agent', responsibility: 'Checks app connections, tokens and permissions.', input: 'GCP BigQuery, Slack access', output: 'Active session tokens verified', status: 'Completed', duration: '2s' },
      { name: 'Discovery Agent', responsibility: 'Reads metadata, jobs, buckets, or databases.', input: 'BigQuery INFORMATION_SCHEMA', output: 'Metadata schemas mapped', status: 'Completed', duration: '3s' },
      { name: 'Plan Builder Agent', responsibility: 'Creates step-by-step automation plan.', input: 'Discovery & validation payloads', output: 'Query statements & webhook templates', status: 'Completed', duration: '3s' },
      { name: 'Risk & Impact Agent', responsibility: 'Identifies affected systems, cost, and rollback details.', input: 'Plan manifest', output: 'Risk & rollback metadata', status: 'Completed', duration: '2s' },
      { name: 'Approval Agent', responsibility: 'Prepares approval request and agreement.', input: 'Full plan analysis', output: 'Interactive modal specs', status: 'Completed', duration: '1s' },
      { name: 'Execution Agent', responsibility: 'Executes approved changes only after authorization.', input: 'Approved YAML blueprint', output: 'Report payload broadcasted', status: 'Pending', duration: '3s' },
      { name: 'Audit & Logs Agent', responsibility: 'Captures logs, outputs, and artifacts.', input: 'Runtime stream', output: 'Logs table, downloadable reports', status: 'Pending', duration: '2s' }
    ],
    impact: {
      affected: ['GCP BigQuery logs (Read)', 'Slack Incoming Webhooks (Post)'],
      type: 'Read-only query and communication post',
      risk: 'Low',
      costCloud: '$0.05 / run',
      costToken: '5,100 tokens ($0.10)',
      costDuration: '1.2 minutes',
      security: 'Read-only access to BigQuery logs. Slack incoming webhook integration.',
      rollback: 'Not applicable (Read-only reports cannot be rolled back).',
      executionId: 'RUN-4823',
      environment: 'DEV'
    }
  },

  'GCP Staging Cleanup': {
    id: 'gcp_cleanup',
    prompt: 'Create automation to clean stale staging tables.',
    systems: ['GCP'],
    question: 'How old should the staging tables be before they are deleted?',
    replies: ['Older than 30 Days', 'Older than 90 Days', 'Custom definition (older than 7 days)'],
    risk: 'critical',
    plan: {
      goal: 'Locate and delete stale partition tables in staging GCP datastores.',
      systems: 'Google Cloud Platform (BigQuery / Storage)',
      trigger: 'Weekly Automation Cron',
      actions: [
        'List all tables inside staging database "adlc_staging"',
        'Identify unused partitions without read hits for defined duration',
        'Drop identified tables and free cloud storage blocks',
        'Log database updates to cloud audit logs'
      ],
      output: 'Deleted stale data partitions, freed storage space.',
      risk: 'Critical (Data Deletion Action)',
      duration: '4 mins',
      tokens: '6,400',
      cost: '$1.80'
    },
    agents: [
      { name: 'Requirement Analyst Agent', responsibility: 'Extracts Objective, systems, actions and constraints.', input: 'Natural Language prompt', output: 'JSON specification', status: 'Completed', duration: '2s' },
      { name: 'Clarification Agent', responsibility: 'Asks missing details before planning.', input: 'Incomplete scope parameters', output: 'Staleness threshold confirmed', status: 'Completed', duration: '1s' },
      { name: 'Connector Validator Agent', responsibility: 'Checks app connections, tokens and permissions.', input: 'GCP connection access', output: 'Write/Delete authorizations validation', status: 'Blocked', duration: '3s' },
      { name: 'Discovery Agent', responsibility: 'Reads metadata, jobs, buckets, or databases.', input: '--', output: '--', status: 'Pending', duration: '4s' },
      { name: 'Plan Builder Agent', responsibility: 'Creates step-by-step automation plan.', input: '--', output: '--', status: 'Pending', duration: '3s' },
      { name: 'Risk & Impact Agent', responsibility: 'Identifies affected systems, cost, and rollback details.', input: '--', output: '--', status: 'Pending', duration: '2s' },
      { name: 'Approval Agent', responsibility: 'Prepares approval request and agreement.', input: '--', output: '--', status: 'Pending', duration: '1s' },
      { name: 'Execution Agent', responsibility: 'Executes approved changes only after authorization.', input: '--', output: '--', status: 'Pending', duration: '5s' },
      { name: 'Audit & Logs Agent', responsibility: 'Captures logs, outputs, and artifacts.', input: '--', output: '--', status: 'Pending', duration: '2s' }
    ],
    impact: {
      affected: ['GCP BigQuery staging tables', 'GCP Storage partitions'],
      type: 'Delete resources (Permanent)',
      risk: 'Critical',
      costCloud: '$1.80 / run',
      costToken: '6,400 tokens ($0.128)',
      costDuration: '3.5 minutes',
      security: 'Admin-level GCP credentials and active DELETE query permissions required.',
      rollback: 'DELETED BigQuery tables CANNOT be automatically recovered. Table backup snapshots must be configured manually.',
      executionId: 'RUN-4824',
      environment: 'DEV'
    }
  },

  'IAM Policy Generator': {
    id: 'iam_policy',
    prompt: 'Create AWS IAM policy after approval.',
    systems: ['AWS'],
    question: 'What scopes and access levels should this AWS IAM policy grant?',
    replies: ['Read-only S3 access', 'Full EC2 control permissions', 'Admin capabilities (limited)'],
    risk: 'high',
    plan: {
      goal: 'Draft and deploy security policy in AWS IAM directory.',
      systems: 'AWS IAM Directory API',
      trigger: 'Manual Admin Approval Check',
      actions: [
        'Generate IAM Policy JSON script matching minimum privilege criteria',
        'Validate JSON structure against standard AWS IAM schemas',
        'Create AWS IAM policy entity "ADLCGeneratedPolicy"',
        'Assign policy metadata tagging for governance auditing'
      ],
      output: 'Active AWS IAM Policy Entity.',
      risk: 'High (Security Authorization Role Creation)',
      duration: '2.5 mins',
      tokens: '4,500',
      cost: '$0.25'
    },
    agents: [
      { name: 'Requirement Analyst Agent', responsibility: 'Extracts Objective, systems, actions and constraints.', input: 'Natural Language prompt', output: 'JSON specification', status: 'Completed', duration: '2s' },
      { name: 'Clarification Agent', responsibility: 'Asks missing details before planning.', input: 'Incomplete scope parameters', output: 'Policy scope parameters confirmed', status: 'Completed', duration: '1s' },
      { name: 'Connector Validator Agent', responsibility: 'Checks app connections, tokens and permissions.', input: 'AWS IAM access API', output: 'Active session tokens verified', status: 'Completed', duration: '2s' },
      { name: 'Discovery Agent', responsibility: 'Reads metadata, jobs, buckets, or databases.', input: 'AWS account configurations', output: 'Directory variables extracted', status: 'Completed', duration: '3s' },
      { name: 'Plan Builder Agent', responsibility: 'Creates step-by-step automation plan.', input: 'Discovery & validation payloads', output: 'IAM policy JSON scripts', status: 'Completed', duration: '3s' },
      { name: 'Risk & Impact Agent', responsibility: 'Identifies affected systems, cost, and rollback details.', input: 'Plan manifest', output: 'Risk & rollback metadata', status: 'Completed', duration: '2s' },
      { name: 'Approval Agent', responsibility: 'Prepares approval request and agreement.', input: 'Full plan analysis', output: 'Interactive modal specs', status: 'Completed', duration: '1s' },
      { name: 'Execution Agent', responsibility: 'Executes approved changes only after authorization.', input: 'Approved YAML blueprint', output: 'AWS IAM Policy deployed', status: 'Pending', duration: '4s' },
      { name: 'Audit & Logs Agent', responsibility: 'Captures logs, outputs, and artifacts.', input: 'Runtime stream', output: 'Logs table, downloadable reports', status: 'Pending', duration: '2s' }
    ],
    impact: {
      affected: ['AWS IAM Directory Permissions'],
      type: 'Update configurations & authorization rules',
      risk: 'High',
      costCloud: '$0.25 / run',
      costToken: '4,500 tokens ($0.09)',
      costDuration: '2.0 minutes',
      security: 'Admin-level AWS IAM policy creation credentials required.',
      rollback: 'Generated policy can be automatically deleted on command.',
      executionId: 'RUN-4825',
      environment: 'DEV'
    }
  }
};

// Helper to dynamically adjust textarea height and scroll overflow
function adjustTextareaHeight(el) {
  if (!el) return;
  if (!el.value) {
    el.style.height = '32px';
    el.style.overflowY = 'hidden';
    return;
  }
  
  el.style.height = 'auto';
  let newHeight = el.scrollHeight;
  if (newHeight < 32) {
    newHeight = 32;
  }
  
  if (newHeight >= 200) {
    el.style.height = '200px';
    el.style.overflowY = 'auto';
  } else {
    el.style.height = newHeight + 'px';
    el.style.overflowY = 'hidden';
  }
}

// Initial welcome cards clicked
function selectPromptCard(title) {
  const data = SCENARIOS[title];
  if (!data) return;
  
  const input = document.getElementById('chat-input-field');
  if (input) {
    input.value = data.prompt;
    adjustTextareaHeight(input);
    input.focus();
  }
}

// Upgraded Attachment & Console Management State
let activeAttachments = [];
let currentUrlType = null;
let recordingTimerInterval = null;
let recordingStartTime = 0;

// Toggle media dropdown shelf
function toggleMediaDrawer(e) {
  if (e) e.stopPropagation();
  const dropdown = document.getElementById('attachment-dropdown');
  const launcher = document.getElementById('btn-media-launcher');
  if (!dropdown || !launcher) return;
  
  dropdown.classList.toggle('active');
  launcher.classList.toggle('active');
}

// Window click to close dropdown outside click
window.addEventListener('click', (e) => {
  const dropdown = document.getElementById('attachment-dropdown');
  const launcher = document.getElementById('btn-media-launcher');
  if (dropdown && dropdown.classList.contains('active')) {
    if (!dropdown.contains(e.target) && !launcher.contains(e.target)) {
      dropdown.classList.remove('active');
      launcher.classList.remove('active');
    }
  }
});

// Setup drag and drop file upload hooks
function setupDragAndDrop() {
  const overlay = document.getElementById('drag-drop-overlay');
  if (!overlay) return;
  
  window.addEventListener('dragenter', (e) => {
    e.preventDefault();
    overlay.classList.add('active');
  });
  
  overlay.addEventListener('dragover', (e) => {
    e.preventDefault();
  });
  
  overlay.addEventListener('dragleave', (e) => {
    if (e.target === overlay) {
      overlay.classList.remove('active');
    }
  });
  
  overlay.addEventListener('drop', (e) => {
    e.preventDefault();
    overlay.classList.remove('active');
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      Array.from(e.dataTransfer.files).forEach(file => {
        attachFileObject(file);
      });
    }
  });
}

// Unified file attachment registration
function attachFileObject(file) {
  let type = 'file';
  if (file.type.startsWith('image/')) type = 'image';
  else if (file.type.startsWith('video/')) type = 'video';
  else if (file.name.endsWith('.zip') || file.name.endsWith('.rar') || file.name.endsWith('.tar') || file.name.endsWith('.gz') || file.name.endsWith('.7z')) type = 'zip';
  else if (file.name.endsWith('.js') || file.name.endsWith('.py') || file.name.endsWith('.java') || file.name.endsWith('.cpp') || file.name.endsWith('.html') || file.name.endsWith('.css') || file.name.endsWith('.json') || file.name.endsWith('.sh') || file.name.endsWith('.go') || file.name.endsWith('.rs')) type = 'code';
  
  let sizeString = '120 KB';
  if (file.size) {
    if (file.size > 1024 * 1024) {
      sizeString = (file.size / (1024 * 1024)).toFixed(1) + ' MB';
    } else {
      sizeString = (file.size / 1024).toFixed(0) + ' KB';
    }
  }
  
  const newAttachment = { type: type, name: file.name, size: sizeString };
  
  if (type === 'image') {
    const reader = new FileReader();
    reader.onload = function(e) {
      newAttachment.thumbnail = e.target.result;
      renderAttachments();
    };
    reader.readAsDataURL(file);
  }
  
  activeAttachments.push(newAttachment);
  renderAttachments();
  showToast(`Attached ${type}: ${file.name}`, 'success');
  
  // Close dropdown
  const dropdown = document.getElementById('attachment-dropdown');
  const launcher = document.getElementById('btn-media-launcher');
  if (dropdown) dropdown.classList.remove('active');
  if (launcher) launcher.classList.remove('active');
}

// File Upload Trigger Helper
function triggerFileUpload(type) {
  const fileInput = document.getElementById('chat-file-upload');
  if (!fileInput) return;
  
  if (type === 'image') {
    fileInput.accept = 'image/*';
  } else if (type === 'video') {
    fileInput.accept = 'video/*';
  } else if (type === 'code') {
    fileInput.accept = '.js,.py,.java,.cpp,.html,.css,.json,.go,.rs,.sh,.ts,.sql,.txt';
  } else if (type === 'zip') {
    fileInput.accept = '.zip,.rar,.tar,.gz,.7z';
  } else {
    fileInput.accept = '*';
  }
  
  fileInput.value = ''; // Reset to ensure change event fires even for same file
  fileInput.click();
}

// Upload file handler
function handleFileAttached(e) {
  const file = e.target.files[0];
  if (!file) return;
  attachFileObject(file);
}

// Render active attachments inside the cockpit input console
function renderAttachments() {
  const container = document.getElementById('cockpit-attachments-container');
  if (!container) return;
  
  if (activeAttachments.length === 0) {
    container.style.display = 'none';
    container.innerHTML = '';
    return;
  }
  
  container.style.display = 'flex';
  container.innerHTML = activeAttachments.map((att, idx) => {
    let icon = '📄';
    let label = 'Document';
    let size = att.size || '120 KB';
    let glowColor = 'var(--color-primary)';
    
    if (att.type === 'image') { icon = '🖼️'; label = 'Image'; glowColor = '#ec4899'; }
    else if (att.type === 'video') { icon = '🎥'; label = 'Video'; glowColor = '#a855f7'; }
    else if (att.type === 'audio') { icon = '🎙️'; label = 'Voice Note'; glowColor = '#10b981'; }
    else if (att.type === 'code') { icon = '💻'; label = 'Code Script'; glowColor = '#f59e0b'; }
    else if (att.type === 'zip') { icon = '📦'; label = 'Archive'; glowColor = '#eab308'; }
    else if (att.type === 'git') { icon = '🐙'; label = 'Git Repo'; size = size || 'Link'; glowColor = '#14b8a6'; }
    else if (att.type === 'web') { icon = '🌐'; label = 'Website'; size = size || 'Link'; glowColor = '#3b82f6'; }
    
    if (att.type === 'image' && att.thumbnail) {
      return `
        <div class="attachment-card image-card" style="--glow: ${glowColor};">
          <div class="attachment-preview-img" style="background-image: url('${att.thumbnail}')"></div>
          <div class="attachment-card-details">
            <span class="attachment-card-name" title="${att.name}">${att.name}</span>
            <span class="attachment-card-meta">${label} • ${size}</span>
          </div>
          <button class="attachment-card-remove" onclick="removeAttachment(${idx})" title="Remove Attachment">&times;</button>
        </div>
      `;
    }
    
    return `
      <div class="attachment-card" style="--glow: ${glowColor};">
        <div class="attachment-card-icon-container" style="background: rgba(${att.type === 'audio' ? '16, 185, 129' : att.type === 'image' ? '236, 72, 153' : '79, 99, 246'}, 0.1);">
          <span class="attachment-card-icon">${icon}</span>
        </div>
        <div class="attachment-card-details">
          <span class="attachment-card-name" title="${att.name}">${att.name}</span>
          <span class="attachment-card-meta">${label} • ${size}</span>
        </div>
        <button class="attachment-card-remove" onclick="removeAttachment(${idx})" title="Remove Attachment">&times;</button>
      </div>
    `;
  }).join('');
}

// Remove an active attachment
function removeAttachment(idx) {
  const name = activeAttachments[idx].name;
  activeAttachments.splice(idx, 1);
  renderAttachments();
  showToast(`Removed attachment: ${name}`, 'info');
}

// Voice recording simulated HUD controls
function startVoiceRecording() {
  const dropdown = document.getElementById('attachment-dropdown');
  const launcher = document.getElementById('btn-media-launcher');
  if (dropdown) dropdown.classList.remove('active');
  if (launcher) launcher.classList.remove('active');
  
  const recorder = document.getElementById('cockpit-voice-recorder');
  if (!recorder) return;
  
  recorder.style.display = 'flex';
  const timer = recorder.querySelector('.recording-timer');
  if (timer) timer.textContent = 'REC 00:00';
  
  recordingStartTime = Date.now();
  recordingTimerInterval = setInterval(() => {
    const elapsed = Math.floor((Date.now() - recordingStartTime) / 1000);
    const m = Math.floor(elapsed / 60).toString().padStart(2, '0');
    const s = (elapsed % 60).toString().padStart(2, '0');
    if (timer) timer.textContent = `REC ${m}:${s}`;
  }, 1000);
  
  showToast('Recording voice note simulation started.', 'info');
}

function finishVoiceRecording() {
  clearInterval(recordingTimerInterval);
  const recorder = document.getElementById('cockpit-voice-recorder');
  if (recorder) recorder.style.display = 'none';
  
  const elapsed = Math.floor((Date.now() - recordingStartTime) / 1000);
  const name = `voice-memo-${Date.now().toString().slice(-4)}.mp3`;
  
  activeAttachments.push({
    type: 'audio',
    name: name,
    size: `${elapsed}s recording`
  });
  
  renderAttachments();
  showToast(`Attached voice memo: ${name}`, 'success');
}

function cancelVoiceRecording() {
  clearInterval(recordingTimerInterval);
  const recorder = document.getElementById('cockpit-voice-recorder');
  if (recorder) recorder.style.display = 'none';
  showToast('Voice memo cancelled.', 'info');
}

// URL modal dialog open and close helpers
function openUrlModal(type) {
  const modal = document.getElementById('url-link-modal');
  const title = document.getElementById('url-modal-title');
  const label = document.getElementById('url-modal-label');
  const icon = document.getElementById('url-modal-icon');
  const field = document.getElementById('cockpit-url-field-modal');
  if (!modal || !title || !label || !icon || !field) return;
  
  currentUrlType = type;
  field.value = '';
  
  if (type === 'git') {
    title.textContent = 'Link Git Repository';
    label.textContent = 'GitHub / GitLab Repository URL';
    icon.textContent = '🐙';
    field.placeholder = 'https://github.com/username/repository';
  } else {
    title.textContent = 'Link Website URL';
    label.textContent = 'Website / Webpage URL';
    icon.textContent = '🌐';
    field.placeholder = 'https://example.com/page';
  }
  
  modal.classList.add('active');
  setTimeout(() => field.focus(), 150);
}

function closeUrlModal() {
  const modal = document.getElementById('url-link-modal');
  if (modal) modal.classList.remove('active');
  currentUrlType = null;
}

function openGitLinkModal() {
  openUrlModal('git');
}

function openWebLinkModal() {
  openUrlModal('web');
}

function submitUrlAttachment() {
  const field = document.getElementById('cockpit-url-field-modal');
  if (!field) return;
  
  const val = field.value.trim();
  if (!val) {
    showToast('Please enter a valid URL.', 'warning');
    return;
  }
  
  if (!val.startsWith('http://') && !val.startsWith('https://') && !val.startsWith('git@') && !val.startsWith('github.com')) {
    showToast('Please check the URL format (e.g., https://...)', 'warning');
    return;
  }
  
  activeAttachments.push({ type: currentUrlType, name: val, size: 'External Link' });
  renderAttachments();
  showToast(`Linked ${currentUrlType === 'git' ? 'Git Repo' : 'Website'}: ${val}`, 'success');
  closeUrlModal();
}

// Prompt keydown logic (Enter to run, Shift+Enter for newlines)
function handlePromptKeydown(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    executeConsoleAutomation();
  }
}

// User hits Send
function submitRequirement() {
  const input = document.getElementById('chat-input-field');
  if (!input) return;
  
  const prompt = input.value.trim();
  
  // Clear input & active attachments
  input.value = '';
  adjustTextareaHeight(input);
  const attachmentsCopy = [...activeAttachments];
  activeAttachments = [];
  renderAttachments();
  closeUrlModal();
  
  // Remove welcome card if visible
  const welcome = document.getElementById('chat-welcome-state');
  if (welcome) welcome.style.display = 'none';
  
  // Identify Scenario
  let matchedScenario = chatState.currentScenario || 'general';
  if (prompt) {
    for (const [key, value] of Object.entries(SCENARIOS)) {
      if (prompt.toLowerCase().includes(value.prompt.toLowerCase()) || prompt.toLowerCase().includes(key.toLowerCase())) {
        matchedScenario = key;
        break;
      }
    }
  }
  
  chatState.currentScenario = matchedScenario;
  updateProjectHUD(matchedScenario);
  
  // Ensure tasks are populated
  if (currentChecklistTasks.length <= 3) {
    loadProjectTasks(matchedScenario);
  }
  
  // Set first prep task active
  currentChecklistTasks.forEach((t, idx) => {
    t.status = idx === 0 ? 'active' : 'pending';
  });
  renderChecklistHUD();
  switchSidebarTab('tasks');
  
  // Append User message to stream
  if (prompt) {
    appendUserMessage(prompt, attachmentsCopy);
  } else {
    appendUserMessage(`Execute automation orchestration for project: ${matchedScenario}`, attachmentsCopy);
  }
  chatState.attachedFile = null;
  
  // Start state machine
  runWorkflowStateMachine();
}

// Main State Machine Logic
function runWorkflowStateMachine() {
  updateStepper(1, 'completed');
  updateStepper(2, 'active');
  
  updateProjectHUD(chatState.currentScenario);
  
  // Set first prep task active
  currentChecklistTasks.forEach((t, idx) => {
    t.status = idx === 0 ? 'active' : 'pending';
  });
  renderChecklistHUD();
  switchSidebarTab('tasks');
  
  // Show thinking analyzer
  showThinking('Analyzing automation requirement...');
  
  setTimeout(() => {
    hideThinking();
    
    // Check if matched scenario has clarification question
    const scenario = SCENARIOS[chatState.currentScenario];
    if (scenario && scenario.question) {
      updateReadinessItem('chk-req-captured', true);
      updateReadinessPanelPercent(15, 'Analysing...');
      
      appendClarification('Need more details', scenario.question, scenario.replies);
    } else {
      updateReadinessItem('chk-req-captured', true);
      updateReadinessPanelPercent(15, 'Analysing...');
      
      appendClarification('Need more details', 'Which cloud environment should this automation run in?', ['DEV', 'UAT', 'PROD']);
    }
  }, 1500);
}

// When user clicks clarification buttons
function replyClarification(choice) {
  const activeReplies = document.querySelector('.quick-replies');
  if (activeReplies) activeReplies.remove();
  
  appendUserMessage(choice);
  
  updateStepper(2, 'completed');
  updateStepper(3, 'active');
  
  showThinking('Checking connector credentials and permissions...');
  
  setTimeout(() => {
    hideThinking();
    
    updateReadinessItem('chk-clarification', true);
    updateReadinessItem('chk-scope', true);
    updateReadinessPanelPercent(30, 'Verifying Connectors...');
    
    const scenario = SCENARIOS[chatState.currentScenario];
    let systems = ['AWS', 'Jira']; // fallback
    if (scenario) {
      systems = scenario.systems;
    }
    
    // Check connection databases
    const connectors = db.getConnectors();
    const checkedList = systems.map(sys => {
      const match = connectors.find(c => c.name.toLowerCase() === sys.toLowerCase());
      return match || { name: sys, status: 'Not Connected', permission: 'No credentials configured' };
    });
    
    appendConnectorCheck(checkedList);
    
    // Check if any checked connector is blocked
    const blockedConn = checkedList.find(c => c.status === 'Needs Auth' || c.status === 'Not Connected' || c.status === 'Permission Issue');
    
    const statSystems = document.getElementById('stat-req-systems');
    const statConnected = document.getElementById('stat-conn-verified');
    const statIssues = document.getElementById('stat-conn-issues');
    
    if (statSystems) statSystems.textContent = checkedList.length;
    if (statConnected) statConnected.textContent = checkedList.filter(c => c.status === 'Connected').length;
    if (statIssues) {
      statIssues.textContent = blockedConn ? '1 Issue' : '0 Issues';
      statIssues.style.color = blockedConn ? 'var(--color-error)' : 'var(--color-success)';
    }
    
    if (blockedConn) {
      // BLOCKED! Stop stepper, update readiness warning, activate fix button
      updateStepper(3, 'blocked');
      updateReadinessPanelPercent(45, 'Blocked', true);
      
      updateReadinessItem('chk-perm-read', false);
      updateReadinessItem('chk-perm-write', false);
      updateReadinessItem('chk-perm-tokens', false);
      
      const fixBtn = document.getElementById('readiness-fix-btn');
      if (fixBtn) {
        fixBtn.disabled = false;
        fixBtn.className = 'btn btn-primary';
      }
      
      appendErrorCard(blockedConn.status, blockedConn.name, blockedConn.permission);
      
      chatState.connectorResolveCallback = () => {
        showToast(`Credentials verified. Resuming planning workflow...`, 'success');
        
        const updatedConnectors = db.getConnectors();
        const reCheckedList = systems.map(sys => updatedConnectors.find(c => c.name.toLowerCase() === sys.toLowerCase()));
        
        const errorCard = document.querySelector('.msg-system-card.error-card');
        if (errorCard) errorCard.remove();
        
        if (statConnected) statConnected.textContent = reCheckedList.filter(c => c.status === 'Connected').length;
        if (statIssues) {
          statIssues.textContent = '0 Issues';
          statIssues.style.color = 'var(--color-success)';
        }
        
        updateReadinessItem('chk-perm-read', true);
        updateReadinessItem('chk-perm-write', true);
        updateReadinessItem('chk-perm-tokens', true);
        
        if (fixBtn) {
          fixBtn.disabled = true;
          fixBtn.className = 'btn btn-secondary';
        }
        
        updateStepper(3, 'completed');
        updateStepper(4, 'active');
        
        generatePlanPipeline();
      };
      
    } else {
      updateReadinessItem('chk-perm-read', true);
      updateReadinessItem('chk-perm-write', true);
      updateReadinessItem('chk-perm-tokens', true);
      if (scenario && scenario.risk === 'high') {
        updateReadinessItem('chk-perm-admin', true);
      }
      
      updateStepper(3, 'completed');
      updateStepper(4, 'active');
      
      setTimeout(() => {
        generatePlanPipeline();
      }, 1200);
    }
  }, 1800);
}

function generatePlanPipeline() {
  updateReadinessPanelPercent(60, 'Generating Plan...');
  showThinking('Creating step-by-step agent execution plan...');
  
  setTimeout(() => {
    hideThinking();
    
    const scenario = SCENARIOS[chatState.currentScenario] || SCENARIOS['AWS & Snowflake Stage'];
    chatState.planData = scenario.plan;
    
    const riskBadge = document.getElementById('readiness-risk-badge');
    if (riskBadge) {
      riskBadge.textContent = scenario.risk;
      riskBadge.className = `status-badge ${scenario.risk === 'critical' ? 'danger' : scenario.risk === 'high' ? 'danger' : 'warning'}`;
    }
    
    appendPlanCard(scenario.plan);
    appendAgentPlan(scenario.agents);
    animateAgentCards();
    
  }, 1600);
}

function animateAgentCards() {
  const cards = document.querySelectorAll('.agent-card');
  let currentIdx = 0;
  
  function processNext() {
    if (currentIdx >= cards.length) {
      setTimeout(() => {
        triggerImpactReview();
      }, 1000);
      return;
    }
    
    const card = cards[currentIdx];
    const status = card.getAttribute('data-status');
    const badge = card.querySelector('.status-badge');
    
    if (status === 'Pending') {
      card.setAttribute('data-status', 'Running');
      if (badge) {
        badge.className = 'status-badge warning';
        badge.textContent = 'running';
      }
      
      setTimeout(() => {
        card.setAttribute('data-status', 'Completed');
        if (badge) {
          badge.className = 'status-badge success';
          badge.textContent = 'completed';
        }
        currentIdx++;
        processNext();
      }, 1200);
    } else {
      currentIdx++;
      processNext();
    }
  }
  
  setTimeout(processNext, 800);
}

function triggerImpactReview() {
  updateStepper(4, 'completed');
  updateStepper(5, 'active');
  
  showThinking('Analyzing affected systems, cost parameters, and security policies...');
  
  setTimeout(() => {
    hideThinking();
    updateReadinessPanelPercent(80, 'Impact Auditing...');
    
    const scenario = SCENARIOS[chatState.currentScenario] || SCENARIOS['AWS & Snowflake Stage'];
    appendImpactCard(scenario.impact);
    
    const stream = document.getElementById('chat-messages-stream');
    if (stream) stream.scrollTop = stream.scrollHeight;
    
    updateReadinessPanelPercent(95, 'Awaiting Auth');
    
  }, 1500);
}

function openAgreementModal() {
  const modal = document.getElementById('agreement-modal');
  if (!modal) return;
  
  const scenario = SCENARIOS[chatState.currentScenario] || SCENARIOS['AWS & Snowflake Stage'];
  const env = localStorage.getItem('adlc_env') || 'DEV';
  
  document.getElementById('modal-sum-req').textContent = scenario.plan.goal;
  document.getElementById('modal-sum-env').textContent = env;
  document.getElementById('modal-sum-systems').textContent = scenario.impact.affected.join(', ');
  document.getElementById('modal-sum-risk').textContent = scenario.risk;
  document.getElementById('modal-sum-cost').textContent = scenario.plan.cost;
  
  const banner = document.getElementById('modal-risk-banner');
  if (scenario.risk === 'critical' || scenario.risk === 'high') {
    banner.style.display = 'flex';
  } else {
    banner.style.display = 'none';
  }
  
  const checkboxes = document.querySelectorAll('.modal-agree-chk');
  checkboxes.forEach(c => c.checked = false);
  
  const approveBtn = document.getElementById('modal-approve-btn');
  if (approveBtn) approveBtn.disabled = true;
  
  modal.classList.add('active');
}

function validateModalChecklist() {
  const checkboxes = document.querySelectorAll('.modal-agree-chk');
  const approveBtn = document.getElementById('modal-approve-btn');
  if (!approveBtn) return;
  
  const allChecked = Array.from(checkboxes).every(c => c.checked);
  approveBtn.disabled = !allChecked;
}

function closeAgreementModal() {
  const modal = document.getElementById('agreement-modal');
  if (modal) modal.classList.remove('active');
}

function requestModalChanges() {
  closeAgreementModal();
  showToast('Change request submitted to planner. Adjusting requirements...', 'warning');
}

function approveAndStartExecution() {
  closeAgreementModal();
  
  updateStepper(5, 'completed');
  updateStepper(6, 'active');
  
  updateReadinessPanelPercent(96, 'Executing...');
  
  appendExecutionTimeline();
  simulateExecutionProgress();
}

function simulateExecutionProgress() {
  const timelineList = document.getElementById('exec-timeline-list');
  const progressText = document.getElementById('exec-progress-lbl');
  
  if (!timelineList) return;
  
  // Find which tasks are still pending or active (specifically execution/custom tasks starting from index 3)
  const pendingExecTasks = currentChecklistTasks.slice(3).filter(t => t.status === 'pending' || t.status === 'active');
  let currentStep = 0;
  
  function addStep() {
    if (currentStep >= pendingExecTasks.length) {
      setTimeout(() => {
        completeWorkflow();
      }, 1000);
      return;
    }
    
    // Mark previous timeline node as completed
    const nodes = timelineList.querySelectorAll('.timeline-node');
    if (nodes.length > 0) {
      const prevNode = nodes[nodes.length - 1];
      const prevIndicator = prevNode.querySelector('.timeline-indicator');
      if (prevIndicator) {
        prevIndicator.className = 'timeline-indicator completed';
        prevIndicator.innerHTML = '✓';
      }
    }
    
    const currentTask = pendingExecTasks[currentStep];
    // Set task to completed in checklist
    currentTask.status = 'completed';
    // Set next task to active
    if (currentStep + 1 < pendingExecTasks.length) {
      pendingExecTasks[currentStep + 1].status = 'active';
    }
    renderChecklistHUD();
    
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    
    const node = document.createElement('div');
    node.className = 'timeline-node';
    node.innerHTML = `
      <div class="timeline-indicator active">⚡</div>
      <div class="timeline-content">
        <div class="timeline-meta-row">
          <span class="timeline-step-name">${currentTask.text}</span>
          <span class="timeline-step-time">${timestamp}</span>
        </div>
        <p class="timeline-step-desc">Orchestration runner successfully executed active step payload.</p>
        <div class="timeline-step-log">INFO: [ADLC Engine] Executing... Done (${(Math.random()*1.2 + 0.5).toFixed(1)}s)</div>
      </div>
    `;
    
    timelineList.appendChild(node);
    
    if (progressText) {
      progressText.textContent = `Executing ${currentStep + 1} of ${pendingExecTasks.length} tasks...`;
    }
    
    const stream = document.getElementById('chat-messages-stream');
    if (stream) stream.scrollTop = stream.scrollHeight;
    
    currentStep++;
    setTimeout(addStep, 1200);
  }
  
  // Set first exec task active
  if (pendingExecTasks.length > 0) {
    pendingExecTasks[0].status = 'active';
    renderChecklistHUD();
  }
  
  setTimeout(addStep, 500);
}

function completeWorkflow() {
  updateStepper(6, 'completed');
  updateReadinessPanelPercent(100, 'Complete');
  
  currentChecklistTasks.forEach(t => t.status = 'completed');
  renderChecklistHUD();
  
  const timelineCard = document.getElementById('exec-timeline-card-node');
  if (timelineCard) {
    const indicators = timelineCard.querySelectorAll('.timeline-indicator');
    indicators.forEach(ind => {
      ind.className = 'timeline-indicator completed';
      ind.innerHTML = '✓';
    });
    
    const progressText = document.getElementById('exec-progress-lbl');
    if (progressText) progressText.textContent = 'Execution finished successfully.';
  }
  
  const scenario = SCENARIOS[chatState.currentScenario] || SCENARIOS['AWS & Snowflake Stage'];
  const env = localStorage.getItem('adlc_env') || 'DEV';
  
  const output = {
    summary: `Successfully completed all orchestration actions. Configured target resources in ${env} environment.`,
    changes: currentChecklistTasks.slice(3).map(t => t.text.replace('[Execute] ', '')),
    artifacts: [`adlc-audit-${scenario.id || 'custom'}.json`, `report-diagnostics.pdf`]
  };
  
  appendOutputCard(output);
  
  const runId = `RUN-${Math.floor(Math.random()*9000 + 1000)}`;
  const completedRun = {
    id: runId,
    name: scenario.plan ? scenario.plan.goal : 'Custom Orchestration Run',
    date: new Date().toISOString().replace('T', ' ').substring(0, 16),
    duration: scenario.plan ? scenario.plan.duration : '2 mins',
    cost: scenario.plan ? scenario.plan.cost : '$0.10',
    status: 'success',
    triggeredBy: 'NK (Chat)'
  };
  db.addRun(completedRun);
  renderRunHistoryHUD();
  switchSidebarTab('history');
  
  showToast(`Automation ${runId} executed successfully!`, 'success');
}

// ==========================================
// RENDER HTML CHAT COMPONENT HELPERS
// ==========================================

function appendUserMessage(text, attachments = []) {
  const container = document.getElementById('chat-messages-stream');
  if (!container) return;
  
  const msg = document.createElement('div');
  msg.className = 'msg msg-user';
  
  let attachmentChips = '';
  if (attachments && attachments.length > 0) {
    attachmentChips = attachments.map(att => {
      let icon = '📎';
      if (att.type === 'image') icon = '🖼️';
      else if (att.type === 'video') icon = '🎥';
      else if (att.type === 'code') icon = '💻';
      else if (att.type === 'zip') icon = '📦';
      else if (att.type === 'git') icon = '🐙';
      else if (att.type === 'web') icon = '🌐';
      return `<div class="file-chip" title="${att.name}">${icon} ${att.name}</div>`;
    }).join('');
  } else if (typeof attachments === 'string') {
    attachmentChips = `<div class="file-chip">📎 ${attachments}</div>`;
  }
  
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  
  msg.innerHTML = `
    ${attachmentChips}
    <div class="msg-content">${text}</div>
    <div class="msg-user-meta">
      <span>${timestamp}</span>
      <span>✓ Delivered</span>
    </div>
  `;
  
  container.appendChild(msg);
  container.scrollTop = container.scrollHeight;
}

function showThinking(text) {
  const container = document.getElementById('chat-messages-stream');
  if (!container) return;
  
  const msg = document.createElement('div');
  msg.className = 'msg msg-thinking';
  msg.id = 'active-thinking-loader';
  msg.innerHTML = `
    <div style="font-size:12px; color:var(--color-text-muted); font-weight:600; display:flex; align-items:center; gap:8px; padding-left:12px;">
      <div class="pulse-loader">
        <div class="pulse-dot"></div>
        <div class="pulse-dot"></div>
        <div class="pulse-dot"></div>
      </div>
      <span>${text}</span>
    </div>
  `;
  
  container.appendChild(msg);
  container.scrollTop = container.scrollHeight;
  chatState.activeThinkingElement = msg;
}

function hideThinking() {
  if (chatState.activeThinkingElement) {
    chatState.activeThinkingElement.remove();
    chatState.activeThinkingElement = null;
  }
}

function appendClarification(title, question, options) {
  const container = document.getElementById('chat-messages-stream');
  if (!container) return;
  
  const card = document.createElement('div');
  card.className = 'msg msg-system-card';
  card.innerHTML = `
    <div class="msg-header-row">
      <div class="msg-header-icon">❓</div>
      <div class="msg-header-title">${title}</div>
    </div>
    <p style="font-size:14px; font-weight:500; margin-bottom: 12px; line-height: 1.4;">${question}</p>
    <div class="quick-replies">
      ${options.map(opt => `<button class="btn btn-secondary btn-sm" onclick="replyClarification('${opt}')">${opt}</button>`).join('')}
    </div>
  `;
  
  container.appendChild(card);
  container.scrollTop = container.scrollHeight;
}

function appendConnectorCheck(connectors) {
  const container = document.getElementById('chat-messages-stream');
  if (!container) return;
  
  const card = document.createElement('div');
  card.className = 'msg msg-system-card';
  
  let headerTitle = 'Connector Audit Healthy';
  let headerIcon = '✓';
  let headerColor = 'success';
  
  const hasIssues = connectors.some(c => c.status !== 'Connected');
  if (hasIssues) {
    headerTitle = 'Connector Audit Action Required';
    headerIcon = '⚠';
    headerColor = 'warning';
  }
  
  card.innerHTML = `
    <div class="msg-header-row">
      <div class="msg-header-icon" style="background-color:rgba(${headerColor === 'success' ? '16,185,129' : '245,158,11'}, 0.08); color:var(--color-${headerColor})">${headerIcon}</div>
      <div class="msg-header-title">${headerTitle}</div>
    </div>
    <p style="font-size:13px; color:var(--color-text-muted); margin-bottom:14px;">Checks integration connection parameters and permission authorizations.</p>
    
    <div class="connector-val-cards">
      ${connectors.map(c => {
        let dotColor = 'success';
        let actionBtn = '';
        if (c.status === 'Needs Auth') {
          dotColor = 'warning';
          actionBtn = `<button class="btn btn-warning btn-sm" style="width:100%; margin-top:8px;" onclick="triggerConnectorFix('${c.id}')">Re-auth</button>`;
        } else if (c.status === 'Not Connected') {
          dotColor = 'danger';
          actionBtn = `<button class="btn btn-primary btn-sm" style="width:100%; margin-top:8px;" onclick="triggerConnectorFix('${c.id}')">Connect</button>`;
        } else if (c.status === 'Permission Issue') {
          dotColor = 'orange';
          actionBtn = `<button class="btn btn-secondary btn-sm" style="width:100%; margin-top:8px;" onclick="showToast('View Access: ${c.permission}', 'warning')">View Scopes</button>`;
        } else {
          actionBtn = `<button class="btn btn-secondary btn-sm" style="width:100%; margin-top:8px;" onclick="triggerConnectorFix('${c.id}')">Configure</button>`;
        }
        
        return `
          <div class="connector-val-card">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
              <span style="font-family:'Space Grotesk', sans-serif; font-weight:700; font-size:13px;">${c.name}</span>
              <span class="status-dot ${dotColor}"></span>
            </div>
            <div style="font-size:10px; color:var(--color-text-muted);">${c.category.toUpperCase()} • ${c.env}</div>
            <div style="font-size:10px; margin-top:6px; font-weight:600;">Status: ${c.status}</div>
            <div style="font-size:9px; color:var(--color-text-muted); margin-top:2px;">Scope: ${c.permission.substring(0, 22) || 'Ok'}...</div>
            ${actionBtn}
          </div>
        `;
      }).join('')}
    </div>
  `;
  
  container.appendChild(card);
  container.scrollTop = container.scrollHeight;
}

function appendErrorCard(status, name, reason) {
  const container = document.getElementById('chat-messages-stream');
  if (!container) return;
  
  const card = document.createElement('div');
  card.className = 'msg msg-system-card error-card';
  card.style.borderLeft = '4px solid var(--color-error)';
  card.innerHTML = `
    <div class="msg-header-row">
      <div class="msg-header-icon" style="background-color:rgba(239, 68, 68, 0.1); color:var(--color-error)">⚠</div>
      <div class="msg-header-title">Missing Connector Connection</div>
    </div>
    <div style="font-size:14px; font-weight:600; margin-bottom:6px;">Cannot continue because ${name} connector is not configured.</div>
    <p style="font-size:13px; color:var(--color-text-muted); margin-bottom:14px;">Reason: ${reason}</p>
    
    <div style="display:flex; gap:10px;">
      <button class="btn btn-danger btn-sm" onclick="triggerConnectorFix('${name.toLowerCase()}')">Re-authenticate Now</button>
      <button class="btn btn-secondary btn-sm" onclick="showToast('Admin help request submitted.', 'success')">Contact Admin</button>
    </div>
  `;
  
  container.appendChild(card);
  container.scrollTop = container.scrollHeight;
}

function appendPlanCard(plan) {
  const container = document.getElementById('chat-messages-stream');
  if (!container) return;
  
  const card = document.createElement('div');
  card.className = 'msg msg-system-card';
  card.innerHTML = `
    <div class="msg-header-row">
      <div class="msg-header-icon">⚙</div>
      <div class="msg-header-title">Automation Plan Generated</div>
    </div>
    
    <div style="background-color:rgba(0,0,0,0.02); border:1px solid var(--color-border); border-radius:var(--border-radius-sm); padding:16px; font-size:13px; margin-bottom:16px; line-height:1.5;">
      <div style="margin-bottom:10px;"><strong>Goal:</strong> ${plan.goal}</div>
      <div style="margin-bottom:10px;"><strong>Systems Involved:</strong> ${plan.systems}</div>
      <div style="margin-bottom:10px;"><strong>Trigger Source:</strong> ${plan.trigger}</div>
      
      <div style="margin-bottom:10px;">
        <strong>Sequence of Actions:</strong>
        <ol style="padding-left:20px; margin-top:4px;">
          ${plan.actions.map(act => `<li>${act}</li>`).join('')}
        </ol>
      </div>
      
      <div><strong>Expected Output:</strong> ${plan.output}</div>
    </div>

    <!-- Metadata stats -->
    <div style="display:grid; grid-template-columns: repeat(3, 1fr); gap:12px; margin-bottom:16px; text-align:center;">
      <div style="background-color:rgba(0,0,0,0.02); border:1px solid var(--color-border); border-radius:8px; padding:10px;">
        <div style="font-size:9px; font-weight:700; text-transform:uppercase; color:var(--color-text-muted);">Est. Duration</div>
        <div style="font-family:'Space Grotesk', sans-serif; font-size:14px; font-weight:700; margin-top:2px;">${plan.duration}</div>
      </div>
      <div style="background-color:rgba(0,0,0,0.02); border:1px solid var(--color-border); border-radius:8px; padding:10px;">
        <div style="font-size:9px; font-weight:700; text-transform:uppercase; color:var(--color-text-muted);">Token Usage</div>
        <div style="font-family:'Space Grotesk', sans-serif; font-size:14px; font-weight:700; margin-top:2px;">${plan.tokens}</div>
      </div>
      <div style="background-color:rgba(0,0,0,0.02); border:1px solid var(--color-border); border-radius:8px; padding:10px;">
        <div style="font-size:9px; font-weight:700; text-transform:uppercase; color:var(--color-text-muted);">Cloud Cost</div>
        <div style="font-family:'Space Grotesk', sans-serif; font-size:14px; font-weight:700; color:var(--color-secondary); margin-top:2px;">${plan.cost}</div>
      </div>
    </div>

    <div style="display:flex; flex-wrap:wrap; gap:10px;">
      <button class="btn btn-secondary btn-sm" onclick="showToast('Regenerating plan...', 'info')">Regenerate Plan</button>
      <button class="btn btn-secondary btn-sm" onclick="showToast('Saved to custom workspace templates.', 'success')">Save as Template</button>
    </div>
  `;
  
  container.appendChild(card);
  container.scrollTop = container.scrollHeight;
}

function appendAgentPlan(agents) {
  const container = document.getElementById('chat-messages-stream');
  if (!container) return;
  
  const card = document.createElement('div');
  card.className = 'msg msg-system-card';
  card.innerHTML = `
    <div class="msg-header-row">
      <div class="msg-header-icon">👥</div>
      <div class="msg-header-title">Agent-Wise Sub-Task Checklist</div>
    </div>
    <p style="font-size:13px; color:var(--color-text-muted); margin-bottom:12px;">ADLC splits planning tasks across functional specialized agent roles.</p>
    
    <div class="agents-grid">
      ${agents.map(ag => {
        let statusBadge = 'info';
        if (ag.status === 'Completed') statusBadge = 'success';
        if (ag.status === 'Blocked') statusBadge = 'danger';
        if (ag.status === 'Running') statusBadge = 'warning';
        
        return `
          <div class="agent-card" data-status="${ag.status}">
            <div class="agent-card-header">
              <span class="agent-name">${ag.name}</span>
              <span class="status-badge ${statusBadge}">${ag.status.toLowerCase()}</span>
            </div>
            <div class="agent-responsibility">${ag.responsibility}</div>
            <div class="agent-io">
              <div><strong>In:</strong> ${ag.input}</div>
              <div style="margin-top:2px;"><strong>Out:</strong> ${ag.output}</div>
            </div>
            <div style="font-size:9px; color:var(--color-text-muted); text-align:right;">Duration: ${ag.duration}</div>
          </div>
        `;
      }).join('')}
    </div>
  `;
  
  container.appendChild(card);
  container.scrollTop = container.scrollHeight;
}

function appendImpactCard(impact) {
  const container = document.getElementById('chat-messages-stream');
  if (!container) return;
  
  const card = document.createElement('div');
  card.className = 'msg msg-system-card';
  card.innerHTML = `
    <div class="msg-header-row">
      <div class="msg-header-icon" style="background-color:rgba(79,99,246,0.1); color:var(--color-primary);">⚖</div>
      <div class="msg-header-title">Review Impact Before Execution</div>
    </div>
    
    <table class="impact-table" style="font-size:13px;">
      <tr>
        <td style="font-weight:600; color:var(--color-text-muted); width:150px; border-bottom:1px solid var(--color-border); padding: 10px 0;">Affected Systems</td>
        <td style="font-weight:700; border-bottom:1px solid var(--color-border); padding: 10px 0;">${impact.affected.join(', ')}</td>
      </tr>
      <tr>
        <td style="font-weight:600; color:var(--color-text-muted); border-bottom:1px solid var(--color-border); padding: 10px 0;">Operation Scope</td>
        <td style="border-bottom:1px solid var(--color-border); padding: 10px 0;"><span class="status-badge info" style="border-radius:4px; padding:2px 6px;">${impact.type}</span></td>
      </tr>
      <tr>
        <td style="font-weight:600; color:var(--color-text-muted); border-bottom:1px solid var(--color-border); padding: 10px 0;">Risk Profile</td>
        <td style="border-bottom:1px solid var(--color-border); padding: 10px 0;"><span class="status-badge ${impact.risk === 'Critical' ? 'danger' : 'warning'}" style="border-radius:4px; padding:2px 6px;">${impact.risk}</span></td>
      </tr>
      <tr>
        <td style="font-weight:600; color:var(--color-text-muted); border-bottom:1px solid var(--color-border); padding: 10px 0;">Cost & Latency</td>
        <td style="border-bottom:1px solid var(--color-border); padding: 10px 0;">Cloud: <strong>${impact.costCloud}</strong> | LLM: <strong>${impact.costToken}</strong> | Latency: <strong>${impact.costDuration}</strong></td>
      </tr>
      <tr>
        <td style="font-weight:600; color:var(--color-text-muted); border-bottom:1px solid var(--color-border); padding: 10px 0;">Security Check</td>
        <td style="color:var(--color-error); font-weight:500; border-bottom:1px solid var(--color-border); padding: 10px 0;">⚠ ${impact.security}</td>
      </tr>
      <tr>
        <td style="font-weight:600; color:var(--color-text-muted); border-bottom:none; padding: 10px 0;">Rollback Strategy</td>
        <td style="color:var(--color-text-muted); font-style:italic; border-bottom:none; padding: 10px 0;">${impact.rollback}</td>
      </tr>
    </table>
    
    <!-- Action buttons -->
    <div style="margin-top:20px; border-top:1px solid var(--color-border); padding-top:16px; display:flex; gap:12px;">
      <button class="btn btn-primary" onclick="openAgreementModal()">Authorize Execution</button>
      <button class="btn btn-secondary" onclick="showToast('Review changes request logged.', 'info')">Request Modifications</button>
    </div>
  `;
  
  container.appendChild(card);
  container.scrollTop = container.scrollHeight;
}

function appendExecutionTimeline() {
  const container = document.getElementById('chat-messages-stream');
  if (!container) return;
  
  const card = document.createElement('div');
  card.className = 'msg msg-system-card';
  card.id = 'exec-timeline-card-node';
  card.innerHTML = `
    <div class="msg-header-row" style="justify-content:space-between;">
      <div style="display:flex; align-items:center; gap:12px;">
        <div class="msg-header-icon" style="background-color:rgba(14,165,233,0.08); color:var(--color-secondary);">⚡</div>
        <div class="msg-header-title">Automation Execution Timeline</div>
      </div>
      <span class="status-badge warning" id="exec-progress-lbl">Executing 0 of 8...</span>
    </div>
    
    <div class="timeline-list" id="exec-timeline-list" style="margin-top:20px;">
      <!-- Timeline nodes injected sequentially -->
    </div>
  `;
  
  container.appendChild(card);
  container.scrollTop = container.scrollHeight;
}

function appendOutputCard(output) {
  const container = document.getElementById('chat-messages-stream');
  if (!container) return;
  
  const card = document.createElement('div');
  card.className = 'msg msg-system-card';
  card.innerHTML = `
    <div class="msg-header-row">
      <div class="msg-header-icon" style="background-color:rgba(16,185,129,0.08); color:var(--color-success)">✓</div>
      <div class="msg-header-title">Automation Completed Successfully</div>
    </div>
    
    <div style="font-size:14px; margin-bottom:16px; line-height:1.5;">${output.summary}</div>
    
    <!-- Changes list -->
    <div style="margin-bottom:16px;">
      <strong style="font-size:13px;">Changes deployed:</strong>
      <ul style="padding-left:20px; font-size:13px; margin-top:4px; line-height:1.6;">
        ${output.changes.map(ch => `<li>${ch}</li>`).join('')}
      </ul>
    </div>

    <!-- Artifacts -->
    <div style="margin-bottom:20px;">
      <strong style="font-size:13px;">Generated Artifacts:</strong>
      <div style="display:flex; flex-wrap:wrap; gap:8px; margin-top:6px;">
        ${output.artifacts.map(art => `
          <span style="font-size:12px; border:1px solid var(--color-border); border-radius:4px; padding:6px 12px; display:inline-flex; align-items:center; gap:6px; background-color:rgba(0,0,0,0.02);">
            📄 ${art}
            <button style="background:transparent; border:none; color:var(--color-primary); cursor:pointer; font-weight:700; font-size:13px;" onclick="showToast('Downloading artifact: ${art}', 'success')">↓</button>
          </span>
        `).join('')}
      </div>
    </div>

    <div style="display:flex; flex-wrap:wrap; gap:10px; border-top:1px solid var(--color-border); padding-top:16px;">
      <button class="btn btn-primary btn-sm" onclick="showToast('Exporting logs to workspace file...', 'success')">Download Execution Logs</button>
      <button class="btn btn-secondary btn-sm" onclick="showToast('Opening follow-up task window...', 'info')">Create Follow-up Task</button>
      <button class="btn btn-secondary btn-sm" onclick="runWorkflowStateMachine()">Run Again</button>
    </div>
  `;
  
  container.appendChild(card);
  container.scrollTop = container.scrollHeight;
}

// ==========================================
// READINESS PANEL STATS UPDATE HELPERS
// ==========================================

// Action Checklist Array
// Action Checklist Array
let currentChecklistTasks = [];

function renderChecklistHUD() {
  const container = document.getElementById('hud-tasks-list');
  if (!container) return;
  
  if (currentChecklistTasks.length === 0) {
    container.innerHTML = `<div class="hud-task-empty">No active automation tasks loaded. Select a project below.</div>`;
    return;
  }
  
  container.innerHTML = currentChecklistTasks.map(task => {
    let icon = '⚪';
    let itemClass = '';
    if (task.status === 'completed') {
      icon = '🟢';
      itemClass = 'completed';
    } else if (task.status === 'active') {
      icon = '⚡';
      itemClass = 'active';
    } else if (task.status === 'blocked') {
      icon = '❌';
      itemClass = 'blocked';
    }
    
    return `
      <div class="hud-task-item ${itemClass}">
        <span class="hud-task-icon">${icon}</span>
        <span class="hud-task-text">${task.text}</span>
      </div>
    `;
  }).join('');
}

function updateReadinessItem(id, completed) {
  if (id === 'chk-req-captured') {
    const t = currentChecklistTasks.find(x => x.id === 'task-prep-analyze');
    if (t) t.status = completed ? 'completed' : 'pending';
    const next = currentChecklistTasks.find(x => x.id === 'task-prep-connectors');
    if (next && next.status === 'pending' && completed) next.status = 'active';
  } else if (id === 'chk-clarification' || id === 'chk-scope') {
    const t = currentChecklistTasks.find(x => x.id === 'task-prep-analyze');
    if (t && completed) t.status = 'completed';
    const next = currentChecklistTasks.find(x => x.id === 'task-prep-connectors');
    if (next && next.status === 'pending' && completed) next.status = 'active';
  } else if (id === 'chk-perm-read' || id === 'chk-perm-write' || id === 'chk-perm-tokens') {
    const t = currentChecklistTasks.find(x => x.id === 'task-prep-connectors');
    if (t) {
      if (completed) {
        t.status = 'completed';
        const next = currentChecklistTasks.find(x => x.id === 'task-prep-plan');
        if (next && next.status === 'pending') next.status = 'active';
      } else {
        t.status = 'blocked';
      }
    }
  }
  renderChecklistHUD();
}

function updateReadinessPanelPercent(percent, label, isBlocked = false) {
  const progressElem = document.getElementById('project-hud-progress');
  if (progressElem) {
    progressElem.textContent = `${percent}% Ready`;
    progressElem.style.color = isBlocked ? 'var(--color-error)' : 'var(--color-primary)';
  }
  
  if (isBlocked) {
    const t = currentChecklistTasks.find(x => x.id === 'task-prep-connectors');
    if (t) t.status = 'blocked';
  } else {
    if (percent >= 60 && percent < 80) {
      const t1 = currentChecklistTasks.find(x => x.id === 'task-prep-connectors');
      if (t1) t1.status = 'completed';
      const t2 = currentChecklistTasks.find(x => x.id === 'task-prep-plan');
      if (t2) t2.status = 'active';
    } else if (percent >= 80 && percent < 95) {
      const t1 = currentChecklistTasks.find(x => x.id === 'task-prep-plan');
      if (t1) t1.status = 'completed';
      if (currentChecklistTasks[3]) currentChecklistTasks[3].status = 'active';
    } else if (percent === 100) {
      currentChecklistTasks.forEach(t => t.status = 'completed');
    }
  }
  
  renderChecklistHUD();
}

function updateProjectHUD(scenarioName) {
  const scenario = SCENARIOS[scenarioName];
  const env = localStorage.getItem('adlc_env') || 'DEV';
  
  const hudName = document.getElementById('project-hud-name');
  const hudEnv = document.getElementById('project-hud-env');
  const hudSystems = document.getElementById('project-hud-systems');
  const hudRisk = document.getElementById('project-hud-risk');
  
  if (hudName) hudName.textContent = scenario ? scenarioName : 'General Chat Session';
  if (hudEnv) hudEnv.textContent = env;
  if (hudSystems) hudSystems.textContent = scenario ? scenario.systems.join(', ') : 'None';
  if (hudRisk) {
    if (scenario) {
      hudRisk.textContent = scenario.risk;
      hudRisk.className = `status-badge ${scenario.risk === 'critical' ? 'danger' : scenario.risk === 'high' ? 'danger' : 'warning'}`;
      hudRisk.style.fontSize = '9px';
      hudRisk.style.padding = '2px 6px';
    } else {
      hudRisk.textContent = '--';
      hudRisk.className = '';
    }
  }

  const cockpitBadge = document.getElementById('cockpit-active-project-badge');
  if (cockpitBadge) {
    cockpitBadge.textContent = scenario ? scenarioName : 'General Chat';
  }
}

function renderRunHistoryHUD() {
  const historyContainer = document.getElementById('hud-history-items');
  if (!historyContainer) return;
  
  const runs = db.getRuns().slice(0, 3);
  if (runs.length === 0) {
    historyContainer.innerHTML = `<span style="font-size:11px; color:var(--color-text-muted); font-style:italic;">No recent execution logs.</span>`;
    return;
  }
  
  historyContainer.innerHTML = runs.map(run => {
    let statusDotColor = 'success';
    if (run.status === 'failed') statusDotColor = 'danger';
    if (run.status === 'running') statusDotColor = 'warning';
    
    return `
      <div class="hud-history-item">
        <div style="display:flex; flex-direction:column; gap:2px; max-width: 70%; overflow:hidden;">
          <span style="font-weight:700; color:var(--color-text-dark); text-overflow:ellipsis; overflow:hidden; white-space:nowrap; text-align:left;">${run.name}</span>
          <span style="font-size:9px; color:var(--color-text-muted); text-align:left;">${run.date} • ${run.id}</span>
        </div>
        <div style="display:flex; align-items:center; gap:6px; flex-shrink:0;">
          <span class="status-dot ${statusDotColor}"></span>
          <span style="text-transform:uppercase; font-size:9px; font-weight:700; color:var(--color-text-dark);">${run.status}</span>
        </div>
      </div>
    `;
  }).join('');
}

// ==========================================
// CONNECTOR MODAL & FIX CREDENTIALS HELPERS
// ==========================================

let activeFixId = null;

function triggerConnectorFix(id) {
  const modal = document.getElementById('connector-modal');
  if (!modal) return;
  
  activeFixId = id;
  const connectors = db.getConnectors();
  const conn = connectors.find(c => c.id === id || c.name.toLowerCase() === id.toLowerCase());
  
  if (!conn) return;
  
  document.getElementById('conn-modal-title').textContent = `Configure Connection: ${conn.name}`;
  document.getElementById('conn-modal-auth').value = conn.authType;
  document.getElementById('conn-modal-scopes').value = conn.scopes.join(', ') || 'None required';
  document.getElementById('conn-modal-env').value = conn.env;
  document.getElementById('conn-modal-cred').value = '';
  
  modal.classList.add('active');
}

function closeConnectorModal() {
  const modal = document.getElementById('connector-modal');
  if (modal) modal.classList.remove('active');
}

function testModalConnection() {
  const btn = document.getElementById('conn-modal-test-btn');
  if (!btn) return;
  
  btn.textContent = 'Testing...';
  btn.disabled = true;
  
  setTimeout(() => {
    btn.textContent = 'Connection Successful ✓';
    btn.className = 'btn btn-success';
    showToast('Handshake verification returned Status 200.', 'success');
    
    setTimeout(() => {
      btn.textContent = 'Test Connection';
      btn.className = 'btn btn-warning';
      btn.disabled = false;
    }, 1500);
  }, 1200);
}

function saveModalConnection() {
  if (!activeFixId) return;
  
  const connectors = db.getConnectors();
  const connIdx = connectors.findIndex(c => c.id === activeFixId || c.name.toLowerCase() === activeFixId.toLowerCase());
  
  if (connIdx !== -1) {
    connectors[connIdx].status = 'Connected';
    connectors[connIdx].permission = 'Required access available';
    connectors[connIdx].env = document.getElementById('conn-modal-env').value;
    
    db.saveConnectors(connectors);
  }
  
  closeConnectorModal();
  showToast('Connector configurations stored successfully.', 'success');
  
  if (chatState.connectorResolveCallback) {
    chatState.connectorResolveCallback();
    chatState.connectorResolveCallback = null;
  }
}

// Initialize workspace panel log widgets on load
document.addEventListener('DOMContentLoaded', () => {
  renderRunHistoryHUD();
  populateConsoleProjects();
  
  // Load initial active project
  const firstScenario = Object.keys(SCENARIOS)[0] || 'general';
  chatState.currentScenario = firstScenario;
  loadProjectTasks(firstScenario);
  updateProjectHUD(firstScenario);
  
  setupRightSidebar();
  setupDragAndDrop();
  
  // Auto-resizing textarea like ChatGPT
  const textarea = document.getElementById('chat-input-field');
  if (textarea) {
    adjustTextareaHeight(textarea);
    textarea.addEventListener('input', function() {
      adjustTextareaHeight(this);
    });
  }
  
  // Handle environment switches in real-time
  const envSelector = document.getElementById('header-env-selector');
  if (envSelector) {
    envSelector.addEventListener('change', () => {
      updateProjectHUD(chatState.currentScenario);
    });
  }
});

// ==========================================
// CONSOLE COCKPIT PANEL AND MODAL HANDLERS
// ==========================================

function populateConsoleProjects() {
  renderProjectExplorer();
}

function loadProjectTasks(scenarioName) {
  const scenario = SCENARIOS[scenarioName];
  if (!scenario) {
    currentChecklistTasks = [
      { id: 'task-prep-analyze', text: '[Prep] Analyze requirement & verify parameters', status: 'pending' },
      { id: 'task-prep-connectors', text: '[Prep] Validate connector permissions & configurations', status: 'pending' },
      { id: 'task-prep-plan', text: '[Prep] Generate plan & assess risk profile', status: 'pending' },
      { id: 'task-exec-fallback', text: '[Execute] Run custom workspace automation action', status: 'pending' }
    ];
    renderChecklistHUD();
    return;
  }
  
  // Standard preparation tasks
  currentChecklistTasks = [
    { id: 'task-prep-analyze', text: '[Prep] Analyze requirement & verify parameters', status: 'pending' },
    { id: 'task-prep-connectors', text: '[Prep] Validate connector permissions & configurations', status: 'pending' },
    { id: 'task-prep-plan', text: '[Prep] Generate plan & assess risk profile', status: 'pending' }
  ];
  
  // Load scenario tasks
  scenario.plan.actions.forEach((act, idx) => {
    currentChecklistTasks.push({
      id: `task-exec-${idx}`,
      text: act,
      status: 'pending'
    });
  });
  
  renderChecklistHUD();
  
  // Update Cockpit console display items
  const taskCountBadge = document.getElementById('cockpit-task-count-badge');
  if (taskCountBadge) taskCountBadge.textContent = currentChecklistTasks.length;
  
  const riskBadge = document.getElementById('cockpit-risk-badge');
  if (riskBadge) {
    riskBadge.textContent = scenario.risk;
    riskBadge.className = `status-badge ${scenario.risk === 'critical' || scenario.risk === 'high' ? 'danger' : 'warning'}`;
  }
  
  const systemsContainer = document.getElementById('cockpit-systems-container');
  if (systemsContainer) {
    systemsContainer.innerHTML = scenario.systems.map(sys => `
      <span class="sys-pill">${sys}</span>
    `).join('');
  }
}

function handleConsoleProjectChange() {
  // Not used directly, selectProjectFromExplorer is used instead
}

function addCustomTaskFromConsole() {
  const input = document.getElementById('cockpit-task-input');
  if (!input) return;
  
  const text = input.value.trim();
  if (!text) return;
  
  // Inject into checklist
  currentChecklistTasks.push({
    id: `task-custom-${Date.now()}`,
    text: `[Execute] ${text}`,
    status: 'pending'
  });
  
  input.value = '';
  renderChecklistHUD();
  
  // Update task badge count
  const taskCountBadge = document.getElementById('cockpit-task-count-badge');
  if (taskCountBadge) taskCountBadge.textContent = currentChecklistTasks.length;
  
  showToast(`Task injected: "${text}"`, 'success');
}

function openCreateProjectModal() {
  const modal = document.getElementById('create-project-modal');
  if (modal) {
    modal.classList.add('active');
    
    // Clear forms
    document.getElementById('cp-name').value = '';
    document.getElementById('cp-goal').value = '';
    document.getElementById('cp-risk').value = 'medium';
    document.getElementById('cp-env').value = 'DEV';
    document.getElementById('cp-tasks').value = '';
    document.querySelectorAll('input[name="cp-systems"]').forEach(cb => cb.checked = false);
  }
}

function closeCreateProjectModal() {
  const modal = document.getElementById('create-project-modal');
  if (modal) modal.classList.remove('active');
}

function submitCreateProject() {
  const name = document.getElementById('cp-name').value.trim();
  const goal = document.getElementById('cp-goal').value.trim() || 'Custom automated task pipeline';
  const risk = document.getElementById('cp-risk').value;
  const env = document.getElementById('cp-env').value;
  const systems = Array.from(document.querySelectorAll('input[name="cp-systems"]:checked')).map(cb => cb.value);
  const tasksText = document.getElementById('cp-tasks').value.trim();
  const actions = tasksText ? tasksText.split('\n').map(t => t.trim()).filter(t => t.length > 0) : ['Perform custom data checks'];
  
  if (!name) {
    showToast('Please enter a Project Name.', 'warning');
    return;
  }
  
  // Register in SCENARIOS
  const agents = [
    { name: 'Requirement Analyst Agent', responsibility: 'Extracts Objective, systems, actions and constraints.', input: 'Natural Language prompt', output: 'JSON specification', status: 'Completed', duration: '2s' },
    { name: 'Connector Validator Agent', responsibility: 'Checks app connections, tokens and permissions.', input: `${systems.join(', ') || 'Sandbox'} access`, output: 'Active session tokens verified', status: 'Completed', duration: '2s' },
    { name: 'Plan Builder Agent', responsibility: 'Creates step-by-step automation plan.', input: 'Discovery payloads', output: 'Execution manifest', status: 'Completed', duration: '2s' },
    { name: 'Risk & Impact Agent', responsibility: 'Identifies affected systems, cost, and rollback details.', input: 'Plan manifest', output: 'Risk & rollback metadata', status: 'Completed', duration: '1s' },
    { name: 'Execution Agent', responsibility: 'Executes approved changes only after authorization.', input: 'Approved YAML blueprint', output: 'System states updated', status: 'Pending', duration: '4s' },
    { name: 'Audit & Logs Agent', responsibility: 'Captures logs, outputs, and artifacts.', input: 'Runtime stream', output: 'Logs table, reports', status: 'Pending', duration: '2s' }
  ];

  SCENARIOS[name] = {
    id: `custom_${Date.now()}`,
    prompt: goal,
    systems: systems.length > 0 ? systems : ['Sandbox'],
    question: `Which secondary target environment should this custom ${name} check perform in?`,
    replies: [env, 'DEV', 'UAT'],
    risk: risk,
    plan: {
      goal: goal,
      systems: systems.join(', ') || 'Custom Workspace Sandbox',
      trigger: 'Manual API Trigger / Cockpit Console',
      actions: actions,
      output: 'Success status confirmation logs',
      risk: risk.charAt(0).toUpperCase() + risk.slice(1) + ' Risk',
      duration: `${actions.length * 0.5 + 1} mins`,
      tokens: '3,000',
      cost: '$0.10'
    },
    agents: agents,
    impact: {
      affected: systems.length > 0 ? systems.map(s => `${s} Configurations`) : ['Sandbox Configurations'],
      type: 'Update configurations & custom integration actions',
      risk: risk.charAt(0).toUpperCase() + risk.slice(1),
      costCloud: '$0.10 / run',
      costToken: '3,000 tokens ($0.06)',
      costDuration: `${actions.length * 0.5 + 1} minutes`,
      security: `Requires active integration keys for ${systems.join(', ') || 'Sandbox'}.`,
      rollback: 'Changes can be rolled back via Cloud state rollbacks.',
      environment: env
    }
  };
  
  // Re-populate project list in Explorer modal grid
  populateConsoleProjects();
  
  // Select it
  chatState.currentScenario = name;
  loadProjectTasks(name);
  updateProjectHUD(name);
  
  // Print message in stream
  const container = document.getElementById('chat-messages-stream');
  if (container) {
    const welcome = document.getElementById('chat-welcome-state');
    if (welcome) welcome.style.display = 'none';
    
    const msg = document.createElement('div');
    msg.className = 'msg msg-system-card';
    msg.style.borderLeft = '4px solid var(--color-primary)';
    msg.innerHTML = `
      <div style="font-size:12px; font-weight:600; color:var(--color-primary); text-transform:uppercase; letter-spacing:0.5px; margin-bottom:6px;">Custom Project Created</div>
      <div style="font-size:14px; font-weight:700; color:var(--color-text-dark); margin-bottom:4px;">📁 ${name}</div>
      <p style="font-size:13px; color:var(--color-text-muted); margin-bottom:0;">Successfully configured custom project automation metadata in sandbox telemetry. Loaded ${actions.length} custom action items.</p>
    `;
    container.appendChild(msg);
    container.scrollTop = container.scrollHeight;
  }
  
  closeCreateProjectModal();
  showToast(`Custom Project "${name}" created!`, 'success');
}

function executeConsoleAutomation() {
  if (currentChecklistTasks.length === 0) {
    showToast('Please load a project or add tasks first.', 'warning');
    return;
  }
  
  // Trigger requirement submit flow
  submitRequirement();
}

// ==========================================
// PROJECT EXPLORER HUD MODAL HELPERS
// ==========================================

function openProjectExplorerModal() {
  const modal = document.getElementById('project-explorer-modal');
  if (modal) {
    renderProjectExplorer();
    modal.classList.add('active');
  }
}

function closeProjectExplorerModal() {
  const modal = document.getElementById('project-explorer-modal');
  if (modal) modal.classList.remove('active');
}

function renderProjectExplorer() {
  const grid = document.getElementById('project-explorer-grid');
  if (!grid) return;
  
  let html = '';
  
  // Loop existing scenarios
  for (const [name, data] of Object.entries(SCENARIOS)) {
    const isCurrent = chatState.currentScenario === name;
    const sysBadges = data.systems.map(s => `<span class="sys-pill">${s}</span>`).join('');
    const riskClass = data.risk === 'critical' || data.risk === 'high' ? 'danger' : 'warning';
    
    html += `
      <div class="explorer-card ${isCurrent ? 'active' : ''}" onclick="selectProjectFromExplorer('${name.replace(/'/g, "\\'")}')">
        <div>
          <div class="explorer-card-title">${name}</div>
          <div class="explorer-card-desc">${data.plan ? data.plan.goal : data.prompt}</div>
        </div>
        <div class="explorer-card-footer">
          <div class="systems-badge-container">${sysBadges}</div>
          <span class="status-badge ${riskClass}" style="font-size:8px; padding: 2px 6px;">${data.risk}</span>
        </div>
      </div>
    `;
  }
  
  // Add "Create Custom Project" Card
  html += `
    <div class="explorer-card create-new-card" onclick="triggerCreateProjectFromExplorer()">
      <div class="create-new-card-content">
        <div class="create-new-card-icon">+</div>
        <div class="create-new-card-label">New Project</div>
      </div>
    </div>
  `;
  
  grid.innerHTML = html;
}

function selectProjectFromExplorer(projectName) {
  closeProjectExplorerModal();
  
  chatState.currentScenario = projectName;
  loadProjectTasks(projectName);
  updateProjectHUD(projectName);
  
  // Print message in stream
  const container = document.getElementById('chat-messages-stream');
  if (container) {
    const welcome = document.getElementById('chat-welcome-state');
    if (welcome) welcome.style.display = 'none';
    
    const msg = document.createElement('div');
    msg.className = 'msg msg-system-card';
    msg.style.borderLeft = '4px solid var(--color-primary)';
    msg.innerHTML = `
      <div style="font-size:12px; font-weight:600; color:var(--color-primary); text-transform:uppercase; letter-spacing:0.5px; margin-bottom:6px;">Project Scope Changed</div>
      <div style="font-size:14px; font-weight:700; color:var(--color-text-dark); margin-bottom:4px;">📁 ${projectName}</div>
      <p style="font-size:13px; color:var(--color-text-muted); margin-bottom:0;">Loaded project automation metadata and ${SCENARIOS[projectName].plan.actions.length} action items into sandbox cockpit. Ready to run.</p>
    `;
    container.appendChild(msg);
    container.scrollTop = container.scrollHeight;
  }
  
  showToast(`Loaded Project: ${projectName}`, 'success');
}

function triggerCreateProjectFromExplorer() {
  closeProjectExplorerModal();
  setTimeout(() => {
    openCreateProjectModal();
  }, 300);
}

// Toggle Right Sidebar (HUD Cockpit Panel)
function setupRightSidebar() {
  const toggleBtn = document.getElementById('right-sidebar-toggle-btn');
  const panel = document.querySelector('.readiness-panel');
  
  if (!toggleBtn || !panel) return;
  
  // Load preference
  const isCollapsed = localStorage.getItem('adlc_right_sidebar_collapsed') === 'true';
  if (isCollapsed) {
    panel.classList.add('collapsed');
    toggleBtn.classList.add('sidebar-collapsed');
  }
  
  toggleBtn.addEventListener('click', () => {
    const collapsed = panel.classList.toggle('collapsed');
    localStorage.setItem('adlc_right_sidebar_collapsed', collapsed);
    if (collapsed) {
      toggleBtn.classList.add('sidebar-collapsed');
      showToast('Right cockpit panel hidden', 'info');
    } else {
      toggleBtn.classList.remove('sidebar-collapsed');
      showToast('Right cockpit panel visible', 'info');
    }
  });
}

// Sidebar Tab Switcher
function switchSidebarTab(tabName) {
  // Remove active class from all tabs
  const tabs = document.querySelectorAll('.hud-sidebar-tab');
  tabs.forEach(tab => tab.classList.remove('active'));
  
  // Remove active class from all tab contents
  const contents = document.querySelectorAll('.hud-tab-content');
  contents.forEach(content => content.classList.remove('active'));
  
  // Add active class to selected tab and content
  const selectedTab = Array.from(tabs).find(t => t.getAttribute('onclick').includes(tabName));
  if (selectedTab) selectedTab.classList.add('active');
  
  const selectedContent = document.getElementById(`hud-tab-${tabName}`);
  if (selectedContent) selectedContent.classList.add('active');
  
  // Proactively expand sidebar if it was collapsed
  const panel = document.querySelector('.readiness-panel');
  const toggleBtn = document.getElementById('right-sidebar-toggle-btn');
  if (panel && panel.classList.contains('collapsed')) {
    panel.classList.remove('collapsed');
    localStorage.setItem('adlc_right_sidebar_collapsed', 'false');
    if (toggleBtn) toggleBtn.classList.remove('sidebar-collapsed');
    showToast('Right cockpit panel expanded to show task execution', 'info');
  }
}

// Workflow Stepper Updates (Failsafe no-op when stepper is not in DOM)
function updateStepper(stepNum, status) {
  const stepElem = document.getElementById(`step-${stepNum}`);
  if (!stepElem) return;
  
  stepElem.className = `stepper-item ${status}`;
}
