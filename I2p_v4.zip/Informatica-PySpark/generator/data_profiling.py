from collections import defaultdict

class DataProfiler:
    def __init__(self):
        self.type_mappings = {
            'string': {'pyspark': 'StringType()', 'suggest_partition': False},
            'varchar': {'pyspark': 'StringType()', 'suggest_partition': False},
            'char': {'pyspark': 'StringType()', 'suggest_partition': False},
            'nvarchar': {'pyspark': 'StringType()', 'suggest_partition': False},
            'text': {'pyspark': 'StringType()', 'suggest_partition': False},
            'integer': {'pyspark': 'IntegerType()', 'suggest_partition': True},
            'int': {'pyspark': 'IntegerType()', 'suggest_partition': True},
            'smallint': {'pyspark': 'ShortType()', 'suggest_partition': False},
            'bigint': {'pyspark': 'LongType()', 'suggest_partition': True},
            'long': {'pyspark': 'LongType()', 'suggest_partition': True},
            'decimal': {'pyspark': 'DecimalType()', 'suggest_partition': False},
            'number': {'pyspark': 'DecimalType()', 'suggest_partition': False},
            'numeric': {'pyspark': 'DecimalType()', 'suggest_partition': False},
            'float': {'pyspark': 'FloatType()', 'suggest_partition': False},
            'double': {'pyspark': 'DoubleType()', 'suggest_partition': False},
            'real': {'pyspark': 'FloatType()', 'suggest_partition': False},
            'date': {'pyspark': 'DateType()', 'suggest_partition': True},
            'datetime': {'pyspark': 'TimestampType()', 'suggest_partition': True},
            'timestamp': {'pyspark': 'TimestampType()', 'suggest_partition': True},
            'boolean': {'pyspark': 'BooleanType()', 'suggest_partition': False},
            'bool': {'pyspark': 'BooleanType()', 'suggest_partition': False},
            'binary': {'pyspark': 'BinaryType()', 'suggest_partition': False},
            'blob': {'pyspark': 'BinaryType()', 'suggest_partition': False},
            'clob': {'pyspark': 'StringType()', 'suggest_partition': False},
        }
        
        self.partition_keywords = ['date', 'year', 'month', 'day', 'region', 'country', 'type', 'category', 'status']
        self.id_keywords = ['id', 'key', 'code', 'num', 'no']
    
    def profile_workflow(self, parsed_data):
        sources = parsed_data.get('sources', [])
        targets = parsed_data.get('targets', [])
        transformations = parsed_data.get('transformations', [])
        
        all_fields = []
        for source in sources:
            for field in source.get('fields', []):
                all_fields.append({
                    **field,
                    'origin': 'source',
                    'table': source.get('name', 'Unknown')
                })
        
        for target in targets:
            for field in target.get('fields', []):
                all_fields.append({
                    **field,
                    'origin': 'target',
                    'table': target.get('name', 'Unknown')
                })
        
        profile = {
            'summary': self._generate_summary(sources, targets, transformations),
            'field_analysis': self._analyze_fields(all_fields),
            'type_distribution': self._analyze_type_distribution(all_fields),
            'partition_suggestions': self._suggest_partitions(all_fields),
            'optimization_hints': self._generate_optimization_hints(parsed_data),
            'schema_recommendations': self._generate_schema_recommendations(all_fields),
            'data_quality_checks': self._suggest_quality_checks(all_fields)
        }
        
        return profile
    
    def _generate_summary(self, sources, targets, transformations):
        total_source_fields = sum(len(s.get('fields', [])) for s in sources)
        total_target_fields = sum(len(t.get('fields', [])) for t in targets)
        
        trans_types = defaultdict(int)
        if isinstance(transformations, dict):
            for t in transformations.values():
                if isinstance(t, dict):
                    trans_types[t.get('type', 'Unknown')] += 1
        elif isinstance(transformations, list):
            for t in transformations:
                trans_types[t.get('type', 'Unknown')] += 1
        
        return {
            'source_tables': len(sources),
            'target_tables': len(targets),
            'total_transformations': len(transformations),
            'source_field_count': total_source_fields,
            'target_field_count': total_target_fields,
            'transformation_types': dict(trans_types),
            'complexity_score': self._calculate_complexity(transformations)
        }
    
    def _calculate_complexity(self, transformations):
        if isinstance(transformations, dict):
            trans_list = [t for t in transformations.values() if isinstance(t, dict)]
        else:
            trans_list = transformations if transformations else []
        
        score = len(trans_list)
        
        for t in trans_list:
            t_type = t.get('type', '')
            if t_type in ['Joiner', 'Lookup']:
                score += 2
            elif t_type in ['Aggregator', 'Router']:
                score += 1.5
            elif t_type == 'Expression':
                fields = t.get('fields', [])
                expr_count = sum(1 for f in fields if f.get('expression'))
                score += expr_count * 0.1
        
        if score < 5:
            return {'score': round(score, 1), 'level': 'Low', 'color': '#22c55e'}
        elif score < 15:
            return {'score': round(score, 1), 'level': 'Medium', 'color': '#f59e0b'}
        else:
            return {'score': round(score, 1), 'level': 'High', 'color': '#ef4444'}
    
    def _analyze_fields(self, fields):
        analysis = []
        
        for field in fields:
            name = field.get('name', '')
            dtype = field.get('datatype', 'string').lower()
            precision = field.get('precision', 0)
            scale = field.get('scale', 0)
            
            type_info = self.type_mappings.get(dtype, {'pyspark': 'StringType()', 'suggest_partition': False})
            
            pyspark_type = type_info['pyspark']
            if 'Decimal' in pyspark_type and (precision or scale):
                pyspark_type = f"DecimalType({precision}, {scale})"
            
            analysis.append({
                'name': name,
                'original_type': dtype,
                'pyspark_type': pyspark_type,
                'precision': precision,
                'scale': scale,
                'origin': field.get('origin', 'unknown'),
                'table': field.get('table', 'Unknown'),
                'is_nullable': field.get('nullable', True),
                'is_key_candidate': self._is_key_candidate(name),
                'is_partition_candidate': self._is_partition_candidate(name, dtype)
            })
        
        return analysis
    
    def _is_key_candidate(self, name):
        name_lower = name.lower()
        return any(kw in name_lower for kw in self.id_keywords)
    
    def _is_partition_candidate(self, name, dtype):
        name_lower = name.lower()
        dtype_lower = dtype.lower()
        
        if any(kw in name_lower for kw in self.partition_keywords):
            return True
        
        if dtype_lower in ['date', 'datetime', 'timestamp']:
            return True
        
        return False
    
    def _analyze_type_distribution(self, fields):
        distribution = defaultdict(int)
        
        for field in fields:
            dtype = field.get('datatype', 'string').lower()
            category = self._categorize_type(dtype)
            distribution[category] += 1
        
        total = len(fields) if fields else 1
        
        return {
            'counts': dict(distribution),
            'percentages': {k: round(v / total * 100, 1) for k, v in distribution.items()}
        }
    
    def _categorize_type(self, dtype):
        dtype = dtype.lower()
        if dtype in ['string', 'varchar', 'char', 'nvarchar', 'text', 'clob']:
            return 'String'
        elif dtype in ['integer', 'int', 'smallint', 'bigint', 'long']:
            return 'Integer'
        elif dtype in ['decimal', 'number', 'numeric', 'float', 'double', 'real']:
            return 'Numeric'
        elif dtype in ['date', 'datetime', 'timestamp']:
            return 'DateTime'
        elif dtype in ['boolean', 'bool']:
            return 'Boolean'
        elif dtype in ['binary', 'blob']:
            return 'Binary'
        else:
            return 'Other'
    
    def _suggest_partitions(self, fields):
        suggestions = []
        
        for field in fields:
            if field.get('origin') != 'source':
                continue
            
            name = field.get('name', '')
            dtype = field.get('datatype', '').lower()
            
            if self._is_partition_candidate(name, dtype):
                reason = []
                if dtype in ['date', 'datetime', 'timestamp']:
                    reason.append('Date/time field - ideal for time-based partitioning')
                if any(kw in name.lower() for kw in ['year', 'month', 'day']):
                    reason.append('Contains date component in name')
                if any(kw in name.lower() for kw in ['region', 'country']):
                    reason.append('Geographic field - good for regional queries')
                if any(kw in name.lower() for kw in ['type', 'category', 'status']):
                    reason.append('Categorical field - useful for filtering')
                
                suggestions.append({
                    'field': name,
                    'table': field.get('table', 'Unknown'),
                    'type': dtype,
                    'reasons': reason,
                    'priority': 'High' if dtype in ['date', 'datetime', 'timestamp'] else 'Medium'
                })
        
        return sorted(suggestions, key=lambda x: 0 if x['priority'] == 'High' else 1)
    
    def _generate_optimization_hints(self, parsed_data):
        hints = []
        
        transformations = parsed_data.get('transformations', {})
        if isinstance(transformations, dict):
            trans_list = [t for t in transformations.values() if isinstance(t, dict)]
        else:
            trans_list = transformations if transformations else []
        
        lookups = [t for t in trans_list if t.get('type') == 'Lookup']
        if lookups:
            hints.append({
                'category': 'Join Optimization',
                'hint': f'Found {len(lookups)} lookup(s). Consider using broadcast joins for small lookup tables.',
                'code_snippet': 'df.join(broadcast(lookup_df), on="key")',
                'priority': 'High'
            })
        
        joiners = [t for t in trans_list if t.get('type') == 'Joiner']
        if joiners:
            hints.append({
                'category': 'Join Strategy',
                'hint': f'Found {len(joiners)} joiner(s). Pre-partition data on join keys for better performance.',
                'code_snippet': 'df.repartition("join_key").join(other_df.repartition("join_key"))',
                'priority': 'Medium'
            })
        
        aggregators = [t for t in trans_list if t.get('type') == 'Aggregator']
        if aggregators:
            hints.append({
                'category': 'Aggregation',
                'hint': f'Found {len(aggregators)} aggregator(s). Cache intermediate results if reused.',
                'code_snippet': 'aggregated_df.cache()',
                'priority': 'Medium'
            })
        
        sorters = [t for t in trans_list if t.get('type') == 'Sorter']
        if sorters:
            hints.append({
                'category': 'Sorting',
                'hint': f'Found {len(sorters)} sorter(s). Global sorting is expensive. Use range partitioning if possible.',
                'code_snippet': 'df.repartitionByRange("sort_column")',
                'priority': 'Low'
            })
        
        if len(trans_list) > 10:
            hints.append({
                'category': 'Pipeline Checkpointing',
                'hint': 'Complex pipeline detected. Consider checkpointing to break lineage.',
                'code_snippet': 'spark.sparkContext.setCheckpointDir("/tmp/checkpoints")\ndf.checkpoint()',
                'priority': 'Medium'
            })
        
        return hints
    
    def _generate_schema_recommendations(self, fields):
        recommendations = []
        
        string_fields = [f for f in fields if f.get('datatype', '').lower() in ['string', 'varchar', 'char']]
        if string_fields:
            high_precision = [f for f in string_fields if f.get('precision', 0) > 1000]
            if high_precision:
                recommendations.append({
                    'type': 'Large String Fields',
                    'fields': [f['name'] for f in high_precision[:5]],
                    'recommendation': 'Consider using text compression or storing in separate files',
                    'impact': 'Memory and storage optimization'
                })
        
        decimal_fields = [f for f in fields if 'decimal' in f.get('datatype', '').lower() or 'number' in f.get('datatype', '').lower()]
        for field in decimal_fields:
            if field.get('precision', 0) > 18:
                recommendations.append({
                    'type': 'High Precision Decimal',
                    'fields': [field['name']],
                    'recommendation': f"Precision {field.get('precision')} may cause overflow. Consider DoubleType or StringType.",
                    'impact': 'Data accuracy'
                })
        
        return recommendations
    
    def _suggest_quality_checks(self, fields):
        checks = []
        
        for field in fields:
            name = field.get('name', '').lower()
            dtype = field.get('datatype', '').lower()
            
            if any(kw in name for kw in self.id_keywords):
                checks.append({
                    'field': field.get('name'),
                    'check': 'Uniqueness',
                    'code': f"df.groupBy('{field.get('name')}').count().filter('count > 1')",
                    'description': 'Check for duplicate key values'
                })
            
            if dtype in ['date', 'datetime', 'timestamp']:
                checks.append({
                    'field': field.get('name'),
                    'check': 'Date Range',
                    'code': f"df.select(min('{field.get('name')}'), max('{field.get('name')}'))",
                    'description': 'Verify date values are within expected range'
                })
            
            if not field.get('nullable', True):
                checks.append({
                    'field': field.get('name'),
                    'check': 'Null Check',
                    'code': f"df.filter(col('{field.get('name')}').isNull()).count()",
                    'description': 'Ensure non-nullable field has no nulls'
                })
        
        seen = set()
        unique_checks = []
        for check in checks:
            key = (check['field'], check['check'])
            if key not in seen:
                seen.add(key)
                unique_checks.append(check)
        
        return unique_checks[:20]
    
    def compare_source_target_fields(self, parsed_data):
        """Compare source and target fields to identify mappings, gaps, and transformations."""
        sources = parsed_data.get('sources', [])
        targets = parsed_data.get('targets', [])
        connectors = parsed_data.get('connectors', [])
        
        source_fields = {}
        for source in sources:
            source_name = source.get('name', 'Unknown')
            for field in source.get('fields', []):
                field_name = field.get('name', '')
                source_fields[field_name.upper()] = {
                    'name': field_name,
                    'table': source_name,
                    'datatype': field.get('datatype', ''),
                    'precision': field.get('precision', ''),
                    'scale': field.get('scale', ''),
                    'nullable': field.get('nullable', '')
                }
        
        target_fields = {}
        for target in targets:
            target_name = target.get('name', 'Unknown')
            for field in target.get('fields', []):
                field_name = field.get('name', '')
                target_fields[field_name.upper()] = {
                    'name': field_name,
                    'table': target_name,
                    'datatype': field.get('datatype', ''),
                    'precision': field.get('precision', ''),
                    'scale': field.get('scale', ''),
                    'nullable': field.get('nullable', '')
                }
        
        field_lineage = self._build_field_lineage(connectors)
        
        comparison = {
            'matched_fields': [],
            'source_only': [],
            'target_only': [],
            'type_mismatches': [],
            'precision_changes': [],
            'field_lineage': field_lineage,
            'summary': {}
        }
        
        source_keys = set(source_fields.keys())
        target_keys = set(target_fields.keys())
        
        matched = source_keys & target_keys
        for field_key in matched:
            sf = source_fields[field_key]
            tf = target_fields[field_key]
            
            match_info = {
                'field_name': sf['name'],
                'source_table': sf['table'],
                'target_table': tf['table'],
                'source_type': sf['datatype'],
                'target_type': tf['datatype'],
                'source_precision': sf['precision'],
                'target_precision': tf['precision']
            }
            comparison['matched_fields'].append(match_info)
            
            if sf['datatype'].lower() != tf['datatype'].lower():
                comparison['type_mismatches'].append({
                    'field': sf['name'],
                    'source_type': sf['datatype'],
                    'target_type': tf['datatype'],
                    'risk': 'High' if self._is_type_change_risky(sf['datatype'], tf['datatype']) else 'Low'
                })
            
            if sf['precision'] != tf['precision']:
                comparison['precision_changes'].append({
                    'field': sf['name'],
                    'source_precision': sf['precision'],
                    'target_precision': tf['precision'],
                    'source_scale': sf['scale'],
                    'target_scale': tf['scale']
                })
        
        for field_key in (source_keys - target_keys):
            sf = source_fields[field_key]
            comparison['source_only'].append({
                'field_name': sf['name'],
                'table': sf['table'],
                'datatype': sf['datatype'],
                'reason': 'Not mapped to target'
            })
        
        for field_key in (target_keys - source_keys):
            tf = target_fields[field_key]
            comparison['target_only'].append({
                'field_name': tf['name'],
                'table': tf['table'],
                'datatype': tf['datatype'],
                'reason': 'Derived or calculated field'
            })
        
        comparison['summary'] = {
            'total_source_fields': len(source_fields),
            'total_target_fields': len(target_fields),
            'matched_count': len(matched),
            'source_only_count': len(source_keys - target_keys),
            'target_only_count': len(target_keys - source_keys),
            'type_mismatch_count': len(comparison['type_mismatches']),
            'precision_change_count': len(comparison['precision_changes']),
            'match_percentage': round(len(matched) / max(len(target_keys), 1) * 100, 1)
        }
        
        return comparison
    
    def _build_field_lineage(self, connectors):
        """Build field lineage from connector information."""
        lineage = []
        for conn in connectors:
            lineage.append({
                'source_instance': conn.get('from_instance', ''),
                'source_field': conn.get('from_field', ''),
                'target_instance': conn.get('to_instance', ''),
                'target_field': conn.get('to_field', ''),
                'source_type': conn.get('from_instance_type', ''),
                'target_type': conn.get('to_instance_type', '')
            })
        return lineage[:100]
    
    def _is_type_change_risky(self, source_type, target_type):
        """Determine if a type change is risky (potential data loss)."""
        source = source_type.lower()
        target = target_type.lower()
        
        risky_changes = [
            ('decimal', 'integer'),
            ('decimal', 'int'),
            ('double', 'float'),
            ('bigint', 'int'),
            ('long', 'int'),
            ('varchar', 'char'),
            ('string', 'integer'),
            ('string', 'date')
        ]
        
        for s, t in risky_changes:
            if s in source and t in target:
                return True
        return False
    
    def analyze_connectors_for_optimization(self, connectors, transformations):
        """Analyze connector patterns for join optimization hints."""
        hints = []
        
        if isinstance(transformations, dict):
            trans_list = list(transformations.values())
        else:
            trans_list = transformations or []
        
        join_targets = defaultdict(int)
        for conn in connectors:
            to_inst = conn.get('to_instance', '')
            join_targets[to_inst] += 1
        
        high_fanin = [(inst, count) for inst, count in join_targets.items() if count > 2]
        for inst, count in high_fanin:
            hints.append({
                'category': 'Join Optimization',
                'target': inst,
                'connections': count,
                'hint': f'Instance {inst} has {count} incoming connections. Consider broadcast join if one source is small.',
                'code_snippet': f'# For small lookup table:\ndf_{inst} = small_df.hint("broadcast").join(large_df, on="key")'
            })
        
        lookup_count = sum(1 for t in trans_list if isinstance(t, dict) and t.get('type') == 'Lookup')
        if lookup_count > 3:
            hints.append({
                'category': 'Caching',
                'hint': f'Found {lookup_count} lookups. Cache frequently used lookup tables.',
                'code_snippet': 'lookup_df.cache()\n# or persist to disk:\nlookup_df.persist(StorageLevel.DISK_ONLY)'
            })
        
        return hints
