"""
Audit Trail Logger
Logs all conversion decisions for compliance and debugging.
"""

from datetime import datetime
import json
import hashlib


class AuditTrail:
    """Records all conversion decisions and actions for compliance."""
    
    def __init__(self):
        self.entries = []
        self.session_id = self._generate_session_id()
        self.start_time = datetime.now()
    
    def _generate_session_id(self):
        """Generate unique session ID."""
        timestamp = datetime.now().isoformat()
        return hashlib.md5(timestamp.encode()).hexdigest()[:12]
    
    def log_action(self, action_type, component, details, decision=None, outcome='success'):
        """Log a conversion action."""
        entry = {
            'timestamp': datetime.now().isoformat(),
            'session_id': self.session_id,
            'action_type': action_type,
            'component': component,
            'details': details,
            'decision': decision,
            'outcome': outcome
        }
        self.entries.append(entry)
        return entry
    
    def log_parse_start(self, filename=None, file_size=None):
        """Log parsing start."""
        return self.log_action(
            action_type='PARSE_START',
            component='XMLParser',
            details={
                'filename': filename,
                'file_size': file_size,
                'timestamp': datetime.now().isoformat()
            }
        )
    
    def log_parse_complete(self, parsed_data):
        """Log parsing completion with summary."""
        return self.log_action(
            action_type='PARSE_COMPLETE',
            component='XMLParser',
            details={
                'sources_found': len(parsed_data.get('sources', [])),
                'targets_found': len(parsed_data.get('targets', [])),
                'transformations_found': len(parsed_data.get('transformations', {})),
                'connectors_found': len(parsed_data.get('connectors', []))
            }
        )
    
    def log_transformation_conversion(self, trans_name, trans_type, decision, notes=None):
        """Log a transformation conversion decision."""
        return self.log_action(
            action_type='TRANSFORMATION_CONVERT',
            component='PySparkGenerator',
            details={
                'transformation_name': trans_name,
                'transformation_type': trans_type,
                'notes': notes
            },
            decision=decision
        )
    
    def log_expression_conversion(self, original, converted, success=True):
        """Log an expression conversion."""
        return self.log_action(
            action_type='EXPRESSION_CONVERT',
            component='ExpressionParser',
            details={
                'original_expression': original[:200] if original else '',
                'converted_expression': converted[:200] if converted else '',
                'truncated': len(original or '') > 200 or len(converted or '') > 200
            },
            outcome='success' if success else 'partial'
        )
    
    def log_unsupported_element(self, element_type, element_name, reason):
        """Log an unsupported element warning."""
        return self.log_action(
            action_type='UNSUPPORTED_ELEMENT',
            component='Validator',
            details={
                'element_type': element_type,
                'element_name': element_name,
                'reason': reason
            },
            outcome='warning'
        )
    
    def log_mapping_rule_applied(self, rule_name, source_pattern, target_pattern):
        """Log custom mapping rule application."""
        return self.log_action(
            action_type='MAPPING_RULE_APPLIED',
            component='MappingRules',
            details={
                'rule_name': rule_name,
                'source_pattern': source_pattern,
                'target_pattern': target_pattern
            }
        )
    
    def log_mapping_rule_application(self, rules):
        """Log the mapping rules configuration being applied."""
        return self.log_action(
            action_type='MAPPING_RULES_CONFIG',
            component='MappingRules',
            details={
                'lookup_strategy': rules.get('lookup', {}).get('strategy', 'broadcast'),
                'sequence_strategy': rules.get('sequence_generator', {}).get('strategy', 'monotonic'),
                'target_write_mode': rules.get('target', {}).get('write_mode', 'overwrite')
            },
            decision='Applied custom mapping rules configuration'
        )
    
    def log_code_generation_complete(self, code_lines, duration_ms=None):
        """Log code generation completion."""
        return self.log_action(
            action_type='GENERATION_COMPLETE',
            component='PySparkGenerator',
            details={
                'total_code_lines': code_lines,
                'duration_ms': duration_ms,
                'end_time': datetime.now().isoformat()
            }
        )
    
    def log_error(self, component, error_message, stack_trace=None):
        """Log an error during conversion."""
        return self.log_action(
            action_type='ERROR',
            component=component,
            details={
                'error_message': error_message,
                'stack_trace': stack_trace[:500] if stack_trace else None
            },
            outcome='error'
        )
    
    def get_summary(self):
        """Get audit trail summary."""
        action_counts = {}
        outcomes = {'success': 0, 'warning': 0, 'error': 0, 'partial': 0}
        
        for entry in self.entries:
            action_type = entry.get('action_type', 'unknown')
            action_counts[action_type] = action_counts.get(action_type, 0) + 1
            
            outcome = entry.get('outcome', 'success')
            if outcome in outcomes:
                outcomes[outcome] += 1
        
        return {
            'session_id': self.session_id,
            'start_time': self.start_time.isoformat(),
            'end_time': datetime.now().isoformat(),
            'total_entries': len(self.entries),
            'action_counts': action_counts,
            'outcomes': outcomes,
            'has_errors': outcomes['error'] > 0,
            'has_warnings': outcomes['warning'] > 0
        }
    
    def get_full_trail(self):
        """Get complete audit trail."""
        return {
            'summary': self.get_summary(),
            'entries': self.entries
        }
    
    def export_json(self):
        """Export audit trail as JSON string."""
        return json.dumps(self.get_full_trail(), indent=2)
    
    def filter_by_outcome(self, outcome):
        """Filter entries by outcome."""
        return [e for e in self.entries if e.get('outcome') == outcome]
    
    def filter_by_component(self, component):
        """Filter entries by component."""
        return [e for e in self.entries if e.get('component') == component]


_current_audit_trail = None


def get_audit_trail():
    """Get or create current audit trail."""
    global _current_audit_trail
    if _current_audit_trail is None:
        _current_audit_trail = AuditTrail()
    return _current_audit_trail


def reset_audit_trail():
    """Reset audit trail for new session."""
    global _current_audit_trail
    _current_audit_trail = AuditTrail()
    return _current_audit_trail
