"""
Tagging System
Metadata labels for converted workflows to enable filtering and organization.
"""

from datetime import datetime
import json
import hashlib


class WorkflowTags:
    """Manages metadata tags for converted workflows."""
    
    PREDEFINED_CATEGORIES = {
        'domain': ['Finance', 'HR', 'Sales', 'Marketing', 'Operations', 'IT', 'Customer', 'Product'],
        'environment': ['Development', 'Testing', 'Staging', 'Production'],
        'type': ['CDC', 'Batch', 'Real-time', 'Incremental', 'Full-load', 'Lookup', 'Aggregation'],
        'priority': ['Critical', 'High', 'Medium', 'Low'],
        'status': ['Draft', 'Review', 'Approved', 'Deployed', 'Deprecated'],
        'complexity': ['Simple', 'Moderate', 'Complex', 'Very Complex']
    }
    
    def __init__(self, workflow_name=None):
        self.workflow_id = self._generate_id()
        self.workflow_name = workflow_name or 'Unnamed Workflow'
        self.tags = {}
        self.custom_tags = []
        self.metadata = {
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat(),
            'version': 1
        }
        self.notes = ''
    
    def _generate_id(self):
        """Generate unique workflow ID."""
        timestamp = datetime.now().isoformat()
        return hashlib.md5(timestamp.encode()).hexdigest()[:16]
    
    def add_tag(self, category, value):
        """Add a predefined category tag."""
        if category in self.PREDEFINED_CATEGORIES:
            if value in self.PREDEFINED_CATEGORIES[category]:
                self.tags[category] = value
                self._update_timestamp()
                return True
        self.tags[category] = value
        self._update_timestamp()
        return True
    
    def add_custom_tag(self, tag):
        """Add a custom freeform tag."""
        tag = tag.strip().lower()
        if tag and tag not in self.custom_tags:
            self.custom_tags.append(tag)
            self._update_timestamp()
            return True
        return False
    
    def remove_tag(self, category):
        """Remove a category tag."""
        if category in self.tags:
            del self.tags[category]
            self._update_timestamp()
            return True
        return False
    
    def remove_custom_tag(self, tag):
        """Remove a custom tag."""
        tag = tag.strip().lower()
        if tag in self.custom_tags:
            self.custom_tags.remove(tag)
            self._update_timestamp()
            return True
        return False
    
    def set_notes(self, notes):
        """Set workflow notes."""
        self.notes = notes
        self._update_timestamp()
    
    def _update_timestamp(self):
        """Update the modified timestamp."""
        self.metadata['updated_at'] = datetime.now().isoformat()
        self.metadata['version'] += 1
    
    def get_all_tags(self):
        """Get all tags as a flat list."""
        all_tags = []
        for category, value in self.tags.items():
            all_tags.append(f"{category}:{value}")
        all_tags.extend(self.custom_tags)
        return all_tags
    
    def has_tag(self, category=None, value=None, custom_tag=None):
        """Check if workflow has a specific tag."""
        if custom_tag:
            return custom_tag.lower() in self.custom_tags
        if category and value:
            return self.tags.get(category) == value
        if category:
            return category in self.tags
        return False
    
    def to_dict(self):
        """Export tags as dictionary."""
        return {
            'workflow_id': self.workflow_id,
            'workflow_name': self.workflow_name,
            'category_tags': self.tags.copy(),
            'custom_tags': self.custom_tags.copy(),
            'notes': self.notes,
            'metadata': self.metadata.copy()
        }
    
    def from_dict(self, data):
        """Load tags from dictionary."""
        self.workflow_id = data.get('workflow_id', self.workflow_id)
        self.workflow_name = data.get('workflow_name', self.workflow_name)
        self.tags = data.get('category_tags', {})
        self.custom_tags = data.get('custom_tags', [])
        self.notes = data.get('notes', '')
        self.metadata = data.get('metadata', self.metadata)
        return self
    
    @classmethod
    def get_predefined_categories(cls):
        """Get all predefined tag categories."""
        return cls.PREDEFINED_CATEGORIES.copy()


class TagManager:
    """Manages tags across multiple workflows."""
    
    def __init__(self):
        self.workflows = {}
    
    def create_workflow_tags(self, workflow_name):
        """Create new workflow tags instance."""
        tags = WorkflowTags(workflow_name)
        self.workflows[tags.workflow_id] = tags
        return tags
    
    def get_workflow_tags(self, workflow_id):
        """Get tags for a specific workflow."""
        return self.workflows.get(workflow_id)
    
    def delete_workflow_tags(self, workflow_id):
        """Delete workflow tags."""
        if workflow_id in self.workflows:
            del self.workflows[workflow_id]
            return True
        return False
    
    def filter_by_tag(self, category=None, value=None, custom_tag=None):
        """Filter workflows by tag."""
        results = []
        for wf_id, wf_tags in self.workflows.items():
            if wf_tags.has_tag(category, value, custom_tag):
                results.append(wf_tags.to_dict())
        return results
    
    def search_workflows(self, query):
        """Search workflows by name or tags."""
        query = query.lower()
        results = []
        for wf_id, wf_tags in self.workflows.items():
            if query in wf_tags.workflow_name.lower():
                results.append(wf_tags.to_dict())
                continue
            
            for tag in wf_tags.get_all_tags():
                if query in tag.lower():
                    results.append(wf_tags.to_dict())
                    break
        return results
    
    def get_all_used_tags(self):
        """Get all tags currently in use."""
        category_tags = {}
        custom_tags = set()
        
        for wf_tags in self.workflows.values():
            for cat, val in wf_tags.tags.items():
                if cat not in category_tags:
                    category_tags[cat] = set()
                category_tags[cat].add(val)
            
            custom_tags.update(wf_tags.custom_tags)
        
        return {
            'category_tags': {k: list(v) for k, v in category_tags.items()},
            'custom_tags': list(custom_tags)
        }
    
    def get_statistics(self):
        """Get tag usage statistics."""
        stats = {
            'total_workflows': len(self.workflows),
            'by_category': {},
            'custom_tag_count': 0
        }
        
        for wf_tags in self.workflows.values():
            for cat, val in wf_tags.tags.items():
                if cat not in stats['by_category']:
                    stats['by_category'][cat] = {}
                if val not in stats['by_category'][cat]:
                    stats['by_category'][cat][val] = 0
                stats['by_category'][cat][val] += 1
            
            stats['custom_tag_count'] += len(wf_tags.custom_tags)
        
        return stats
    
    def export_all(self):
        """Export all workflow tags."""
        return {
            wf_id: wf_tags.to_dict()
            for wf_id, wf_tags in self.workflows.items()
        }
    
    def import_all(self, data):
        """Import workflow tags from data."""
        for wf_id, wf_data in data.items():
            tags = WorkflowTags()
            tags.from_dict(wf_data)
            self.workflows[wf_id] = tags


_tag_manager = None


def get_tag_manager():
    """Get or create tag manager instance."""
    global _tag_manager
    if _tag_manager is None:
        _tag_manager = TagManager()
    return _tag_manager


def create_workflow_tags(workflow_name, initial_tags=None):
    """Create and optionally initialize workflow tags."""
    manager = get_tag_manager()
    tags = manager.create_workflow_tags(workflow_name)
    
    if initial_tags:
        if 'category_tags' in initial_tags:
            for cat, val in initial_tags['category_tags'].items():
                tags.add_tag(cat, val)
        if 'custom_tags' in initial_tags:
            for tag in initial_tags['custom_tags']:
                tags.add_custom_tag(tag)
    
    return tags
