from datetime import datetime

class DocumentationGenerator:
    def __init__(self):
        self.transformation_docs = {
            'Source Qualifier': 'Reads data from source tables with optional SQL override for filtering or joining at the database level.',
            'Expression': 'Performs row-level calculations and data transformations using expressions.',
            'Filter': 'Filters rows based on a condition, passing only matching records downstream.',
            'Lookup': 'Retrieves values from a lookup table based on matching key conditions.',
            'Joiner': 'Combines data from two sources based on join conditions (INNER, LEFT, RIGHT, FULL).',
            'Aggregator': 'Groups data and calculates aggregate values (SUM, COUNT, AVG, MIN, MAX).',
            'Sorter': 'Orders data by specified columns in ascending or descending order.',
            'Router': 'Routes data to different output groups based on conditions.',
            'Union': 'Combines multiple data streams with the same schema into one.',
            'Sequence Generator': 'Generates unique sequential numbers for each row.',
            'Update Strategy': 'Determines how to handle each row (INSERT, UPDATE, DELETE, REJECT).',
            'Normalizer': 'Converts a single row into multiple rows based on repeating groups.',
            'Stored Procedure': 'Executes a stored procedure in the database.',
            'Target': 'Writes data to the target table or file.'
        }
    
    def generate_documentation(self, parsed_data, pyspark_code):
        doc = []
        
        doc.append(self._generate_header(parsed_data))
        doc.append(self._generate_overview(parsed_data))
        doc.append(self._generate_source_section(parsed_data))
        doc.append(self._generate_transformations_section(parsed_data))
        doc.append(self._generate_target_section(parsed_data))
        doc.append(self._generate_field_mappings(parsed_data))
        doc.append(self._generate_data_flow(parsed_data))
        doc.append(self._generate_code_summary(pyspark_code))
        doc.append(self._generate_footer())
        
        return '\n'.join(doc)
    
    def _generate_header(self, parsed_data):
        workflow_name = parsed_data.get('workflow_name', 'Unknown Workflow')
        return f"""# {workflow_name}

**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**Tool:** Informatica to PySpark Converter v2.0

---
"""
    
    def _generate_overview(self, parsed_data):
        sources = parsed_data.get('sources', [])
        targets = parsed_data.get('targets', [])
        transformations = parsed_data.get('transformations', {})
        trans_count = len(transformations) if isinstance(transformations, (list, dict)) else 0
        
        return f"""## Overview

| Metric | Count |
|--------|-------|
| Source Tables | {len(sources)} |
| Target Tables | {len(targets)} |
| Transformations | {trans_count} |
| Total Fields | {self._count_total_fields(parsed_data)} |

"""
    
    def _count_total_fields(self, parsed_data):
        count = 0
        for source in parsed_data.get('sources', []):
            count += len(source.get('fields', []))
        transformations = parsed_data.get('transformations', {})
        if isinstance(transformations, dict):
            for trans in transformations.values():
                if isinstance(trans, dict):
                    count += len(trans.get('fields', []))
        elif isinstance(transformations, list):
            for trans in transformations:
                count += len(trans.get('fields', []))
        return count
    
    def _generate_source_section(self, parsed_data):
        sources = parsed_data.get('sources', [])
        if not sources:
            return "## Sources\n\nNo sources defined.\n\n"
        
        lines = ["## Sources\n"]
        
        for source in sources:
            name = source.get('name', 'Unknown')
            table = source.get('table_name', 'N/A')
            owner = source.get('owner', 'N/A')
            fields = source.get('fields', [])
            
            lines.append(f"### {name}\n")
            lines.append(f"- **Table:** `{table}`")
            lines.append(f"- **Owner/Schema:** `{owner}`")
            lines.append(f"- **Fields:** {len(fields)}\n")
            
            if fields:
                lines.append("| Field Name | Data Type | Precision | Scale |")
                lines.append("|------------|-----------|-----------|-------|")
                for field in fields[:20]:
                    fname = field.get('name', '')
                    dtype = field.get('datatype', '')
                    prec = field.get('precision', '')
                    scale = field.get('scale', '')
                    lines.append(f"| {fname} | {dtype} | {prec} | {scale} |")
                if len(fields) > 20:
                    lines.append(f"\n*...and {len(fields) - 20} more fields*\n")
            lines.append("")
        
        return '\n'.join(lines) + '\n'
    
    def _generate_transformations_section(self, parsed_data):
        transformations = parsed_data.get('transformations', {})
        if not transformations:
            return "## Transformations\n\nNo transformations defined.\n\n"
        
        lines = ["## Transformations\n"]
        
        if isinstance(transformations, dict):
            trans_items = [(name, data) for name, data in transformations.items() if isinstance(data, dict)]
        else:
            trans_items = [(t.get('name', f'Trans_{i}'), t) for i, t in enumerate(transformations)]
        
        for i, (name, trans) in enumerate(trans_items, 1):
            trans_type = trans.get('type', 'Unknown')
            fields = trans.get('fields', [])
            
            description = self.transformation_docs.get(trans_type, 'Custom transformation.')
            
            lines.append(f"### {i}. {name}")
            lines.append(f"**Type:** `{trans_type}`\n")
            lines.append(f"> {description}\n")
            
            if trans_type == 'Expression':
                self._add_expression_details(lines, trans)
            elif trans_type == 'Filter':
                self._add_filter_details(lines, trans)
            elif trans_type == 'Lookup':
                self._add_lookup_details(lines, trans)
            elif trans_type == 'Joiner':
                self._add_joiner_details(lines, trans)
            elif trans_type == 'Aggregator':
                self._add_aggregator_details(lines, trans)
            elif trans_type == 'Router':
                self._add_router_details(lines, trans)
            
            lines.append(f"**Output Fields:** {len(fields)}\n")
            lines.append("---\n")
        
        return '\n'.join(lines) + '\n'
    
    def _add_expression_details(self, lines, trans):
        fields = trans.get('fields', [])
        expressions = [(f['name'], f.get('expression', '')) for f in fields if f.get('expression')]
        
        if expressions:
            lines.append("**Calculated Fields:**\n")
            lines.append("| Output Field | Expression |")
            lines.append("|--------------|------------|")
            for name, expr in expressions[:10]:
                expr_display = expr[:50] + '...' if len(expr) > 50 else expr
                lines.append(f"| `{name}` | `{expr_display}` |")
            if len(expressions) > 10:
                lines.append(f"\n*...and {len(expressions) - 10} more expressions*")
            lines.append("")
    
    def _add_filter_details(self, lines, trans):
        condition = trans.get('filter_condition', 'N/A')
        lines.append(f"**Filter Condition:**\n```\n{condition}\n```\n")
    
    def _add_lookup_details(self, lines, trans):
        table = trans.get('lookup_table', 'N/A')
        condition = trans.get('lookup_condition', 'N/A')
        lines.append(f"**Lookup Table:** `{table}`\n")
        lines.append(f"**Condition:** `{condition}`\n")
    
    def _add_joiner_details(self, lines, trans):
        join_type = trans.get('join_type', 'INNER')
        condition = trans.get('join_condition', 'N/A')
        lines.append(f"**Join Type:** `{join_type}`\n")
        lines.append(f"**Condition:** `{condition}`\n")
    
    def _add_aggregator_details(self, lines, trans):
        group_by = trans.get('group_by_fields', [])
        if group_by:
            lines.append(f"**Group By:** `{', '.join(group_by)}`\n")
    
    def _add_router_details(self, lines, trans):
        groups = trans.get('groups', [])
        if groups:
            lines.append("**Route Groups:**\n")
            for group in groups:
                gname = group.get('name', 'Unknown')
                condition = group.get('condition', 'N/A')
                lines.append(f"- **{gname}:** `{condition}`")
            lines.append("")
    
    def _generate_target_section(self, parsed_data):
        targets = parsed_data.get('targets', [])
        if not targets:
            return "## Targets\n\nNo targets defined.\n\n"
        
        lines = ["## Targets\n"]
        
        for target in targets:
            name = target.get('name', 'Unknown')
            table = target.get('table_name', 'N/A')
            owner = target.get('owner', 'N/A')
            fields = target.get('fields', [])
            
            lines.append(f"### {name}\n")
            lines.append(f"- **Table:** `{table}`")
            lines.append(f"- **Owner/Schema:** `{owner}`")
            lines.append(f"- **Fields:** {len(fields)}\n")
        
        return '\n'.join(lines) + '\n'
    
    def _generate_field_mappings(self, parsed_data):
        mappings = parsed_data.get('mappings', [])
        if not mappings:
            return "## Field Mappings\n\nNo explicit field mappings found.\n\n"
        
        lines = ["## Field Mappings\n"]
        lines.append("| Source Field | Target Field | Transformation |")
        lines.append("|--------------|--------------|----------------|")
        
        for mapping in mappings[:30]:
            src = mapping.get('from_field', 'N/A')
            tgt = mapping.get('to_field', 'N/A')
            trans = mapping.get('transformation', 'Direct')
            lines.append(f"| `{src}` | `{tgt}` | {trans} |")
        
        if len(mappings) > 30:
            lines.append(f"\n*...and {len(mappings) - 30} more mappings*")
        
        return '\n'.join(lines) + '\n\n'
    
    def _generate_data_flow(self, parsed_data):
        flow = parsed_data.get('flow', [])
        if not flow:
            return "## Data Flow\n\nData flow not available.\n\n"
        
        lines = ["## Data Flow\n"]
        lines.append("```")
        
        for i, step in enumerate(flow):
            arrow = "  └──> " if i == len(flow) - 1 else "  ├──> "
            if i == 0:
                lines.append(f"  {step}")
            else:
                lines.append(f"{arrow}{step}")
        
        lines.append("```\n")
        
        return '\n'.join(lines) + '\n'
    
    def _generate_code_summary(self, pyspark_code):
        if not pyspark_code:
            return ""
        
        lines = ["## Generated PySpark Code Summary\n"]
        
        line_count = len(pyspark_code.split('\n'))
        spark_session = 'SparkSession' in pyspark_code
        has_udf = 'udf' in pyspark_code.lower()
        has_window = 'Window' in pyspark_code
        
        lines.append(f"- **Total Lines:** {line_count}")
        lines.append(f"- **Uses SparkSession:** {'Yes' if spark_session else 'No'}")
        lines.append(f"- **Contains UDFs:** {'Yes' if has_udf else 'No'}")
        lines.append(f"- **Uses Window Functions:** {'Yes' if has_window else 'No'}\n")
        
        return '\n'.join(lines) + '\n'
    
    def _generate_footer(self):
        return """---

*This documentation was auto-generated by the Informatica to PySpark Converter.*  
*Review and update as needed for your specific environment.*
"""
