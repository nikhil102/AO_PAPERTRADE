"""
Validation Report Generator
Compares XML structure vs generated PySpark code for coverage analysis.
"""

from datetime import datetime


class ValidationReport:
    """Generates validation reports comparing XML vs PySpark conversion."""
    
    SUPPORTED_TRANSFORMATION_TYPES = {
        'SOURCE QUALIFIER',
        'EXPRESSION',
        'FILTER',
        'LOOKUP PROCEDURE',
        'LOOKUP',
        'JOINER',
        'AGGREGATOR',
        'SORTER',
        'ROUTER',
        'UNION',
        'SEQUENCE GENERATOR',
        'UPDATE STRATEGY',
        'NORMALIZER',
        'STORED PROCEDURE'
    }
    
    SUPPORTED_EXPRESSION_FUNCTIONS = {
        'IIF', 'DECODE', 'ISNULL', 'NVL', 'TO_DATE', 'TO_CHAR',
        'UPPER', 'LOWER', 'LTRIM', 'RTRIM', 'TRIM', 'LENGTH',
        'SUBSTR', 'SUBSTRING', 'CONCAT', 'LPAD', 'RPAD', 'REPLACE',
        'ABS', 'ROUND', 'TRUNC', 'FLOOR', 'CEIL', 'MOD', 'POWER', 'SQRT',
        'SYSDATE', 'SYSTIMESTAMP', 'ADD_TO_DATE', 'DATE_DIFF',
        'GET_DATE_PART', 'COALESCE'
    }
    
    def __init__(self, parsed_data, pyspark_code):
        self.parsed_data = parsed_data
        self.pyspark_code = pyspark_code
        self.warnings = []
        self.errors = []
        self.info = []
    
    def generate_report(self):
        """Generate comprehensive validation report."""
        report = {
            'timestamp': datetime.now().isoformat(),
            'summary': self._generate_summary(),
            'coverage': self._analyze_coverage(),
            'schema_analysis': self._analyze_schema(),
            'transformation_analysis': self._analyze_transformations(),
            'expression_analysis': self._analyze_expressions(),
            'warnings': self.warnings,
            'errors': self.errors,
            'info': self.info,
            'unsupported_elements': self._find_unsupported_elements()
        }
        return report
    
    def _generate_summary(self):
        """Generate high-level summary."""
        sources = self.parsed_data.get('sources', [])
        targets = self.parsed_data.get('targets', [])
        transformations = self.parsed_data.get('transformations', {})
        connectors = self.parsed_data.get('connectors', [])
        
        return {
            'total_sources': len(sources),
            'total_targets': len(targets),
            'total_transformations': len(transformations),
            'total_connectors': len(connectors),
            'code_lines': len(self.pyspark_code.split('\n')),
            'conversion_timestamp': datetime.now().isoformat()
        }
    
    def _analyze_coverage(self):
        """Analyze conversion coverage percentage."""
        transformations = self.parsed_data.get('transformations', {})
        
        total = len(transformations)
        supported = 0
        unsupported = []
        partially_supported = []
        
        for name, data in transformations.items():
            trans_type = data.get('type', '').upper()
            if trans_type in self.SUPPORTED_TRANSFORMATION_TYPES:
                supported += 1
            elif any(st in trans_type for st in self.SUPPORTED_TRANSFORMATION_TYPES):
                partially_supported.append({
                    'name': name,
                    'type': trans_type,
                    'reason': 'Partial match - may require manual review'
                })
                supported += 0.5
            else:
                unsupported.append({
                    'name': name,
                    'type': trans_type
                })
                self.warnings.append(f"Unsupported transformation type: {trans_type} ({name})")
        
        coverage_pct = (supported / total * 100) if total > 0 else 100
        
        return {
            'coverage_percentage': round(coverage_pct, 2),
            'supported_count': int(supported),
            'unsupported_count': len(unsupported),
            'partially_supported': partially_supported,
            'unsupported_transformations': unsupported
        }
    
    def _analyze_schema(self):
        """Analyze schema differences between source and target."""
        sources = self.parsed_data.get('sources', [])
        targets = self.parsed_data.get('targets', [])
        
        source_fields = {}
        for source in sources:
            for field in source.get('fields', []):
                key = f"{source['name']}.{field['name']}"
                source_fields[key] = {
                    'datatype': field.get('datatype', ''),
                    'precision': field.get('precision', ''),
                    'scale': field.get('scale', ''),
                    'nullable': field.get('nullable', '')
                }
        
        target_fields = {}
        for target in targets:
            for field in target.get('fields', []):
                key = f"{target['name']}.{field['name']}"
                target_fields[key] = {
                    'datatype': field.get('datatype', ''),
                    'precision': field.get('precision', ''),
                    'scale': field.get('scale', ''),
                    'nullable': field.get('nullable', '')
                }
        
        schema_changes = []
        for target_key, target_info in target_fields.items():
            target_name = target_key.split('.')[1]
            matching_sources = [k for k in source_fields.keys() if k.endswith(f'.{target_name}')]
            
            if matching_sources:
                source_info = source_fields[matching_sources[0]]
                if source_info['datatype'] != target_info['datatype']:
                    schema_changes.append({
                        'field': target_key,
                        'change': 'datatype',
                        'source': source_info['datatype'],
                        'target': target_info['datatype']
                    })
        
        return {
            'source_field_count': len(source_fields),
            'target_field_count': len(target_fields),
            'schema_changes': schema_changes,
            'type_conversions_detected': len(schema_changes)
        }
    
    def _analyze_transformations(self):
        """Analyze each transformation for potential issues."""
        transformations = self.parsed_data.get('transformations', {})
        analysis = []
        
        for name, data in transformations.items():
            trans_type = data.get('type', '').upper()
            fields = data.get('fields', [])
            table_attrs = data.get('table_attributes', {})
            
            issues = []
            notes = []
            
            if trans_type not in self.SUPPORTED_TRANSFORMATION_TYPES:
                issues.append(f"Transformation type '{trans_type}' is not fully supported")
            
            if trans_type == 'STORED PROCEDURE':
                issues.append("Stored procedures require manual implementation")
            
            if trans_type == 'LOOKUP PROCEDURE' or trans_type == 'LOOKUP':
                if not table_attrs.get('Lookup table name'):
                    issues.append("Missing lookup table name")
                notes.append("Consider using broadcast join for small lookup tables")
            
            if trans_type == 'JOINER':
                if not table_attrs.get('Join Condition'):
                    issues.append("Missing join condition - manual configuration needed")
            
            complex_expressions = []
            for field in fields:
                expr = field.get('expression', '')
                if expr and len(expr) > 100:
                    complex_expressions.append(field.get('name', 'unknown'))
            
            if complex_expressions:
                notes.append(f"Complex expressions in fields: {', '.join(complex_expressions[:3])}")
            
            analysis.append({
                'name': name,
                'type': trans_type,
                'field_count': len(fields),
                'issues': issues,
                'notes': notes,
                'status': 'warning' if issues else 'ok'
            })
            
            for issue in issues:
                self.warnings.append(f"{name}: {issue}")
        
        return analysis
    
    def _analyze_expressions(self):
        """Analyze expressions for conversion coverage."""
        transformations = self.parsed_data.get('transformations', {})
        
        total_expressions = 0
        converted_expressions = 0
        problematic = []
        
        for name, data in transformations.items():
            for field in data.get('fields', []):
                expr = field.get('expression', '')
                if expr and expr.strip():
                    total_expressions += 1
                    
                    found_unsupported = False
                    for func in self._extract_function_names(expr):
                        if func.upper() not in self.SUPPORTED_EXPRESSION_FUNCTIONS:
                            found_unsupported = True
                            problematic.append({
                                'transformation': name,
                                'field': field.get('name', ''),
                                'expression': expr[:100],
                                'unsupported_function': func
                            })
                            self.warnings.append(
                                f"Unsupported function '{func}' in {name}.{field.get('name', '')}"
                            )
                    
                    if not found_unsupported:
                        converted_expressions += 1
        
        return {
            'total_expressions': total_expressions,
            'converted_expressions': converted_expressions,
            'conversion_rate': round(
                (converted_expressions / total_expressions * 100) if total_expressions > 0 else 100, 2
            ),
            'problematic_expressions': problematic[:20]
        }
    
    def _extract_function_names(self, expression):
        """Extract function names from expression."""
        import re
        pattern = r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\('
        matches = re.findall(pattern, expression)
        return matches
    
    def _find_unsupported_elements(self):
        """Find all unsupported XML elements."""
        unsupported = {
            'transformations': [],
            'expressions': [],
            'attributes': []
        }
        
        transformations = self.parsed_data.get('transformations', {})
        for name, data in transformations.items():
            trans_type = data.get('type', '').upper()
            if trans_type not in self.SUPPORTED_TRANSFORMATION_TYPES:
                unsupported['transformations'].append({
                    'name': name,
                    'type': trans_type,
                    'severity': 'warning'
                })
        
        for name, data in transformations.items():
            for field in data.get('fields', []):
                expr = field.get('expression', '')
                if expr:
                    for func in self._extract_function_names(expr):
                        if func.upper() not in self.SUPPORTED_EXPRESSION_FUNCTIONS:
                            unsupported['expressions'].append({
                                'transformation': name,
                                'field': field.get('name', ''),
                                'function': func,
                                'severity': 'warning'
                            })
        
        return unsupported


def generate_validation_report(parsed_data, pyspark_code):
    """Generate validation report comparing XML vs PySpark."""
    validator = ValidationReport(parsed_data, pyspark_code)
    return validator.generate_report()
