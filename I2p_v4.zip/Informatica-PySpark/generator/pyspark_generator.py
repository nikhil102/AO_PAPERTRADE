from parser.expression_parser import ExpressionParser
from generator.mapping_rules import get_mapping_rules
import re


class PySparkGenerator:
    """
    Generates PySpark code from parsed Informatica XML components.
    """
    
    DATATYPE_MAPPING = {
        'nvarchar': 'StringType()',
        'varchar': 'StringType()',
        'varchar2': 'StringType()',
        'char': 'StringType()',
        'string': 'StringType()',
        'text': 'StringType()',
        'integer': 'IntegerType()',
        'int': 'IntegerType()',
        'smallint': 'ShortType()',
        'bigint': 'LongType()',
        'decimal': 'DecimalType()',
        'number': 'DecimalType()',
        'numeric': 'DecimalType()',
        'float': 'FloatType()',
        'double': 'DoubleType()',
        'real': 'FloatType()',
        'date': 'DateType()',
        'datetime': 'TimestampType()',
        'timestamp': 'TimestampType()',
        'boolean': 'BooleanType()',
        'bit': 'BooleanType()',
        'binary': 'BinaryType()',
        'varbinary': 'BinaryType()',
    }
    
    def __init__(self, parsed_data, mapping_rules=None):
        self.parsed_data = parsed_data
        self.expression_parser = ExpressionParser()
        self.generated_code = []
        self.variable_counter = 0
        if mapping_rules is None:
            rules_obj = get_mapping_rules()
            self.mapping_rules = rules_obj.export_rules()
        elif hasattr(mapping_rules, 'export_rules'):
            self.mapping_rules = mapping_rules.export_rules()
        else:
            self.mapping_rules = mapping_rules
    
    def generate(self):
        """Generate complete PySpark script."""
        self.generated_code = []
        
        self._add_imports()
        self._add_spark_session()
        self._add_jdbc_config()
        self._add_source_reads()
        self._add_transformations()
        self._add_target_writes()
        
        return '\n'.join(self.generated_code)
    
    def _add_imports(self):
        """Add PySpark imports."""
        imports = '''"""
PySpark Script - Auto-generated from Informatica Workflow XML
Generated using Informatica to PySpark Converter Tool
"""

from pyspark.sql import SparkSession, DataFrame, Window
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, LongType,
    FloatType, DoubleType, DecimalType, DateType, TimestampType,
    BooleanType, BinaryType, ShortType
)
import os
import sys
from datetime import datetime
'''
        self.generated_code.append(imports)
    
    def _add_spark_session(self):
        """Add Spark session initialization."""
        spark_init = '''
# Initialize Spark Session
spark = SparkSession.builder \\
    .appName("Informatica_Converted_Job") \\
    .config("spark.sql.adaptive.enabled", "true") \\
    .getOrCreate()

# Set log level
spark.sparkContext.setLogLevel("WARN")
'''
        self.generated_code.append(spark_init)
    
    def _add_jdbc_config(self):
        """Add JDBC configuration."""
        sources = self.parsed_data.get('sources', [])
        targets = self.parsed_data.get('targets', [])
        
        databases = set()
        for source in sources:
            if source.get('db'):
                databases.add(source['db'])
        for target in targets:
            if target.get('db'):
                databases.add(target['db'])
        
        jdbc_config = '''
# JDBC Configuration
# Replace these with your actual connection details or use environment variables
JDBC_CONFIG = {
    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
    "host": os.getenv("DB_HOST", "localhost"),
    "user": os.getenv("DB_USER", "user"),
    "password": os.getenv("DB_PASSWORD", "password"),
}

def get_jdbc_url(database_name):
    """Generate JDBC URL for given database."""
    return (
        f"jdbc:sqlserver://{JDBC_CONFIG['host']};"
        f"databaseName={database_name};"
        f"user={JDBC_CONFIG['user']};"
        f"password={JDBC_CONFIG['password']};"
        f"trustServerCertificate=true;encrypt=false"
    )

jdbc_properties = {
    "driver": JDBC_CONFIG["driver"],
    "user": JDBC_CONFIG["user"],
    "password": JDBC_CONFIG["password"]
}
'''
        self.generated_code.append(jdbc_config)
    
    def _add_source_reads(self):
        """Generate source read operations."""
        sources = self.parsed_data.get('sources', [])
        
        if not sources:
            self.generated_code.append("\n# No sources found in mapping\n")
            return
        
        self.generated_code.append("\n# ============ SOURCE READS ============\n")
        
        for source in sources:
            name = source.get('name', 'unknown_source')
            db = source.get('db', 'default_db')
            var_name = self._to_variable_name(name)
            
            code = f'''
# Reading from Source: {name}
# Database: {db}
{var_name} = spark.read.format("jdbc").options(
    url=get_jdbc_url("{db}"),
    dbtable="{name}",
    driver=JDBC_CONFIG["driver"]
).load()
'''
            self.generated_code.append(code)
    
    def _add_transformations(self):
        """Generate transformation operations."""
        transformations = self.parsed_data.get('transformations', {})
        connectors = self.parsed_data.get('connectors', [])
        
        if not transformations:
            self.generated_code.append("\n# No transformations found in mapping\n")
            return
        
        self.generated_code.append("\n# ============ TRANSFORMATIONS ============\n")
        
        sorted_transforms = self._topological_sort_transformations(transformations, connectors)
        
        for trans_name in sorted_transforms:
            trans_data = transformations.get(trans_name, {})
            trans_type = trans_data.get('type', '').upper()
            
            self.generated_code.append(f"\n# Transformation: {trans_name} (Type: {trans_type})")
            if trans_data.get('description'):
                self.generated_code.append(f"# Description: {trans_data['description']}")
            
            if 'SOURCE QUALIFIER' in trans_type or trans_type == 'SOURCE QUALIFIER':
                self._generate_source_qualifier(trans_name, trans_data)
            elif trans_type == 'EXPRESSION':
                self._generate_expression_transformation(trans_name, trans_data)
            elif trans_type == 'FILTER':
                self._generate_filter_transformation(trans_name, trans_data)
            elif trans_type == 'LOOKUP PROCEDURE':
                self._generate_lookup_transformation(trans_name, trans_data)
            elif trans_type == 'LOOKUP':
                self._generate_lookup_transformation(trans_name, trans_data)
            elif trans_type == 'JOINER':
                self._generate_joiner_transformation(trans_name, trans_data)
            elif trans_type == 'AGGREGATOR':
                self._generate_aggregator_transformation(trans_name, trans_data)
            elif trans_type == 'SORTER':
                self._generate_sorter_transformation(trans_name, trans_data)
            elif trans_type == 'ROUTER':
                self._generate_router_transformation(trans_name, trans_data)
            elif trans_type == 'UNION':
                self._generate_union_transformation(trans_name, trans_data)
            elif trans_type == 'SEQUENCE GENERATOR':
                self._generate_sequence_transformation(trans_name, trans_data)
            elif trans_type == 'UPDATE STRATEGY':
                self._generate_update_strategy(trans_name, trans_data)
            elif trans_type == 'NORMALIZER':
                self._generate_normalizer_transformation(trans_name, trans_data)
            elif trans_type == 'STORED PROCEDURE':
                self._generate_stored_procedure(trans_name, trans_data)
            else:
                self._generate_passthrough_transformation(trans_name, trans_data)
    
    def _generate_source_qualifier(self, name, data):
        """Generate Source Qualifier transformation."""
        var_name = self._to_variable_name(name)
        sql_query = data.get('table_attributes', {}).get('Sql Query', '')
        
        if sql_query:
            code = f'''
# Source Qualifier with SQL Override
{var_name}_query = """{sql_query}"""
{var_name} = spark.read.format("jdbc").options(
    url=get_jdbc_url("source_db"),  # Replace with actual database
    query={var_name}_query,
    driver=JDBC_CONFIG["driver"]
).load()
'''
        else:
            fields = data.get('fields', [])
            field_list = ', '.join([f'F.col("{f["name"]}")' for f in fields if f.get('name')])
            code = f'''
# Source Qualifier - Select columns
{var_name} = df_source.select({field_list if field_list else "*"})
'''
        self.generated_code.append(code)
    
    def _generate_expression_transformation(self, name, data):
        """Generate Expression transformation."""
        var_name = self._to_variable_name(name)
        fields = data.get('fields', [])
        
        code_lines = [f"\n{var_name} = df_input  # Replace df_input with actual input DataFrame"]
        
        for field in fields:
            field_name = field.get('name', '')
            expression = field.get('expression', '')
            port_type = field.get('port_type', '').upper()
            
            if expression and 'OUTPUT' in port_type:
                pyspark_expr = self.expression_parser.parse(expression)
                if pyspark_expr and not pyspark_expr.startswith('#'):
                    code_lines.append(f'{var_name} = {var_name}.withColumn("{field_name}", {pyspark_expr})')
                else:
                    code_lines.append(f'# {var_name} = {var_name}.withColumn("{field_name}", ...)  # Original: {expression}')
        
        self.generated_code.append('\n'.join(code_lines))
    
    def _generate_filter_transformation(self, name, data):
        """Generate Filter transformation."""
        var_name = self._to_variable_name(name)
        filter_condition = data.get('table_attributes', {}).get('Filter Condition', 'TRUE')
        
        pyspark_condition = self.expression_parser.parse(filter_condition) if filter_condition != 'TRUE' else 'F.lit(True)'
        
        code = f'''
# Filter Transformation
{var_name} = df_input.filter({pyspark_condition})  # Replace df_input with actual input
'''
        self.generated_code.append(code)
    
    def _generate_lookup_transformation(self, name, data):
        """Generate Lookup transformation."""
        var_name = self._to_variable_name(name)
        lookup_table = data.get('table_attributes', {}).get('Lookup table name', 'lookup_table')
        lookup_condition = data.get('table_attributes', {}).get('Lookup condition', '')
        
        lookup_strategy = self.mapping_rules.get('lookup', {}).get('strategy', 'broadcast')
        cache_lookup = self.mapping_rules.get('lookup', {}).get('cache', True)
        
        if lookup_strategy == 'broadcast':
            join_code = f'F.broadcast({var_name}_lookup)'
            strategy_comment = '# Using broadcast join for better performance (configurable)'
        else:
            join_code = f'{var_name}_lookup'
            strategy_comment = '# Using shuffle join (configurable)'
        
        cache_code = f'\n{var_name}_lookup = {var_name}_lookup.cache()  # Caching enabled' if cache_lookup else ''
        
        code = f'''
# Lookup Transformation: {name}
# Lookup Table: {lookup_table}
{strategy_comment}
{var_name}_lookup = spark.read.format("jdbc").options(
    url=get_jdbc_url("lookup_db"),  # Replace with actual database
    dbtable="{lookup_table}",
    driver=JDBC_CONFIG["driver"]
).load(){cache_code}

# Perform lookup join
{var_name} = df_input.join(
    {join_code},
    on="lookup_key",  # Replace with actual join condition: {lookup_condition}
    how="left"
)
'''
        self.generated_code.append(code)
    
    def _generate_joiner_transformation(self, name, data):
        """Generate Joiner transformation."""
        var_name = self._to_variable_name(name)
        join_type = data.get('table_attributes', {}).get('Join Type', 'Normal')
        join_condition = data.get('table_attributes', {}).get('Join Condition', '')
        
        pyspark_join = 'inner'
        if 'OUTER' in join_type.upper():
            if 'LEFT' in join_type.upper():
                pyspark_join = 'left'
            elif 'RIGHT' in join_type.upper():
                pyspark_join = 'right'
            else:
                pyspark_join = 'outer'
        
        code = f'''
# Joiner Transformation: {name}
# Join Type: {join_type} -> {pyspark_join}
# Original Condition: {join_condition}
{var_name} = df_master.join(
    df_detail,
    on="join_key",  # Replace with actual join condition
    how="{pyspark_join}"
)
'''
        self.generated_code.append(code)
    
    def _generate_aggregator_transformation(self, name, data):
        """Generate Aggregator transformation."""
        var_name = self._to_variable_name(name)
        fields = data.get('fields', [])
        
        group_cols = []
        agg_exprs = []
        
        for field in fields:
            port_type = field.get('port_type', '').upper()
            field_name = field.get('name', '')
            expression = field.get('expression', '')
            
            if 'GROUP BY' in port_type or field.get('group_by'):
                group_cols.append(f'"{field_name}"')
            elif expression:
                if 'SUM' in expression.upper():
                    agg_exprs.append(f'F.sum("{field_name}").alias("{field_name}")')
                elif 'COUNT' in expression.upper():
                    agg_exprs.append(f'F.count("{field_name}").alias("{field_name}")')
                elif 'AVG' in expression.upper():
                    agg_exprs.append(f'F.avg("{field_name}").alias("{field_name}")')
                elif 'MAX' in expression.upper():
                    agg_exprs.append(f'F.max("{field_name}").alias("{field_name}")')
                elif 'MIN' in expression.upper():
                    agg_exprs.append(f'F.min("{field_name}").alias("{field_name}")')
        
        group_by_str = ', '.join(group_cols) if group_cols else '"group_key"  # Replace with actual group columns'
        agg_str = ',\n    '.join(agg_exprs) if agg_exprs else 'F.count("*").alias("count")  # Add aggregations'
        
        code = f'''
# Aggregator Transformation: {name}
{var_name} = df_input.groupBy({group_by_str}).agg(
    {agg_str}
)
'''
        self.generated_code.append(code)
    
    def _generate_sorter_transformation(self, name, data):
        """Generate Sorter transformation."""
        var_name = self._to_variable_name(name)
        fields = data.get('fields', [])
        
        sort_cols = []
        for field in fields:
            field_name = field.get('name', '')
            if field_name:
                sort_cols.append(f'F.col("{field_name}")')
        
        sort_str = ', '.join(sort_cols) if sort_cols else 'F.col("sort_key")  # Replace with actual sort columns'
        
        code = f'''
# Sorter Transformation: {name}
{var_name} = df_input.orderBy({sort_str})
'''
        self.generated_code.append(code)
    
    def _generate_router_transformation(self, name, data):
        """Generate Router transformation."""
        var_name = self._to_variable_name(name)
        
        code = f'''
# Router Transformation: {name}
# Creates multiple output DataFrames based on conditions
{var_name}_group1 = df_input.filter(F.lit(True))  # Replace with actual condition
{var_name}_group2 = df_input.filter(F.lit(False))  # Replace with actual condition
{var_name}_default = df_input.filter(F.lit(True))  # Default group
'''
        self.generated_code.append(code)
    
    def _generate_union_transformation(self, name, data):
        """Generate Union transformation."""
        var_name = self._to_variable_name(name)
        
        code = f'''
# Union Transformation: {name}
{var_name} = df_input1.unionByName(df_input2, allowMissingColumns=True)
# Add more union operations as needed
'''
        self.generated_code.append(code)
    
    def _generate_sequence_transformation(self, name, data):
        """Generate Sequence Generator transformation."""
        var_name = self._to_variable_name(name)
        
        seq_strategy = self.mapping_rules.get('sequence_generator', {}).get('strategy', 'monotonic')
        
        if seq_strategy == 'row_number':
            seq_code = f'''
# Sequence Generator Transformation: {name}
# Using row_number strategy (configurable via mapping rules)
{var_name} = df_input.withColumn(
    "sequence_id",
    F.row_number().over(Window.orderBy(F.lit(1)))
)
'''
        else:
            seq_code = f'''
# Sequence Generator Transformation: {name}
# Using monotonically_increasing_id (configurable via mapping rules)
{var_name} = df_input.withColumn(
    "sequence_id",
    F.monotonically_increasing_id()
)
'''
        self.generated_code.append(seq_code)
    
    def _generate_update_strategy(self, name, data):
        """Generate Update Strategy transformation."""
        var_name = self._to_variable_name(name)
        
        code = f'''
# Update Strategy Transformation: {name}
# Determines INSERT/UPDATE/DELETE operations
{var_name}_insert = df_input.filter(F.col("update_strategy_flag") == 0)
{var_name}_update = df_input.filter(F.col("update_strategy_flag") == 1)
{var_name}_delete = df_input.filter(F.col("update_strategy_flag") == 2)
# Use appropriate write mode based on strategy
'''
        self.generated_code.append(code)
    
    def _generate_normalizer_transformation(self, name, data):
        """Generate Normalizer transformation."""
        var_name = self._to_variable_name(name)
        
        code = f'''
# Normalizer Transformation: {name}
# Converts single row to multiple rows (unpivot/explode)
{var_name} = df_input.select(
    F.col("key_columns"),  # Replace with actual key columns
    F.explode(F.array("col1", "col2", "col3")).alias("normalized_value")  # Replace with columns to normalize
)
'''
        self.generated_code.append(code)
    
    def _generate_stored_procedure(self, name, data):
        """Generate Stored Procedure stub."""
        var_name = self._to_variable_name(name)
        
        code = f'''
# Stored Procedure Transformation: {name}
# NOTE: Stored procedures need manual implementation
def {var_name}_procedure(df):
    """
    Simulates stored procedure logic.
    TODO: Implement actual stored procedure logic
    """
    # Add procedure logic here
    return df

{var_name} = {var_name}_procedure(df_input)
'''
        self.generated_code.append(code)
    
    def _generate_passthrough_transformation(self, name, data):
        """Generate passthrough for unknown transformation types."""
        var_name = self._to_variable_name(name)
        trans_type = data.get('type', 'Unknown')
        
        code = f'''
# Passthrough Transformation: {name} (Type: {trans_type})
# TODO: Implement specific logic for this transformation type
{var_name} = df_input.select("*")
'''
        self.generated_code.append(code)
    
    def _add_target_writes(self):
        """Generate target write operations."""
        targets = self.parsed_data.get('targets', [])
        
        if not targets:
            self.generated_code.append("\n# No targets found in mapping\n")
            return
        
        self.generated_code.append("\n# ============ TARGET WRITES ============\n")
        
        for target in targets:
            name = target.get('name', 'unknown_target')
            db = target.get('db', 'target_db')
            
            code = f'''
# Writing to Target: {name}
# Database: {db}
df_final.write.format("jdbc").options(
    url=get_jdbc_url("{db}"),
    dbtable="{name}",
    driver=JDBC_CONFIG["driver"]
).mode("overwrite").save()  # Change mode as needed: append, overwrite, ignore
'''
            self.generated_code.append(code)
        
        self.generated_code.append("\nprint('Job completed successfully!')")
        self.generated_code.append("spark.stop()")
    
    def _topological_sort_transformations(self, transformations, connectors):
        """Sort transformations based on data flow."""
        graph = {name: set() for name in transformations.keys()}
        
        for conn in connectors:
            from_inst = conn.get('from_instance', '')
            to_inst = conn.get('to_instance', '')
            if to_inst in graph and from_inst in transformations:
                graph[to_inst].add(from_inst)
        
        result = []
        visited = set()
        temp_visited = set()
        
        def visit(node):
            if node in temp_visited:
                return
            if node in visited:
                return
            temp_visited.add(node)
            for dep in graph.get(node, []):
                visit(dep)
            temp_visited.remove(node)
            visited.add(node)
            result.append(node)
        
        for node in graph:
            if node not in visited:
                visit(node)
        
        return result if result else list(transformations.keys())
    
    def _to_variable_name(self, name):
        """Convert name to valid Python variable name."""
        var_name = re.sub(r'[^a-zA-Z0-9_]', '_', name.lower())
        if var_name[0].isdigit():
            var_name = 'df_' + var_name
        return var_name


def generate_pyspark_code(parsed_data, mapping_rules=None):
    """Convenience function to generate PySpark code."""
    if mapping_rules is None:
        rules_obj = get_mapping_rules()
        mapping_rules = rules_obj.export_rules()
    elif hasattr(mapping_rules, 'export_rules'):
        mapping_rules = mapping_rules.export_rules()
    generator = PySparkGenerator(parsed_data, mapping_rules)
    return generator.generate()
