"""
Configurable Mapping Rules
Allows users to customize how Informatica transformations map to PySpark functions.
"""

from copy import deepcopy


class MappingRules:
    """Manages configurable transformation mapping rules."""
    
    DEFAULT_RULES = {
        'lookup': {
            'strategy': 'broadcast',
            'options': ['broadcast', 'standard', 'bucket'],
            'description': 'How to handle Lookup transformations',
            'pyspark_mapping': {
                'broadcast': 'F.broadcast(df_lookup)',
                'standard': 'df_lookup',
                'bucket': 'df_lookup.hint("shuffle_hash")'
            }
        },
        'joiner': {
            'default_join_type': 'inner',
            'options': ['inner', 'left', 'right', 'outer', 'cross', 'semi', 'anti'],
            'description': 'Default join type when not specified',
            'optimize_small_tables': True
        },
        'aggregator': {
            'use_window_functions': False,
            'description': 'Use window functions instead of groupBy where applicable'
        },
        'sequence_generator': {
            'strategy': 'monotonic',
            'options': ['monotonic', 'row_number', 'uuid'],
            'description': 'How to generate sequence IDs',
            'pyspark_mapping': {
                'monotonic': 'F.monotonically_increasing_id()',
                'row_number': 'F.row_number().over(Window.orderBy(F.lit(1)))',
                'uuid': 'F.expr("uuid()")'
            }
        },
        'filter': {
            'null_handling': 'strict',
            'options': ['strict', 'coalesce_false'],
            'description': 'How to handle NULL in filter conditions'
        },
        'expression': {
            'null_safe_operations': True,
            'description': 'Use null-safe operations in expressions'
        },
        'source_qualifier': {
            'pushdown_predicates': True,
            'partition_column': None,
            'description': 'Enable predicate pushdown for source reads'
        },
        'target': {
            'write_mode': 'overwrite',
            'options': ['overwrite', 'append', 'ignore', 'error'],
            'description': 'Default write mode for targets',
            'partition_by': None,
            'coalesce': None
        },
        'datatype_mappings': {
            'nvarchar': 'StringType()',
            'varchar': 'StringType()',
            'varchar2': 'StringType()',
            'char': 'StringType()',
            'string': 'StringType()',
            'text': 'StringType()',
            'integer': 'IntegerType()',
            'int': 'IntegerType()',
            'smallint': 'ShortType()',
            'bigint': 'LongType()',
            'decimal': 'DecimalType(38, 10)',
            'number': 'DecimalType(38, 10)',
            'numeric': 'DecimalType(38, 10)',
            'float': 'FloatType()',
            'double': 'DoubleType()',
            'real': 'FloatType()',
            'date': 'DateType()',
            'datetime': 'TimestampType()',
            'timestamp': 'TimestampType()',
            'boolean': 'BooleanType()',
            'bit': 'BooleanType()',
            'binary': 'BinaryType()',
            'varbinary': 'BinaryType()'
        },
        'expression_functions': {
            'IIF': 'F.when({condition}, {true_val}).otherwise({false_val})',
            'DECODE': 'F.when().when()...otherwise()',
            'ISNULL': '{col}.isNull()',
            'NVL': 'F.coalesce({col}, {default})',
            'TO_DATE': 'F.to_date({col}, {format})',
            'TO_CHAR': 'F.date_format({col}, {format})',
            'UPPER': 'F.upper({col})',
            'LOWER': 'F.lower({col})',
            'TRIM': 'F.trim({col})',
            'LTRIM': 'F.ltrim({col})',
            'RTRIM': 'F.rtrim({col})',
            'CONCAT': 'F.concat({args})',
            'SUBSTR': 'F.substring({col}, {start}, {length})',
            'LENGTH': 'F.length({col})',
            'REPLACE': 'F.regexp_replace({col}, {pattern}, {replacement})',
            'ABS': 'F.abs({col})',
            'ROUND': 'F.round({col}, {scale})',
            'TRUNC': 'F.trunc({col}, {format})',
            'FLOOR': 'F.floor({col})',
            'CEIL': 'F.ceil({col})',
            'POWER': 'F.pow({base}, {exp})',
            'SQRT': 'F.sqrt({col})',
            'SYSDATE': 'F.current_date()',
            'SYSTIMESTAMP': 'F.current_timestamp()'
        }
    }
    
    def __init__(self, custom_rules=None):
        self.rules = deepcopy(self.DEFAULT_RULES)
        if custom_rules:
            self.apply_custom_rules(custom_rules)
    
    def apply_custom_rules(self, custom_rules):
        """Apply custom rules on top of defaults."""
        for category, settings in custom_rules.items():
            if category in self.rules:
                if isinstance(self.rules[category], dict) and isinstance(settings, dict):
                    self.rules[category].update(settings)
                else:
                    self.rules[category] = settings
            else:
                self.rules[category] = settings
    
    def get_rule(self, category, key=None):
        """Get a specific rule or category."""
        if category not in self.rules:
            return None
        if key is None:
            return self.rules[category]
        return self.rules[category].get(key)
    
    def set_rule(self, category, key, value):
        """Set a specific rule value."""
        if category not in self.rules:
            self.rules[category] = {}
        self.rules[category][key] = value
    
    def get_lookup_strategy(self):
        """Get the current lookup transformation strategy."""
        return self.rules['lookup']['strategy']
    
    def set_lookup_strategy(self, strategy):
        """Set lookup strategy (broadcast, standard, bucket)."""
        if strategy in self.rules['lookup']['options']:
            self.rules['lookup']['strategy'] = strategy
            return True
        return False
    
    def get_sequence_strategy(self):
        """Get sequence generator strategy."""
        return self.rules['sequence_generator']['strategy']
    
    def set_sequence_strategy(self, strategy):
        """Set sequence strategy (monotonic, row_number, uuid)."""
        if strategy in self.rules['sequence_generator']['options']:
            self.rules['sequence_generator']['strategy'] = strategy
            return True
        return False
    
    def get_write_mode(self):
        """Get default write mode."""
        return self.rules['target']['write_mode']
    
    def set_write_mode(self, mode):
        """Set default write mode."""
        if mode in self.rules['target']['options']:
            self.rules['target']['write_mode'] = mode
            return True
        return False
    
    def get_datatype_mapping(self, informatica_type):
        """Get PySpark datatype for Informatica type."""
        return self.rules['datatype_mappings'].get(
            informatica_type.lower(),
            'StringType()'
        )
    
    def set_datatype_mapping(self, informatica_type, spark_type):
        """Set custom datatype mapping."""
        self.rules['datatype_mappings'][informatica_type.lower()] = spark_type
    
    def get_expression_template(self, function_name):
        """Get PySpark template for Informatica function."""
        return self.rules['expression_functions'].get(function_name.upper())
    
    def export_rules(self):
        """Export current rules as dictionary."""
        return deepcopy(self.rules)
    
    def get_configurable_options(self):
        """Get list of all configurable options for UI."""
        options = []
        
        for category, settings in self.rules.items():
            if isinstance(settings, dict) and 'options' in settings:
                options.append({
                    'category': category,
                    'description': settings.get('description', ''),
                    'current_value': settings.get('strategy') or settings.get('default_join_type') or settings.get('write_mode'),
                    'available_options': settings['options']
                })
        
        return options
    
    def validate_rules(self):
        """Validate current rules configuration."""
        errors = []
        
        if self.rules['lookup']['strategy'] not in self.rules['lookup']['options']:
            errors.append(f"Invalid lookup strategy: {self.rules['lookup']['strategy']}")
        
        if self.rules['sequence_generator']['strategy'] not in self.rules['sequence_generator']['options']:
            errors.append(f"Invalid sequence strategy: {self.rules['sequence_generator']['strategy']}")
        
        if self.rules['target']['write_mode'] not in self.rules['target']['options']:
            errors.append(f"Invalid write mode: {self.rules['target']['write_mode']}")
        
        return {
            'valid': len(errors) == 0,
            'errors': errors
        }


_current_mapping_rules = None


def get_mapping_rules():
    """Get or create current mapping rules instance."""
    global _current_mapping_rules
    if _current_mapping_rules is None:
        _current_mapping_rules = MappingRules()
    return _current_mapping_rules


def update_mapping_rules(custom_rules):
    """Update mapping rules with custom configuration."""
    global _current_mapping_rules
    if _current_mapping_rules is None:
        _current_mapping_rules = MappingRules(custom_rules)
    else:
        _current_mapping_rules.apply_custom_rules(custom_rules)
    return _current_mapping_rules


def reset_mapping_rules():
    """Reset to default mapping rules."""
    global _current_mapping_rules
    _current_mapping_rules = MappingRules()
    return _current_mapping_rules
