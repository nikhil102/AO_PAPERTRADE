import difflib
import hashlib
import json
from datetime import datetime

class DiffViewer:
    def __init__(self):
        self.conversion_history = {}
    
    def generate_diff(self, old_code, new_code, old_label="Previous", new_label="Current"):
        if not old_code or not new_code:
            return {
                'has_changes': False,
                'summary': 'No comparison available',
                'unified_diff': '',
                'side_by_side': [],
                'stats': {'added': 0, 'removed': 0, 'modified': 0}
            }
        
        old_lines = old_code.splitlines(keepends=True)
        new_lines = new_code.splitlines(keepends=True)
        
        unified = list(difflib.unified_diff(
            old_lines, 
            new_lines, 
            fromfile=old_label, 
            tofile=new_label,
            lineterm=''
        ))
        
        side_by_side = self._generate_side_by_side(old_lines, new_lines)
        
        stats = self._calculate_stats(old_lines, new_lines)
        
        has_changes = old_code.strip() != new_code.strip()
        
        return {
            'has_changes': has_changes,
            'summary': self._generate_summary(stats, has_changes),
            'unified_diff': ''.join(unified),
            'side_by_side': side_by_side,
            'stats': stats,
            'old_hash': self._hash_code(old_code),
            'new_hash': self._hash_code(new_code)
        }
    
    def _generate_side_by_side(self, old_lines, new_lines):
        differ = difflib.SequenceMatcher(None, old_lines, new_lines)
        result = []
        
        for tag, i1, i2, j1, j2 in differ.get_opcodes():
            if tag == 'equal':
                for i in range(i1, i2):
                    result.append({
                        'type': 'equal',
                        'line_old': i + 1,
                        'line_new': i - i1 + j1 + 1,
                        'old': old_lines[i].rstrip('\n'),
                        'new': new_lines[i - i1 + j1].rstrip('\n')
                    })
            elif tag == 'delete':
                for i in range(i1, i2):
                    result.append({
                        'type': 'delete',
                        'line_old': i + 1,
                        'line_new': None,
                        'old': old_lines[i].rstrip('\n'),
                        'new': ''
                    })
            elif tag == 'insert':
                for j in range(j1, j2):
                    result.append({
                        'type': 'insert',
                        'line_old': None,
                        'line_new': j + 1,
                        'old': '',
                        'new': new_lines[j].rstrip('\n')
                    })
            elif tag == 'replace':
                max_len = max(i2 - i1, j2 - j1)
                for k in range(max_len):
                    old_idx = i1 + k if k < (i2 - i1) else None
                    new_idx = j1 + k if k < (j2 - j1) else None
                    result.append({
                        'type': 'modify',
                        'line_old': old_idx + 1 if old_idx is not None else None,
                        'line_new': new_idx + 1 if new_idx is not None else None,
                        'old': old_lines[old_idx].rstrip('\n') if old_idx is not None else '',
                        'new': new_lines[new_idx].rstrip('\n') if new_idx is not None else ''
                    })
        
        return result
    
    def _calculate_stats(self, old_lines, new_lines):
        differ = difflib.SequenceMatcher(None, old_lines, new_lines)
        
        added = 0
        removed = 0
        modified = 0
        
        for tag, i1, i2, j1, j2 in differ.get_opcodes():
            if tag == 'insert':
                added += j2 - j1
            elif tag == 'delete':
                removed += i2 - i1
            elif tag == 'replace':
                modified += max(i2 - i1, j2 - j1)
        
        return {
            'added': added,
            'removed': removed,
            'modified': modified,
            'total_old': len(old_lines),
            'total_new': len(new_lines)
        }
    
    def _generate_summary(self, stats, has_changes):
        if not has_changes:
            return "No changes detected between versions."
        
        parts = []
        if stats['added'] > 0:
            parts.append(f"+{stats['added']} lines added")
        if stats['removed'] > 0:
            parts.append(f"-{stats['removed']} lines removed")
        if stats['modified'] > 0:
            parts.append(f"~{stats['modified']} lines modified")
        
        return ', '.join(parts) if parts else "Files are identical."
    
    def _hash_code(self, code):
        return hashlib.md5(code.encode()).hexdigest()[:8]
    
    def store_conversion(self, workflow_name, pyspark_code, parsed_data):
        code_hash = self._hash_code(pyspark_code)
        
        if workflow_name not in self.conversion_history:
            self.conversion_history[workflow_name] = []
        
        history = self.conversion_history[workflow_name]
        
        if not history or history[-1]['hash'] != code_hash:
            history.append({
                'timestamp': datetime.now().isoformat(),
                'hash': code_hash,
                'code': pyspark_code,
                'line_count': len(pyspark_code.splitlines()),
                'transformation_count': len(parsed_data.get('transformations', []))
            })
            
            if len(history) > 10:
                history.pop(0)
        
        return len(history)
    
    def get_history(self, workflow_name):
        return self.conversion_history.get(workflow_name, [])
    
    def compare_versions(self, workflow_name, version1_idx, version2_idx):
        history = self.get_history(workflow_name)
        
        if not history or version1_idx >= len(history) or version2_idx >= len(history):
            return None
        
        old_version = history[version1_idx]
        new_version = history[version2_idx]
        
        diff_result = self.generate_diff(
            old_version['code'], 
            new_version['code'],
            f"Version {version1_idx + 1} ({old_version['timestamp'][:10]})",
            f"Version {version2_idx + 1} ({new_version['timestamp'][:10]})"
        )
        
        diff_result['version1'] = {
            'index': version1_idx,
            'timestamp': old_version['timestamp'],
            'hash': old_version['hash']
        }
        diff_result['version2'] = {
            'index': version2_idx,
            'timestamp': new_version['timestamp'],
            'hash': new_version['hash']
        }
        
        return diff_result


diff_viewer = DiffViewer()
