"""
Pipeline Flow Diagram Generator
Generates Mermaid diagrams from Informatica connector data.
"""


def generate_mermaid_diagram(connectors):
    """
    Generate Mermaid diagram from connector data.
    
    Args:
        connectors: List of connector dictionaries with from_instance, to_instance, etc.
    
    Returns:
        Mermaid diagram string
    """
    if not connectors:
        return "graph TD\n    A[No connectors found]"
    
    edges = set()
    for conn in connectors:
        from_inst = conn.get('from_instance', '')
        to_inst = conn.get('to_instance', '')
        if from_inst and to_inst:
            safe_from = sanitize_node_name(from_inst)
            safe_to = sanitize_node_name(to_inst)
            edges.add((safe_from, safe_to))
    
    lines = ["graph TD"]
    for from_node, to_node in sorted(edges):
        lines.append(f"    {from_node}[{from_node}] --> {to_node}[{to_node}]")
    
    return "\n".join(lines)


def generate_detailed_mermaid(connectors, transformations=None):
    """
    Generate detailed Mermaid diagram with transformation types.
    
    Args:
        connectors: List of connector dictionaries
        transformations: Dictionary of transformation data (optional)
    
    Returns:
        Mermaid diagram string with styled nodes
    """
    if not connectors:
        return "graph TD\n    A[No connectors found]"
    
    edges = set()
    nodes = set()
    
    for conn in connectors:
        from_inst = conn.get('from_instance', '')
        to_inst = conn.get('to_instance', '')
        if from_inst and to_inst:
            safe_from = sanitize_node_name(from_inst)
            safe_to = sanitize_node_name(to_inst)
            edges.add((safe_from, safe_to, from_inst, to_inst))
            nodes.add((safe_from, from_inst))
            nodes.add((safe_to, to_inst))
    
    lines = ["graph TD"]
    
    if transformations:
        lines.append("    %% Style definitions")
        lines.append("    classDef source fill:#e1f5fe,stroke:#01579b")
        lines.append("    classDef target fill:#e8f5e9,stroke:#1b5e20")
        lines.append("    classDef expression fill:#fff3e0,stroke:#e65100")
        lines.append("    classDef filter fill:#fce4ec,stroke:#880e4f")
        lines.append("    classDef lookup fill:#f3e5f5,stroke:#4a148c")
        lines.append("    classDef joiner fill:#e0f2f1,stroke:#004d40")
        lines.append("    classDef aggregator fill:#fff8e1,stroke:#ff6f00")
        lines.append("    classDef default fill:#f5f5f5,stroke:#424242")
        lines.append("")
    
    for safe_name, orig_name in sorted(nodes):
        trans_type = ""
        if transformations and orig_name in transformations:
            trans_type = transformations[orig_name].get('type', '')
        
        node_shape = get_node_shape(trans_type)
        lines.append(f"    {safe_name}{node_shape}")
    
    lines.append("")
    
    for safe_from, safe_to, orig_from, orig_to in sorted(edges):
        lines.append(f"    {safe_from} --> {safe_to}")
    
    if transformations:
        lines.append("")
        source_nodes = []
        target_nodes = []
        expression_nodes = []
        filter_nodes = []
        lookup_nodes = []
        joiner_nodes = []
        aggregator_nodes = []
        
        for safe_name, orig_name in nodes:
            if orig_name in transformations:
                trans_type = transformations[orig_name].get('type', '').upper()
                if 'SOURCE' in trans_type:
                    source_nodes.append(safe_name)
                elif 'TARGET' in trans_type:
                    target_nodes.append(safe_name)
                elif 'EXPRESSION' in trans_type:
                    expression_nodes.append(safe_name)
                elif 'FILTER' in trans_type:
                    filter_nodes.append(safe_name)
                elif 'LOOKUP' in trans_type:
                    lookup_nodes.append(safe_name)
                elif 'JOINER' in trans_type:
                    joiner_nodes.append(safe_name)
                elif 'AGGREGATOR' in trans_type:
                    aggregator_nodes.append(safe_name)
        
        if source_nodes:
            lines.append(f"    class {','.join(source_nodes)} source")
        if target_nodes:
            lines.append(f"    class {','.join(target_nodes)} target")
        if expression_nodes:
            lines.append(f"    class {','.join(expression_nodes)} expression")
        if filter_nodes:
            lines.append(f"    class {','.join(filter_nodes)} filter")
        if lookup_nodes:
            lines.append(f"    class {','.join(lookup_nodes)} lookup")
        if joiner_nodes:
            lines.append(f"    class {','.join(joiner_nodes)} joiner")
        if aggregator_nodes:
            lines.append(f"    class {','.join(aggregator_nodes)} aggregator")
    
    return "\n".join(lines)


def sanitize_node_name(name):
    """
    Sanitize node name for Mermaid compatibility.
    Removes special characters that cause parsing issues.
    """
    import re
    sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', name)
    if sanitized[0].isdigit():
        sanitized = 'n_' + sanitized
    return sanitized


def get_node_shape(trans_type):
    """Get Mermaid node shape based on transformation type."""
    trans_type = trans_type.upper() if trans_type else ''
    
    if 'SOURCE' in trans_type:
        return '([Source])'
    elif 'TARGET' in trans_type:
        return '[[Target]]'
    elif 'EXPRESSION' in trans_type:
        return '{Expression}'
    elif 'FILTER' in trans_type:
        return '{{Filter}}'
    elif 'LOOKUP' in trans_type:
        return '[(Lookup)]'
    elif 'JOINER' in trans_type:
        return '>Joiner]'
    elif 'AGGREGATOR' in trans_type:
        return '((Aggregator))'
    elif 'ROUTER' in trans_type:
        return '{Router}'
    elif 'UNION' in trans_type:
        return '[Union]'
    elif 'SORTER' in trans_type:
        return '[/Sorter/]'
    else:
        return f'[{trans_type if trans_type else "Transform"}]'


def generate_lineage_data(connectors):
    """
    Generate field-level lineage data.
    
    Args:
        connectors: List of connector dictionaries
    
    Returns:
        Dictionary mapping target fields to source fields
    """
    lineage = {}
    for conn in connectors:
        from_inst = conn.get('from_instance', '')
        from_field = conn.get('from_field', '')
        to_inst = conn.get('to_instance', '')
        to_field = conn.get('to_field', '')
        
        if from_inst and from_field and to_inst and to_field:
            target_key = f"{to_inst}.{to_field}"
            source_key = f"{from_inst}.{from_field}"
            
            if target_key not in lineage:
                lineage[target_key] = []
            lineage[target_key].append(source_key)
    
    return lineage


def generate_flow_summary(parsed_data):
    """
    Generate a text summary of the data flow.
    
    Args:
        parsed_data: Full parsed data dictionary
    
    Returns:
        String summary of the flow
    """
    summary_lines = ["=" * 60]
    summary_lines.append("DATA FLOW SUMMARY")
    summary_lines.append("=" * 60)
    
    sources = parsed_data.get('sources', [])
    if sources:
        summary_lines.append(f"\nSOURCES ({len(sources)}):")
        for source in sources:
            summary_lines.append(f"  - {source.get('name', 'Unknown')} [{source.get('db', 'Unknown DB')}]")
    
    targets = parsed_data.get('targets', [])
    if targets:
        summary_lines.append(f"\nTARGETS ({len(targets)}):")
        for target in targets:
            summary_lines.append(f"  - {target.get('name', 'Unknown')} [{target.get('db', 'Unknown DB')}]")
    
    transformations = parsed_data.get('transformations', {})
    if transformations:
        summary_lines.append(f"\nTRANSFORMATIONS ({len(transformations)}):")
        type_counts = {}
        for name, data in transformations.items():
            trans_type = data.get('type', 'Unknown')
            type_counts[trans_type] = type_counts.get(trans_type, 0) + 1
        
        for trans_type, count in sorted(type_counts.items()):
            summary_lines.append(f"  - {trans_type}: {count}")
    
    connectors = parsed_data.get('connectors', [])
    if connectors:
        summary_lines.append(f"\nCONNECTORS: {len(connectors)} data flows")
    
    summary_lines.append("\n" + "=" * 60)
    
    return "\n".join(summary_lines)
