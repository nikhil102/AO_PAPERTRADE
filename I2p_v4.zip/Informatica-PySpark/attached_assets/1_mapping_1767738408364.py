import pyspark
from pyspark import SparkConf,SQLContext,SparkContext,StorageLevel
from pyspark.sql import SparkSession,DataFrame,Window,Row
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import pyspark.sql.functions as f
import pyspark.sql.types as t
import datetime
import time
import os
import sys
from functools import reduce
from os.path import join, abspath
import jaydebeapi


# Hardcoded JDBC connection details
server_name = "w908925\\CGSQL"
database_name_lkp = "msscdm_dev3"
database_name_source = "msscdm_dev3"
database_name_target = "msscdm_dev4"
jdbc_url_lkp = f"jdbc:sqlserver://w908925.cguser.capgroup.com\\CGSQL;databaseName={database_name_lkp};user=spark_user;password=spark@25091990;trustServerCertificate=true;encrypt=false"
jdbc_url_source = f"jdbc:sqlserver://w908925.cguser.capgroup.com\\CGSQL;databaseName={database_name_source};user=spark_user;password=spark@25091990;trustServerCertificate=true;encrypt=false"
jdbc_url_target = f"jdbc:sqlserver://w908925.cguser.capgroup.com\\CGSQL;databaseName={database_name_target};user=spark_user;password=spark@25091990;trustServerCertificate=true;encrypt=false"

# JDBC Driver Path
jdbc_driver_path = "C:/Drivers/mssql-jdbc-12.4.2.jre11.jar"
authentication_dll_path = "C:/Drivers"  # Location of `mssql-jdbc_auth-12.4.2.x64.dll`

# Initialize Spark Session with Authentication DLL Config
spark = SparkSession.builder \
    .appName("s_landing_sfdc_to_cdm_office_party_contact_mechanism") \
    .config("spark.ui.port", "4040") \
    .config("spark.driver.extraClassPath", jdbc_driver_path) \
    .config("spark.executor.extraClassPath", jdbc_driver_path) \
    .config("spark.driver.extraLibraryPath", authentication_dll_path) \
    .config("spark.executor.extraLibraryPath", authentication_dll_path) \
    .config("spark.executor.extraJavaOptions", f"-Djava.library.path={authentication_dll_path}") \
    .getOrCreate()

# Connection Properties
connection_properties = {
    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"
}
# Global Variables
PMMappingName = "s_landing_sfdc_to_cdm_contact_party_pyspark"
user = "spark_user"
password = "spark@25091990"
conn = spark._sc._gateway.jvm.java.sql.DriverManager.getConnection(jdbc_url_target,user,password)
stmt = conn.createStatement()
conn = jaydebeapi.connect(
	"com.microsoft.sqlserver.jdbc.SQLServerDriver",
	jdbc_url_target,
	["spark_user", "spark@25091990"],
	jars=jdbc_driver_path
	)
curs = conn.cursor()

try:
	#Ignoring the source "SQ_pre_land_sfdc_contact1" since it has no columns propagating to target

	# Reading Data From Source - SQ_pre_land_sfdc_contact1
	# Description : NA

	query = f""" SELECT con.Id, con.IsDeleted, con.LastName, con.FirstName, con.Salutation, con.MailingCountry, con.CreatedDate, 
	con.LastModifiedDate, con.Nickname__c, con.Sequence_N__c, con.Status__c, con.Middle_Initial__c, 
	con.SOURCE_SYSTEM_NAME, con.Createdby_Alias, con.Lastmodifiedby_Alias, con.Parent_Recordtype_Name,
	con.suffix__c, con.Professional_Credentials__c, con.Role_Status_primary_office__c 
	,case when 
	ofc.Client_Group_C IN ('ECM Local Consultant','ECM Global Consultant') and BillingCountry NOT IN('United Kingdom','Ireland','Channel Islands','Guernsey') then 
	NULL 
	else 
	ofc.Client_Group_C end as Client_Group_C,
	case when  ofc.Client_Group_C='UK' 
	or ((ofc.Client_Group_C='Australia' and ofc.BillingCountry is NULL) OR (ofc.Client_Group_C is NOT NULL and ofc.BillingCountry = 'Australia'))
	or (ofc.Client_Group_C IN ('ECM Local Consultant','ECM Global Consultant') and BillingCountry IN('United Kingdom','Ireland','Channel Islands','Guernsey')) then con.Title else null end as Title
	FROM
	pre_land_sfdc_contact con
	left join
	pre_land_sfdc_office ofc
	on con.AccountId=ofc.id
	WHERE
	team_profile__c=0 and Parent_Recordtype_Name is not NULL"""
	sq_pre_land_sfdc_contact1 = spark.read.format("jdbc").options(url=jdbc_url_source, driver="com.microsoft.sqlserver.jdbc.SQLServerDriver", query=query).load()

	sq_pre_land_sfdc_contact1 = sq_pre_land_sfdc_contact1.coalesce(1).withColumn("jkey",monotonically_increasing_id())
	# Reading Data From Source - lkup_transformation_map
	# Description : NA

	query = f""" SELECT LTRIM(RTRIM(std_lkup_id)) as std_lkup_id
	,LTRIM(RTRIM(src_sys_nm)) as src_sys_nm
	,LTRIM(RTRIM(src_val)) as src_val
	,LTRIM(RTRIM(attrib_nm)) as attrib_nm 
	FROM lkup_transformation_map
	where src_sys_nm in ('SFDC','SFDCLEAD')"""
	lkup_transformation_map = spark.read.format("jdbc").options(url=jdbc_url_source, driver="com.microsoft.sqlserver.jdbc.SQLServerDriver", query=query).load()

	# Reading Data From Source - TODAY_PARTY_XFORM
	# Description : NA

	query = f""" SELECT LTRIM(RTRIM(SOURCE_SYSTEM)) as SOURCE_SYSTEM, 
	LTRIM(RTRIM(SOURCE_PARTY_ID)) as SOURCE_PARTY_ID FROM  
	TODAY_PARTY_XFORM WHERE SOURCE_SYSTEM IN ( 'SOFI', 'DORIS','SALESCONNECT') """
	today_party_xform = spark.read.format("jdbc").options(url=jdbc_url_source, driver="com.microsoft.sqlserver.jdbc.SQLServerDriver", query=query).load()

	# Filter Transformation  - FILTRANS
	# Description : NA

	filtrans = sq_pre_land_sfdc_contact1.select(col("LastModifiedDate"),col("IsDeleted"),col("LastName"),col("FirstName"),col("Salutation"),col("Status__c"),col("Nickname__c"),col("Client_Group_C"),col("SOURCE_SYSTEM_NAME"),col("Createdby_Alias"),col("Lastmodifiedby_Alias").alias("LastModified_Alias"),col("Professional_Credentials__c"),col("Role_Status_primary_office__c"),col("Sequence_N__c"),col("Id"),col("CreatedDate"),col("MailingCountry"),col("Middle_Initial__c"),col("Parent_Recordtype_Name"),col("suffix__c"),col("Title"),col("jkey")).filter(lit(True))
	# Expression Transformation  - DSExp_TODAY_PARTY_XFORM_LOOKUP_EXP_1
	# Description : NA lookup4

	dsexp_today_party_xform_lookup_exp_1 = filtrans.select(col("Id"),col("CreatedDate"),col("CreatedBy_Alias"),col("LastModifiedDate"),col("LastModified_Alias"),col("SOURCE_SYSTEM_NAME"),col("Middle_Initial__c"),col("FirstName"),col("LastName"),col("Nickname__c"),col("Salutation"),col("Status__c"),col("Sequence_N__c"),col("Parent_Recordtype_Name"),col("suffix__c"),col("Professional_Credentials__c"),col("Role_Status_primary_office__c"),col("Client_Group_C"),col("Title"),col("jkey"))

	dsexp_today_party_xform_lookup_exp_1 = dsexp_today_party_xform_lookup_exp_1.withColumn("IN_Id",concat(lit('PER_'), col("Sequence_N__c")))


	# # Expression Transformation  - DSExp_LKP_VALUES_EXP_0
	# # Description : NA lookup6

	dsexp_lkp_values_exp_0 = filtrans.select(col("Id"),col("CreatedDate"),col("CreatedBy_Alias"),col("LastModifiedDate"),col("LastModified_Alias"),col("SOURCE_SYSTEM_NAME"),col("Middle_Initial__c"),col("FirstName"),col("LastName"),col("Nickname__c"),col("Salutation"),col("Status__c"),col("Sequence_N__c"),col("Parent_Recordtype_Name"),col("suffix__c"),col("Professional_Credentials__c"),col("Role_Status_primary_office__c"),col("Client_Group_C"),col("Title"),col("jkey"))

	dsexp_lkp_values_exp_0 = dsexp_lkp_values_exp_0.withColumn("src_val_in",lit('Fully-Qualified')) \
	.withColumn("attrib_nm_in",lit('PARTY_QUALIFICATION_LEVEL_ID')) \
	

	# # Expression Transformation  - DSExp_lkp_values_EXP_3
	# # Description : NA -lookup3

	dsexp_lkp_values_exp_3 = filtrans.select(col("Id"),col("CreatedDate"),col("CreatedBy_Alias"),col("LastModifiedDate"),col("LastModified_Alias"),col("SOURCE_SYSTEM_NAME"),col("Middle_Initial__c"),col("FirstName"),col("LastName"),col("Nickname__c"),col("Salutation"),col("Status__c"),col("Sequence_N__c"),col("Parent_Recordtype_Name"),col("suffix__c"),col("Professional_Credentials__c"),col("Role_Status_primary_office__c"),col("Client_Group_C"),col("Title"),col("jkey"))

	dsexp_lkp_values_exp_3 = dsexp_lkp_values_exp_3.withColumn("src_val_in",lit('Person')) \
	.withColumn("attrib_nm_in",lit('PARTY_TYPE_ID')) \
	

	# # Expression Transformation  - DSExp_lkp_values_EXP_2
	# # Description : NA lookup5

	dsexp_lkp_values_exp_2 = filtrans.select(col("Id"),col("CreatedDate"),col("CreatedBy_Alias"),col("LastModifiedDate"),col("LastModified_Alias"),col("SOURCE_SYSTEM_NAME"),col("Middle_Initial__c"),col("FirstName"),col("LastName"),col("Nickname__c"),col("Salutation"),col("Status__c"),col("Sequence_N__c"),col("Parent_Recordtype_Name"),col("suffix__c"),col("Professional_Credentials__c"),col("Role_Status_primary_office__c"),col("Client_Group_C"),col("Title"),col("jkey"))

	dsexp_lkp_values_exp_2 = dsexp_lkp_values_exp_2.withColumn("V_party_inctvtn_rsn_type_name",when(col("Role_Status_primary_office__c") == 'Not in Compliance',lit('Compliance')).otherwise(when(col("Role_Status_primary_office__c") == 'Deceased',lit('Deceased')).otherwise(None))) \
	.withColumn("src_val_in",col("V_party_inctvtn_rsn_type_name")) \
	.withColumn("attrib_nm_in",lit('PARTY_INACTIVATION_REASON_TYPE')) \
	

	# # Expression Transformation  - DSExp_lkp_values_EXP_5
	# # Description : NA - lookup1

	dsexp_lkp_values_exp_5 = filtrans.select(col("Id"),col("CreatedDate"),col("CreatedBy_Alias"),col("LastModifiedDate"),col("LastModified_Alias"),col("SOURCE_SYSTEM_NAME"),col("Middle_Initial__c"),col("FirstName"),col("LastName"),col("Nickname__c"),col("Salutation"),col("Status__c"),col("Sequence_N__c"),col("Parent_Recordtype_Name"),col("suffix__c"),col("Professional_Credentials__c"),col("Role_Status_primary_office__c"),col("Client_Group_C"),col("Title"),col("jkey"))

	dsexp_lkp_values_exp_5 = dsexp_lkp_values_exp_5.withColumn("src_val_in",ltrim(rtrim(col("Salutation")))) \
	.withColumn("attrib_nm_in",lit('PERSON_HONORIFIC_ID')) \
	

	# # Expression Transformation  - DSExp_LKP_VALUES_EXP_4
	# # Description : NA lookup7

	dsexp_lkp_values_exp_4 = filtrans.select(col("Id"),col("CreatedDate"),col("CreatedBy_Alias"),col("LastModifiedDate"),col("LastModified_Alias"),col("SOURCE_SYSTEM_NAME"),col("Middle_Initial__c"),col("FirstName"),col("LastName"),col("Nickname__c"),col("Salutation"),col("Status__c"),col("Sequence_N__c"),col("Parent_Recordtype_Name"),col("suffix__c"),col("Professional_Credentials__c"),col("Role_Status_primary_office__c"),col("Client_Group_C"),col("Title"),col("jkey"))

	dsexp_lkp_values_exp_4 = dsexp_lkp_values_exp_4.withColumn("src_val_in",ltrim(rtrim(col("Client_Group_C")))) \
	.withColumn("attrib_nm_in",lit('CLIENT_GROUP_ID')) \
	

	# # Expression Transformation  - DSExp_lkp_values_EXP_6
	# # Description : NA - lookup2

	dsexp_lkp_values_exp_6 = filtrans.select(col("Id"),col("CreatedDate"),col("CreatedBy_Alias"),col("LastModifiedDate"),col("LastModified_Alias"),col("SOURCE_SYSTEM_NAME"),col("Middle_Initial__c"),col("FirstName"),col("LastName"),col("Nickname__c"),col("Salutation"),col("Status__c"),col("Sequence_N__c"),col("Parent_Recordtype_Name"),col("suffix__c"),col("Professional_Credentials__c"),col("Role_Status_primary_office__c"),col("Client_Group_C"),col("Title"),col("jkey"))

	dsexp_lkp_values_exp_6 = dsexp_lkp_values_exp_6.withColumn("V_STATUS_NAME",rtrim(col("Status__c"))).withColumn("src_val_in",ltrim(rtrim(col("V_STATUS_NAME")))).withColumn("attrib_nm_in",lit('PARTY_STATUS_ID'))


	# # Lookup Transformation  - DSUnLkp_TODAY_PARTY_XFORM_LOOKUP_EXP_1
	# # Description : NA - lookup4

	dsexp_today_party_xform_lookup_exp_1_lkpin = dsexp_today_party_xform_lookup_exp_1.select(col("IN_Id"),col("jkey"))

	today_party_xform_lkpin = today_party_xform

	dsunlkp_today_party_xform_lookup_exp_1 = dsexp_today_party_xform_lookup_exp_1_lkpin.join(today_party_xform_lkpin,(today_party_xform_lkpin['SOURCE_PARTY_ID'] == dsexp_today_party_xform_lookup_exp_1_lkpin['IN_Id']),how='left').select(dsexp_today_party_xform_lookup_exp_1_lkpin["jkey"],today_party_xform_lkpin["SOURCE_SYSTEM"].alias("unLkpRT_SOURCE_SYSTEM1") )
	dsunlkp_today_party_xform_lookup_exp_1 = dsunlkp_today_party_xform_lookup_exp_1.groupBy("jkey").agg(first('unLkpRT_SOURCE_SYSTEM1').alias("unLkpRT_SOURCE_SYSTEM1"))


	# # Lookup Transformation  - DSUnLkp_lkp_values_EXP_6
	# # Description : NA lookup2

	dsexp_lkp_values_exp_6_lkpin = dsexp_lkp_values_exp_6.select(col("src_val_in"),col("attrib_nm_in"),col("jkey"))

	lkup_transformation_map_lkpin = lkup_transformation_map

	dsunlkp_lkp_values_exp_6 = dsexp_lkp_values_exp_6_lkpin.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == dsexp_lkp_values_exp_6_lkpin['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == dsexp_lkp_values_exp_6_lkpin['attrib_nm_in']),how='left').select(dsexp_lkp_values_exp_6_lkpin["jkey"],lkup_transformation_map_lkpin["std_lkup_id"].alias("unLkpRT_std_lkup_id4") )
	dsunlkp_lkp_values_exp_6 = dsunlkp_lkp_values_exp_6.groupBy("jkey").agg(first("unLkpRT_std_lkup_id4").alias("unLkpRT_std_lkup_id4"))


	# # Lookup Transformation  - DSUnLkp_lkp_values_EXP_5
	# # Description : NA

	lkup_transformation_map_lkpin = lkup_transformation_map

	dsexp_lkp_values_exp_5_lkpin = dsexp_lkp_values_exp_5.select(col("src_val_in"),col("attrib_nm_in"),col("jkey"))

	dsunlkp_lkp_values_exp_5 = dsexp_lkp_values_exp_5_lkpin.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == dsexp_lkp_values_exp_5_lkpin['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == dsexp_lkp_values_exp_5_lkpin['attrib_nm_in']),how='left').select(dsexp_lkp_values_exp_5_lkpin["jkey"],lkup_transformation_map_lkpin["std_lkup_id"].alias("unLkpRT_std_lkup_id3") )
	dsunlkp_lkp_values_exp_5 = dsunlkp_lkp_values_exp_5.groupBy("jkey").agg(first("unLkpRT_std_lkup_id3").alias("unLkpRT_std_lkup_id3"))

	# # Lookup Transformation  - DSUnLkp_LKP_VALUES_EXP_4
	# # Description : NA

	lkup_transformation_map_lkpin = lkup_transformation_map

	dsexp_lkp_values_exp_4_lkpin = dsexp_lkp_values_exp_4.select(col("src_val_in"),col("attrib_nm_in"),col("jkey"))

	dsunlkp_lkp_values_exp_4 = dsexp_lkp_values_exp_4_lkpin.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == dsexp_lkp_values_exp_4_lkpin['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == dsexp_lkp_values_exp_4_lkpin['attrib_nm_in']),how='left').select(dsexp_lkp_values_exp_4_lkpin["jkey"],lkup_transformation_map_lkpin["std_lkup_id"].alias("unLkpRT_std_lkup_id2") )
	dsunlkp_lkp_values_exp_4 = dsunlkp_lkp_values_exp_4.groupBy("jkey").agg(first("unLkpRT_std_lkup_id2").alias("unLkpRT_std_lkup_id2"))


	# # Lookup Transformation  - DSUnLkp_lkp_values_EXP_3
	# # Description : NA

	lkup_transformation_map_lkpin = lkup_transformation_map

	dsexp_lkp_values_exp_3_lkpin = dsexp_lkp_values_exp_3.select(col("src_val_in"),col("attrib_nm_in"),col("jkey"))

	dsunlkp_lkp_values_exp_3 = dsexp_lkp_values_exp_3_lkpin.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == dsexp_lkp_values_exp_3_lkpin['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == dsexp_lkp_values_exp_3_lkpin['attrib_nm_in']),how='left').select(dsexp_lkp_values_exp_3_lkpin["jkey"],lkup_transformation_map_lkpin["std_lkup_id"].alias("unLkpRT_std_lkup_id2_3") )
	dsunlkp_lkp_values_exp_3 = dsunlkp_lkp_values_exp_3.groupBy("jkey").agg(first("unLkpRT_std_lkup_id2_3").alias("unLkpRT_std_lkup_id2_3"))
	
	print(217)

	# # Lookup Transformation  - DSUnLkp_lkp_values_EXP_2
	# # Description : NA

	lkup_transformation_map_lkpin = lkup_transformation_map

	dsexp_lkp_values_exp_2_lkpin = dsexp_lkp_values_exp_2.select(col("src_val_in"),col("attrib_nm_in"),col("jkey"))

	dsunlkp_lkp_values_exp_2 = dsexp_lkp_values_exp_2_lkpin.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == dsexp_lkp_values_exp_2_lkpin['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == dsexp_lkp_values_exp_2_lkpin['attrib_nm_in']),how='left').select(dsexp_lkp_values_exp_2_lkpin["jkey"],lkup_transformation_map_lkpin["std_lkup_id"].alias("unLkpRT_std_lkup_id1") )
	dsunlkp_lkp_values_exp_2 = dsunlkp_lkp_values_exp_2.groupBy("jkey").agg(first("unLkpRT_std_lkup_id1").alias("unLkpRT_std_lkup_id1_1"))
	
	

	# # Lookup Transformation  - DSUnLkp_LKP_VALUES_EXP_0
	# # Description : NA

	dsexp_lkp_values_exp_0_lkpin = dsexp_lkp_values_exp_0.select(col("src_val_in"),col("attrib_nm_in"),col("jkey"))

	lkup_transformation_map_lkpin = lkup_transformation_map

	dsunlkp_lkp_values_exp_0 = dsexp_lkp_values_exp_0_lkpin.join(lkup_transformation_map_lkpin,(lkup_transformation_map_lkpin['src_val'] == dsexp_lkp_values_exp_0_lkpin['src_val_in']) & (lkup_transformation_map_lkpin['attrib_nm'] == dsexp_lkp_values_exp_0_lkpin['attrib_nm_in']),how='left').select(dsexp_lkp_values_exp_0_lkpin["jkey"],lkup_transformation_map_lkpin["std_lkup_id"].alias("unLkpRT_std_lkup_id1") )
	dsunlkp_lkp_values_exp_0 = dsunlkp_lkp_values_exp_0.groupBy("jkey").agg(first("unLkpRT_std_lkup_id1").alias("unLkpRT_std_lkup_id1"))
	
	print(240)

	# # Multi Joiner Transformation  - dsJoiner_EXP0
	filtrans_input = filtrans.select(col("Id"),col("CreatedDate"),col("CreatedBy_Alias"),col("LastModifiedDate"),col("LastModified_Alias"),col("SOURCE_SYSTEM_NAME"),col("Middle_Initial__c"),col("FirstName"),col("LastName"),col("Nickname__c"),col("Salutation"),col("Status__c"),col("Sequence_N__c"),col("Parent_Recordtype_Name"),col("suffix__c"),col("Professional_Credentials__c"),col("Role_Status_primary_office__c"),col("Client_Group_C"),col("Title"),col("jkey"))

	dsunlkp_lkp_values_exp_2_input = dsunlkp_lkp_values_exp_2.select(col("unLkpRT_std_lkup_id1_1"),col("jkey").alias("jkey1"))

	dsunlkp_today_party_xform_lookup_exp_1_input = dsunlkp_today_party_xform_lookup_exp_1.select(col("unLkpRT_SOURCE_SYSTEM1"),col("jkey").alias("jkey2"))

	dsunlkp_lkp_values_exp_4_input = dsunlkp_lkp_values_exp_4.select(col("unLkpRT_std_lkup_id2"),col("jkey").alias("jkey3"))

	dsunlkp_lkp_values_exp_0_input = dsunlkp_lkp_values_exp_0.select(col("unLkpRT_std_lkup_id1"),col("jkey").alias("jkey4"))

	dsunlkp_lkp_values_exp_5_input = dsunlkp_lkp_values_exp_5.select(col("unLkpRT_std_lkup_id3"),col("jkey").alias("jkey5"))

	dsunlkp_lkp_values_exp_6_input = dsunlkp_lkp_values_exp_6.select(col("unLkpRT_std_lkup_id4"),col("jkey").alias("jkey6"))

	dsunlkp_lkp_values_exp_3_input = dsunlkp_lkp_values_exp_3.select(col("unLkpRT_std_lkup_id2_3"),col("jkey").alias("jkey7"))
	print(257)

	dsjoiner_exp0 = filtrans_input.join(dsunlkp_lkp_values_exp_0_input,(filtrans_input['jkey'] == dsunlkp_lkp_values_exp_0_input['jkey4']),how="inner").join(dsunlkp_today_party_xform_lookup_exp_1_input,(filtrans_input['jkey'] == dsunlkp_today_party_xform_lookup_exp_1_input['jkey2']),how="inner").join(dsunlkp_lkp_values_exp_2_input,(filtrans_input['jkey'] == dsunlkp_lkp_values_exp_2_input['jkey1']),how="inner").join(dsunlkp_lkp_values_exp_3_input,(filtrans_input['jkey'] == dsunlkp_lkp_values_exp_3_input['jkey7']),how="inner").join(dsunlkp_lkp_values_exp_4_input,(filtrans_input['jkey'] == dsunlkp_lkp_values_exp_4_input['jkey3']),how="inner").join(dsunlkp_lkp_values_exp_5_input,(filtrans_input['jkey'] == dsunlkp_lkp_values_exp_5_input['jkey5']),how="inner").join(dsunlkp_lkp_values_exp_6_input,(filtrans_input['jkey'] == dsunlkp_lkp_values_exp_6_input['jkey6']),how="inner").select(filtrans_input['Id'],filtrans_input['CreatedDate'],filtrans_input['CreatedBy_alias'],filtrans_input['LastModifiedDate'],filtrans_input['LastModified_Alias'],filtrans_input['SOURCE_SYSTEM_NAME'],filtrans_input['Middle_Initial__c'],filtrans_input['FirstName'],filtrans_input['LastName'],filtrans_input['Nickname__c'],filtrans_input['Salutation'],filtrans_input['Status__c'],filtrans_input['Sequence_N__c'],filtrans_input['Parent_Recordtype_Name'],filtrans_input['suffix__c'],filtrans_input['Professional_Credentials__c'],filtrans_input['Role_Status_primary_office__c'],filtrans_input['Client_Group_C'],filtrans_input['Title'],dsunlkp_lkp_values_exp_0_input['unLkpRT_std_lkup_id1'],dsunlkp_today_party_xform_lookup_exp_1_input['unLkpRT_SOURCE_SYSTEM1'],dsunlkp_lkp_values_exp_2_input['unLkpRT_std_lkup_id1_1'],dsunlkp_lkp_values_exp_3_input['unLkpRT_std_lkup_id2_3'],dsunlkp_lkp_values_exp_4_input['unLkpRT_std_lkup_id2'],dsunlkp_lkp_values_exp_5_input['unLkpRT_std_lkup_id3'],dsunlkp_lkp_values_exp_6_input['unLkpRT_std_lkup_id4'],filtrans_input['jkey'])
	print(260)
	# # Expression Transformation  - EXP
	# # Description : NA

	exp = dsjoiner_exp0.withColumn("Out_ID",concat(lit('PER_'),col("Id"))) \
	.withColumn("salutation_var",col("unLkpRT_std_lkup_id3")) \
	.withColumn("salutation_var2",when(col("Salutation").isNull(),lit(None)).otherwise(when(col("salutation_var").isNull(),lit(9999)).otherwise(col("salutation_var")))) \
	.withColumn("PERSON_HONORIFIC_ID",col("salutation_var2")) \
	.withColumn("V_STATUS_NAME",ltrim(rtrim(col("Status__c")))) \
	.withColumn("Status__var",col("unLkpRT_std_lkup_id4")) \
	.withColumn("status__var2",when(col("Status__c").isNull(),lit(None)).otherwise(when(col("Status__var").isNull(),lit(9999)).otherwise(col("Status__var")))) \
	.withColumn("PARTY_STATUS_ID",col("status__var2")) \
	.withColumn("Var_Type_ID",col("unLkpRT_std_lkup_id2_3")) \
	.withColumn("PARTY_TYPE_ID",when(col("Var_Type_ID").isNull(),lit(9999)).otherwise(col("Var_Type_ID"))) \
	.withColumn("Out_Sequence_N__c",when(col("Sequence_N__c").isNull(),lit(None)).otherwise(concat(lit('PER_'),col("Sequence_N__c")))) \
	.withColumn("PERSON_PFSNL_CRDNTLS_TXT",ltrim(rtrim(col("suffix__c")))) \
	.withColumn("MAPPING_NAME",lit(PMMappingName)) \
	.withColumn("LookupSOFIDORIS",col("unLkpRT_SOURCE_SYSTEM1")) \
	.withColumn("LookupSOFIDORIS_out",col("LookupSOFIDORIS")) \
	.withColumn("V_party_inctvtn_rsn_type_name",when(col("Role_Status_primary_office__c") == 'Not in Compliance','Compliance').otherwise(when(col("Role_Status_primary_office__c") == 'Deceased','Deceased').otherwise(None))) \
	.withColumn("V_party_inctvtn_rsn_type_lookup_id",col("unLkpRT_std_lkup_id1_1")) \
	.withColumn("party_inctvtn_rsn_type_id",when(col("V_party_inctvtn_rsn_type_lookup_id").isNotNull(),col("V_party_inctvtn_rsn_type_lookup_id")).otherwise(when(col("V_party_inctvtn_rsn_type_lookup_id").isNull() & col("V_party_inctvtn_rsn_type_name").isNull(),lit(None)).otherwise('9999'))) \
	.withColumn("DEFERRED_OWNERSHIP_IND_Out",when((ltrim(rtrim(col("Parent_Recordtype_Name"))).isin('Retail Office RO','CIAM Office RO','Financial Intermediary','NT Advisory Office RO')),'Y').otherwise('N')) \
	.withColumn("PERSON_MIDDLE_INITIAL",substring(ltrim(col("Middle_Initial__c")),1,1)) \
	.withColumn("V_PARTY_QUALIFICATION_LEVEL_ID",col("unLkpRT_std_lkup_id1")) \
	.withColumn("O_PARTY_QUALIFICATION_LEVEL_ID",col("V_PARTY_QUALIFICATION_LEVEL_ID")) \
	.withColumn("Client_Group_id",col("unLkpRT_std_lkup_id2"))
	exp_proc = exp
	exp_proc = exp_proc.cache()
	#exp_proc.show()
	for row in exp_proc.collect():
		if(row["salutation_var2"]==9999):
			Salutation = row['Salutation']
			Id = 'PER_' + row['Id']
			CreatedDate = row['CreatedDate']
			SOURCE_SYSTEM_NAME = row['SOURCE_SYSTEM_NAME']
			etlname = 'wf_landing_sfdc_to_cdm_contact_party'
			attrib_nm = 'PERSON_HONORIFIC_ID'
			error_msg = 'Lookup NULL Record'
			dw_pgm_name = 'wf_landing_sfdc_to_cdm_contact_party'
 
			procedure_call = f"""EXEC dbo.SP_LKP_LOAD_TOTAL_ERROR_INFO  '{Salutation}','{Id}','{Id}','{CreatedDate}', '{SOURCE_SYSTEM_NAME}', '{etlname}', '{attrib_nm}','{error_msg}', '{dw_pgm_name}'""" 
			print("Procedure call", procedure_call)	
			curs.execute(procedure_call)
			V_CHK_PERSON_HONORIFIC_ID = curs.fetone() 
		else:
			V_CHK_PERSON_HONORIFIC_ID = "NULL"

	# Filter Transformation  - FILTRANS1
	# Description : NA
	print(320)
	filtrans1 = exp_proc.select(col("LastName").alias("Person_last_name"),
	col("LastModifiedDate").alias("LAST_UPDATED_DATE"),
	col("Out_ID").alias("source_party_id"),
	col("PERSON_HONORIFIC_ID").alias("Person_Honorific_id"),
	col("Middle_Initial__c").alias("Person_Middle_Name"),
	col("Createdby_Alias").alias("created_by"),
	col("CreatedDate").alias("Created_Date"),
	col("Source_System_Name").alias("source_system"),
	col("Professional_Credentials__c").alias("person_pfsnl_crdntls_txt"),
	col("FirstName").alias("person_first_name"),
	col("LastModified_Alias").alias("last_updated_by"),col("Nickname__c").alias("person_nickname"),col("party_status_id"),col("party_type_id"),col("MAPPING_NAME"),col("suffix__c").alias("Person_Name_suffix_raw"),col("party_inctvtn_rsn_type_id"),col("DEFERRED_OWNERSHIP_IND_Out").alias("DEFERRED_OWNERSHIP_IND"),col("PERSON_MIDDLE_INITIAL"),col("O_PARTY_QUALIFICATION_LEVEL_ID").alias("PARTY_QUALIFICATION_LEVEL_ID"),col("Title").alias("PRSN_JOB_TITLE"),col("CLIENT_GROUP_ID")).filter(lit(True))
	print(323)
	# #Target Pre SQL
	delete_query = f"""delete from dbo.TODAY_PARTY_XFORM_poonam where MAPPING_NAME='{PMMappingName}'"""
	stmt.executeUpdate(delete_query)
	stmt.close()
	conn.close()
	print(400)
	
	# Writing data to Target insert-TODAY_PARTY_XFORM1
	# # Description : NA
	filtrans1.write.format('jdbc').option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver").option("url",jdbc_url_target).option("dbtable","today_party_xform").option("user", user).option("password", password).mode('append').save()
	print("Execution completed")
	filtrans1.show()
except Exception as Error:
	print(Error)
# finally:
# 	print("Job - {} Execution Completed".format("s_landing_sfdc_to_cdm_contact_party"))