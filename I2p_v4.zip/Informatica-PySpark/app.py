"""
Informatica to PySpark Converter Tool
Flask Web Application
"""

import os
import json
import tempfile
import time
from flask import Flask, render_template, request, jsonify, send_file
from dotenv import load_dotenv

from parser.xml_parser import parse_full_mapping
from generator.pyspark_generator import generate_pyspark_code
from generator.diagram_generator import (
    generate_mermaid_diagram,
    generate_detailed_mermaid,
    generate_flow_summary,
    generate_lineage_data
)
from generator.validation import generate_validation_report
from generator.audit_trail import get_audit_trail, reset_audit_trail
from generator.mapping_rules import get_mapping_rules, update_mapping_rules, reset_mapping_rules
from generator.tagging import (
    get_tag_manager,
    create_workflow_tags,
    WorkflowTags
)
from generator.documentation import DocumentationGenerator
from generator.diff_viewer import diff_viewer
from generator.data_profiling import DataProfiler

load_dotenv()

doc_generator = DocumentationGenerator()
data_profiler = DataProfiler()

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024


@app.route('/')
def index():
    """Render main page."""
    return render_template('index.html')


@app.route('/api/convert', methods=['POST'])
def convert_xml():
    """
    Convert Informatica XML to PySpark code.
    Accepts XML file upload or XML content.
    """
    start_time = time.time()
    audit = reset_audit_trail()
    
    try:
        xml_content = None
        filename = None
        
        if 'file' in request.files:
            file = request.files['file']
            if file and file.filename:
                filename = file.filename
                xml_content = file.read()
        elif request.is_json:
            data = request.get_json()
            xml_content = data.get('xml_content', '')
            if isinstance(xml_content, str):
                xml_content = xml_content.encode('utf-8')
        
        if not xml_content:
            return jsonify({
                'success': False,
                'error': 'No XML content provided'
            }), 400
        
        audit.log_parse_start(filename=filename, file_size=len(xml_content))
        
        parsed_data = parse_full_mapping(xml_content)
        
        audit.log_parse_complete(parsed_data)
        
        for trans_name, trans_data in parsed_data.get('transformations', {}).items():
            trans_type = trans_data.get('type', 'Unknown')
            if trans_type:
                audit.log_transformation_conversion(
                    trans_name,
                    trans_type,
                    decision=f"Converting {trans_type} transformation"
                )
        
        current_rules = get_mapping_rules()
        rules_dict = current_rules.export_rules()
        audit.log_mapping_rule_application(rules_dict)
        pyspark_code = generate_pyspark_code(parsed_data, rules_dict)
        
        duration_ms = int((time.time() - start_time) * 1000)
        audit.log_code_generation_complete(
            code_lines=len(pyspark_code.split('\n')),
            duration_ms=duration_ms
        )
        
        mermaid_diagram = generate_mermaid_diagram(parsed_data.get('connectors', []))
        
        detailed_diagram = generate_detailed_mermaid(
            parsed_data.get('connectors', []),
            parsed_data.get('transformations', {})
        )
        
        flow_summary = generate_flow_summary(parsed_data)
        
        lineage = generate_lineage_data(parsed_data.get('connectors', []))
        
        validation_report = generate_validation_report(parsed_data, pyspark_code)
        
        for warning in validation_report.get('warnings', []):
            audit.log_unsupported_element('warning', 'validation', warning)
        
        return jsonify({
            'success': True,
            'pyspark_code': pyspark_code,
            'mermaid_diagram': mermaid_diagram,
            'detailed_diagram': detailed_diagram,
            'flow_summary': flow_summary,
            'parsed_data': {
                'sources_count': len(parsed_data.get('sources', [])),
                'targets_count': len(parsed_data.get('targets', [])),
                'transformations_count': len(parsed_data.get('transformations', {})),
                'connectors_count': len(parsed_data.get('connectors', [])),
                'sources': parsed_data.get('sources', []),
                'targets': parsed_data.get('targets', []),
                'transformations': list(parsed_data.get('transformations', {}).keys()),
                'transformation_details': parsed_data.get('transformations', {})
            },
            'lineage': lineage,
            'validation_report': validation_report,
            'audit_trail': audit.get_full_trail(),
            'sql_info': parsed_data.get('sql_info', {})
        })
        
    except Exception as e:
        import traceback
        audit.log_error('Converter', str(e), traceback.format_exc())
        return jsonify({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc(),
            'audit_trail': audit.get_full_trail()
        }), 500


@app.route('/api/parse', methods=['POST'])
def parse_xml_only():
    """Parse XML and return structured data without generating code."""
    try:
        xml_content = None
        
        if 'file' in request.files:
            file = request.files['file']
            if file and file.filename:
                xml_content = file.read()
        elif request.is_json:
            data = request.get_json()
            xml_content = data.get('xml_content', '')
            if isinstance(xml_content, str):
                xml_content = xml_content.encode('utf-8')
        
        if not xml_content:
            return jsonify({
                'success': False,
                'error': 'No XML content provided'
            }), 400
        
        parsed_data = parse_full_mapping(xml_content)
        
        return jsonify({
            'success': True,
            'parsed_data': parsed_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/download', methods=['POST'])
def download_code():
    """Download generated PySpark code as a file."""
    try:
        data = request.get_json()
        code = data.get('code', '')
        filename = data.get('filename', 'generated_pyspark.py')
        
        if not code:
            return jsonify({
                'success': False,
                'error': 'No code provided'
            }), 400
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write(code)
            temp_path = f.name
        
        return send_file(
            temp_path,
            as_attachment=True,
            download_name=filename,
            mimetype='text/x-python'
        )
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/expression/convert', methods=['POST'])
def convert_expression():
    """Convert a single Informatica expression to PySpark."""
    try:
        from parser.expression_parser import ExpressionParser
        
        data = request.get_json()
        expression = data.get('expression', '')
        
        if not expression:
            return jsonify({
                'success': False,
                'error': 'No expression provided'
            }), 400
        
        parser = ExpressionParser()
        pyspark_expr = parser.parse(expression)
        
        return jsonify({
            'success': True,
            'original': expression,
            'pyspark': pyspark_expr,
            'columns_referenced': list(parser.column_references)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/mapping-rules', methods=['GET'])
def get_rules():
    """Get current mapping rules configuration."""
    rules = get_mapping_rules()
    return jsonify({
        'success': True,
        'rules': rules.export_rules(),
        'configurable_options': rules.get_configurable_options()
    })


@app.route('/api/mapping-rules', methods=['POST'])
def update_rules():
    """Update mapping rules with custom configuration."""
    try:
        data = request.get_json()
        custom_rules = data.get('rules', {})
        
        rules = update_mapping_rules(custom_rules)
        validation = rules.validate_rules()
        
        return jsonify({
            'success': validation['valid'],
            'rules': rules.export_rules(),
            'validation': validation
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/mapping-rules/reset', methods=['POST'])
def reset_rules():
    """Reset mapping rules to defaults."""
    rules = reset_mapping_rules()
    return jsonify({
        'success': True,
        'rules': rules.export_rules()
    })


@app.route('/api/tags', methods=['GET'])
def get_tags():
    """Get all workflow tags and predefined categories."""
    manager = get_tag_manager()
    return jsonify({
        'success': True,
        'predefined_categories': WorkflowTags.get_predefined_categories(),
        'used_tags': manager.get_all_used_tags(),
        'statistics': manager.get_statistics()
    })


@app.route('/api/tags/workflow', methods=['POST'])
def create_tags():
    """Create tags for a workflow."""
    try:
        data = request.get_json()
        workflow_name = data.get('workflow_name', 'Unnamed')
        initial_tags = data.get('tags', {})
        
        tags = create_workflow_tags(workflow_name, initial_tags)
        
        return jsonify({
            'success': True,
            'workflow_tags': tags.to_dict()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/tags/workflow/<workflow_id>', methods=['GET'])
def get_workflow_tags(workflow_id):
    """Get tags for a specific workflow."""
    manager = get_tag_manager()
    tags = manager.get_workflow_tags(workflow_id)
    
    if tags:
        return jsonify({
            'success': True,
            'workflow_tags': tags.to_dict()
        })
    return jsonify({
        'success': False,
        'error': 'Workflow not found'
    }), 404


@app.route('/api/tags/workflow/<workflow_id>', methods=['PUT'])
def update_workflow_tags(workflow_id):
    """Update tags for a workflow."""
    try:
        manager = get_tag_manager()
        tags = manager.get_workflow_tags(workflow_id)
        
        if not tags:
            return jsonify({
                'success': False,
                'error': 'Workflow not found'
            }), 404
        
        data = request.get_json()
        
        if 'category_tags' in data:
            for cat, val in data['category_tags'].items():
                tags.add_tag(cat, val)
        
        if 'custom_tags' in data:
            for tag in data['custom_tags']:
                tags.add_custom_tag(tag)
        
        if 'notes' in data:
            tags.set_notes(data['notes'])
        
        return jsonify({
            'success': True,
            'workflow_tags': tags.to_dict()
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/tags/search', methods=['GET'])
def search_tags():
    """Search workflows by tag or name."""
    query = request.args.get('q', '')
    category = request.args.get('category')
    value = request.args.get('value')
    
    manager = get_tag_manager()
    
    if query:
        results = manager.search_workflows(query)
    elif category:
        results = manager.filter_by_tag(category=category, value=value)
    else:
        results = list(manager.export_all().values())
    
    return jsonify({
        'success': True,
        'results': results
    })


@app.route('/api/validation/report', methods=['POST'])
def get_validation_report():
    """Generate validation report for provided data."""
    try:
        data = request.get_json()
        parsed_data = data.get('parsed_data', {})
        pyspark_code = data.get('pyspark_code', '')
        
        report = generate_validation_report(parsed_data, pyspark_code)
        
        return jsonify({
            'success': True,
            'report': report
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/documentation/generate', methods=['POST'])
def generate_documentation():
    """Generate markdown documentation for a workflow."""
    try:
        data = request.get_json()
        parsed_data = data.get('parsed_data', {})
        pyspark_code = data.get('pyspark_code', '')
        
        markdown_doc = doc_generator.generate_documentation(parsed_data, pyspark_code)
        
        return jsonify({
            'success': True,
            'documentation': markdown_doc
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/diff/compare', methods=['POST'])
def compare_code():
    """Compare two versions of generated code."""
    try:
        data = request.get_json()
        old_code = data.get('old_code', '')
        new_code = data.get('new_code', '')
        old_label = data.get('old_label', 'Previous Version')
        new_label = data.get('new_label', 'Current Version')
        
        diff_result = diff_viewer.generate_diff(old_code, new_code, old_label, new_label)
        
        return jsonify({
            'success': True,
            'diff': diff_result
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/diff/store', methods=['POST'])
def store_conversion():
    """Store a conversion for later comparison."""
    try:
        data = request.get_json()
        workflow_name = data.get('workflow_name', 'Unknown')
        pyspark_code = data.get('pyspark_code', '')
        parsed_data = data.get('parsed_data', {})
        
        version_count = diff_viewer.store_conversion(workflow_name, pyspark_code, parsed_data)
        
        return jsonify({
            'success': True,
            'workflow_name': workflow_name,
            'version_count': version_count,
            'message': f'Stored as version {version_count}'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/diff/history/<workflow_name>', methods=['GET'])
def get_conversion_history(workflow_name):
    """Get conversion history for a workflow."""
    history = diff_viewer.get_history(workflow_name)
    
    history_summary = []
    for i, version in enumerate(history):
        history_summary.append({
            'version': i + 1,
            'timestamp': version['timestamp'],
            'hash': version['hash'],
            'line_count': version['line_count'],
            'transformation_count': version.get('transformation_count', 0)
        })
    
    return jsonify({
        'success': True,
        'workflow_name': workflow_name,
        'history': history_summary
    })


@app.route('/api/diff/versions', methods=['POST'])
def compare_versions():
    """Compare two specific versions from history."""
    try:
        data = request.get_json()
        workflow_name = data.get('workflow_name', '')
        version1 = data.get('version1', 0)
        version2 = data.get('version2', 1)
        
        diff_result = diff_viewer.compare_versions(workflow_name, version1, version2)
        
        if diff_result is None:
            return jsonify({
                'success': False,
                'error': 'Versions not found'
            }), 404
        
        return jsonify({
            'success': True,
            'diff': diff_result
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/profiling/analyze', methods=['POST'])
def analyze_profiling():
    """Analyze workflow data and provide profiling insights."""
    try:
        data = request.get_json()
        parsed_data = data.get('parsed_data', {})
        
        profile = data_profiler.profile_workflow(parsed_data)
        
        return jsonify({
            'success': True,
            'profile': profile
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/profiling/field-comparison', methods=['POST'])
def compare_fields():
    """Compare source and target fields."""
    try:
        data = request.get_json()
        parsed_data = data.get('parsed_data', {})
        
        comparison = data_profiler.compare_source_target_fields(parsed_data)
        
        connectors = parsed_data.get('connectors', [])
        transformations = parsed_data.get('transformations', {})
        connector_hints = data_profiler.analyze_connectors_for_optimization(connectors, transformations)
        
        return jsonify({
            'success': True,
            'comparison': comparison,
            'connector_hints': connector_hints
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/health')
def health_check():
    """Health check endpoint."""
    return jsonify({
        'status': 'healthy',
        'service': 'Informatica to PySpark Converter',
        'features': [
            'XML Parsing',
            'PySpark Generation',
            'Pipeline Visualization',
            'Validation Reports',
            'Audit Trail',
            'Configurable Mapping Rules',
            'Workflow Tagging',
            'Auto-Documentation',
            'Code Diff View',
            'Data Profiling',
            'Field Comparison'
        ]
    })


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
