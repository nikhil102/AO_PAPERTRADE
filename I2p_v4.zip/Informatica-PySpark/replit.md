# Informatica to PySpark Converter Tool

## Overview
A web-based tool that converts Informatica Workflow XML files into PySpark code. Built with Python 3.10, Flask 3.1, and plain JavaScript.

## Features
- **XML Upload**: Drag-and-drop or file selection for Informatica XML files
- **PySpark Code Generation**: Automatic conversion of transformations to PySpark equivalents
- **Pipeline Visualization**: Mermaid diagrams showing data flow
- **Expression Converter**: Convert individual Informatica expressions to PySpark
- **Field Lineage**: Track data flow from source to target fields
- **Download**: Export generated PySpark code as .py files
- **Validation Reports**: Coverage analysis, schema comparison, and error highlighting
- **Audit Trail**: Complete log of conversion decisions for compliance
- **Configurable Mapping Rules**: Customize transformation mappings (lookup strategy, sequence generation, etc.)
- **Tagging System**: Metadata labels (domain, type, priority, status) for workflow organization
- **Auto-Documentation**: Generate markdown docs explaining each transformation step
- **Code Diff View**: Compare changes when re-converting updated XML files
- **Data Profiling**: Analyze field types, suggest partitioning, and get optimization hints
- **Source vs Target Field Comparison**: Compare SOURCEFIELD and TARGETFIELD schemas with type mismatch detection
- **Connector-Based Optimization**: Analyze CONNECTOR patterns for join optimization hints

## Project Structure
```
/
├── app.py                      # Flask application entry point
├── parser/
│   ├── __init__.py
│   ├── xml_parser.py           # Informatica XML parsing
│   └── expression_parser.py    # Expression conversion (IIF, DECODE, etc.)
├── generator/
│   ├── __init__.py
│   ├── pyspark_generator.py    # PySpark code generation
│   ├── diagram_generator.py    # Mermaid diagram generation
│   ├── validation.py           # Validation reports and coverage analysis
│   ├── audit_trail.py          # Audit logging for compliance
│   ├── mapping_rules.py        # Configurable transformation mappings
│   ├── tagging.py              # Workflow tagging system
│   ├── documentation.py        # Auto-documentation generator
│   ├── diff_viewer.py          # Code diff comparison
│   └── data_profiling.py       # Data profiling and optimization hints
├── templates/
│   └── index.html              # Main HTML template
├── static/
│   ├── css/
│   │   └── styles.css          # Application styles
│   └── js/
│       └── app.js              # Frontend JavaScript
└── attached_assets/            # Sample XML files for testing
```

## Supported Transformations
- Source Qualifier (with SQL Override)
- Expression Transformation
- Filter Transformation
- Lookup Transformation
- Joiner Transformation
- Aggregator Transformation
- Sorter Transformation
- Router Transformation
- Union Transformation
- Sequence Generator
- Update Strategy
- Normalizer
- Stored Procedure (stub generation)

## Supported Expression Functions
- IIF (conditional)
- DECODE (multi-value conditional)
- ISNULL / NVL
- TO_DATE / TO_CHAR
- UPPER / LOWER / TRIM / LTRIM / RTRIM
- CONCAT / SUBSTRING
- Mathematical functions (ABS, ROUND, etc.)

## API Endpoints
- `GET /` - Main web interface
- `POST /api/convert` - Convert XML to PySpark (file upload)
- `POST /api/parse` - Parse XML only (returns structured data)
- `POST /api/download` - Download generated code
- `POST /api/expression/convert` - Convert single expression
- `GET /api/mapping-rules` - Get current mapping rules
- `POST /api/mapping-rules` - Update mapping rules
- `POST /api/mapping-rules/reset` - Reset to default rules
- `GET /api/tags` - Get tag categories and statistics
- `POST /api/tags/workflow` - Create workflow tags
- `GET /api/tags/workflow/<id>` - Get workflow tags
- `PUT /api/tags/workflow/<id>` - Update workflow tags
- `GET /api/tags/search` - Search workflows by tags
- `POST /api/validation/report` - Generate validation report
- `POST /api/documentation/generate` - Generate markdown documentation
- `POST /api/diff/compare` - Compare two code versions
- `POST /api/diff/store` - Store conversion for history
- `GET /api/diff/history/<name>` - Get conversion history
- `POST /api/profiling/analyze` - Analyze data profiling
- `POST /api/profiling/field-comparison` - Compare source and target fields
- `GET /health` - Health check

## Usage
1. Open the web interface
2. Upload or drag-drop an Informatica XML file
3. Click "Convert to PySpark"
4. View generated code, pipeline diagram, and lineage
5. Download the .py file or copy code

## Technical Notes
- Flask server runs on port 5000
- Maximum file size: 50MB
- Uses lxml for XML parsing
- Mermaid.js for pipeline visualization

## Recent Changes
- January 2026: Initial implementation
- Support for all major Informatica transformation types
- Pipeline flow visualization with Mermaid diagrams
- Expression parser with recursive descent for nested functions
- Added validation reports with coverage analysis and error highlighting
- Added audit trail logging for compliance tracking
- Added configurable mapping rules (lookup strategy, sequence generation, etc.)
- Added workflow tagging system with predefined and custom tags
- Updated UI: Modern gradient header with logo, version badge, and styled footer
- Added SQL Queries tab showing all tables, SELECT queries, stored procedures, lookups, and filters
- Added Auto-Documentation tab with markdown export
- Added Code Diff View for comparing conversion changes
- Added Data Profiling with complexity analysis, partition suggestions, and optimization hints
- Updated color palette with Tailwind-inspired design (professional blues and grays)
- Pill-style tabs with modern UI styling
- Added Source vs Target Field Comparison with matched fields, type mismatches, and risk analysis
- Added Connector-Based Optimization hints based on CONNECTOR patterns in XML
- Enhanced Data Profiling tab with field comparison summary, matched/unmatched fields tables
