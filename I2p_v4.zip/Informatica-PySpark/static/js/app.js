document.addEventListener('DOMContentLoaded', function() {
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const fileInfo = document.getElementById('fileInfo');
    const convertBtn = document.getElementById('convertBtn');
    const clearBtn = document.getElementById('clearBtn');
    const resultsSection = document.getElementById('resultsSection');
    const loadingOverlay = document.getElementById('loadingOverlay');
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');
    
    let selectedFile = null;
    let currentData = null;
    let currentWorkflowTags = null;
    let customTags = [];
    
    mermaid.initialize({
        startOnLoad: false,
        theme: 'default',
        securityLevel: 'loose',
        flowchart: {
            useMaxWidth: true,
            htmlLabels: true,
            curve: 'basis'
        }
    });
    
    document.getElementById('settingsToggle').addEventListener('click', function() {
        const panel = document.getElementById('settingsPanel');
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        loadMappingRules();
    });
    
    async function loadMappingRules() {
        try {
            const response = await fetch('/api/mapping-rules');
            const data = await response.json();
            if (data.success) {
                document.getElementById('lookupStrategy').value = data.rules.lookup.strategy;
                document.getElementById('sequenceStrategy').value = data.rules.sequence_generator.strategy;
                document.getElementById('writeMode').value = data.rules.target.write_mode;
                document.getElementById('nullHandling').value = data.rules.filter.null_handling;
            }
        } catch (error) {
            console.error('Error loading mapping rules:', error);
        }
    }
    
    document.getElementById('saveSettings').addEventListener('click', async function() {
        try {
            const response = await fetch('/api/mapping-rules', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    rules: {
                        lookup: { strategy: document.getElementById('lookupStrategy').value },
                        sequence_generator: { strategy: document.getElementById('sequenceStrategy').value },
                        target: { write_mode: document.getElementById('writeMode').value },
                        filter: { null_handling: document.getElementById('nullHandling').value }
                    }
                })
            });
            const data = await response.json();
            if (data.success) {
                alert('Settings saved successfully!');
            }
        } catch (error) {
            alert('Error saving settings: ' + error.message);
        }
    });
    
    document.getElementById('resetSettings').addEventListener('click', async function() {
        try {
            await fetch('/api/mapping-rules/reset', { method: 'POST' });
            await loadMappingRules();
            alert('Settings reset to defaults');
        } catch (error) {
            alert('Error resetting settings: ' + error.message);
        }
    });
    
    dropZone.addEventListener('dragover', function(e) {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });
    
    dropZone.addEventListener('dragleave', function(e) {
        e.preventDefault();
        dropZone.classList.remove('dragover');
    });
    
    dropZone.addEventListener('drop', function(e) {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFile(files[0]);
        }
    });
    
    fileInput.addEventListener('change', function(e) {
        if (e.target.files.length > 0) {
            handleFile(e.target.files[0]);
        }
    });
    
    function handleFile(file) {
        if (!file.name.endsWith('.xml')) {
            alert('Please select an XML file');
            return;
        }
        
        selectedFile = file;
        fileInfo.textContent = `Selected: ${file.name} (${formatFileSize(file.size)})`;
        convertBtn.disabled = false;
    }
    
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    convertBtn.addEventListener('click', async function() {
        if (!selectedFile) return;
        
        loadingOverlay.style.display = 'flex';
        
        try {
            const formData = new FormData();
            formData.append('file', selectedFile);
            
            const response = await fetch('/api/convert', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                currentData = data;
                displayResults(data);
                resultsSection.style.display = 'block';
                resultsSection.scrollIntoView({ behavior: 'smooth' });
            } else {
                alert('Error: ' + data.error);
            }
        } catch (error) {
            alert('Error converting file: ' + error.message);
        } finally {
            loadingOverlay.style.display = 'none';
        }
    });
    
    clearBtn.addEventListener('click', function() {
        selectedFile = null;
        currentData = null;
        currentWorkflowTags = null;
        customTags = [];
        fileInput.value = '';
        fileInfo.textContent = '';
        convertBtn.disabled = true;
        resultsSection.style.display = 'none';
    });
    
    function displayResults(data) {
        document.getElementById('pysparkCode').textContent = data.pyspark_code;
        
        renderMermaidDiagram(data.mermaid_diagram);
        
        document.getElementById('flowSummary').textContent = data.flow_summary;
        
        displayStats(data.parsed_data);
        
        displayLineage(data.lineage);
        
        if (data.validation_report) {
            displayValidation(data.validation_report);
        }
        
        if (data.audit_trail) {
            displayAuditTrail(data.audit_trail);
        }
        
        if (data.sql_info) {
            displaySQLInfo(data.sql_info);
        }
        
        loadDocumentation(data.parsed_data, data.pyspark_code);
        
        loadProfiling(data.parsed_data);
        
        document.getElementById('parsedJson').textContent = JSON.stringify(data.parsed_data, null, 2);
    }
    
    function displaySQLInfo(sqlInfo) {
        const tablesContainer = document.getElementById('sqlTables');
        if (sqlInfo.tables && sqlInfo.tables.length > 0) {
            tablesContainer.innerHTML = sqlInfo.tables.map(t => `
                <div class="sql-table-card">
                    <div class="sql-table-name">
                        ${escapeHtml(t.name)}
                        <span class="sql-table-type ${t.type.toLowerCase()}">${t.type}</span>
                    </div>
                    <div class="sql-table-meta">
                        ${t.owner ? `Owner: ${escapeHtml(t.owner)}` : ''}
                        ${t.database ? ` | DB: ${escapeHtml(t.database)}` : ''}
                        ${t.database_type ? ` | ${escapeHtml(t.database_type)}` : ''}
                    </div>
                </div>
            `).join('');
        } else {
            tablesContainer.innerHTML = '<p class="sql-empty">No tables found</p>';
        }
        
        const selectContainer = document.getElementById('sqlSelectQueries');
        if (sqlInfo.select_queries && sqlInfo.select_queries.length > 0) {
            selectContainer.innerHTML = sqlInfo.select_queries.map(q => `
                <div class="sql-query-card">
                    <div class="sql-query-header">
                        <span class="sql-query-title">${escapeHtml(q.transformation)}</span>
                        <span class="sql-query-type">${escapeHtml(q.type)}</span>
                    </div>
                    <div class="sql-query-body">
                        <pre class="sql-query-code">${escapeHtml(q.query)}</pre>
                    </div>
                </div>
            `).join('');
        } else {
            selectContainer.innerHTML = '<p class="sql-empty">No SELECT queries found</p>';
        }
        
        const spContainer = document.getElementById('sqlStoredProcs');
        if (sqlInfo.stored_procedures && sqlInfo.stored_procedures.length > 0) {
            spContainer.innerHTML = sqlInfo.stored_procedures.map(sp => `
                <div class="sql-query-card">
                    <div class="sql-query-header">
                        <span class="sql-query-title">${escapeHtml(sp.name)}</span>
                        <span class="sql-query-type">${escapeHtml(sp.procedure_type)}</span>
                    </div>
                    <div class="sql-query-body">
                        <div class="sp-info">
                            <span>Transformation: <strong>${escapeHtml(sp.transformation)}</strong></span>
                        </div>
                        ${sp.call_text ? `<pre class="sql-query-code">${escapeHtml(sp.call_text)}</pre>` : '<p class="sql-empty">No call text defined</p>'}
                    </div>
                </div>
            `).join('');
        } else {
            spContainer.innerHTML = '<p class="sql-empty">No stored procedures found</p>';
        }
        
        const lookupContainer = document.getElementById('sqlLookupQueries');
        if (sqlInfo.lookup_queries && sqlInfo.lookup_queries.length > 0) {
            lookupContainer.innerHTML = sqlInfo.lookup_queries.map(q => `
                <div class="sql-query-card">
                    <div class="sql-query-header">
                        <span class="sql-query-title">${escapeHtml(q.transformation)}</span>
                        <span class="sql-query-type">Lookup Override</span>
                    </div>
                    <div class="sql-query-body">
                        <pre class="sql-query-code">${escapeHtml(q.query)}</pre>
                    </div>
                </div>
            `).join('');
        } else {
            lookupContainer.innerHTML = '<p class="sql-empty">No lookup queries found</p>';
        }
        
        const prePostContainer = document.getElementById('sqlPrePost');
        const preSql = sqlInfo.pre_sql || [];
        const postSql = sqlInfo.post_sql || [];
        if (preSql.length > 0 || postSql.length > 0) {
            let html = '';
            preSql.forEach(p => {
                html += `
                    <div class="sql-query-card">
                        <div class="sql-query-header">
                            <span class="sql-query-title">${escapeHtml(p.transformation)}</span>
                            <span class="sql-query-type">Pre-SQL</span>
                        </div>
                        <div class="sql-query-body">
                            <pre class="sql-query-code">${escapeHtml(p.sql)}</pre>
                        </div>
                    </div>
                `;
            });
            postSql.forEach(p => {
                html += `
                    <div class="sql-query-card">
                        <div class="sql-query-header">
                            <span class="sql-query-title">${escapeHtml(p.transformation)}</span>
                            <span class="sql-query-type">Post-SQL</span>
                        </div>
                        <div class="sql-query-body">
                            <pre class="sql-query-code">${escapeHtml(p.sql)}</pre>
                        </div>
                    </div>
                `;
            });
            prePostContainer.innerHTML = html;
        } else {
            prePostContainer.innerHTML = '<p class="sql-empty">No Pre/Post SQL found</p>';
        }
        
        const filtersContainer = document.getElementById('sqlFilters');
        if (sqlInfo.filter_conditions && sqlInfo.filter_conditions.length > 0) {
            filtersContainer.innerHTML = sqlInfo.filter_conditions.map(f => `
                <div class="sql-query-card">
                    <div class="sql-query-header">
                        <span class="sql-query-title">${escapeHtml(f.transformation)}</span>
                        <span class="sql-query-type">Filter</span>
                    </div>
                    <div class="sql-query-body">
                        <pre class="sql-query-code">${escapeHtml(f.condition)}</pre>
                    </div>
                </div>
            `).join('');
        } else {
            filtersContainer.innerHTML = '<p class="sql-empty">No filter conditions found</p>';
        }
    }
    
    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    function displayValidation(report) {
        const coverage = report.coverage;
        const badge = document.getElementById('coverageBadge');
        const pct = coverage.coverage_percentage;
        
        let badgeClass = 'coverage-high';
        if (pct < 70) badgeClass = 'coverage-low';
        else if (pct < 90) badgeClass = 'coverage-medium';
        
        badge.className = 'coverage-badge ' + badgeClass;
        badge.textContent = `${pct}% Coverage`;
        
        const coverageDetails = document.getElementById('coverageDetails');
        coverageDetails.innerHTML = `
            <div class="coverage-stat">
                <span class="stat-label">Supported Transformations:</span>
                <span class="stat-value">${coverage.supported_count}</span>
            </div>
            <div class="coverage-stat">
                <span class="stat-label">Unsupported Transformations:</span>
                <span class="stat-value warning">${coverage.unsupported_count}</span>
            </div>
            <div class="coverage-stat">
                <span class="stat-label">Expression Conversion Rate:</span>
                <span class="stat-value">${report.expression_analysis.conversion_rate}%</span>
            </div>
        `;
        
        const warningsContainer = document.getElementById('validationWarnings');
        if (report.warnings.length > 0) {
            warningsContainer.innerHTML = report.warnings.map(w => 
                `<div class="warning-item"><span class="warning-icon">&#9888;</span> ${w}</div>`
            ).join('');
        } else {
            warningsContainer.innerHTML = '<p class="no-warnings">No warnings detected</p>';
        }
        
        const unsupportedContainer = document.getElementById('unsupportedElements');
        const unsupported = report.unsupported_elements;
        let unsupportedHtml = '';
        
        if (unsupported.transformations.length > 0) {
            unsupportedHtml += '<div class="unsupported-group"><h5>Transformations</h5>';
            unsupported.transformations.forEach(t => {
                unsupportedHtml += `<div class="unsupported-item">${t.name} (${t.type})</div>`;
            });
            unsupportedHtml += '</div>';
        }
        
        if (unsupported.expressions.length > 0) {
            unsupportedHtml += '<div class="unsupported-group"><h5>Expression Functions</h5>';
            unsupported.expressions.slice(0, 10).forEach(e => {
                unsupportedHtml += `<div class="unsupported-item">${e.function} in ${e.transformation}.${e.field}</div>`;
            });
            if (unsupported.expressions.length > 10) {
                unsupportedHtml += `<div class="unsupported-more">...and ${unsupported.expressions.length - 10} more</div>`;
            }
            unsupportedHtml += '</div>';
        }
        
        unsupportedContainer.innerHTML = unsupportedHtml || '<p>No unsupported elements detected</p>';
        
        const schemaContainer = document.getElementById('schemaAnalysis');
        const schema = report.schema_analysis;
        schemaContainer.innerHTML = `
            <div class="schema-stat">Source Fields: ${schema.source_field_count}</div>
            <div class="schema-stat">Target Fields: ${schema.target_field_count}</div>
            <div class="schema-stat">Type Conversions: ${schema.type_conversions_detected}</div>
        `;
    }
    
    function displayAuditTrail(audit) {
        const summaryContainer = document.getElementById('auditSummary');
        const summary = audit.summary;
        
        summaryContainer.innerHTML = `
            <div class="audit-info">
                <span>Session: ${summary.session_id}</span>
                <span>Total Actions: ${summary.total_entries}</span>
                <span class="${summary.has_errors ? 'error' : ''}">Errors: ${summary.outcomes.error}</span>
                <span class="${summary.has_warnings ? 'warning' : ''}">Warnings: ${summary.outcomes.warning}</span>
            </div>
        `;
        
        displayAuditEntries(audit.entries, 'all');
        
        document.getElementById('auditFilter').addEventListener('change', function() {
            displayAuditEntries(audit.entries, this.value);
        });
    }
    
    function displayAuditEntries(entries, filter) {
        const container = document.getElementById('auditTrail');
        
        let filteredEntries = entries;
        if (filter !== 'all') {
            filteredEntries = entries.filter(e => e.action_type === filter);
        }
        
        container.innerHTML = filteredEntries.map(entry => {
            const outcomeClass = entry.outcome === 'error' ? 'error' : 
                                entry.outcome === 'warning' ? 'warning' : '';
            return `
                <div class="audit-entry ${outcomeClass}">
                    <div class="audit-entry-header">
                        <span class="audit-type">${entry.action_type}</span>
                        <span class="audit-component">${entry.component}</span>
                        <span class="audit-time">${new Date(entry.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <div class="audit-entry-details">
                        ${formatAuditDetails(entry.details)}
                    </div>
                </div>
            `;
        }).join('');
    }
    
    function formatAuditDetails(details) {
        if (!details) return '';
        return Object.entries(details)
            .filter(([k, v]) => v !== null && v !== undefined)
            .map(([k, v]) => `<span class="detail-item"><strong>${k}:</strong> ${typeof v === 'object' ? JSON.stringify(v) : v}</span>`)
            .join(' ');
    }
    
    document.getElementById('exportAuditBtn').addEventListener('click', function() {
        if (!currentData || !currentData.audit_trail) return;
        
        const blob = new Blob([JSON.stringify(currentData.audit_trail, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'audit_trail.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    });
    
    document.getElementById('addCustomTagBtn').addEventListener('click', function() {
        const input = document.getElementById('customTagInput');
        const tag = input.value.trim().toLowerCase();
        
        if (tag && !customTags.includes(tag)) {
            customTags.push(tag);
            renderCustomTags();
            input.value = '';
        }
    });
    
    function renderCustomTags() {
        const container = document.getElementById('customTagsList');
        container.innerHTML = customTags.map(tag => 
            `<span class="custom-tag">${tag} <button class="remove-tag" data-tag="${tag}">&times;</button></span>`
        ).join('');
        
        container.querySelectorAll('.remove-tag').forEach(btn => {
            btn.addEventListener('click', function() {
                const tagToRemove = this.dataset.tag;
                customTags = customTags.filter(t => t !== tagToRemove);
                renderCustomTags();
            });
        });
    }
    
    document.getElementById('saveTagsBtn').addEventListener('click', async function() {
        const workflowName = selectedFile ? selectedFile.name.replace('.xml', '') : 'Unnamed';
        
        const tags = {
            category_tags: {},
            custom_tags: customTags
        };
        
        const domain = document.getElementById('tagDomain').value;
        const type = document.getElementById('tagType').value;
        const priority = document.getElementById('tagPriority').value;
        const status = document.getElementById('tagStatus').value;
        
        if (domain) tags.category_tags.domain = domain;
        if (type) tags.category_tags.type = type;
        if (priority) tags.category_tags.priority = priority;
        if (status) tags.category_tags.status = status;
        
        try {
            const response = await fetch('/api/tags/workflow', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    workflow_name: workflowName,
                    tags: tags
                })
            });
            
            const data = await response.json();
            if (data.success) {
                currentWorkflowTags = data.workflow_tags;
                alert('Tags saved successfully!');
            }
        } catch (error) {
            alert('Error saving tags: ' + error.message);
        }
    });
    
    async function renderMermaidDiagram(diagramCode) {
        const container = document.getElementById('mermaidDiagram');
        container.innerHTML = '';
        
        try {
            const id = 'mermaid-' + Date.now();
            const { svg } = await mermaid.render(id, diagramCode);
            container.innerHTML = svg;
        } catch (error) {
            container.innerHTML = `<pre>${diagramCode}</pre>`;
            console.error('Mermaid render error:', error);
        }
    }
    
    function displayStats(parsedData) {
        const statsGrid = document.getElementById('statsGrid');
        statsGrid.innerHTML = `
            <div class="stat-card sources">
                <span class="stat-number">${parsedData.sources_count}</span>
                <span class="stat-label">Sources</span>
            </div>
            <div class="stat-card targets">
                <span class="stat-number">${parsedData.targets_count}</span>
                <span class="stat-label">Targets</span>
            </div>
            <div class="stat-card transformations">
                <span class="stat-number">${parsedData.transformations_count}</span>
                <span class="stat-label">Transformations</span>
            </div>
            <div class="stat-card connectors">
                <span class="stat-number">${parsedData.connectors_count}</span>
                <span class="stat-label">Connectors</span>
            </div>
        `;
    }
    
    function displayLineage(lineage) {
        const container = document.getElementById('lineageData');
        
        if (!lineage || Object.keys(lineage).length === 0) {
            container.innerHTML = '<p>No lineage data available</p>';
            return;
        }
        
        let html = '';
        for (const [target, sources] of Object.entries(lineage)) {
            for (const source of sources) {
                html += `
                    <div class="lineage-item">
                        <span class="lineage-source">${source}</span>
                        <span class="lineage-arrow">&#8594;</span>
                        <span class="lineage-target">${target}</span>
                    </div>
                `;
            }
        }
        container.innerHTML = html;
    }
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.dataset.tab;
            
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabPanes.forEach(pane => pane.classList.remove('active'));
            
            this.classList.add('active');
            document.getElementById(tabId + 'Tab').classList.add('active');
        });
    });
    
    document.getElementById('detailedDiagram').addEventListener('change', async function() {
        if (!currentData) return;
        
        const diagramCode = this.checked ? currentData.detailed_diagram : currentData.mermaid_diagram;
        await renderMermaidDiagram(diagramCode);
    });
    
    document.getElementById('copyBtn').addEventListener('click', function() {
        const code = document.getElementById('pysparkCode').textContent;
        navigator.clipboard.writeText(code).then(() => {
            const originalText = this.textContent;
            this.textContent = 'Copied!';
            setTimeout(() => {
                this.textContent = originalText;
            }, 2000);
        });
    });
    
    document.getElementById('downloadBtn').addEventListener('click', async function() {
        const code = document.getElementById('pysparkCode').textContent;
        
        const blob = new Blob([code], { type: 'text/x-python' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'generated_pyspark.py';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    });
    
    document.getElementById('lineageSearch').addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        const items = document.querySelectorAll('.lineage-item');
        
        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            item.style.display = text.includes(searchTerm) ? 'flex' : 'none';
        });
    });
    
    document.getElementById('convertExprBtn').addEventListener('click', async function() {
        const expression = document.getElementById('expressionInput').value.trim();
        
        if (!expression) {
            alert('Please enter an expression');
            return;
        }
        
        try {
            const response = await fetch('/api/expression/convert', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ expression })
            });
            
            const data = await response.json();
            
            if (data.success) {
                document.getElementById('expressionResult').textContent = data.pyspark;
                document.getElementById('expressionOutput').style.display = 'block';
            } else {
                alert('Error: ' + data.error);
            }
        } catch (error) {
            alert('Error converting expression: ' + error.message);
        }
    });
    
    document.getElementById('showRawMarkdown')?.addEventListener('change', function() {
        const preview = document.querySelector('.docs-preview');
        const raw = document.querySelector('.docs-raw');
        if (this.checked) {
            preview.style.display = 'none';
            raw.style.display = 'block';
        } else {
            preview.style.display = 'block';
            raw.style.display = 'none';
        }
    });
    
    document.getElementById('copyDocsBtn')?.addEventListener('click', function() {
        const markdown = document.getElementById('docsMarkdown')?.textContent || '';
        navigator.clipboard.writeText(markdown);
        alert('Markdown copied to clipboard!');
    });
    
    document.getElementById('downloadDocsBtn')?.addEventListener('click', function() {
        const markdown = document.getElementById('docsMarkdown')?.textContent || '';
        const blob = new Blob([markdown], { type: 'text/markdown' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'workflow_documentation.md';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    });
    
    document.getElementById('compareDiffBtn')?.addEventListener('click', async function() {
        const oldCode = document.getElementById('diffOldCode')?.value || '';
        const newCode = currentData?.pyspark_code || '';
        
        if (!oldCode.trim()) {
            alert('Please paste previous code to compare');
            return;
        }
        
        if (!newCode) {
            alert('No current code available. Please convert an XML file first.');
            return;
        }
        
        try {
            const response = await fetch('/api/diff/compare', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    old_code: oldCode,
                    new_code: newCode
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                displayDiffResults(data.diff);
            } else {
                alert('Error: ' + data.error);
            }
        } catch (error) {
            alert('Error comparing code: ' + error.message);
        }
    });
    
    document.getElementById('clearDiffBtn')?.addEventListener('click', function() {
        document.getElementById('diffOldCode').value = '';
        document.getElementById('diffResults').style.display = 'none';
    });
    
    document.querySelectorAll('.diff-view-toggle .btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.diff-view-toggle .btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    function displayDiffResults(diff) {
        const resultsDiv = document.getElementById('diffResults');
        resultsDiv.style.display = 'block';
        
        document.getElementById('diffSummary').textContent = diff.summary || 'Comparison complete';
        
        const stats = diff.stats || { added: 0, removed: 0, modified: 0 };
        const statsHtml = `
            <div class="diff-stat added">+${stats.added} added</div>
            <div class="diff-stat removed">-${stats.removed} removed</div>
            <div class="diff-stat modified">~${stats.modified} modified</div>
        `;
        document.getElementById('diffStats').innerHTML = statsHtml;
        
        let diffHtml = '';
        if (diff.side_by_side && diff.side_by_side.length > 0) {
            diff.side_by_side.forEach(line => {
                const lineNum = line.line_new !== null ? line.line_new : (line.line_old !== null ? line.line_old : '');
                const content = line.new !== undefined && line.new !== '' ? line.new : (line.old || '');
                diffHtml += `
                    <div class="diff-line ${line.type || 'equal'}">
                        <div class="diff-line-number">${lineNum}</div>
                        <div class="diff-line-content">${escapeHtml(content)}</div>
                    </div>
                `;
            });
        } else {
            diffHtml = '<div class="diff-line"><div class="diff-line-content">No differences found</div></div>';
        }
        document.getElementById('diffContent').innerHTML = diffHtml;
    }
    
    async function loadDocumentation(parsedData, pysparkCode) {
        try {
            const response = await fetch('/api/documentation/generate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    parsed_data: parsedData,
                    pyspark_code: pysparkCode
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                document.getElementById('docsMarkdown').textContent = data.documentation;
                document.getElementById('docsPreview').innerHTML = markdownToHtml(data.documentation);
            }
        } catch (error) {
            console.error('Error loading documentation:', error);
        }
    }
    
    async function loadProfiling(parsedData) {
        try {
            const [profileResponse, comparisonResponse] = await Promise.all([
                fetch('/api/profiling/analyze', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ parsed_data: parsedData })
                }),
                fetch('/api/profiling/field-comparison', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ parsed_data: parsedData })
                })
            ]);
            
            const profileData = await profileResponse.json();
            const comparisonData = await comparisonResponse.json();
            
            if (profileData.success) {
                displayProfiling(profileData.profile);
            }
            
            if (comparisonData.success) {
                displayFieldComparison(comparisonData.comparison, comparisonData.connector_hints);
            }
        } catch (error) {
            console.error('Error loading profiling:', error);
        }
    }
    
    function displayFieldComparison(comparison, connectorHints) {
        const summary = comparison.summary;
        document.getElementById('fieldComparisonSummary').innerHTML = `
            <div class="comparison-stats">
                <div class="comparison-stat">
                    <span class="stat-value">${summary.total_source_fields}</span>
                    <span class="stat-label">Source Fields</span>
                </div>
                <div class="comparison-stat">
                    <span class="stat-value">${summary.total_target_fields}</span>
                    <span class="stat-label">Target Fields</span>
                </div>
                <div class="comparison-stat matched">
                    <span class="stat-value">${summary.matched_count}</span>
                    <span class="stat-label">Matched</span>
                </div>
                <div class="comparison-stat warning">
                    <span class="stat-value">${summary.type_mismatch_count}</span>
                    <span class="stat-label">Type Mismatches</span>
                </div>
                <div class="comparison-stat">
                    <span class="stat-value">${summary.match_percentage}%</span>
                    <span class="stat-label">Match Rate</span>
                </div>
            </div>
        `;
        
        const matched = comparison.matched_fields;
        if (matched && matched.length > 0) {
            document.getElementById('matchedFields').innerHTML = `
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Field</th>
                            <th>Source Table</th>
                            <th>Source Type</th>
                            <th>Target Table</th>
                            <th>Target Type</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${matched.slice(0, 20).map(f => `
                            <tr>
                                <td><code>${escapeHtml(f.field_name)}</code></td>
                                <td>${escapeHtml(f.source_table)}</td>
                                <td>${escapeHtml(f.source_type)}</td>
                                <td>${escapeHtml(f.target_table)}</td>
                                <td>${escapeHtml(f.target_type)}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
                ${matched.length > 20 ? `<p class="more-items">...and ${matched.length - 20} more fields</p>` : ''}
            `;
        } else {
            document.getElementById('matchedFields').innerHTML = '<p>No matched fields found</p>';
        }
        
        const mismatches = comparison.type_mismatches;
        if (mismatches && mismatches.length > 0) {
            document.getElementById('typeMismatches').innerHTML = `
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Field</th>
                            <th>Source Type</th>
                            <th>Target Type</th>
                            <th>Risk</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${mismatches.map(m => `
                            <tr class="${m.risk.toLowerCase()}-risk">
                                <td><code>${escapeHtml(m.field)}</code></td>
                                <td>${escapeHtml(m.source_type)}</td>
                                <td>${escapeHtml(m.target_type)}</td>
                                <td><span class="risk-badge ${m.risk.toLowerCase()}">${m.risk}</span></td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        } else {
            document.getElementById('typeMismatches').innerHTML = '<p>No type mismatches found</p>';
        }
        
        const sourceOnly = comparison.source_only;
        if (sourceOnly && sourceOnly.length > 0) {
            document.getElementById('sourceOnlyFields').innerHTML = sourceOnly.slice(0, 15).map(f => `
                <div class="field-item source">
                    <code>${escapeHtml(f.field_name)}</code>
                    <span class="field-type">${escapeHtml(f.datatype)}</span>
                    <span class="field-table">${escapeHtml(f.table)}</span>
                </div>
            `).join('') + (sourceOnly.length > 15 ? `<p class="more-items">...and ${sourceOnly.length - 15} more</p>` : '');
        } else {
            document.getElementById('sourceOnlyFields').innerHTML = '<p>All source fields mapped</p>';
        }
        
        const targetOnly = comparison.target_only;
        if (targetOnly && targetOnly.length > 0) {
            document.getElementById('targetOnlyFields').innerHTML = targetOnly.slice(0, 15).map(f => `
                <div class="field-item target">
                    <code>${escapeHtml(f.field_name)}</code>
                    <span class="field-type">${escapeHtml(f.datatype)}</span>
                    <span class="field-table">${escapeHtml(f.table)}</span>
                </div>
            `).join('') + (targetOnly.length > 15 ? `<p class="more-items">...and ${targetOnly.length - 15} more</p>` : '');
        } else {
            document.getElementById('targetOnlyFields').innerHTML = '<p>No derived fields</p>';
        }
        
        if (connectorHints && connectorHints.length > 0) {
            document.getElementById('connectorHints').innerHTML = connectorHints.map(h => `
                <div class="hint-item">
                    <div class="hint-category">${escapeHtml(h.category)}</div>
                    <div class="hint-text">${escapeHtml(h.hint)}</div>
                    <pre class="hint-code">${escapeHtml(h.code_snippet)}</pre>
                </div>
            `).join('');
        } else {
            document.getElementById('connectorHints').innerHTML = '<p>No connector-based optimizations</p>';
        }
    }
    
    function displayProfiling(profile) {
        const summary = profile.summary;
        document.getElementById('profilingSummary').innerHTML = `
            <div class="profiling-stat">
                <div class="profiling-stat-value">${summary.source_tables}</div>
                <div class="profiling-stat-label">Source Tables</div>
            </div>
            <div class="profiling-stat">
                <div class="profiling-stat-value">${summary.target_tables}</div>
                <div class="profiling-stat-label">Target Tables</div>
            </div>
            <div class="profiling-stat">
                <div class="profiling-stat-value">${summary.total_transformations}</div>
                <div class="profiling-stat-label">Transformations</div>
            </div>
            <div class="profiling-stat">
                <div class="profiling-stat-value">${summary.source_field_count}</div>
                <div class="profiling-stat-label">Source Fields</div>
            </div>
            <div class="profiling-stat">
                <div class="profiling-stat-value">${summary.target_field_count}</div>
                <div class="profiling-stat-label">Target Fields</div>
            </div>
        `;
        
        const complexity = summary.complexity_score;
        const percent = Math.min(complexity.score * 5, 100);
        document.getElementById('complexityScore').innerHTML = `
            <div class="complexity-meter">
                <div class="complexity-fill" style="width: ${percent}%; background: ${complexity.color}"></div>
            </div>
            <div class="complexity-label" style="background: ${complexity.color}20; color: ${complexity.color}">
                ${complexity.level} (${complexity.score})
            </div>
        `;
        
        const typeDist = profile.type_distribution;
        let typeHtml = '';
        for (const [type, count] of Object.entries(typeDist.counts)) {
            typeHtml += `
                <div class="type-bar">
                    <div class="type-bar-label">${type}</div>
                    <div class="type-bar-value">${count}</div>
                    <div class="type-bar-percent">${typeDist.percentages[type]}%</div>
                </div>
            `;
        }
        document.getElementById('typeDistribution').innerHTML = typeHtml || '<p>No type data available</p>';
        
        const partitions = profile.partition_suggestions;
        if (partitions && partitions.length > 0) {
            document.getElementById('partitionSuggestions').innerHTML = partitions.map(p => `
                <div class="partition-item ${p.priority.toLowerCase()}">
                    <div class="partition-field">
                        ${escapeHtml(p.field)} 
                        <span class="priority-badge ${p.priority.toLowerCase()}">${p.priority}</span>
                    </div>
                    <div class="partition-reasons">
                        Table: ${escapeHtml(p.table)} | Type: ${escapeHtml(p.type)}
                        <ul>${p.reasons.map(r => `<li>${escapeHtml(r)}</li>`).join('')}</ul>
                    </div>
                </div>
            `).join('');
        } else {
            document.getElementById('partitionSuggestions').innerHTML = '<p>No partition suggestions available</p>';
        }
        
        const hints = profile.optimization_hints;
        if (hints && hints.length > 0) {
            document.getElementById('optimizationHints').innerHTML = hints.map(h => `
                <div class="hint-item ${h.priority.toLowerCase()}">
                    <div class="hint-category">
                        ${escapeHtml(h.category)}
                        <span class="priority-badge ${h.priority.toLowerCase()}">${h.priority}</span>
                    </div>
                    <div class="hint-text">${escapeHtml(h.hint)}</div>
                    <pre class="hint-code">${escapeHtml(h.code_snippet)}</pre>
                </div>
            `).join('');
        } else {
            document.getElementById('optimizationHints').innerHTML = '<p>No optimization hints available</p>';
        }
        
        const recommendations = profile.schema_recommendations;
        if (recommendations && recommendations.length > 0) {
            document.getElementById('schemaRecommendations').innerHTML = recommendations.map(r => `
                <div class="recommendation-item">
                    <div class="recommendation-type">${escapeHtml(r.type)}</div>
                    <div class="recommendation-text">${escapeHtml(r.recommendation)}</div>
                    <div class="recommendation-text"><strong>Impact:</strong> ${escapeHtml(r.impact)}</div>
                </div>
            `).join('');
        } else {
            document.getElementById('schemaRecommendations').innerHTML = '<p>No schema recommendations</p>';
        }
        
        const checks = profile.data_quality_checks;
        if (checks && checks.length > 0) {
            document.getElementById('qualityChecks').innerHTML = checks.slice(0, 10).map(c => `
                <div class="quality-check-item">
                    <div>
                        <span class="quality-field">${escapeHtml(c.field)}</span>
                        <span class="quality-type">${escapeHtml(c.check)}</span>
                    </div>
                    <div class="quality-description">${escapeHtml(c.description)}</div>
                    <pre class="quality-code">${escapeHtml(c.code)}</pre>
                </div>
            `).join('');
        } else {
            document.getElementById('qualityChecks').innerHTML = '<p>No quality checks available</p>';
        }
    }
    
    function markdownToHtml(markdown) {
        let html = markdown;
        
        html = html.replace(/^### (.*$)/gm, '<h3>$1</h3>');
        html = html.replace(/^## (.*$)/gm, '<h2>$1</h2>');
        html = html.replace(/^# (.*$)/gm, '<h1>$1</h1>');
        
        html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
        
        html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
        
        html = html.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
        
        html = html.replace(/^\> (.*$)/gm, '<blockquote>$1</blockquote>');
        
        html = html.replace(/^---$/gm, '<hr>');
        
        html = html.replace(/\n\n/g, '</p><p>');
        
        const lines = html.split('\n');
        let inTable = false;
        let tableHtml = '';
        let result = [];
        
        for (let line of lines) {
            if (line.startsWith('|')) {
                if (!inTable) {
                    inTable = true;
                    tableHtml = '<table>';
                }
                if (line.includes('---')) continue;
                
                const cells = line.split('|').filter(c => c.trim());
                const tag = tableHtml.includes('<tr>') ? 'td' : 'th';
                tableHtml += '<tr>' + cells.map(c => `<${tag}>${c.trim()}</${tag}>`).join('') + '</tr>';
            } else {
                if (inTable) {
                    tableHtml += '</table>';
                    result.push(tableHtml);
                    inTable = false;
                    tableHtml = '';
                }
                result.push(line);
            }
        }
        if (inTable) {
            tableHtml += '</table>';
            result.push(tableHtml);
        }
        
        return result.join('\n');
    }
});
