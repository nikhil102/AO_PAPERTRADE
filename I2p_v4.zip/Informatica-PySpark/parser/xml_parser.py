from lxml import etree
import json


def parse_xml(file_path):
    """Parse Informatica XML file and return root element."""
    tree = etree.parse(file_path)
    return tree.getroot()


def parse_xml_string(xml_content):
    """Parse Informatica XML string and return root element."""
    root = etree.fromstring(xml_content.encode('utf-8'))
    return root


def extract_sources(root):
    """Extract SOURCE elements from XML."""
    sources = []
    for source in root.findall(".//SOURCE"):
        source_data = {
            "name": source.attrib.get("NAME", ""),
            "db": source.attrib.get("DBDNAME", ""),
            "database_type": source.attrib.get("DATABASETYPE", ""),
            "owner": source.attrib.get("OWNERNAME", ""),
            "fields": []
        }
        for field in source.findall("SOURCEFIELD"):
            source_data["fields"].append({
                "name": field.attrib.get("NAME", ""),
                "datatype": field.attrib.get("DATATYPE", ""),
                "precision": field.attrib.get("PRECISION", ""),
                "scale": field.attrib.get("SCALE", ""),
                "nullable": field.attrib.get("NULLABLE", "")
            })
        sources.append(source_data)
    return sources


def extract_targets(root):
    """Extract TARGET elements from XML."""
    targets = []
    for target in root.findall(".//TARGET"):
        target_data = {
            "name": target.attrib.get("NAME", ""),
            "db": target.attrib.get("DBDNAME", ""),
            "database_type": target.attrib.get("DATABASETYPE", ""),
            "owner": target.attrib.get("OWNERNAME", ""),
            "fields": []
        }
        for field in target.findall("TARGETFIELD"):
            target_data["fields"].append({
                "name": field.attrib.get("NAME", ""),
                "datatype": field.attrib.get("DATATYPE", ""),
                "precision": field.attrib.get("PRECISION", ""),
                "scale": field.attrib.get("SCALE", ""),
                "nullable": field.attrib.get("NULLABLE", "")
            })
        targets.append(target_data)
    return targets


def extract_transformations(root):
    """Extract TRANSFORMATION elements from XML."""
    transformations = {}
    for transformation in root.findall(".//TRANSFORMATION"):
        name = transformation.attrib.get("NAME", "")
        trans_type = transformation.attrib.get("TYPE", "")
        description = transformation.attrib.get("DESCRIPTION", "")
        
        fields = []
        for tf in transformation.findall("TRANSFORMFIELD"):
            field = {
                "name": tf.attrib.get("NAME", ""),
                "port_type": tf.attrib.get("PORTTYPE", ""),
                "datatype": tf.attrib.get("DATATYPE", ""),
                "expression": tf.attrib.get("EXPRESSION", ""),
                "precision": tf.attrib.get("PRECISION", ""),
                "scale": tf.attrib.get("SCALE", ""),
                "default_value": tf.attrib.get("DEFAULTVALUE", "")
            }
            fields.append(field)
        
        table_attrs = {}
        for attr in transformation.findall("TABLEATTRIBUTE"):
            attr_name = attr.attrib.get("NAME", "")
            attr_value = attr.attrib.get("VALUE", "")
            table_attrs[attr_name] = attr_value
        
        transformations[name] = {
            "type": trans_type,
            "description": description,
            "fields": fields,
            "table_attributes": table_attrs
        }
    
    return transformations


def extract_connectors(root):
    """Extract CONNECTOR elements from XML."""
    connectors = []
    for conn in root.findall(".//CONNECTOR"):
        connectors.append({
            "from_instance": conn.attrib.get("FROMINSTANCE", ""),
            "from_field": conn.attrib.get("FROMFIELD", ""),
            "to_instance": conn.attrib.get("TOINSTANCE", ""),
            "to_field": conn.attrib.get("TOFIELD", ""),
            "from_instance_type": conn.attrib.get("FROMINSTANCETYPE", ""),
            "to_instance_type": conn.attrib.get("TOINSTANCETYPE", "")
        })
    return connectors


def extract_instances(root):
    """Extract INSTANCE elements from XML."""
    instances = []
    for instance in root.findall(".//INSTANCE"):
        instances.append({
            "name": instance.attrib.get("NAME", ""),
            "type": instance.attrib.get("TYPE", ""),
            "transformation_name": instance.attrib.get("TRANSFORMATION_NAME", ""),
            "transformation_type": instance.attrib.get("TRANSFORMATION_TYPE", "")
        })
    return instances


def extract_mappings(root):
    """Extract MAPPING elements from XML."""
    mappings = []
    for mapping in root.findall(".//MAPPING"):
        mapping_data = {
            "name": mapping.attrib.get("NAME", ""),
            "description": mapping.attrib.get("DESCRIPTION", ""),
            "is_valid": mapping.attrib.get("ISVALID", "")
        }
        mappings.append(mapping_data)
    return mappings


def extract_workflows(root):
    """Extract WORKFLOW elements from XML."""
    workflows = []
    for workflow in root.findall(".//WORKFLOW"):
        workflow_data = {
            "name": workflow.attrib.get("NAME", ""),
            "description": workflow.attrib.get("DESCRIPTION", ""),
            "is_valid": workflow.attrib.get("ISVALID", ""),
            "sessions": []
        }
        for session in workflow.findall(".//SESSION"):
            workflow_data["sessions"].append({
                "name": session.attrib.get("NAME", ""),
                "mapping_name": session.attrib.get("MAPPINGNAME", "")
            })
        workflows.append(workflow_data)
    return workflows


def extract_sql_info(root, transformations):
    """Extract all SQL-related information from XML."""
    sql_info = {
        "tables": [],
        "select_queries": [],
        "stored_procedures": [],
        "lookup_queries": [],
        "pre_sql": [],
        "post_sql": [],
        "filter_conditions": []
    }
    
    for source in root.findall(".//SOURCE"):
        table_name = source.attrib.get("NAME", "")
        owner = source.attrib.get("OWNERNAME", "")
        db = source.attrib.get("DBDNAME", "")
        db_type = source.attrib.get("DATABASETYPE", "")
        if table_name:
            sql_info["tables"].append({
                "name": table_name,
                "type": "SOURCE",
                "owner": owner,
                "database": db,
                "database_type": db_type
            })
    
    for target in root.findall(".//TARGET"):
        table_name = target.attrib.get("NAME", "")
        owner = target.attrib.get("OWNERNAME", "")
        db = target.attrib.get("DBDNAME", "")
        db_type = target.attrib.get("DATABASETYPE", "")
        if table_name:
            sql_info["tables"].append({
                "name": table_name,
                "type": "TARGET",
                "owner": owner,
                "database": db,
                "database_type": db_type
            })
    
    for trans_name, trans_data in transformations.items():
        table_attrs = trans_data.get("table_attributes", {})
        trans_type = trans_data.get("type", "")
        
        sql_query = table_attrs.get("Sql Query", "")
        if sql_query:
            sql_info["select_queries"].append({
                "transformation": trans_name,
                "type": trans_type,
                "query": sql_query.replace("&#xD;&#xA;", "\n").replace("&apos;", "'")
            })
        
        lookup_sql = table_attrs.get("Lookup Sql Override", "")
        if lookup_sql:
            sql_info["lookup_queries"].append({
                "transformation": trans_name,
                "type": trans_type,
                "query": lookup_sql.replace("&#xD;&#xA;", "\n").replace("&apos;", "'")
            })
        
        lookup_table = table_attrs.get("Lookup table name", "")
        if lookup_table:
            sql_info["tables"].append({
                "name": lookup_table,
                "type": "LOOKUP",
                "owner": "",
                "database": "",
                "database_type": ""
            })
        
        if trans_type == "Stored Procedure":
            sp_name = table_attrs.get("Stored Procedure Name", trans_name)
            sp_type = table_attrs.get("Stored Procedure Type", "Normal")
            call_text = table_attrs.get("Call Text", "")
            sql_info["stored_procedures"].append({
                "name": sp_name,
                "transformation": trans_name,
                "procedure_type": sp_type,
                "call_text": call_text
            })
        
        pre_sql = table_attrs.get("Pre SQL", "")
        if pre_sql:
            sql_info["pre_sql"].append({
                "transformation": trans_name,
                "sql": pre_sql.replace("&#xD;&#xA;", "\n").replace("&apos;", "'")
            })
        
        post_sql = table_attrs.get("Post SQL", "")
        if post_sql:
            sql_info["post_sql"].append({
                "transformation": trans_name,
                "sql": post_sql.replace("&#xD;&#xA;", "\n").replace("&apos;", "'")
            })
        
        filter_cond = table_attrs.get("Filter Condition", "")
        if filter_cond and filter_cond != "TRUE":
            sql_info["filter_conditions"].append({
                "transformation": trans_name,
                "condition": filter_cond
            })
    
    return sql_info


def parse_full_mapping(xml_content):
    """Parse full Informatica XML and return structured data."""
    if isinstance(xml_content, bytes):
        root = etree.fromstring(xml_content)
    else:
        root = etree.fromstring(xml_content.encode('utf-8'))
    
    transformations = extract_transformations(root)
    sql_info = extract_sql_info(root, transformations)
    
    return {
        "sources": extract_sources(root),
        "targets": extract_targets(root),
        "transformations": transformations,
        "connectors": extract_connectors(root),
        "instances": extract_instances(root),
        "mappings": extract_mappings(root),
        "workflows": extract_workflows(root),
        "sql_info": sql_info
    }
