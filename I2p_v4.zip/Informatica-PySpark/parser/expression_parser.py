import re


class ExpressionParser:
    """
    Converts Informatica-style expressions to PySpark expressions.
    Handles: IIF, DECODE, ISNULL, NVL, TO_DATE, TO_CHAR, UPPER, LOWER, LTRIM, RTRIM, CONCAT, etc.
    """
    
    FUNCTION_MAPPINGS = {
        'UPPER': 'F.upper',
        'LOWER': 'F.lower',
        'LTRIM': 'F.ltrim',
        'RTRIM': 'F.rtrim',
        'TRIM': 'F.trim',
        'LENGTH': 'F.length',
        'SUBSTR': 'F.substring',
        'SUBSTRING': 'F.substring',
        'CONCAT': 'F.concat',
        'LPAD': 'F.lpad',
        'RPAD': 'F.rpad',
        'REPLACE': 'F.regexp_replace',
        'ABS': 'F.abs',
        'ROUND': 'F.round',
        'TRUNC': 'F.trunc',
        'FLOOR': 'F.floor',
        'CEIL': 'F.ceil',
        'MOD': 'F.expr("MOD")',
        'POWER': 'F.pow',
        'SQRT': 'F.sqrt',
        'SYSDATE': 'F.current_date()',
        'SYSTIMESTAMP': 'F.current_timestamp()',
        'ADD_TO_DATE': 'F.date_add',
        'DATE_DIFF': 'F.datediff',
        'GET_DATE_PART': 'F.date_format',
        'COALESCE': 'F.coalesce',
    }
    
    COMPARISON_OPERATORS = {
        '=': '==',
        '<>': '!=',
        '!=': '!=',
        '>=': '>=',
        '<=': '<=',
        '>': '>',
        '<': '<',
    }
    
    LOGICAL_OPERATORS = {
        'AND': '&',
        'OR': '|',
        'NOT': '~',
    }
    
    def __init__(self):
        self.column_references = set()
    
    def parse(self, expression):
        """Main entry point - converts Informatica expression to PySpark."""
        if not expression or expression.strip() == '':
            return None
        
        expr = expression.strip()
        self.column_references = set()
        
        try:
            result = self._convert_expression(expr)
            return result
        except Exception as e:
            return f"# TODO: Manual conversion needed for: {expr}\n# Error: {str(e)}"
    
    def _convert_expression(self, expr):
        """Recursively convert expression."""
        expr = expr.strip()
        
        if self._is_iif(expr):
            return self._convert_iif(expr)
        
        if self._is_decode(expr):
            return self._convert_decode(expr)
        
        if self._is_isnull(expr):
            return self._convert_isnull(expr)
        
        if self._is_nvl(expr):
            return self._convert_nvl(expr)
        
        if self._is_to_date(expr):
            return self._convert_to_date(expr)
        
        if self._is_to_char(expr):
            return self._convert_to_char(expr)
        
        for func_name, pyspark_func in self.FUNCTION_MAPPINGS.items():
            if expr.upper().startswith(func_name + '('):
                return self._convert_simple_function(expr, func_name, pyspark_func)
        
        return self._convert_simple_expression(expr)
    
    def _is_iif(self, expr):
        return expr.upper().startswith('IIF(')
    
    def _is_decode(self, expr):
        return expr.upper().startswith('DECODE(')
    
    def _is_isnull(self, expr):
        return expr.upper().startswith('ISNULL(')
    
    def _is_nvl(self, expr):
        return expr.upper().startswith('NVL(')
    
    def _is_to_date(self, expr):
        return expr.upper().startswith('TO_DATE(')
    
    def _is_to_char(self, expr):
        return expr.upper().startswith('TO_CHAR(')
    
    def _convert_iif(self, expr):
        """Convert IIF(condition, true_val, false_val) to F.when().otherwise()"""
        content = self._extract_function_content(expr, 'IIF')
        args = self._split_args(content)
        
        if len(args) >= 3:
            condition = self._convert_condition(args[0])
            true_val = self._convert_expression(args[1])
            false_val = self._convert_expression(args[2])
            return f"F.when({condition}, {true_val}).otherwise({false_val})"
        
        return f"# TODO: Invalid IIF: {expr}"
    
    def _convert_decode(self, expr):
        """Convert DECODE(expr, val1, result1, ..., default) to chained F.when()"""
        content = self._extract_function_content(expr, 'DECODE')
        args = self._split_args(content)
        
        if len(args) < 3:
            return f"# TODO: Invalid DECODE: {expr}"
        
        source_col = self._convert_to_column(args[0])
        pairs = args[1:]
        
        result = ""
        for i in range(0, len(pairs) - 1, 2):
            if i + 1 < len(pairs):
                compare_val = self._convert_expression(pairs[i])
                result_val = self._convert_expression(pairs[i + 1])
                if result == "":
                    result = f"F.when({source_col} == {compare_val}, {result_val})"
                else:
                    result += f".when({source_col} == {compare_val}, {result_val})"
        
        if len(pairs) % 2 == 1:
            default_val = self._convert_expression(pairs[-1])
            result += f".otherwise({default_val})"
        else:
            result += ".otherwise(F.lit(None))"
        
        return result
    
    def _convert_isnull(self, expr):
        """Convert ISNULL(col) to col.isNull()"""
        content = self._extract_function_content(expr, 'ISNULL')
        col = self._convert_to_column(content)
        return f"{col}.isNull()"
    
    def _convert_nvl(self, expr):
        """Convert NVL(col, default) to F.coalesce()"""
        content = self._extract_function_content(expr, 'NVL')
        args = self._split_args(content)
        
        if len(args) >= 2:
            col = self._convert_expression(args[0])
            default = self._convert_expression(args[1])
            return f"F.coalesce({col}, {default})"
        
        return f"# TODO: Invalid NVL: {expr}"
    
    def _convert_to_date(self, expr):
        """Convert TO_DATE(col, format) to F.to_date()"""
        content = self._extract_function_content(expr, 'TO_DATE')
        args = self._split_args(content)
        
        if len(args) >= 1:
            col = self._convert_expression(args[0])
            if len(args) >= 2:
                fmt = self._convert_date_format(args[1])
                return f"F.to_date({col}, {fmt})"
            return f"F.to_date({col})"
        
        return f"# TODO: Invalid TO_DATE: {expr}"
    
    def _convert_to_char(self, expr):
        """Convert TO_CHAR(col, format) to F.date_format()"""
        content = self._extract_function_content(expr, 'TO_CHAR')
        args = self._split_args(content)
        
        if len(args) >= 1:
            col = self._convert_expression(args[0])
            if len(args) >= 2:
                fmt = self._convert_date_format(args[1])
                return f"F.date_format({col}, {fmt})"
            return f"F.cast({col}, 'string')"
        
        return f"# TODO: Invalid TO_CHAR: {expr}"
    
    def _convert_simple_function(self, expr, func_name, pyspark_func):
        """Convert simple function calls."""
        content = self._extract_function_content(expr, func_name)
        args = self._split_args(content)
        converted_args = [self._convert_expression(arg) for arg in args]
        
        if '()' in pyspark_func:
            return pyspark_func
        
        return f"{pyspark_func}({', '.join(converted_args)})"
    
    def _convert_condition(self, condition):
        """Convert condition expression."""
        cond = condition.strip()
        
        for op, pyspark_op in self.COMPARISON_OPERATORS.items():
            if op in cond:
                parts = cond.split(op, 1)
                if len(parts) == 2:
                    left = self._convert_expression(parts[0].strip())
                    right = self._convert_expression(parts[1].strip())
                    return f"({left} {pyspark_op} {right})"
        
        if self._is_isnull(cond):
            return self._convert_isnull(cond)
        
        return self._convert_expression(cond)
    
    def _convert_simple_expression(self, expr):
        """Convert simple expressions (columns, literals, etc.)."""
        expr = expr.strip()
        
        if expr.startswith("'") and expr.endswith("'"):
            return f"F.lit({expr})"
        
        if expr.startswith('"') and expr.endswith('"'):
            return f"F.lit({expr})"
        
        if re.match(r'^-?\d+\.?\d*$', expr):
            return f"F.lit({expr})"
        
        if expr.upper() == 'NULL':
            return 'F.lit(None)'
        
        if expr.upper() == 'TRUE':
            return 'F.lit(True)'
        
        if expr.upper() == 'FALSE':
            return 'F.lit(False)'
        
        if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', expr):
            self.column_references.add(expr)
            return f'F.col("{expr}")'
        
        return f'F.expr("{expr}")'
    
    def _convert_to_column(self, expr):
        """Convert expression to column reference."""
        expr = expr.strip()
        if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', expr):
            self.column_references.add(expr)
            return f'F.col("{expr}")'
        return self._convert_expression(expr)
    
    def _convert_date_format(self, fmt):
        """Convert Informatica date format to Spark format."""
        fmt = fmt.strip().strip("'\"")
        spark_fmt = fmt
        spark_fmt = spark_fmt.replace('YYYY', 'yyyy')
        spark_fmt = spark_fmt.replace('MM', 'MM')
        spark_fmt = spark_fmt.replace('DD', 'dd')
        spark_fmt = spark_fmt.replace('HH24', 'HH')
        spark_fmt = spark_fmt.replace('MI', 'mm')
        spark_fmt = spark_fmt.replace('SS', 'ss')
        return f'"{spark_fmt}"'
    
    def _extract_function_content(self, expr, func_name):
        """Extract content between function parentheses."""
        start = len(func_name) + 1
        depth = 1
        end = start
        
        while end < len(expr) and depth > 0:
            if expr[end] == '(':
                depth += 1
            elif expr[end] == ')':
                depth -= 1
            end += 1
        
        return expr[start:end - 1] if end > start else ""
    
    def _split_args(self, content):
        """Split function arguments respecting nested parentheses and quotes."""
        args = []
        current = ""
        depth = 0
        in_string = False
        string_char = None
        
        for char in content:
            if char in ("'", '"') and not in_string:
                in_string = True
                string_char = char
                current += char
            elif char == string_char and in_string:
                in_string = False
                string_char = None
                current += char
            elif char == '(' and not in_string:
                depth += 1
                current += char
            elif char == ')' and not in_string:
                depth -= 1
                current += char
            elif char == ',' and depth == 0 and not in_string:
                args.append(current.strip())
                current = ""
            else:
                current += char
        
        if current.strip():
            args.append(current.strip())
        
        return args


def parse_expression(expr):
    """Convenience function to parse a single expression."""
    parser = ExpressionParser()
    return parser.parse(expr)
