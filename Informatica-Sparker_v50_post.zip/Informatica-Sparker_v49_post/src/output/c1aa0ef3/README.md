# m_landing_party_delta - PySpark Conversion

This code was auto-generated from Informatica PowerCenter XML by the Informatica to PySpark Converter.

## 1. Environment Variables Setup

### PowerShell
```powershell
# Required environment variables (MSSQL for both source and target)
$env:MSSQL_HOST='your_server.com\INSTANCE'
$env:MSSQL_USER='spark_user'
$env:MSSQL_PASSWORD='your_mssql_password'
$env:MSSQL_DRIVER_JAR='C:/Drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
$env:SRC_SYSTEM_NM='SSC'
$env:ENV_NAME='development'
$env:LOG_LEVEL='INFO'
```

### Bash/Linux
```bash
# Required environment variables (MSSQL for both source and target)
export MSSQL_HOST='your_server.com\INSTANCE'
export MSSQL_USER='spark_user'
export MSSQL_PASSWORD='your_mssql_password'
export MSSQL_DRIVER_JAR='/opt/drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
export SRC_SYSTEM_NM='SSC'
export ENV_NAME='development'
export LOG_LEVEL='INFO'
```

## 2. Target Table Schema

### Target: C_LDG_PARTY (Database: msscdm_dev3)

```sql
-- MSSQL CREATE TABLE syntax
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[C_LDG_PARTY]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[C_LDG_PARTY] (
        [SRC_ROWID] BIGINT IDENTITY(1,1) NOT NULL,
        [SOURCE_PARTY_ID] NVARCHAR(255) NULL,
        [PARTY_TYPE_ID] BIGINT NULL,
        [PARTY_TAX_ID] NVARCHAR(50) NULL,
        [PARTY_STATUS_ID] BIGINT NULL,
        [PARTY_INACTIVATION_DATE] NVARCHAR(27) NULL,
        [ORG_LEGAL_NAME] NVARCHAR(255) NULL,
        [ORG_NAME] NVARCHAR(255) NULL,
        [ORG_BUSINESS_STRUCTURE_TYPE_ID] BIGINT NULL,
        [PERSON_FIRST_NAME] NVARCHAR(50) NULL,
        [PERSON_MIDDLE_NAME] NVARCHAR(50) NULL,
        [PERSON_LAST_NAME] NVARCHAR(50) NULL,
        [PERSON_HONORIFIC_ID] BIGINT NULL,
        [PERSON_NAME_SUFFIX_ID] BIGINT NULL,
        [PERSON_NAME_SUFFIX_RAW] NVARCHAR(50) NULL,
        [PERSON_NICKNAME] NVARCHAR(50) NULL,
        [PERSON_GENDER_ID] BIGINT NULL,
        [PERSON_PFSNL_CRDNTLS_TXT] NVARCHAR(200) NULL,
        [OFFICE_TYPE_ID] BIGINT NULL,
        [GROUP_NAME] NVARCHAR(100) NULL,
        [GROUP_NICKNAME] NVARCHAR(100) NULL,
        [SOURCE_SYSTEM] NVARCHAR(50) NULL,
        [CREATED_DATE] NVARCHAR(27) NULL,
        [CREATED_BY] NVARCHAR(50) NULL,
        [LAST_UPDATED_BY] NVARCHAR(50) NULL,
        [LAST_UPDATED_DATE] NVARCHAR(27) NULL,
        [DELETED_INDICATOR] NCHAR(1) NULL,
        [PARTY_INCTVTN_RSN_TYPE_ID] BIGINT NULL,
        [DEFERRED_OWNERSHIP_IND] NCHAR(1) NOT NULL,
        [PRSN_MIDDLE_INITIAL] NCHAR(1) NULL,
        [person_marital_status_id] BIGINT NULL,
        [person_birth_date] DATETIME2 NULL,
        [person_deceased_date] DATETIME2 NULL,
        [person_citizen_type_ID] BIGINT NULL,
        [PERSON_DISABLED_DATE] DATETIME2 NULL,
        [TIN_TYPE_ID] BIGINT NULL,
        [RIA_COVERAGE_TYPE_ID] BIGINT NULL,
        [MATCHED_ROWID_OBJECT] NCHAR(14) NULL,
        [PARTY_QUALIFICATION_LVL_ID] NCHAR(14) NULL,
        [SURV_ASST_CODE_C] NVARCHAR(3) NULL,
        [PRSN_JOB_TITLE] NVARCHAR(255) NULL,
        [CLNT_GRP_ID] NCHAR(14) NULL,
        [OFF_CORRESPONDENT_FIRM] NVARCHAR(40) NULL,
        [PRSN_NAME_ON_ACCOUNT] NVARCHAR(50) NULL,
        [GRP_FIRST_NAME] NVARCHAR(35) NULL,
        [GRP_LAST_NAME] NVARCHAR(35) NULL
    )
END
```

## 3. What is $$SRC_SYSTEM_NM?

`$$SRC_SYSTEM_NM` is an Informatica runtime parameter used in mapping/workflow sessions.

**How to find the value:**
1. Open Workflow Manager
2. Open the workflow
3. In the Session task -> Properties / Config Object, check the Parameter File path
4. Open that `.par` file and search for `SRC_SYSTEM_NM`

In this config, the default is set to `SSC`. Override via environment variable if needed:
```powershell
$env:SRC_SYSTEM_NM='YOUR_VALUE'
```

## 4. How to Run

### Quick Run (config in same folder)
```bash
python m_landing_party_delta.py
```

### With custom config path
```powershell
$env:CONFIG_PATH='C:\path\to\config_m_landing_party_delta.yml'
python m_landing_party_delta.py
```

## 5. Files Generated

- `m_landing_party_delta.py` - Main PySpark mapping code
- `config_m_landing_party_delta.yml` - Configuration file with environment variables
- `README.md` - This documentation file

## 6. Notes

- Passwords with special characters (like `$`, `@`, `*`) must use single quotes in PowerShell
- The `SRC_ROWID` column is typically set as IDENTITY in MSSQL if not mapped from source
- Target database is fixed as msscdm_dev3
- Review and test the generated code before production use
