import os
import re
import json

WORKSPACE_DIR = os.path.dirname(os.path.abspath(__file__))
JSON_DIR = os.path.join(WORKSPACE_DIR, 'output', 'json')
DAGS_DIR = os.path.join(WORKSPACE_DIR, 'output', 'dags')

os.makedirs(DAGS_DIR, exist_ok=True)

def parse_cmd_arguments(cmd):
    """
    Parses AutoSys command arguments to map to Databricks job run parameters.
    Example: bl -g runetl $cdm_script $BATCH_USER_NAME $BATCH_PASSWORD empower_plan_sponsor_address $MSSCDM_CTL/today_plan_sponsor.ctl
    Returns: ['empower_plan_sponsor_address', '/dbfs/ctl/today_plan_sponsor.ctl']
    """
    if not cmd:
        return []
        
    # Standard prefix to strip
    prefix_pattern = r'^.*?runetl\s+\$cdm_script\s+\$BATCH_USER_NAME\s+\$BATCH_PASSWORD\s+'
    cleaned_cmd = re.sub(prefix_pattern, '', cmd)
    
    # If the regex didn't match (different command structure), let's fall back to split
    if cleaned_cmd == cmd:
        words = cmd.split()
        # Find if runetl is in the words, take everything after it
        try:
            idx = words.index('runetl')
            # Skip runetl and next 3 wrapper params if they look like variables
            skip = 1
            if idx + 4 < len(words) and words[idx+1].startswith('$'):
                skip = 4
            return words[idx+skip:]
        except ValueError:
            pass
            
        if len(words) > 4:
            return words[4:]
        return words
        
    args = cleaned_cmd.split()
    
    # Translate env path vars to DBFS standard mounts
    translated_args = []
    for arg in args:
        if '$MSSCDM_CTL/' in arg:
            arg = arg.replace('$MSSCDM_CTL/', '/dbfs/ctl/')
        translated_args.append(arg)
        
    return translated_args

def get_dag_for_job(job_name, registry):
    """
    Determines which DAG (box) a job belongs to.
    """
    if job_name in registry:
        job = registry[job_name]
        if job["box_name"]:
            return job["box_name"]
        elif job["job_type"] == "BOX":
            return job["job_name"]
        else:
            src = job["source_file"]
            base = os.path.splitext(src)[0]
            return f"dag_{base}"
            
    # Fallback: if not in registry, check if it fits other box patterns
    # or just assume it is in its own box
    return job_name

def generate_dag_code(dag_id, jobs_in_dag, registry):
    """
    Generates the Python code for a single Airflow DAG containing its respective jobs and dependencies.
    """
    code = f'''"""
Airflow DAG generated from AutoSys Box/Job: {dag_id}
Generated dynamically by AutoSys-to-Airflow Converter.
"""
from airflow import DAG
from airflow.providers.databricks.operators.databricks import DatabricksSubmitRunOperator
from airflow.sensors.external_task import ExternalTaskSensor
from datetime import datetime, timedelta
from airflow.operators.empty import EmptyOperator

default_args = {{
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}}

with DAG(
    dag_id='{dag_id}',
    default_args=default_args,
    description='Airflow DAG for {dag_id}',
    schedule_interval=None,  # Triggered manually or by external schedules
    start_date=datetime(2026, 1, 1),
    catchup=False,
) as dag:

    # Start and End Dummy Nodes
    start_task = EmptyOperator(task_id='start')
    end_task = EmptyOperator(task_id='end')

'''
    
    created_tasks = {}  # job_name -> task_var_name
    external_sensors = {}  # (ext_dag, ext_job) -> sensor_var_name
    
    # 1. Create task nodes
    for job in jobs_in_dag:
        job_name = job["job_name"]
        job_type = job["job_type"]
        var_name = job_name.replace('-', '_').replace('.', '_')
        
        if job_type == "BOX":
            code += f"    # AutoSys BOX: {job_name}\n"
            code += f"    {var_name} = EmptyOperator(\n"
            code += f"        task_id='{job_name}',\n"
            code += f"    )\n\n"
            created_tasks[job_name] = var_name
        else:
            cmd = job["command"] or ""
            args = parse_cmd_arguments(cmd)
            args_str = ", ".join([f"'{a}'" for a in args])
            
            code += f"    # AutoSys CMD Job: {job_name}\n"
            code += f"    # AutoSys command: {cmd}\n"
            code += f"    {var_name} = DatabricksSubmitRunOperator(\n"
            code += f"        task_id='{job_name}',\n"
            code += f"        json={{\n"
            code += f"            'run_name': '{job_name}',\n"
            code += f"            'spark_jar_task': {{\n"
            code += f"                'main_class_name': 'com.databricks.RunEtl',\n"
            code += f"                'parameters': [{args_str}]\n"
            code += f"            }}\n"
            code += f"        }},\n"
            code += f"        databricks_conn_id='databricks_default',\n"
            code += f"    )\n\n"
            created_tasks[job_name] = var_name

    # 2. Add dependencies
    dependency_statements = []
    
    for job in jobs_in_dag:
        job_name = job["job_name"]
        var_name = created_tasks[job_name]
        
        # If no dependencies, run after start
        if not job["dependencies"]:
            dependency_statements.append(f"    start_task >> {var_name}")
            
        for dep in job["dependencies"]:
            dep_dag = get_dag_for_job(dep, registry)
            
            if dep_dag == dag_id:
                # Same DAG dependency
                if dep in created_tasks:
                    dep_var = created_tasks[dep]
                    dependency_statements.append(f"    {dep_var} >> {var_name}")
                else:
                    # Dependency job is in the same box but not in our JIL file list
                    # We create a placeholder Empty task
                    dep_var = dep.replace('-', '_').replace('.', '_')
                    code += f"    # Placeholder for unparsed job {dep} in the same box\n"
                    code += f"    {dep_var} = EmptyOperator(task_id='{dep}')\n\n"
                    created_tasks[dep] = dep_var
                    dependency_statements.append(f"    {dep_var} >> {var_name}")
            else:
                # Cross-DAG dependency -> ExternalTaskSensor
                sensor_key = (dep_dag, dep)
                if sensor_key not in external_sensors:
                    sensor_var = f"sensor_{dep}".replace('-', '_').replace('.', '_')
                    
                    # Check if target dependency is a BOX DAG itself
                    is_box = False
                    if dep in registry and registry[dep]["job_type"] == "BOX":
                        is_box = True
                    elif dep_dag == dep: # Name pattern matches Box
                        is_box = True
                        
                    ext_task_id_val = "None" if is_box else f"'{dep}'"
                    
                    code += f"    # External dependency on {dep} in DAG {dep_dag}\n"
                    code += f"    {sensor_var} = ExternalTaskSensor(\n"
                    code += f"        task_id='wait_for_{dep}',\n"
                    code += f"        external_dag_id='{dep_dag}',\n"
                    code += f"        external_task_id={ext_task_id_val},\n"
                    code += f"        mode='poke',\n"
                    code += f"        timeout=600,\n"
                    code += f"        poke_interval=60,\n"
                    code += f"    )\n\n"
                    external_sensors[sensor_key] = sensor_var
                    dependency_statements.append(f"    start_task >> {sensor_var}")
                    
                sensor_var = external_sensors[sensor_key]
                dependency_statements.append(f"    {sensor_var} >> {var_name}")

    # Connect leaf nodes to end_task
    upstream_tasks = set()
    for statement in dependency_statements:
        match = re.match(r'^\s*([a-zA-Z_0-9]+)\s*>>\s*([a-zA-Z_0-9]+)', statement)
        if match:
            upstream_tasks.add(match.group(1).strip())
            
    for job_name, var in created_tasks.items():
        if var not in upstream_tasks:
            dependency_statements.append(f"    {var} >> end_task")
            
    for (dep_dag, dep), sensor_var in external_sensors.items():
        if sensor_var not in upstream_tasks:
            dependency_statements.append(f"    {sensor_var} >> end_task")

    code += "    # Task Dependencies\n"
    for stmt in dependency_statements:
        code += f"{stmt}\n"
        
    return code

def generate_all_dags():
    """
    Reads the job registry and generates python DAG files in output/dags.
    """
    registry_path = os.path.join(JSON_DIR, 'all_jobs_registry.json')
    if not os.path.exists(registry_path):
        return {}
        
    with open(registry_path, 'r', encoding='utf-8') as f:
        registry = json.load(f)
        
    # Group jobs by their DAG ID
    dag_groups = {}
    for job_name, job in registry.items():
        dag_id = get_dag_for_job(job_name, registry)
        if dag_id not in dag_groups:
            dag_groups[dag_id] = []
        dag_groups[dag_id].append(job)
        
    generated_files = {}
    for dag_id, jobs in dag_groups.items():
        dag_code = generate_dag_code(dag_id, jobs, registry)
        file_name = f"dev_{dag_id}_dag.py"
        file_path = os.path.join(DAGS_DIR, file_name)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(dag_code)
            
        generated_files[dag_id] = {
            "file_name": file_name,
            "jobs_count": len(jobs),
            "code": dag_code
        }
        
    return generated_files

if __name__ == '__main__':
    res = generate_all_dags()
    print(f"Generated {len(res)} DAGs:")
    for d, info in res.items():
        print(f"- {d}: {info['file_name']} ({info['jobs_count']} jobs)")
