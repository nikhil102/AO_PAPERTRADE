"""
Airflow DAG generated from AutoSys Box/Job: cdm_box_today_plan_sponsor_empower
Generated dynamically by AutoSys-to-Airflow Converter.
"""
from airflow import DAG
from airflow.providers.databricks.operators.databricks import DatabricksSubmitRunOperator
from airflow.sensors.external_task import ExternalTaskSensor
from datetime import datetime, timedelta
from airflow.operators.empty import EmptyOperator

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id='cdm_box_today_plan_sponsor_empower',
    default_args=default_args,
    description='Airflow DAG for cdm_box_today_plan_sponsor_empower',
    schedule_interval=None,  # Triggered manually or by external schedules
    start_date=datetime(2026, 1, 1),
    catchup=False,
) as dag:

    # Start and End Dummy Nodes
    start_task = EmptyOperator(task_id='start')
    end_task = EmptyOperator(task_id='end')

    # AutoSys CMD Job: cdm_today_empower_plan_sponsor_address
    # AutoSys command: bl -g runetl $cdm_script $BATCH_USER_NAME $BATCH_PASSWORD empower_plan_sponsor_address $MSSCDM_CTL/today_plan_sponsor.ctl
    cdm_today_empower_plan_sponsor_address = DatabricksSubmitRunOperator(
        task_id='cdm_today_empower_plan_sponsor_address',
        json={
            'run_name': 'cdm_today_empower_plan_sponsor_address',
            'spark_jar_task': {
                'main_class_name': 'com.databricks.RunEtl',
                'parameters': ['empower_plan_sponsor_address', '/dbfs/ctl/today_plan_sponsor.ctl']
            }
        },
        databricks_conn_id='databricks_default',
    )

    # External dependency on cdm_today_empower_plan_sponsor_party in DAG cdm_today_empower_plan_sponsor_party
    sensor_cdm_today_empower_plan_sponsor_party = ExternalTaskSensor(
        task_id='wait_for_cdm_today_empower_plan_sponsor_party',
        external_dag_id='cdm_today_empower_plan_sponsor_party',
        external_task_id=None,
        mode='poke',
        timeout=600,
        poke_interval=60,
    )

    # Task Dependencies
    start_task >> sensor_cdm_today_empower_plan_sponsor_party
    sensor_cdm_today_empower_plan_sponsor_party >> cdm_today_empower_plan_sponsor_address
    cdm_today_empower_plan_sponsor_address >> end_task
