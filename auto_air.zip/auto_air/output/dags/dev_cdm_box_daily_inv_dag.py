"""
Airflow DAG generated from AutoSys Box/Job: cdm_box_daily_inv
Generated dynamically by AutoSys-to-Airflow Converter.
"""
from airflow import DAG
from airflow.providers.databricks.operators.databricks import DatabricksSubmitRunOperator
from airflow.sensors.external_task import ExternalTaskSensor
from datetime import datetime, timedelta
from airflow.operators.empty import EmptyOperator

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id='cdm_box_daily_inv',
    default_args=default_args,
    description='Airflow DAG for cdm_box_daily_inv',
    schedule_interval=None,  # Triggered manually or by external schedules
    start_date=datetime(2026, 1, 1),
    catchup=False,
) as dag:

    # Start and End Dummy Nodes
    start_task = EmptyOperator(task_id='start')
    end_task = EmptyOperator(task_id='end')

    # AutoSys BOX: cdm_box_daily_inv
    cdm_box_daily_inv = EmptyOperator(
        task_id='cdm_box_daily_inv',
    )

    # External dependency on cdm_box_daily_inv_ta2000 in DAG cdm_box_daily_inv_ta2000
    sensor_cdm_box_daily_inv_ta2000 = ExternalTaskSensor(
        task_id='wait_for_cdm_box_daily_inv_ta2000',
        external_dag_id='cdm_box_daily_inv_ta2000',
        external_task_id=None,
        mode='poke',
        timeout=600,
        poke_interval=60,
    )

    # Task Dependencies
    start_task >> sensor_cdm_box_daily_inv_ta2000
    sensor_cdm_box_daily_inv_ta2000 >> cdm_box_daily_inv
    cdm_box_daily_inv >> end_task
