# AutoSys to Airflow Conversion Summary Report

## Migration Statistics
- **Total Files Scanned**: 2
- **Total Jobs Parsed**: 2
- **AutoSys Boxes Found**: 1
- **AutoSys CMD Jobs Found**: 1

## File Processing Summary
| Filename | Jobs Count | Parsing Status |
| --- | --- | --- |
| cdm_box_daily_inv.txt | 1 | Success |
| cdm_today_empower_plan_sponsor_address.txt | 1 | Success |

