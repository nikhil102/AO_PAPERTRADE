import os
import re
import json
import csv

# Directory paths
WORKSPACE_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_DIR = os.path.join(WORKSPACE_DIR, 'input')
OUTPUT_DIR = os.path.join(WORKSPACE_DIR, 'output')
JSON_DIR = os.path.join(OUTPUT_DIR, 'json')
REPORTS_DIR = os.path.join(OUTPUT_DIR, 'reports')
DAGS_DIR = os.path.join(OUTPUT_DIR, 'dags')

# Ensure directories exist
for d in [JSON_DIR, REPORTS_DIR, DAGS_DIR]:
    os.makedirs(d, exist_ok=True)

# Standard AutoSys fields mapped in our target structure
SUPPORTED_FIELDS = {
    'insert_job', 'job_type', 'box_name', 'command', 'machine', 'owner', 'permission',
    'date_conditions', 'days_of_week', 'exclude_calendar', 'start_times', 'condition',
    'description', 'n_retrys', 'std_out_file', 'std_err_file', 'alarm_if_fail',
    'profile', 'alarm_if_terminated'
}

def extract_dependencies(condition_str):
    """
    Extracts all job names referenced in a condition string.
    AutoSys conditions usually look like success(job_a) & s(job_b) | failure(job_c).
    """
    if not condition_str:
        return []
    # Match success(job), s(job), failure(job), f(job), terminated(job), t(job)
    pattern = r'\b(?:success|s|failure|f|terminated|t)\s*\(\s*([a-zA-Z0-9_\-\.]+)\s*\)'
    return re.findall(pattern, condition_str)

def parse_jil_content(content, filename):
    """
    Parses a single file's content, extracting and formatting AutoSys JIL job definitions.
    """
    # 1. Look for the JIL Source block if it exists
    if "PD1 JIL Source" in content:
        parts = content.split("PD1 JIL Source")
        jil_block = parts[1]
        if "PD1 Dependencies" in jil_block:
            jil_block = jil_block.split("PD1 Dependencies")[0]
    else:
        jil_block = content

    # Remove C-style multi-line comments /* ... */
    jil_block = re.sub(r'/\*.*?\*/', '', jil_block, flags=re.DOTALL)
    
    # Split by job insertions
    job_blocks = jil_block.split("insert_job:")
    jobs = []
    
    for block in job_blocks:
        block = block.strip()
        if not block:
            continue
        
        lines = block.split('\n')
        first_line = lines[0].strip()
        
        # Parse job name and job type from: 'job_name   job_type: type'
        match = re.match(r'^([^\s]+)\s+job_type:\s*([^\s]+)', first_line)
        if not match:
            # Fallback if job_type is on another line
            match = re.match(r'^([^\s]+)', first_line)
            if match:
                job_name = match.group(1)
                job_type = "UNKNOWN"
            else:
                continue
        else:
            job_name = match.group(1)
            job_type = match.group(2)
            
        job_data = {
            "job_name": job_name,
            "job_type": job_type,
            "box_name": None,
            "command": None,
            "machine": None,
            "owner": None,
            "permission": None,
            "date_conditions": None,
            "days_of_week": None,
            "exclude_calendar": None,
            "start_times": None,
            "condition": None,
            "description": None,
            "n_retrys": None,
            "std_out_file": None,
            "std_err_file": None,
            "alarm_if_fail": None,
            "profile": None,
            "alarm_if_terminated": None,
            "source_file": filename,
            "unsupported_attrs": {}
        }
        
        current_attr = None
        current_value = []
        
        for line in lines[1:]:
            line_str = line.strip()
            if not line_str or line_str.startswith("#") or line_str.startswith("/*"):
                continue
            
            # Check for new attribute definition: key: value
            attr_match = re.match(r'^([a-zA-Z_0-9]+):\s*(.*)$', line_str)
            if attr_match:
                # Save previous attribute
                if current_attr:
                    val = " ".join(current_value).strip()
                    if val.startswith('"') and val.endswith('"'):
                        val = val[1:-1]
                    if current_attr in job_data:
                        job_data[current_attr] = val
                    else:
                        job_data["unsupported_attrs"][current_attr] = val
                
                current_attr = attr_match.group(1)
                val_part = attr_match.group(2).strip()
                current_value = [val_part] if val_part else []
            else:
                # Attribute continuation
                if current_attr:
                    current_value.append(line_str)
                    
        # Save last attribute
        if current_attr:
            val = " ".join(current_value).strip()
            if val.startswith('"') and val.endswith('"'):
                val = val[1:-1]
            if current_attr in job_data:
                job_data[current_attr] = val
            else:
                job_data["unsupported_attrs"][current_attr] = val
                
        # Move job_type back to main key if it was parsed as attribute
        if job_data["job_type"] == "UNKNOWN" and "job_type" in job_data["unsupported_attrs"]:
            job_data["job_type"] = job_data["unsupported_attrs"].pop("job_type")
            
        # Standardize empty/null strings
        for k in job_data:
            if job_data[k] == "":
                job_data[k] = None
                
        # Parse dependencies
        job_data["dependencies"] = extract_dependencies(job_data["condition"])
        jobs.append(job_data)
        
    return jobs

def scan_and_parse():
    """
    Scans the input directory for txt/jil files and parses them into a central registry.
    Returns files list, jobs registry dict, and status message.
    """
    all_jobs = {}
    files_scanned = []
    errors = []
    
    if not os.path.exists(INPUT_DIR):
        return [], {}, f"Input directory {INPUT_DIR} does not exist."
        
    for file_name in os.listdir(INPUT_DIR):
        if file_name.endswith('.txt') or file_name.endswith('.jil'):
            file_path = os.path.join(INPUT_DIR, file_name)
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                jobs = parse_jil_content(content, file_name)
                for job in jobs:
                    all_jobs[job["job_name"]] = job
                files_scanned.append({
                    "filename": file_name,
                    "jobs_count": len(jobs),
                    "status": "Success"
                })
            except Exception as e:
                errors.append(f"Error parsing {file_name}: {str(e)}")
                files_scanned.append({
                    "filename": file_name,
                    "jobs_count": 0,
                    "status": f"Error: {str(e)}"
                })
                
    # Save the parsed registry
    registry_path = os.path.join(JSON_DIR, 'all_jobs_registry.json')
    with open(registry_path, 'w', encoding='utf-8') as f:
        json.dump(all_jobs, f, indent=4)
        
    # Write unsupported attributes CSV
    write_unsupported_attributes_report(all_jobs)
    
    # Write conversion report Markdown
    write_conversion_report(files_scanned, all_jobs, errors)
    
    return files_scanned, all_jobs, f"Successfully parsed {len(files_scanned)} files containing {len(all_jobs)} jobs."

def write_unsupported_attributes_report(all_jobs):
    """
    Generates a CSV report summarizing unsupported JIL attributes across all parsed jobs.
    """
    unsupported_path = os.path.join(REPORTS_DIR, 'unsupported_attributes.csv')
    
    # Define mapping recommendations for unsupported fields
    recommendations = {
        'std_out_file': 'Captured in Airflow task log output automatically. Manual redirection not required.',
        'std_err_file': 'Captured in Airflow task log output automatically. Manual redirection not required.',
        'profile': 'Managed via Airflow Environment Variables, Databricks Cluster settings, or Connections.',
        'alarm_if_fail': 'Managed in Airflow using email alerts (email_on_failure=True) or Slack webhooks.',
        'alarm_if_terminated': 'Managed in Airflow via SLA miss callbacks or standard alerting hooks.',
        'permission': 'Managed via Airflow RBAC (Role-Based Access Control) permissions.',
        'date_conditions': 'Airflow runs schedules at the DAG level. Task-level date conditions require custom sensors.',
        'days_of_week': 'DAG-level schedule_interval should be configured using cron (e.g. days tu,we,th,fr,sa).',
        'exclude_calendar': 'Requires custom Airflow Timetables or a helper task to skip run on holidays.',
        'start_times': 'DAG-level schedule_interval should represent the start time.',
        'machine': 'Mapped to a specific Airflow execution queue or a Databricks cluster name.'
    }
    
    # These fields are parsed as standard fields but are not directly supported by Airflow
    unsupported_field_keys = [
        'std_out_file', 'std_err_file', 'profile', 'alarm_if_fail', 
        'alarm_if_terminated', 'permission', 'date_conditions', 
        'days_of_week', 'exclude_calendar', 'start_times', 'machine'
    ]
    
    rows = []
    for job_name, job in all_jobs.items():
        # Check standard fields that have values but are unmappable
        for key in unsupported_field_keys:
            val = job.get(key)
            if val is not None and val != "0" and val != "":
                rec = recommendations.get(key, 'Configure manually in Airflow task or cluster configurations.')
                rows.append({
                    "Job Name": job_name,
                    "Job Type": job["job_type"],
                    "Unsupported Attribute": key,
                    "AutoSys Value": val,
                    "Airflow Recommendation": rec
                })
                
        # Check extra attributes parsed that are not in our schema
        for attr, val in job.get("unsupported_attrs", {}).items():
            if val is not None and val != "":
                rec = recommendations.get(attr, 'Configure manually in Airflow task or cluster configurations.')
                rows.append({
                    "Job Name": job_name,
                    "Job Type": job["job_type"],
                    "Unsupported Attribute": attr,
                    "AutoSys Value": val,
                    "Airflow Recommendation": rec
                })
            
    with open(unsupported_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=["Job Name", "Job Type", "Unsupported Attribute", "AutoSys Value", "Airflow Recommendation"])
        writer.writeheader()
        writer.writerows(rows)

def write_conversion_report(files_scanned, all_jobs, errors):
    """
    Generates a summary conversion markdown report.
    """
    report_path = os.path.join(REPORTS_DIR, 'conversion_report.md')
    
    total_boxes = sum(1 for job in all_jobs.values() if job["job_type"] == "BOX")
    total_cmds = sum(1 for job in all_jobs.values() if job["job_type"] == "CMD")
    
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("# AutoSys to Airflow Conversion Summary Report\n\n")
        f.write("## Migration Statistics\n")
        f.write(f"- **Total Files Scanned**: {len(files_scanned)}\n")
        f.write(f"- **Total Jobs Parsed**: {len(all_jobs)}\n")
        f.write(f"- **AutoSys Boxes Found**: {total_boxes}\n")
        f.write(f"- **AutoSys CMD Jobs Found**: {total_cmds}\n\n")
        
        f.write("## File Processing Summary\n")
        f.write("| Filename | Jobs Count | Parsing Status |\n")
        f.write("| --- | --- | --- |\n")
        for f_info in files_scanned:
            f.write(f"| {f_info['filename']} | {f_info['jobs_count']} | {f_info['status']} |\n")
        f.write("\n")
        
        if errors:
            f.write("## Parsing Errors & Warnings\n")
            for err in errors:
                f.write(f"- ⚠️ {err}\n")
            f.write("\n")

if __name__ == '__main__':
    # Test scan
    scanned, registry, msg = scan_and_parse()
    print(msg)
    print(f"Scanned files list: {[s['filename'] for s in scanned]}")
