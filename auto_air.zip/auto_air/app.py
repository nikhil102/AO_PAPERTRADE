import os
import json
import io
import zipfile
from flask import Flask, render_template, jsonify, request, send_file, redirect, url_for
from parser import scan_and_parse, INPUT_DIR, REPORTS_DIR, DAGS_DIR, JSON_DIR
from generator import generate_all_dags, get_dag_for_job

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = INPUT_DIR
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

# Ensure folders exist
os.makedirs(INPUT_DIR, exist_ok=True)

def load_registry():
    registry_path = os.path.join(JSON_DIR, 'all_jobs_registry.json')
    if os.path.exists(registry_path):
        with open(registry_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

@app.route('/')
def dashboard():
    # Automatically scan on startup if registry is empty
    registry = load_registry()
    if not registry:
        scan_and_parse()
        generate_all_dags()
        registry = load_registry()
        
    # Get scan report info
    files_info = []
    report_path = os.path.join(REPORTS_DIR, 'conversion_report.md')
    
    # Calculate stats
    total_jobs = len(registry)
    total_boxes = sum(1 for job in registry.values() if job["job_type"] == "BOX")
    total_cmds = sum(1 for job in registry.values() if job["job_type"] == "CMD")
    
    # Count external dependencies
    external_deps = set()
    for job_name, job in registry.items():
        dag_id = get_dag_for_job(job_name, registry)
        for dep in job["dependencies"]:
            dep_dag = get_dag_for_job(dep, registry)
            if dep_dag != dag_id:
                external_deps.add(dep)
    
    total_external_deps = len(external_deps)
    
    # Calculate parsing status per file
    files_info = []
    for f_name in os.listdir(INPUT_DIR):
        if f_name.endswith('.txt') or f_name.endswith('.jil'):
            # Just count how many jobs have this source file
            jobs_count = sum(1 for job in registry.values() if job["source_file"] == f_name)
            files_info.append({
                "filename": f_name,
                "jobs_count": jobs_count,
                "status": "Success" if jobs_count > 0 else "Pending"
            })
            
    return render_template(
        'dashboard.html',
        total_jobs=total_jobs,
        total_boxes=total_boxes,
        total_cmds=total_cmds,
        total_external_deps=total_external_deps,
        files_info=files_info
    )

@app.route('/scanner')
def scanner():
    registry = load_registry()
    files_info = []
    for f_name in os.listdir(INPUT_DIR):
        if f_name.endswith('.txt') or f_name.endswith('.jil'):
            jobs_count = sum(1 for job in registry.values() if job["source_file"] == f_name)
            files_info.append({
                "filename": f_name,
                "jobs_count": jobs_count,
                "status": "Parsed" if jobs_count > 0 else "Ready"
            })
    return render_template('scanner.html', files_info=files_info)

@app.route('/analyzer')
def analyzer():
    registry = load_registry()
    # Find all box names to populate dropdown
    dags_list = set()
    for job_name, job in registry.items():
        dag_id = get_dag_for_job(job_name, registry)
        dags_list.add(dag_id)
        
    return render_template('analyzer.html', dags=sorted(list(dags_list)))

@app.route('/editor')
def editor():
    registry = load_registry()
    return render_template('editor.html', jobs=sorted(list(registry.keys())))

# REST APIs
@app.route('/api/scan', methods=['POST'])
def api_scan():
    files_scanned, all_jobs, msg = scan_and_parse()
    generate_all_dags()
    return jsonify({
        "status": "success",
        "message": msg,
        "files_scanned": files_scanned,
        "jobs_count": len(all_jobs)
    })

@app.route('/api/upload', methods=['POST'])
def api_upload():
    if 'files[]' not in request.files:
        return jsonify({"status": "error", "message": "No files uploaded"}), 400
        
    files = request.files.getlist('files[]')
    uploaded_count = 0
    for file in files:
        if file and (file.filename.endswith('.txt') or file.filename.endswith('.jil')):
            filename = os.path.basename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            uploaded_count += 1
            
    if uploaded_count > 0:
        # Re-scan and generate DAGs
        scan_and_parse()
        generate_all_dags()
        return jsonify({"status": "success", "message": f"Successfully uploaded and parsed {uploaded_count} files."})
        
    return jsonify({"status": "error", "message": "No valid JIL files (.txt or .jil) were uploaded."}), 400

@app.route('/api/job/<job_name>')
def api_job_details(job_name):
    registry = load_registry()
    if job_name not in registry:
        return jsonify({"status": "error", "message": "Job not found"}), 404
        
    job = registry[job_name]
    
    # Read JIL block from source file
    source_file_path = os.path.join(INPUT_DIR, job["source_file"])
    jil_source = "JIL source not found."
    if os.path.exists(source_file_path):
        try:
            with open(source_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
            # Extract PD1 JIL Source segment
            if "PD1 JIL Source" in content:
                parts = content.split("PD1 JIL Source")
                jil_block = parts[1]
                if "PD1 Dependencies" in jil_block:
                    jil_block = jil_block.split("PD1 Dependencies")[0]
                jil_source = jil_block.strip()
            else:
                jil_source = content.strip()
        except Exception as e:
            jil_source = f"Error reading source file: {str(e)}"
            
    # Read Airflow code
    dag_id = get_dag_for_job(job_name, registry)
    dag_file_path = os.path.join(DAGS_DIR, f"dev_{dag_id}_dag.py")
    airflow_code = "# DAG file not generated."
    if os.path.exists(dag_file_path):
        try:
            with open(dag_file_path, 'r', encoding='utf-8') as f:
                airflow_code = f.read()
        except Exception as e:
            airflow_code = f"# Error reading DAG code: {str(e)}"
            
    return jsonify({
        "job": job,
        "jil_source": jil_source,
        "airflow_code": airflow_code,
        "dag_id": dag_id,
        "dag_file_name": f"dev_{dag_id}_dag.py"
    })

@app.route('/api/graph/<dag_id>')
def api_graph(dag_id):
    registry = load_registry()
    elements = []
    
    # Filter jobs in this DAG (box)
    jobs_in_dag = []
    for job_name, job in registry.items():
        job_dag = get_dag_for_job(job_name, registry)
        if job_dag == dag_id:
            jobs_in_dag.append(job)
            
    if not jobs_in_dag:
        return jsonify([])
        
    # Start and End Nodes
    elements.append({
        "data": {
            "id": "start",
            "label": "Start Node",
            "type": "start"
        }
    })
    elements.append({
        "data": {
            "id": "end",
            "label": "End Node",
            "type": "end"
        }
    })
    
    # Track created nodes and edges to avoid duplicates
    created_nodes = {"start", "end"}
    created_edges = set()
    
    # Create nodes for jobs
    for job in jobs_in_dag:
        job_name = job["job_name"]
        job_type = job["job_type"]
        elements.append({
            "data": {
                "id": job_name,
                "label": job_name,
                "type": job_type
            }
        })
        created_nodes.add(job_name)
        
    # Create nodes for external sensors & add edges
    for job in jobs_in_dag:
        job_name = job["job_name"]
        
        # If no dependencies, link from start
        if not job["dependencies"]:
            edge_id = f"start->{job_name}"
            elements.append({
                "data": {
                    "id": edge_id,
                    "source": "start",
                    "target": job_name
                }
            })
            created_edges.add(edge_id)
            
        for dep in job["dependencies"]:
            dep_dag = get_dag_for_job(dep, registry)
            
            if dep_dag == dag_id:
                # Same DAG dependency
                # Ensure the dependency node is created (if JIL didn't define it in files, create as placeholder)
                if dep not in created_nodes:
                    elements.append({
                        "data": {
                            "id": dep,
                            "label": f"{dep} (Placeholder)",
                            "type": "placeholder"
                        }
                    })
                    created_nodes.add(dep)
                    
                edge_id = f"{dep}->{job_name}"
                if edge_id not in created_edges:
                    elements.append({
                        "data": {
                            "id": edge_id,
                            "source": dep,
                            "target": job_name
                        }
                    })
                    created_edges.add(edge_id)
            else:
                # External dependency -> Sensor Node
                sensor_id = f"wait_for_{dep}"
                if sensor_id not in created_nodes:
                    elements.append({
                        "data": {
                            "id": sensor_id,
                            "label": f"Wait for {dep}\n(External DAG: {dep_dag})",
                            "type": "sensor",
                            "ext_dag": dep_dag
                        }
                    })
                    created_nodes.add(sensor_id)
                    
                    # Link start to the sensor
                    edge_id = f"start->{sensor_id}"
                    elements.append({
                        "data": {
                            "id": edge_id,
                            "source": "start",
                            "target": sensor_id
                        }
                    })
                    created_edges.add(edge_id)
                    
                # Link sensor to job
                edge_id = f"{sensor_id}->{job_name}"
                if edge_id not in created_edges:
                    elements.append({
                        "data": {
                            "id": edge_id,
                            "source": sensor_id,
                            "target": job_name
                        }
                    })
                    created_edges.add(edge_id)

    # Link leaf nodes to end
    # A node is leaf if it never acts as a source in any of the created edges (except for start/sensor edges)
    sources = set()
    for el in elements:
        if "source" in el["data"]:
            sources.add(el["data"]["source"])
            
    for job in jobs_in_dag:
        job_name = job["job_name"]
        if job_name not in sources:
            edge_id = f"{job_name}->end"
            if edge_id not in created_edges:
                elements.append({
                    "data": {
                        "id": edge_id,
                        "source": job_name,
                        "target": "end"
                    }
                })
                created_edges.add(edge_id)

    return jsonify(elements)

@app.route('/api/download/dags')
def download_dags():
    # Build dynamic ZIP in memory
    memory_file = io.BytesIO()
    with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        if os.path.exists(DAGS_DIR):
            for file_name in os.listdir(DAGS_DIR):
                if file_name.endswith('.py'):
                    file_path = os.path.join(DAGS_DIR, file_name)
                    zip_file.write(file_path, file_name)
                    
    memory_file.seek(0)
    return send_file(
        memory_file,
        mimetype='application/zip',
        as_attachment=True,
        download_name='airflow_generated_dags.zip'
    )

@app.route('/reports/download/unsupported')
def download_unsupported_csv():
    csv_path = os.path.join(REPORTS_DIR, 'unsupported_attributes.csv')
    if os.path.exists(csv_path):
        return send_file(csv_path, as_attachment=True, download_name='unsupported_attributes.csv')
    return "Report not generated.", 404

if __name__ == '__main__':
    # Initialize parsing/generating on load
    scan_and_parse()
    generate_all_dags()
    app.run(host='0.0.0.0', port=5000, debug=True)
