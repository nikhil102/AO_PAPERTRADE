# Design Guidelines: Informatica XML to PySpark Converter

## Design Approach
**System-Based Approach** using **Linear + Notion hybrid patterns**

This enterprise productivity tool requires clarity, efficiency, and a professional technical aesthetic. Drawing from Linear's clean interfaces and Notion's data-dense layouts, prioritizing information hierarchy and workflow efficiency over visual flourish.

## Core Design Principles
1. **Technical Clarity**: Every element serves the conversion workflow
2. **Progressive Disclosure**: Show complexity only when needed
3. **Status Transparency**: Always indicate processing state and progress
4. **Error Prevention**: Guide users with clear validation and feedback

## Typography System
- **Primary Font**: Inter (via Google Fonts CDN)
- **Monospace Font**: JetBrains Mono (for code/XML display)
- **Scale**:
  - H1: text-3xl font-semibold (page titles)
  - H2: text-xl font-semibold (section headers)
  - H3: text-lg font-medium (subsection titles)
  - Body: text-sm (primary content)
  - Code/Technical: text-xs font-mono (file names, paths, code snippets)

## Layout System
**Spacing Units**: Tailwind units 2, 4, 6, 8, 12, 16
- Component padding: p-6
- Section spacing: gap-8
- Card padding: p-6
- Form field spacing: gap-4
- Tight grouping: gap-2

**Container Strategy**:
- Main content: max-w-7xl mx-auto px-8
- Narrow forms: max-w-2xl mx-auto
- Full-width results: w-full with inner constraints

## Application Layout Structure

### Header (Fixed)
- App title + version indicator (left)
- Process status badge (center) - shows "Ready" / "Analyzing" / "Converting"
- Documentation link (right)
- Height: h-16, border-b

### Main Content Area
**Two-Column Layout** for workflow steps:
- Left sidebar (w-80): Step navigation showing progress (Upload → Analyze → Configure → Generate)
- Right content (flex-1): Active step content

### Step 1: Upload Interface
- Large drag-and-drop zone (min-h-64)
- Supported formats clearly listed (.xml, mapping or workflow)
- File info display after upload (name, size, type detected)
- Multiple file support with list view

### Step 2: Analysis Results
**Information Cards Grid** (grid-cols-2 gap-6):
- Mapping count card
- Sources breakdown card (SQL vs FILE with counts)
- Targets summary card
- Transformation types card

**Flow Visualization**:
- Horizontal flow diagram using connected boxes
- Source → SQ → Transformations → Target
- Side-panel for detached lookups/SPs (differentiated visually)

**Data Tables** for detailed lists:
- Sources table: Name | Type | DB/Path | Status
- Targets table: Name | Type | Destination
- Transformations table: Name | Type | Complexity indicator

### Step 3: Configuration Form
**Grouped Sections** (divide with visual separators):

**Per-Source Configuration**:
- Source name as section header
- If SQL: Connection alias dropdown + test connection button
- If FILE: Format radio buttons (parquet/csv/dat) + Path input + Location toggle (local/s3)
- Advanced options (collapsed by default): delimiter, header, encoding

**Target Configuration**:
- Target name headers
- Output format selection
- Destination path/table input
- Write mode dropdown (append/overwrite)

**Form Layout**: Single column, max-w-2xl, generous spacing (gap-6)

### Step 4: Generate & Download
**Status Panel**:
- Progress indicator (0-100% with step labels)
- Real-time log output (scrollable, monospace)
- Success/error summary

**Results Panel** (after completion):
- Generated files list with download buttons
- Report summary with expandable warnings/notes
- ZIP download (primary action button)

## Component Library

### Buttons
- Primary: Solid fill, medium weight, px-6 py-2.5
- Secondary: Border style, same padding
- Text: No background, subtle hover
- Icon buttons: Square, p-2

### Form Inputs
- Text fields: w-full, px-4 py-2.5, border, rounded-md
- Select dropdowns: Consistent sizing with text fields
- Radio groups: Vertical stack with clear labels
- File input: Custom styled with icon + text

### Cards
- Border: border rounded-lg
- Padding: p-6
- Shadow: Subtle on hover only
- Sections within cards: divide-y

### Data Display
- Tables: Striped rows, sticky headers for long lists
- Code blocks: Monospace, border, p-4, max-height with scroll
- Badges: Inline status indicators (rounded-full px-3 py-1 text-xs)
- Progress bars: Linear, height-2, rounded-full

### Status Indicators
- Success: Green accent
- Warning: Amber accent
- Error: Red accent
- Processing: Blue accent with animation (pulse)
- Ready: Gray/neutral

### Icons
**Font Awesome 6 (Free)** via CDN:
- Upload: fa-cloud-upload-alt
- Check: fa-check-circle
- Warning: fa-exclamation-triangle
- Error: fa-times-circle
- Download: fa-download
- Code: fa-code
- Database: fa-database
- File: fa-file-code
- Settings: fa-cog

## Interaction Patterns
- **Wizard progression**: Linear flow with back/next navigation
- **Real-time validation**: Inline feedback on form fields
- **Expandable sections**: Accordion for advanced options
- **Toast notifications**: Top-right for non-blocking alerts
- **Loading states**: Skeleton screens for data fetch, spinners for actions

## Accessibility
- All form inputs with associated labels
- Keyboard navigation throughout wizard
- Focus indicators on interactive elements
- ARIA labels for icon-only buttons
- Error messages linked to form fields

## Responsive Considerations
- Desktop-first (primary use case)
- Tablet: Single column, collapsible sidebar
- Mobile: Stack all layouts, simplified navigation

No animations except subtle transitions (150ms) on hover/focus states and loading spinners.