/**
 * Informatica XML to PySpark Converter
 * Frontend JavaScript Application
 */

class App {
    constructor() {
        this.currentStep = 1;
        this.artifactId = null;
        this.analysisData = null;
        this.workflowAnalysis = null;
        this.selectedFile = null;
        this.userConfig = {
            sources: [],
            targets: [],
            db_connections: {}
        };
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.initTheme();
    }
    
    bindEvents() {
        const uploadZone = document.getElementById('uploadZone');
        const fileInput = document.getElementById('fileInput');
        const removeFileBtn = document.getElementById('removeFileBtn');
        const analyzeBtn = document.getElementById('analyzeBtn');
        
        uploadZone.addEventListener('click', () => fileInput.click());
        uploadZone.addEventListener('dragover', (e) => this.handleDragOver(e));
        uploadZone.addEventListener('dragleave', (e) => this.handleDragLeave(e));
        uploadZone.addEventListener('drop', (e) => this.handleDrop(e));
        fileInput.addEventListener('change', (e) => this.handleFileSelect(e));
        removeFileBtn.addEventListener('click', () => this.removeFile());
        analyzeBtn.addEventListener('click', () => this.analyzeFile());
        
        document.getElementById('backToStep1').addEventListener('click', () => this.goToStep(1));
        document.getElementById('goToStep3').addEventListener('click', () => this.goToStep(3));
        document.getElementById('backToStep2').addEventListener('click', () => this.goToStep(2));
        document.getElementById('generateBtn').addEventListener('click', () => this.generateCode());
        document.getElementById('backToStep3').addEventListener('click', () => this.goToStep(3));
        document.getElementById('startOverBtn').addEventListener('click', () => this.startOver());
        
        document.getElementById('addConnectionBtn').addEventListener('click', () => this.addConnection());
        
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.switchTab(e.target.dataset.tab));
        });
        
        document.getElementById('themeToggle').addEventListener('click', () => this.toggleTheme());
        
        document.getElementById('closeModalBtn').addEventListener('click', () => this.closeModal());
        document.querySelector('.modal-overlay').addEventListener('click', () => this.closeModal());
        document.getElementById('copyCodeBtn').addEventListener('click', () => this.copyCode());
        
        document.getElementById('downloadZipBtn').addEventListener('click', () => this.downloadZip());
        
        // Main dropdown (merged Tools + Docs)
        const mainDropdownBtn = document.getElementById('mainDropdownBtn');
        const mainDropdown = mainDropdownBtn?.closest('.header-dropdown');
        if (mainDropdownBtn && mainDropdown) {
            mainDropdownBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                mainDropdown.classList.toggle('open');
            });
        }
        
        // Close dropdowns when clicking outside
        document.addEventListener('click', (e) => {
            document.querySelectorAll('.header-dropdown.open').forEach(dropdown => {
                if (!dropdown.contains(e.target)) {
                    dropdown.classList.remove('open');
                }
            });
        });
        
        // Tools menu items
        const toolPySparkConverter = document.getElementById('toolPySparkConverter');
        const toolExpressionConverter = document.getElementById('toolExpressionConverter');
        
        if (toolPySparkConverter) {
            toolPySparkConverter.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchTool('pyspark');
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        if (toolExpressionConverter) {
            toolExpressionConverter.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchTool('expression');
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        // XML Docs Modal
        const openXmlReferenceBtn = document.getElementById('openXmlReference');
        const xmlDocsModal = document.getElementById('xmlDocsModal');
        const closeXmlDocsBtn = document.getElementById('closeXmlDocsModal');
        const xmlDocsOverlay = document.getElementById('xmlDocsOverlay');
        
        if (openXmlReferenceBtn) {
            openXmlReferenceBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.openXmlDocsModal();
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        if (closeXmlDocsBtn) {
            closeXmlDocsBtn.addEventListener('click', () => this.closeXmlDocsModal());
        }
        
        if (xmlDocsOverlay) {
            xmlDocsOverlay.addEventListener('click', () => this.closeXmlDocsModal());
        }
        
        // PySpark Guide and About
        const openPySparkGuide = document.getElementById('openPySparkGuide');
        const openAbout = document.getElementById('openAbout');
        
        if (openPySparkGuide) {
            openPySparkGuide.addEventListener('click', (e) => {
                e.preventDefault();
                this.openPySparkGuideModal();
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        // PySpark Guide Modal
        const closePySparkGuideBtn = document.getElementById('closePySparkGuideModal');
        const pysparkGuideOverlay = document.getElementById('pysparkGuideOverlay');
        
        if (closePySparkGuideBtn) {
            closePySparkGuideBtn.addEventListener('click', () => this.closePySparkGuideModal());
        }
        
        if (pysparkGuideOverlay) {
            pysparkGuideOverlay.addEventListener('click', () => this.closePySparkGuideModal());
        }
        
        if (openAbout) {
            openAbout.addEventListener('click', (e) => {
                e.preventDefault();
                this.showToast('Informatica to PySpark Converter v4.0 by Capital Group', 'info');
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        // DB Connection Modal
        const openDbConnection = document.getElementById('openDbConnection');
        const closeDbConnectionBtn = document.getElementById('closeDbConnectionModal');
        const dbConnectionOverlay = document.getElementById('dbConnectionOverlay');
        const cancelDbConnection = document.getElementById('cancelDbConnection');
        
        if (openDbConnection) {
            openDbConnection.addEventListener('click', (e) => {
                e.preventDefault();
                this.openConnectionsManager();
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        [closeDbConnectionBtn, dbConnectionOverlay, cancelDbConnection].forEach(el => {
            if (el) el.addEventListener('click', () => this.closeSettingsModal('dbConnectionModal'));
        });
        
        // Add New Connection Button
        const addNewConnection = document.getElementById('addNewConnection');
        if (addNewConnection) {
            addNewConnection.addEventListener('click', () => this.openConnectionForm());
        }
        
        // Connection Form Modal
        const closeConnectionFormBtn = document.getElementById('closeConnectionFormModal');
        const connectionFormOverlay = document.getElementById('connectionFormOverlay');
        const cancelConnectionForm = document.getElementById('cancelConnectionForm');
        const saveConnectionForm = document.getElementById('saveConnectionForm');
        
        [closeConnectionFormBtn, connectionFormOverlay, cancelConnectionForm].forEach(el => {
            if (el) el.addEventListener('click', () => this.closeSettingsModal('connectionFormModal'));
        });
        
        if (saveConnectionForm) {
            saveConnectionForm.addEventListener('click', () => this.saveConnection());
        }
        
        // File Path Modal
        const openFilePath = document.getElementById('openFilePath');
        const closeFilePathBtn = document.getElementById('closeFilePathModal');
        const filePathOverlay = document.getElementById('filePathOverlay');
        const cancelFilePath = document.getElementById('cancelFilePath');
        const saveFilePath = document.getElementById('saveFilePath');
        
        if (openFilePath) {
            openFilePath.addEventListener('click', (e) => {
                e.preventDefault();
                this.openSettingsModal('filePathModal');
                if (mainDropdown) mainDropdown.classList.remove('open');
            });
        }
        
        [closeFilePathBtn, filePathOverlay, cancelFilePath].forEach(el => {
            if (el) el.addEventListener('click', () => this.closeSettingsModal('filePathModal'));
        });
        
        if (saveFilePath) {
            saveFilePath.addEventListener('click', () => this.saveFilePathSettings());
        }
    }
    
    openSettingsModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('open');
            document.body.style.overflow = 'hidden';
            this.loadSettingsFromStorage(modalId);
        }
    }
    
    closeSettingsModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('open');
            document.body.style.overflow = '';
        }
    }
    
    loadSettingsFromStorage(modalId) {
        if (modalId === 'filePathModal') {
            const settings = JSON.parse(localStorage.getItem('filePathSettings') || '{}');
            if (settings.sourceFilePath) document.getElementById('sourceFilePath').value = settings.sourceFilePath;
            if (settings.lookupFilePath) document.getElementById('lookupFilePath').value = settings.lookupFilePath;
            if (settings.targetFilePath) document.getElementById('targetFilePath').value = settings.targetFilePath;
            if (settings.logFilePath) document.getElementById('logFilePath').value = settings.logFilePath;
            if (settings.checkpointPath) document.getElementById('checkpointPath').value = settings.checkpointPath;
            if (settings.cloudStorageType) document.getElementById('cloudStorageType').value = settings.cloudStorageType;
            if (settings.cloudBasePath) document.getElementById('cloudBasePath').value = settings.cloudBasePath;
        }
    }
    
    // Connection Management Methods
    getConnections() {
        return JSON.parse(localStorage.getItem('dbConnections') || '[]');
    }
    
    saveConnections(connections) {
        localStorage.setItem('dbConnections', JSON.stringify(connections));
    }
    
    openConnectionsManager() {
        this.openSettingsModal('dbConnectionModal');
        this.renderConnectionsList();
    }
    
    renderConnectionsList() {
        const connections = this.getConnections();
        const listEl = document.getElementById('connectionsList');
        const countEl = document.getElementById('connectionCount');
        const emptyEl = document.getElementById('emptyConnections');
        
        countEl.textContent = connections.length;
        
        if (connections.length === 0) {
            listEl.innerHTML = '';
            listEl.appendChild(emptyEl.cloneNode(true));
            return;
        }
        
        const typeIcons = {
            source: 'fas fa-arrow-right',
            target: 'fas fa-arrow-left',
            lookup: 'fas fa-search'
        };
        
        listEl.innerHTML = connections.map(conn => `
            <div class="connection-card" data-id="${conn.id}">
                <div class="connection-icon ${conn.connType}-type">
                    <i class="${typeIcons[conn.connType] || 'fas fa-database'}"></i>
                </div>
                <div class="connection-details">
                    <div class="connection-name">${this.escapeHtml(conn.name)}</div>
                    <div class="connection-meta">
                        <span class="connection-badge ${conn.connType}">${conn.connType}</span>
                        <span class="connection-badge">${conn.dbType.toUpperCase()}</span>
                        <span class="connection-url" title="${this.escapeHtml(conn.jdbcUrl)}">${this.escapeHtml(conn.jdbcUrl)}</span>
                    </div>
                </div>
                <div class="connection-actions">
                    <button class="btn btn-secondary" onclick="window.converter.editConnection('${conn.id}')" title="Edit" data-testid="button-edit-conn-${conn.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-danger" onclick="window.converter.deleteConnection('${conn.id}')" title="Delete" data-testid="button-delete-conn-${conn.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    openConnectionForm(connectionId = null) {
        const modal = document.getElementById('connectionFormModal');
        const title = document.getElementById('connectionFormTitle');
        const editingId = document.getElementById('editingConnectionId');
        
        // Reset form
        document.getElementById('connName').value = '';
        document.getElementById('connType').value = 'source';
        document.getElementById('connDbType').value = 'oracle';
        document.getElementById('connJdbcUrl').value = '';
        document.getElementById('connUser').value = '';
        document.getElementById('connPassword').value = '';
        document.getElementById('connSchema').value = '';
        
        if (connectionId) {
            const connections = this.getConnections();
            const conn = connections.find(c => c.id === connectionId);
            if (conn) {
                title.textContent = 'Edit Connection';
                editingId.value = connectionId;
                document.getElementById('connName').value = conn.name;
                document.getElementById('connType').value = conn.connType;
                document.getElementById('connDbType').value = conn.dbType;
                document.getElementById('connJdbcUrl').value = conn.jdbcUrl;
                document.getElementById('connUser').value = conn.user || '';
                document.getElementById('connPassword').value = conn.password || '';
                document.getElementById('connSchema').value = conn.schema || '';
            }
        } else {
            title.textContent = 'Add Connection';
            editingId.value = '';
        }
        
        modal.classList.add('open');
    }
    
    saveConnection() {
        const name = document.getElementById('connName').value.trim();
        const connType = document.getElementById('connType').value;
        const dbType = document.getElementById('connDbType').value;
        const jdbcUrl = document.getElementById('connJdbcUrl').value.trim();
        const user = document.getElementById('connUser').value.trim();
        const password = document.getElementById('connPassword').value;
        const schema = document.getElementById('connSchema').value.trim();
        const editingId = document.getElementById('editingConnectionId').value;
        
        if (!name) {
            this.showToast('Connection name is required', 'error');
            return;
        }
        if (!jdbcUrl) {
            this.showToast('JDBC URL is required', 'error');
            return;
        }
        
        const connections = this.getConnections();
        
        // Check for duplicate names
        const duplicate = connections.find(c => c.name.toLowerCase() === name.toLowerCase() && c.id !== editingId);
        if (duplicate) {
            this.showToast('A connection with this name already exists', 'error');
            return;
        }
        
        if (editingId) {
            // Update existing
            const index = connections.findIndex(c => c.id === editingId);
            if (index !== -1) {
                connections[index] = { ...connections[index], name, connType, dbType, jdbcUrl, user, password, schema };
            }
        } else {
            // Add new
            connections.push({
                id: 'conn_' + Date.now(),
                name,
                connType,
                dbType,
                jdbcUrl,
                user,
                password,
                schema
            });
        }
        
        this.saveConnections(connections);
        this.closeSettingsModal('connectionFormModal');
        this.renderConnectionsList();
        this.showToast(editingId ? 'Connection updated' : 'Connection added', 'success');
    }
    
    editConnection(connectionId) {
        this.openConnectionForm(connectionId);
    }
    
    deleteConnection(connectionId) {
        if (!confirm('Are you sure you want to delete this connection?')) return;
        
        const connections = this.getConnections();
        const filtered = connections.filter(c => c.id !== connectionId);
        this.saveConnections(filtered);
        this.renderConnectionsList();
        this.showToast('Connection deleted', 'success');
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    saveFilePathSettings() {
        const settings = {
            sourceFilePath: document.getElementById('sourceFilePath').value,
            lookupFilePath: document.getElementById('lookupFilePath').value,
            targetFilePath: document.getElementById('targetFilePath').value,
            logFilePath: document.getElementById('logFilePath').value,
            checkpointPath: document.getElementById('checkpointPath').value,
            cloudStorageType: document.getElementById('cloudStorageType').value,
            cloudBasePath: document.getElementById('cloudBasePath').value
        };
        localStorage.setItem('filePathSettings', JSON.stringify(settings));
        this.closeSettingsModal('filePathModal');
        this.showToast('File path settings saved', 'success');
    }
    
    switchTool(tool) {
        const pysparkView = document.getElementById('pysparkConverterView');
        const expressionView = document.getElementById('expressionConverterView');
        const toolPySpark = document.getElementById('toolPySparkConverter');
        const toolExpression = document.getElementById('toolExpressionConverter');
        
        if (tool === 'pyspark') {
            if (pysparkView) pysparkView.style.display = '';
            if (expressionView) expressionView.style.display = 'none';
            if (toolPySpark) toolPySpark.classList.add('active');
            if (toolExpression) toolExpression.classList.remove('active');
        } else if (tool === 'expression') {
            if (pysparkView) pysparkView.style.display = 'none';
            if (expressionView) expressionView.style.display = 'block';
            if (toolPySpark) toolPySpark.classList.remove('active');
            if (toolExpression) toolExpression.classList.add('active');
            this.initExpressionConverter();
        }
    }
    
    initExpressionConverter() {
        const convertBtn = document.getElementById('convertExpressionBtn');
        const clearBtn = document.getElementById('clearExpressionBtn');
        const copyBtn = document.getElementById('copyPySparkExprBtn');
        
        if (convertBtn && !convertBtn.hasAttribute('data-initialized')) {
            convertBtn.setAttribute('data-initialized', 'true');
            convertBtn.addEventListener('click', () => this.convertExpression());
        }
        
        if (clearBtn && !clearBtn.hasAttribute('data-initialized')) {
            clearBtn.setAttribute('data-initialized', 'true');
            clearBtn.addEventListener('click', () => this.clearExpression());
        }
        
        if (copyBtn && !copyBtn.hasAttribute('data-initialized')) {
            copyBtn.setAttribute('data-initialized', 'true');
            copyBtn.addEventListener('click', () => this.copyPySparkExpression());
        }
        
        // Function item click to insert
        document.querySelectorAll('.function-item').forEach(item => {
            if (!item.hasAttribute('data-initialized')) {
                item.setAttribute('data-initialized', 'true');
                item.addEventListener('click', () => {
                    const infaFunc = item.getAttribute('data-infa');
                    const textarea = document.getElementById('infaExpression');
                    if (textarea) {
                        const start = textarea.selectionStart;
                        const end = textarea.selectionEnd;
                        const text = textarea.value;
                        textarea.value = text.substring(0, start) + infaFunc + '()' + text.substring(end);
                        textarea.focus();
                        textarea.setSelectionRange(start + infaFunc.length + 1, start + infaFunc.length + 1);
                    }
                });
            }
        });
    }
    
    async convertExpression() {
        const input = document.getElementById('infaExpression');
        const output = document.getElementById('pysparkExpressionOutput');
        
        if (!input || !output) return;
        
        const expression = input.value.trim();
        if (!expression) {
            this.showToast('Please enter an Informatica expression', 'warning');
            return;
        }
        
        try {
            const response = await fetch('/api/convert-expression', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ expression })
            });
            
            const result = await response.json();
            
            if (result.success) {
                output.innerHTML = `<code>${this.escapeHtml(result.pyspark_expression)}</code>`;
                this.showToast('Expression converted successfully', 'success');
            } else {
                output.innerHTML = `<span class="error-text">${this.escapeHtml(result.error || 'Conversion failed')}</span>`;
                this.showToast(result.error || 'Conversion failed', 'error');
            }
        } catch (error) {
            output.innerHTML = `<span class="error-text">Error: ${this.escapeHtml(error.message)}</span>`;
            this.showToast('Failed to convert expression', 'error');
        }
    }
    
    clearExpression() {
        const input = document.getElementById('infaExpression');
        const output = document.getElementById('pysparkExpressionOutput');
        
        if (input) input.value = '';
        if (output) output.innerHTML = '<span class="placeholder-text">Converted PySpark expression will appear here...</span>';
    }
    
    copyPySparkExpression() {
        const output = document.getElementById('pysparkExpressionOutput');
        if (!output) return;
        
        const code = output.querySelector('code');
        if (code) {
            navigator.clipboard.writeText(code.textContent).then(() => {
                this.showToast('Copied to clipboard', 'success');
            });
        } else {
            this.showToast('No expression to copy', 'warning');
        }
    }
    
    initTheme() {
        const savedTheme = localStorage.getItem('theme') || 'light';
        if (savedTheme === 'dark') {
            document.body.classList.add('dark');
            document.getElementById('themeToggle').innerHTML = '<i class="fas fa-sun"></i>';
        }
    }
    
    toggleTheme() {
        const isDark = document.body.classList.toggle('dark');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
        document.getElementById('themeToggle').innerHTML = isDark ? 
            '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    }
    
    handleDragOver(e) {
        e.preventDefault();
        e.currentTarget.classList.add('dragover');
    }
    
    handleDragLeave(e) {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
    }
    
    handleDrop(e) {
        e.preventDefault();
        e.currentTarget.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    }
    
    handleFileSelect(e) {
        const files = e.target.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    }
    
    processFile(file) {
        if (!file.name.toLowerCase().endsWith('.xml')) {
            this.showToast('Please select an XML file', 'error');
            return;
        }
        
        this.selectedFile = file;
        
        document.getElementById('fileName').textContent = file.name;
        document.getElementById('fileSize').textContent = this.formatFileSize(file.size);
        document.getElementById('fileInfo').classList.remove('hidden');
        document.getElementById('analyzeBtn').disabled = false;
        
        this.countXmlElements(file);
    }
    
    countXmlElements(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const parser = new DOMParser();
                const xmlDoc = parser.parseFromString(e.target.result, 'text/xml');
                const parserError = xmlDoc.querySelector('parsererror');
                
                if (parserError) {
                    document.getElementById('fileElements').textContent = 'Invalid XML';
                } else {
                    const allElements = xmlDoc.getElementsByTagName('*');
                    const elementCount = allElements.length;
                    document.getElementById('fileElements').textContent = 
                        elementCount.toLocaleString() + ' element' + (elementCount !== 1 ? 's' : '');
                }
            } catch (err) {
                document.getElementById('fileElements').textContent = 'Error parsing';
            }
        };
        reader.readAsText(file);
    }
    
    removeFile() {
        this.selectedFile = null;
        document.getElementById('fileInput').value = '';
        document.getElementById('fileInfo').classList.add('hidden');
        document.getElementById('analyzeBtn').disabled = true;
    }
    
    formatFileSize(bytes) {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    }
    
    async analyzeFile() {
        if (!this.selectedFile) return;
        
        this.setStatus('processing', 'Analyzing...');
        document.getElementById('analyzeBtn').disabled = true;
        
        const formData = new FormData();
        formData.append('file', this.selectedFile);
        
        try {
            const response = await fetch('/api/analyze', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.artifactId = result.artifact_id;
                this.analysisData = result.analysis;
                this.workflowAnalysis = result.workflow_analysis;
                this.configsData = result.configs || [];
                this.displayAnalysis(result.analysis);
                this.displayWorkflowAnalysis(result.workflow_analysis);
                this.displayConfigs(this.configsData);
                this.displayConnectors(result.analysis.mappings);
                this.displayPipelineDiagrams(result.analysis.mappings, result.workflow_analysis);
                this.displayRawJson(result);
                this.goToStep(2);
                this.showToast('Analysis complete', 'success');
            } else {
                this.showToast(result.error || 'Analysis failed', 'error');
            }
        } catch (error) {
            console.error('Analysis error:', error, error.message, error.stack);
            this.showToast('Failed to analyze file: ' + (error.message || 'Unknown error'), 'error');
        } finally {
            this.setStatus('ready', 'Ready');
            document.getElementById('analyzeBtn').disabled = false;
        }
    }
    
    displayAnalysis(analysis) {
        if (!analysis || !analysis.mappings) {
            console.error('Invalid analysis data:', analysis);
            return;
        }
        
        let totalSources = 0;
        let totalTargets = 0;
        let totalTransforms = 0;
        
        analysis.mappings.forEach(mapping => {
            totalSources += (mapping.sources || []).length;
            totalTargets += (mapping.targets || []).length;
            
            const ts = mapping.transform_summary || {};
            totalTransforms += (ts.source_qualifiers || 0) + (ts.expressions || 0) + (ts.filters || 0) + 
                              (ts.joiners || 0) + (ts.lookups || 0) + (ts.stored_procedures || 0) + 
                              (ts.update_strategies || 0) + (ts.aggregators || 0) + (ts.sorters || 0) +
                              (ts.routers || 0) + (ts.unions || 0) + (ts.others || 0);
        });
        
        document.getElementById('mappingCount').textContent = analysis.mapping_count;
        document.getElementById('sourceCount').textContent = totalSources;
        document.getElementById('targetCount').textContent = totalTargets;
        document.getElementById('transformCount').textContent = totalTransforms;
        
        if (analysis.mappings.length > 0) {
            const mapping = analysis.mappings[0];
            this.displayFlow(mapping.flow_text || '');
            this.displaySources(mapping.sources || []);
            this.displayTargets(mapping.targets || []);
            this.displayTransformSummary(mapping.transform_summary || {});
            this.displayAllMappingTransformations(analysis.mappings);
            this.displaySqlQueries(analysis.mappings);
            this.prepareConfigForm(mapping);
        }
    }
    
    displayFlow(flowText) {
        const flowDiagram = document.getElementById('flowDiagram');
        
        if (!flowText || flowText === 'No flow detected') {
            flowDiagram.innerHTML = '<p class="text-muted">No flow information available</p>';
            return;
        }
        
        const steps = flowText.split(' -> ');
        let html = '<div class="flow-container">';
        
        steps.forEach((step, index) => {
            const match = step.match(/(.+)\s*\((.+)\)/);
            const name = match ? match[1].trim() : step;
            const type = match ? match[2].trim() : '';
            
            let nodeClass = 'flow-node';
            if (type === 'SRC' || type.includes('Source')) nodeClass += ' source';
            else if (type === 'TGT' || type.includes('Target')) nodeClass += ' target';
            else nodeClass += ' transform';
            
            html += `<div class="${nodeClass}">
                <span class="node-name">${name}</span>
                ${type ? `<span class="node-type">${type}</span>` : ''}
            </div>`;
            
            if (index < steps.length - 1) {
                html += '<i class="fas fa-arrow-right flow-arrow"></i>';
            }
        });
        
        html += '</div>';
        flowDiagram.innerHTML = html;
    }
    
    displaySources(sources) {
        if (sources.length === 0) {
            document.getElementById('sqlSourcesList').innerHTML = '<p class="empty-message">No SQL sources found</p>';
            return;
        }
        
        // Count sources by type
        const fileSources = sources.filter(s => s.type === 'FILE');
        const sqlSources = sources.filter(s => s.type === 'SQL' || s.type === 'UNKNOWN');
        const sfdcSources = sources.filter(s => s.database_type && s.database_type.toLowerCase().includes('salesforce'));
        
        // Update counts
        document.querySelector('#totalSourcesCount .count-value').textContent = sources.length;
        document.querySelector('#fileSourcesCount .count-value').textContent = fileSources.length;
        document.querySelector('#sqlSourcesCount .count-value').textContent = sqlSources.length;
        document.querySelector('#sfdcSourcesCount .count-value').textContent = sfdcSources.length;
        
        // Display file sources
        if (fileSources.length > 0) {
            document.getElementById('fileSourcesList').innerHTML = fileSources.map(source => 
                this.renderSourceCard(source)
            ).join('');
        } else {
            document.getElementById('fileSourcesList').innerHTML = '<p class="empty-message">No file sources found</p>';
        }
        
        // Display SQL sources
        if (sqlSources.length > 0) {
            document.getElementById('sqlSourcesList').innerHTML = sqlSources.map(source => 
                this.renderSourceCard(source)
            ).join('');
        } else {
            document.getElementById('sqlSourcesList').innerHTML = '<p class="empty-message">No SQL sources found</p>';
        }
        
        // Bind expand/collapse events
        setTimeout(() => {
            document.querySelectorAll('.source-card-header').forEach(header => {
                header.addEventListener('click', () => {
                    const card = header.closest('.source-card');
                    card.classList.toggle('expanded');
                });
            });
        }, 100);
    }
    
    renderSourceCard(source) {
        const isStoredProc = source.database_type && source.database_type.toLowerCase().includes('stored');
        const sourceType = isStoredProc ? 'Stored Procedure' : 'Table';
        
        return `
            <div class="source-card" data-testid="source-card-${source.name}">
                <div class="source-card-header">
                    <div class="source-card-title">
                        <span class="source-name">${source.name}</span>
                        <span class="source-type-badge">${sourceType}</span>
                    </div>
                    <button class="expand-btn" data-testid="button-expand-${source.name}">
                        <i class="fas fa-chevron-down"></i>
                    </button>
                </div>
                <div class="source-card-meta">
                    ${source.db_name ? `<span><i class="fas fa-database"></i> Table: ${source.name}</span>` : ''}
                    ${source.db_name ? `<span><i class="fas fa-server"></i> Database: ${source.db_name}</span>` : ''}
                    ${source.database_type ? `<span><i class="fas fa-cog"></i> Type: ${source.database_type}</span>` : ''}
                    ${source.owner_name ? `<span><i class="fas fa-user"></i> Owner: ${source.owner_name}</span>` : ''}
                    <span><i class="fas fa-list"></i> Fields: ${source.field_count}</span>
                </div>
                <div class="source-card-body">
                    ${source.sql_query ? `
                        <div class="source-query-section">
                            <h5><i class="fas fa-code"></i> Source Query:</h5>
                            <pre class="sql-query-code"><code>${this.escapeHtml(source.sql_query)}</code></pre>
                        </div>
                    ` : ''}
                    <div class="source-fields-section">
                        <h5><i class="fas fa-th-list"></i> Source Fields (${source.field_count})</h5>
                        <div class="table-container">
                            <table class="data-table fields-table">
                                <thead>
                                    <tr>
                                        <th>Field Name</th>
                                        <th>Data Type</th>
                                        <th>Precision</th>
                                        <th>Scale</th>
                                        <th>Nullable</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${source.fields && source.fields.length > 0 ? 
                                        source.fields.map(field => `
                                            <tr>
                                                <td><code>${field.name}</code></td>
                                                <td>${field.datatype}</td>
                                                <td>${field.precision}</td>
                                                <td>${field.scale}</td>
                                                <td>${field.nullable ? '<i class="fas fa-check text-success"></i>' : '<i class="fas fa-times text-error"></i>'}</td>
                                            </tr>
                                        `).join('') : 
                                        '<tr><td colspan="5" class="text-center">No fields available</td></tr>'
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    displayTargets(targets) {
        if (targets.length === 0) {
            document.getElementById('sqlTargetsList').innerHTML = '<p class="empty-message">No SQL targets found</p>';
            return;
        }
        
        // Count targets by type
        const fileTargets = targets.filter(t => t.type === 'FILE');
        const sqlTargets = targets.filter(t => t.type === 'SQL' || !t.type);
        const sfdcTargets = targets.filter(t => t.type === 'SFDC');
        
        // Update counts
        document.querySelector('#totalTargetsCount .count-value').textContent = targets.length;
        document.querySelector('#fileTargetsCount .count-value').textContent = fileTargets.length;
        document.querySelector('#sqlTargetsCount .count-value').textContent = sqlTargets.length;
        document.querySelector('#sfdcTargetsCount .count-value').textContent = sfdcTargets.length;
        
        // Display file targets
        if (fileTargets.length > 0) {
            document.getElementById('fileTargetsList').innerHTML = fileTargets.map(target => 
                this.renderTargetCard(target)
            ).join('');
        } else {
            document.getElementById('fileTargetsList').innerHTML = '<p class="empty-message">No file targets found</p>';
        }
        
        // Display SQL targets
        if (sqlTargets.length > 0) {
            document.getElementById('sqlTargetsList').innerHTML = sqlTargets.map(target => 
                this.renderTargetCard(target)
            ).join('');
        } else {
            document.getElementById('sqlTargetsList').innerHTML = '<p class="empty-message">No SQL targets found</p>';
        }
        
        // Display SFDC targets
        if (sfdcTargets.length > 0) {
            document.getElementById('sfdcTargetsList').innerHTML = sfdcTargets.map(target => 
                this.renderTargetCard(target)
            ).join('');
        } else {
            document.getElementById('sfdcTargetsList').innerHTML = '<p class="empty-message">No SFDC targets found</p>';
        }
        
        // Bind expand/collapse events for targets
        setTimeout(() => {
            document.querySelectorAll('.target-card-header').forEach(header => {
                header.addEventListener('click', () => {
                    const card = header.closest('.target-card');
                    card.classList.toggle('expanded');
                });
            });
        }, 100);
    }
    
    renderTargetCard(target) {
        return `
            <div class="target-card" data-testid="target-card-${target.name}">
                <div class="target-card-header">
                    <div class="target-card-title">
                        <span class="target-name">${target.name}</span>
                        <span class="target-type-badge">Table</span>
                    </div>
                    <button class="expand-btn" data-testid="button-expand-target-${target.name}">
                        <i class="fas fa-chevron-down"></i>
                    </button>
                </div>
                <div class="target-card-meta">
                    <span><i class="fas fa-table"></i> Table: ${target.name}</span>
                    <span><i class="fas fa-database"></i> Database: ${target.db_name || 'N/A'}</span>
                    <span><i class="fas fa-cog"></i> Type: ${target.database_type || 'N/A'}</span>
                    <span><i class="fas fa-user"></i> Schema/Owner: ${target.owner_name || 'N/A'}</span>
                    <span><i class="fas fa-list"></i> Fields: ${target.field_count}</span>
                </div>
                <div class="target-pyspark-hint">
                    <i class="fas fa-code"></i>
                    <span>PySpark Write:</span>
                    <code>${target.pyspark_write || `df.write.jdbc(url, '${target.name}', properties)`}</code>
                </div>
                <div class="target-card-body">
                    <div class="target-fields-section">
                        <h5><i class="fas fa-th-list"></i> Target Fields (${target.field_count})</h5>
                        <div class="table-container">
                            <table class="data-table fields-table">
                                <thead>
                                    <tr>
                                        <th>Field Name</th>
                                        <th>Data Type</th>
                                        <th>Precision</th>
                                        <th>Scale</th>
                                        <th>Nullable</th>
                                        <th>Key</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${target.fields && target.fields.length > 0 ? 
                                        target.fields.map(field => `
                                            <tr>
                                                <td><code>${field.name}</code></td>
                                                <td>${field.datatype}</td>
                                                <td>${field.precision}</td>
                                                <td>${field.scale}</td>
                                                <td>${field.nullable ? '<i class="fas fa-check text-success"></i>' : '<i class="fas fa-times text-error"></i>'}</td>
                                                <td>${field.key_type || '-'}</td>
                                            </tr>
                                        `).join('') : 
                                        '<tr><td colspan="6" class="text-center">No fields available</td></tr>'
                                    }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    displayTransformSummary(summary) {
        const container = document.getElementById('transformSummary');
        if (!container) return;
        if (!summary) summary = {};
        
        const transforms = [
            { name: 'Source Qualifier', count: summary.source_qualifiers || 0 },
            { name: 'Expression', count: summary.expressions || 0 },
            { name: 'Filter', count: summary.filters || 0 },
            { name: 'Joiner', count: summary.joiners || 0 },
            { name: 'Lookup', count: summary.lookups || 0 },
            { name: 'Stored Procedure', count: summary.stored_procedures || 0 },
            { name: 'Update Strategy', count: summary.update_strategies || 0 },
            { name: 'Aggregator', count: summary.aggregators || 0 },
            { name: 'Sorter', count: summary.sorters || 0 },
            { name: 'Router', count: summary.routers || 0 },
            { name: 'Union', count: summary.unions || 0 },
            { name: 'Other', count: summary.others || 0 }
        ].filter(t => t.count > 0);
        
        container.innerHTML = transforms.map(t => `
            <div class="transform-badge">
                <span class="name">${t.name}</span>
                <span class="count">${t.count}</span>
            </div>
        `).join('');
    }
    
    displayAllMappingTransformations(mappings) {
        const container = document.getElementById('transformationsByMapping');
        if (!container) return;
        
        if (!mappings || mappings.length === 0) {
            container.innerHTML = '<p class="empty-message">No mappings found</p>';
            return;
        }
        
        let html = '';
        
        mappings.forEach((mapping, index) => {
            const transformations = mapping.transformations || [];
            const summary = mapping.transform_summary || {};
            const mappingName = mapping.mapping_name || `Mapping ${index + 1}`;
            
            // Group transformations by type
            const groups = {
                'Source Qualifier': [],
                'Expression': [],
                'Filter': [],
                'Joiner': [],
                'Lookup Procedure': [],
                'Stored Procedure': [],
                'Sorter': [],
                'Aggregator': [],
                'Router': [],
                'Union': [],
                'Update Strategy': [],
                'other': []
            };
            
            transformations.forEach(t => {
                if (groups[t.type] !== undefined) {
                    groups[t.type].push(t);
                } else {
                    groups['other'].push(t);
                }
            });
            
            // Build summary counts
            const countsHtml = [
                { name: 'Source Qualifier', count: summary.source_qualifiers || 0, icon: 'filter' },
                { name: 'Expression', count: summary.expressions || 0, icon: 'calculator' },
                { name: 'Filter', count: summary.filters || 0, icon: 'funnel-dollar' },
                { name: 'Joiner', count: summary.joiners || 0, icon: 'code-branch' },
                { name: 'Lookup', count: summary.lookups || 0, icon: 'search' },
                { name: 'Stored Proc', count: summary.stored_procedures || 0, icon: 'terminal' },
                { name: 'Sorter', count: summary.sorters || 0, icon: 'sort-amount-down' },
                { name: 'Aggregator', count: summary.aggregators || 0, icon: 'layer-group' },
                { name: 'Router', count: summary.routers || 0, icon: 'random' },
                { name: 'Union', count: summary.unions || 0, icon: 'object-group' },
                { name: 'Other', count: summary.others || 0, icon: 'puzzle-piece' }
            ].filter(t => t.count > 0).map(t => `
                <div class="transform-count-item">
                    <i class="fas fa-${t.icon}"></i>
                    <span class="count-value">${t.count}</span>
                    <span class="count-label">${t.name}</span>
                </div>
            `).join('');
            
            html += `
                <div class="mapping-transform-section ${index === 0 ? 'expanded' : ''}" data-testid="mapping-transform-${mappingName}">
                    <div class="mapping-transform-header" data-testid="button-expand-mapping-${mappingName}">
                        <div class="mapping-transform-title">
                            <i class="fas fa-project-diagram"></i>
                            <span class="mapping-name">${mappingName}</span>
                            <span class="transform-total-badge">${transformations.length} transformations</span>
                        </div>
                        <button class="expand-btn">
                            <i class="fas fa-chevron-down"></i>
                        </button>
                    </div>
                    <div class="mapping-transform-body">
                        <div class="transform-counts-row">
                            ${countsHtml || '<span class="text-muted">No transformations</span>'}
                        </div>
                        
                        ${this.renderTransformTypeSection('Source Qualifier', 'filter', groups['Source Qualifier'])}
                        ${this.renderTransformTypeSection('Expression', 'calculator', groups['Expression'])}
                        ${this.renderTransformTypeSection('Filter', 'funnel-dollar', groups['Filter'])}
                        ${this.renderTransformTypeSection('Joiner', 'code-branch', groups['Joiner'])}
                        ${this.renderTransformTypeSection('Lookup', 'search', groups['Lookup Procedure'])}
                        ${this.renderTransformTypeSection('Stored Procedure', 'terminal', groups['Stored Procedure'])}
                        ${this.renderTransformTypeSection('Sorter', 'sort-amount-down', groups['Sorter'])}
                        ${this.renderTransformTypeSection('Aggregator', 'layer-group', groups['Aggregator'])}
                        ${this.renderTransformTypeSection('Router', 'random', groups['Router'])}
                        ${this.renderTransformTypeSection('Union', 'object-group', groups['Union'])}
                        ${this.renderTransformTypeSection('Update Strategy', 'exchange-alt', groups['Update Strategy'])}
                        ${this.renderTransformTypeSection('Other', 'puzzle-piece', groups['other'])}
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
        
        // Bind expand/collapse events for mapping sections
        container.querySelectorAll('.mapping-transform-header').forEach(header => {
            header.addEventListener('click', () => {
                const section = header.closest('.mapping-transform-section');
                section.classList.toggle('expanded');
            });
        });
        
        // Bind expand/collapse events for transform cards
        container.querySelectorAll('.transform-card-header').forEach(header => {
            header.addEventListener('click', (e) => {
                e.stopPropagation();
                const card = header.closest('.transform-card');
                card.classList.toggle('expanded');
            });
        });
        
        // Bind click events for clickable expressions
        container.querySelectorAll('.clickable-expr').forEach(expr => {
            expr.addEventListener('click', (e) => {
                e.stopPropagation();
                const fullExpr = expr.getAttribute('data-full-expr');
                if (fullExpr) {
                    this.showExpressionPopup(fullExpr);
                }
            });
        });
    }
    
    showExpressionPopup(expression) {
        // Remove any existing popup
        const existingPopup = document.querySelector('.expr-popup-overlay');
        if (existingPopup) {
            existingPopup.remove();
        }
        
        const popupHtml = `
            <div class="expr-popup-overlay" data-testid="popup-expression-overlay">
                <div class="expr-popup" data-testid="popup-expression">
                    <div class="expr-popup-header">
                        <h4><i class="fas fa-code"></i> Full Expression</h4>
                        <button class="expr-popup-close" data-testid="button-close-popup">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="expr-popup-content">
                        <code>${this.escapeHtml(expression)}</code>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', popupHtml);
        
        // Bind close events
        const overlay = document.querySelector('.expr-popup-overlay');
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                overlay.remove();
            }
        });
        
        document.querySelector('.expr-popup-close').addEventListener('click', () => {
            overlay.remove();
        });
        
        // Close on Escape key
        const escHandler = (e) => {
            if (e.key === 'Escape') {
                overlay.remove();
                document.removeEventListener('keydown', escHandler);
            }
        };
        document.addEventListener('keydown', escHandler);
    }
    
    renderTransformTypeSection(title, icon, transforms) {
        if (!transforms || transforms.length === 0) return '';
        
        return `
            <div class="transform-type-section">
                <h4 class="transform-type-title">
                    <i class="fas fa-${icon}"></i>
                    ${title}
                    <span class="count-badge">${transforms.length}</span>
                </h4>
                <div class="transform-cards">
                    ${transforms.map(t => this.renderTransformCard(t)).join('')}
                </div>
            </div>
        `;
    }
    
    renderTransformCard(transform) {
        const typeIcons = {
            'Source Qualifier': 'filter',
            'Expression': 'calculator',
            'Filter': 'funnel-dollar',
            'Joiner': 'code-branch',
            'Lookup Procedure': 'search',
            'Stored Procedure': 'terminal',
            'Sorter': 'sort-amount-down',
            'Aggregator': 'layer-group',
            'Router': 'random',
            'Union': 'object-group',
            'Update Strategy': 'exchange-alt'
        };
        
        const icon = typeIcons[transform.type] || 'puzzle-piece';
        const fieldCount = transform.field_count || (transform.fields ? transform.fields.length : 0);
        const showAllFields = fieldCount <= 50;
        const displayFields = showAllFields ? (transform.fields || []) : (transform.fields || []).slice(0, 30);
        const remainingFields = showAllFields ? 0 : fieldCount - 30;
        
        return `
            <div class="transform-card" data-testid="transform-card-${transform.name}">
                <div class="transform-card-header">
                    <div class="transform-card-title">
                        <i class="fas fa-${icon}"></i>
                        <span class="transform-name" title="${this.escapeHtml(transform.name)}">${transform.name}</span>
                        <span class="transform-type-badge">${transform.type}</span>
                    </div>
                    <button class="expand-btn" data-testid="button-expand-transform-${transform.name}">
                        <i class="fas fa-chevron-down"></i>
                    </button>
                </div>
                <div class="transform-card-meta">
                    <span><i class="fas fa-list"></i> Fields: ${fieldCount}</span>
                    ${transform.description ? `<span title="${this.escapeHtml(transform.description)}"><i class="fas fa-info-circle"></i> ${this.truncateText(transform.description, 50)}</span>` : ''}
                </div>
                <div class="transform-pyspark-hint">
                    <i class="fas fa-code"></i>
                    <span>PySpark:</span>
                    <code title="${this.escapeHtml(transform.pyspark_equivalent || '')}">${transform.pyspark_equivalent || 'N/A'}</code>
                </div>
                <div class="transform-card-body">
                    <div class="transform-fields-section">
                        <h5><i class="fas fa-th-list"></i> Fields (${fieldCount})</h5>
                        <div class="table-container scrollable-table">
                            <table class="data-table fields-table">
                                <thead>
                                    <tr>
                                        <th>Field Name</th>
                                        <th>Data Type</th>
                                        <th>Port Type</th>
                                        <th>Expression</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${displayFields.length > 0 ? 
                                        displayFields.map(field => {
                                            const expr = field.expression ? String(field.expression) : '';
                                            const truncatedExpr = expr.length > 60 ? expr.substring(0, 60) + '...' : expr;
                                            return `
                                            <tr>
                                                <td><code title="${this.escapeHtml(field.name)}">${field.name}</code></td>
                                                <td title="${field.datatype || ''}">${field.datatype || '-'}</td>
                                                <td title="${field.port_type || ''}">${field.port_type || '-'}</td>
                                                <td class="expression-cell">
                                                    ${expr ? `
                                                        <div class="expression-value clickable-expr" 
                                                             title="${this.escapeHtml(expr)}"
                                                             data-full-expr="${this.escapeHtml(expr)}"
                                                             data-testid="expr-${field.name}">
                                                            <code>${this.escapeHtml(truncatedExpr)}</code>
                                                            ${expr.length > 60 ? '<i class="fas fa-expand-alt expand-icon"></i>' : ''}
                                                        </div>
                                                    ` : '-'}
                                                </td>
                                            </tr>
                                        `}).join('') : 
                                        '<tr><td colspan="4" class="text-center">No fields available</td></tr>'
                                    }
                                    ${remainingFields > 0 ? `
                                        <tr class="more-fields-row">
                                            <td colspan="4" class="text-center text-muted">
                                                <i class="fas fa-ellipsis-h"></i> 
                                                ${remainingFields} more fields not shown
                                            </td>
                                        </tr>
                                    ` : ''}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    truncateText(text, maxLength) {
        if (!text) return '';
        return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
    }
    
    displaySqlQueries(mappings) {
        const container = document.getElementById('sqlQueriesByMapping');
        if (!container) return;
        
        if (!mappings || mappings.length === 0) {
            container.innerHTML = '<p class="empty-message">No mappings found</p>';
            return;
        }
        
        let html = '';
        
        mappings.forEach((mapping, index) => {
            const sqlAnalysis = mapping.sql_analysis || {};
            const mappingName = mapping.mapping_name || `Mapping ${index + 1}`;
            
            const tables = sqlAnalysis.tables || [];
            const selectQueries = sqlAnalysis.select_queries || [];
            const storedProcedures = sqlAnalysis.stored_procedures || [];
            const lookupQueries = sqlAnalysis.lookup_queries || [];
            const filterConditions = sqlAnalysis.filter_conditions || [];
            const prePostSql = sqlAnalysis.pre_post_sql || [];
            
            const totalElements = tables.length + selectQueries.length + storedProcedures.length + 
                                  lookupQueries.length + filterConditions.length + prePostSql.length;
            
            html += `
                <div class="mapping-sql-section ${index === 0 ? 'expanded' : ''}" data-testid="mapping-sql-${mappingName}">
                    <div class="mapping-sql-header" data-testid="button-expand-sql-${mappingName}">
                        <div class="mapping-sql-title">
                            <i class="fas fa-project-diagram"></i>
                            <span class="mapping-name">${mappingName}</span>
                            <span class="sql-total-badge">${totalElements} SQL elements</span>
                        </div>
                        <button class="expand-btn">
                            <i class="fas fa-chevron-down"></i>
                        </button>
                    </div>
                    <div class="mapping-sql-body">
                        ${this.renderSqlTablesSection(tables)}
                        ${this.renderSelectQueriesSection(selectQueries)}
                        ${this.renderStoredProceduresSection(storedProcedures)}
                        ${this.renderLookupQueriesSection(lookupQueries)}
                        ${this.renderFilterConditionsSection(filterConditions)}
                        ${this.renderPrePostSqlSection(prePostSql)}
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
        
        // Bind expand/collapse events for mapping sections
        container.querySelectorAll('.mapping-sql-header').forEach(header => {
            header.addEventListener('click', () => {
                const section = header.closest('.mapping-sql-section');
                section.classList.toggle('expanded');
            });
        });
        
        // Bind click events for clickable SQL code
        container.querySelectorAll('.clickable-sql').forEach(sqlEl => {
            sqlEl.addEventListener('click', (e) => {
                e.stopPropagation();
                const fullSql = sqlEl.getAttribute('data-full-sql');
                if (fullSql) {
                    this.showSqlPopup(fullSql, sqlEl.getAttribute('data-sql-title') || 'SQL Query');
                }
            });
        });
    }
    
    renderSqlTablesSection(tables) {
        if (!tables || tables.length === 0) return '';
        
        // Group tables by type
        const sourcesTables = tables.filter(t => t.type === 'SOURCE');
        const targetsTables = tables.filter(t => t.type === 'TARGET');
        const lookupTables = tables.filter(t => t.type === 'LOOKUP');
        
        return `
            <div class="sql-section">
                <h4 class="sql-section-title">
                    <i class="fas fa-table"></i>
                    Tables
                    <span class="count-badge">${tables.length}</span>
                </h4>
                <div class="table-container scrollable-table">
                    <table class="data-table sql-table">
                        <thead>
                            <tr>
                                <th>Table Name</th>
                                <th>Type</th>
                                <th>Owner</th>
                                <th>Database</th>
                                <th>DB Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${tables.map(table => `
                                <tr>
                                    <td><code title="${this.escapeHtml(table.name)}">${table.name}</code></td>
                                    <td><span class="type-badge type-${table.type.toLowerCase()}">${table.type}</span></td>
                                    <td title="${table.owner || ''}">${table.owner || '-'}</td>
                                    <td title="${table.database || ''}">${table.database || '-'}</td>
                                    <td title="${table.database_type || ''}">${table.database_type || '-'}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }
    
    renderSelectQueriesSection(queries) {
        if (!queries || queries.length === 0) return '';
        
        return `
            <div class="sql-section">
                <h4 class="sql-section-title">
                    <i class="fas fa-search"></i>
                    SELECT Queries
                    <span class="count-badge">${queries.length}</span>
                </h4>
                <div class="sql-queries-list">
                    ${queries.map(query => `
                        <div class="sql-query-card">
                            <div class="sql-query-header">
                                <div class="sql-query-info">
                                    <span class="sql-query-name">${query.name}</span>
                                    <span class="sql-query-type-badge">${query.type}</span>
                                </div>
                            </div>
                            <div class="sql-query-content clickable-sql" 
                                 data-full-sql="${this.escapeHtml(query.query)}"
                                 data-sql-title="${this.escapeHtml(query.name)}"
                                 data-testid="sql-query-${query.name}">
                                <pre><code>${this.escapeHtml(this.truncateText(query.query, 500))}</code></pre>
                                ${query.query.length > 500 ? '<div class="click-to-expand"><i class="fas fa-expand-alt"></i> Click to view full query</div>' : ''}
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    renderStoredProceduresSection(procedures) {
        if (!procedures || procedures.length === 0) return '';
        
        return `
            <div class="sql-section">
                <h4 class="sql-section-title">
                    <i class="fas fa-terminal"></i>
                    Stored Procedures
                    <span class="count-badge">${procedures.length}</span>
                </h4>
                <div class="sql-queries-list">
                    ${procedures.map(sp => `
                        <div class="sql-query-card stored-proc">
                            <div class="sql-query-header">
                                <div class="sql-query-info">
                                    <span class="sql-query-name">${sp.name}</span>
                                    <span class="sql-query-type-badge">${sp.type}</span>
                                </div>
                                <span class="transformation-ref">Transformation: ${sp.transformation}</span>
                            </div>
                            <div class="sql-query-content ${sp.call_text !== 'No call text defined' ? 'clickable-sql' : ''}"
                                 ${sp.call_text !== 'No call text defined' ? `data-full-sql="${this.escapeHtml(sp.call_text)}" data-sql-title="${this.escapeHtml(sp.name)}"` : ''}
                                 data-testid="sp-${sp.name}">
                                <pre><code>${sp.call_text !== 'No call text defined' ? this.escapeHtml(this.truncateText(sp.call_text, 300)) : '<span class="text-muted">No call text defined</span>'}</code></pre>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    renderLookupQueriesSection(queries) {
        if (!queries || queries.length === 0) return '';
        
        return `
            <div class="sql-section">
                <h4 class="sql-section-title">
                    <i class="fas fa-search-plus"></i>
                    Lookup Queries
                    <span class="count-badge">${queries.length}</span>
                </h4>
                <div class="sql-queries-list">
                    ${queries.map(query => `
                        <div class="sql-query-card lookup">
                            <div class="sql-query-header">
                                <div class="sql-query-info">
                                    <span class="sql-query-name">${query.name}</span>
                                    <span class="sql-query-type-badge">${query.type}</span>
                                </div>
                                ${query.table ? `<span class="table-ref"><i class="fas fa-table"></i> ${query.table}</span>` : ''}
                            </div>
                            <div class="sql-query-content clickable-sql"
                                 data-full-sql="${this.escapeHtml(query.query)}"
                                 data-sql-title="${this.escapeHtml(query.name)}"
                                 data-testid="lookup-${query.name}">
                                <pre><code>${this.escapeHtml(this.truncateText(query.query, 400))}</code></pre>
                                ${query.query.length > 400 ? '<div class="click-to-expand"><i class="fas fa-expand-alt"></i> Click to view full query</div>' : ''}
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    renderFilterConditionsSection(filters) {
        if (!filters || filters.length === 0) return '';
        
        return `
            <div class="sql-section">
                <h4 class="sql-section-title">
                    <i class="fas fa-filter"></i>
                    Filter Conditions
                    <span class="count-badge">${filters.length}</span>
                </h4>
                <div class="sql-queries-list">
                    ${filters.map(filter => `
                        <div class="sql-query-card filter">
                            <div class="sql-query-header">
                                <div class="sql-query-info">
                                    <span class="sql-query-name">${filter.name}</span>
                                    <span class="sql-query-type-badge">${filter.type}</span>
                                </div>
                            </div>
                            <div class="sql-query-content" data-testid="filter-${filter.name}">
                                <pre><code>${this.escapeHtml(filter.condition)}</code></pre>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    renderPrePostSqlSection(sqlList) {
        if (!sqlList || sqlList.length === 0) {
            return `
                <div class="sql-section">
                    <h4 class="sql-section-title">
                        <i class="fas fa-code"></i>
                        Pre/Post SQL
                    </h4>
                    <p class="empty-message">No Pre/Post SQL found</p>
                </div>
            `;
        }
        
        return `
            <div class="sql-section">
                <h4 class="sql-section-title">
                    <i class="fas fa-code"></i>
                    Pre/Post SQL
                    <span class="count-badge">${sqlList.length}</span>
                </h4>
                <div class="sql-queries-list">
                    ${sqlList.map(sql => `
                        <div class="sql-query-card prepost">
                            <div class="sql-query-header">
                                <div class="sql-query-info">
                                    <span class="sql-query-name">${sql.name}</span>
                                    <span class="sql-query-type-badge">${sql.type}</span>
                                </div>
                            </div>
                            <div class="sql-query-content clickable-sql"
                                 data-full-sql="${this.escapeHtml(sql.sql)}"
                                 data-sql-title="${this.escapeHtml(sql.name + ' - ' + sql.type)}"
                                 data-testid="prepost-${sql.name}">
                                <pre><code>${this.escapeHtml(this.truncateText(sql.sql, 300))}</code></pre>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    showSqlPopup(sql, title) {
        // Remove any existing popup
        const existingPopup = document.querySelector('.expr-popup-overlay');
        if (existingPopup) {
            existingPopup.remove();
        }
        
        const popupHtml = `
            <div class="expr-popup-overlay" data-testid="popup-sql-overlay">
                <div class="expr-popup sql-popup" data-testid="popup-sql">
                    <div class="expr-popup-header">
                        <h4><i class="fas fa-database"></i> ${this.escapeHtml(title)}</h4>
                        <button class="expr-popup-close" data-testid="button-close-sql-popup">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="expr-popup-content sql-popup-content">
                        <pre><code>${this.escapeHtml(sql)}</code></pre>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', popupHtml);
        
        // Bind close events
        const overlay = document.querySelector('.expr-popup-overlay');
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                overlay.remove();
            }
        });
        
        document.querySelector('.expr-popup-close').addEventListener('click', () => {
            overlay.remove();
        });
        
        // Close on Escape key
        const escHandler = (e) => {
            if (e.key === 'Escape') {
                overlay.remove();
                document.removeEventListener('keydown', escHandler);
            }
        };
        document.addEventListener('keydown', escHandler);
    }
    
    displayConfigs(configs) {
        const container = document.getElementById('configsContainer');
        if (!container) return;
        
        if (!configs || configs.length === 0) {
            container.innerHTML = '<p class="empty-message">No configurations found in this XML file</p>';
            return;
        }
        
        let html = '';
        
        configs.forEach((config, index) => {
            const attributes = config.attributes || [];
            
            // Group attributes by category
            const categories = {
                'Memory & Performance': [],
                'Logging': [],
                'Error Handling': [],
                'Partitioning': [],
                'Date/Time': [],
                'Other': []
            };
            
            attributes.forEach(attr => {
                const name = attr.name.toLowerCase();
                if (name.includes('memory') || name.includes('buffer') || name.includes('cache') || name.includes('pipeline') || name.includes('optimization')) {
                    categories['Memory & Performance'].push(attr);
                } else if (name.includes('log') || name.includes('tracing') || name.includes('save session')) {
                    categories['Logging'].push(attr);
                } else if (name.includes('error') || name.includes('stop') || name.includes('recovery')) {
                    categories['Error Handling'].push(attr);
                } else if (name.includes('partition') || name.includes('grid')) {
                    categories['Partitioning'].push(attr);
                } else if (name.includes('date') || name.includes('time') || name.includes('timestamp')) {
                    categories['Date/Time'].push(attr);
                } else {
                    categories['Other'].push(attr);
                }
            });
            
            html += `
                <div class="config-section ${index === 0 ? 'expanded' : ''}" data-testid="config-${config.name}">
                    <div class="config-header" data-testid="button-expand-config-${config.name}">
                        <div class="config-title">
                            <i class="fas fa-cog"></i>
                            <span class="config-name">${this.escapeHtml(config.name)}</span>
                            ${config.is_default ? '<span class="default-badge">Default</span>' : ''}
                            <span class="attr-count-badge">${attributes.length} attributes</span>
                        </div>
                        <button class="expand-btn">
                            <i class="fas fa-chevron-down"></i>
                        </button>
                    </div>
                    <div class="config-body">
                        ${config.description ? `<p class="config-description"><i class="fas fa-info-circle"></i> ${this.escapeHtml(config.description)}</p>` : ''}
                        ${config.version ? `<p class="config-version">Version: ${this.escapeHtml(config.version)}</p>` : ''}
                        
                        ${Object.entries(categories).map(([category, attrs]) => {
                            if (attrs.length === 0) return '';
                            return `
                                <div class="config-category">
                                    <h4 class="category-title">
                                        <i class="fas ${this.getCategoryIcon(category)}"></i>
                                        ${category}
                                        <span class="count-badge">${attrs.length}</span>
                                    </h4>
                                    <div class="table-container scrollable-table">
                                        <table class="data-table config-table">
                                            <thead>
                                                <tr>
                                                    <th>Attribute</th>
                                                    <th>Value</th>
                                                    <th>Description</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                ${attrs.map(attr => `
                                                    <tr>
                                                        <td><code title="${this.escapeHtml(attr.name)}">${this.escapeHtml(attr.name)}</code></td>
                                                        <td>
                                                            ${attr.value ? 
                                                                `<span class="attr-value" title="${this.escapeHtml(attr.value)}">${this.escapeHtml(this.truncateText(attr.value, 50))}</span>` : 
                                                                '<span class="text-muted">-</span>'
                                                            }
                                                        </td>
                                                        <td>
                                                            ${attr.description ? 
                                                                `<span class="attr-desc" title="${this.escapeHtml(attr.description)}">${this.escapeHtml(attr.description)}</span>` : 
                                                                '<span class="text-muted">-</span>'
                                                            }
                                                        </td>
                                                    </tr>
                                                `).join('')}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
        
        // Bind expand/collapse events
        container.querySelectorAll('.config-header').forEach(header => {
            header.addEventListener('click', () => {
                const section = header.closest('.config-section');
                section.classList.toggle('expanded');
            });
        });
    }
    
    getCategoryIcon(category) {
        const icons = {
            'Memory & Performance': 'fa-microchip',
            'Logging': 'fa-file-alt',
            'Error Handling': 'fa-exclamation-triangle',
            'Partitioning': 'fa-th-large',
            'Date/Time': 'fa-clock',
            'Other': 'fa-cog'
        };
        return icons[category] || 'fa-cog';
    }
    
    displayConnectors(mappings) {
        const container = document.getElementById('connectorsContainer');
        if (!container) return;
        
        if (!mappings || mappings.length === 0) {
            container.innerHTML = '<p class="empty-message">No mappings found</p>';
            return;
        }
        
        let html = '';
        
        mappings.forEach((mapping, index) => {
            const connAnalysis = mapping.connectors_analysis || {};
            const connectors = connAnalysis.connectors || [];
            const summary = connAnalysis.summary || {};
            const bySource = connAnalysis.by_source_instance || {};
            const mappingName = mapping.mapping_name || `Mapping ${index + 1}`;
            const totalCount = connAnalysis.total_count || connectors.length;
            
            html += `
                <div class="connector-mapping-section ${index === 0 ? 'expanded' : ''}" data-testid="connector-mapping-${mappingName}">
                    <div class="connector-mapping-header" data-testid="button-expand-connector-${mappingName}">
                        <div class="connector-mapping-title">
                            <i class="fas fa-project-diagram"></i>
                            <span class="mapping-name">${this.escapeHtml(mappingName)}</span>
                            <span class="connector-count-badge">${totalCount} connectors</span>
                        </div>
                        <button class="expand-btn">
                            <i class="fas fa-chevron-down"></i>
                        </button>
                    </div>
                    <div class="connector-mapping-body">
                        ${this.renderConnectorSummary(summary)}
                        ${this.renderConnectorsBySource(bySource)}
                        ${this.renderConnectorsTable(connectors)}
                    </div>
                </div>
            `;
        });
        
        container.innerHTML = html;
        
        // Bind expand/collapse events
        container.querySelectorAll('.connector-mapping-header').forEach(header => {
            header.addEventListener('click', () => {
                const section = header.closest('.connector-mapping-section');
                section.classList.toggle('expanded');
            });
        });
        
        // Bind source instance expand/collapse
        container.querySelectorAll('.source-instance-header').forEach(header => {
            header.addEventListener('click', (e) => {
                e.stopPropagation();
                const section = header.closest('.source-instance-section');
                section.classList.toggle('expanded');
            });
        });
    }
    
    renderConnectorSummary(summary) {
        if (!summary) return '';
        
        const items = [
            { label: 'Source → SQ', count: summary.source_to_sq || 0, icon: 'fa-database', color: 'success' },
            { label: 'SQ → Transform', count: summary.sq_to_transform || 0, icon: 'fa-cogs', color: 'info' },
            { label: 'Transform → Transform', count: summary.transform_to_transform || 0, icon: 'fa-exchange-alt', color: 'warning' },
            { label: 'Transform → Target', count: summary.transform_to_target || 0, icon: 'fa-bullseye', color: 'primary' }
        ].filter(item => item.count > 0);
        
        if (items.length === 0) return '';
        
        return `
            <div class="connector-summary">
                <h4 class="connector-section-title">
                    <i class="fas fa-chart-bar"></i>
                    Flow Summary
                </h4>
                <div class="connector-summary-cards">
                    ${items.map(item => `
                        <div class="summary-card summary-card-${item.color}">
                            <div class="summary-card-icon">
                                <i class="fas ${item.icon}"></i>
                            </div>
                            <div class="summary-card-content">
                                <span class="summary-card-count">${item.count}</span>
                                <span class="summary-card-label">${item.label}</span>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    renderConnectorsBySource(bySource) {
        if (!bySource || Object.keys(bySource).length === 0) return '';
        
        const sources = Object.entries(bySource);
        
        return `
            <div class="connectors-by-source">
                <h4 class="connector-section-title">
                    <i class="fas fa-sitemap"></i>
                    Connections by Source Instance
                    <span class="count-badge">${sources.length} sources</span>
                </h4>
                <div class="source-instances-list">
                    ${sources.map(([sourceName, data], idx) => `
                        <div class="source-instance-section ${idx === 0 ? 'expanded' : ''}" data-testid="source-instance-${sourceName}">
                            <div class="source-instance-header">
                                <div class="source-instance-info">
                                    <i class="fas fa-arrow-right"></i>
                                    <span class="source-name">${this.escapeHtml(sourceName)}</span>
                                    <span class="instance-type-badge">${this.escapeHtml(data.type || 'Unknown')}</span>
                                    <span class="connection-count">${data.connections.length} outbound</span>
                                </div>
                                <button class="expand-btn">
                                    <i class="fas fa-chevron-down"></i>
                                </button>
                            </div>
                            <div class="source-instance-body">
                                <div class="table-container scrollable-table">
                                    <table class="data-table connector-table">
                                        <thead>
                                            <tr>
                                                <th>From Field</th>
                                                <th></th>
                                                <th>To Instance</th>
                                                <th>To Field</th>
                                                <th>To Type</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${data.connections.map(conn => `
                                                <tr>
                                                    <td><code title="${this.escapeHtml(conn.field)}">${this.escapeHtml(conn.field)}</code></td>
                                                    <td><i class="fas fa-long-arrow-alt-right connector-arrow"></i></td>
                                                    <td><strong title="${this.escapeHtml(conn.to_instance)}">${this.escapeHtml(conn.to_instance)}</strong></td>
                                                    <td><code title="${this.escapeHtml(conn.to_field)}">${this.escapeHtml(conn.to_field)}</code></td>
                                                    <td><span class="instance-type-badge small">${this.escapeHtml(conn.to_type || 'Unknown')}</span></td>
                                                </tr>
                                            `).join('')}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    renderConnectorsTable(connectors) {
        if (!connectors || connectors.length === 0) return '';
        
        return `
            <div class="all-connectors">
                <h4 class="connector-section-title">
                    <i class="fas fa-list"></i>
                    All Connectors
                    <span class="count-badge">${connectors.length}</span>
                </h4>
                <div class="table-container scrollable-table">
                    <table class="data-table connector-table full-connector-table">
                        <thead>
                            <tr>
                                <th>From Instance</th>
                                <th>From Type</th>
                                <th>From Field</th>
                                <th></th>
                                <th>To Instance</th>
                                <th>To Type</th>
                                <th>To Field</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${connectors.map(conn => `
                                <tr>
                                    <td><strong title="${this.escapeHtml(conn.from_instance)}">${this.escapeHtml(this.truncateText(conn.from_instance, 30))}</strong></td>
                                    <td><span class="instance-type-badge small">${this.escapeHtml(conn.from_type || 'Unknown')}</span></td>
                                    <td><code title="${this.escapeHtml(conn.from_field)}">${this.escapeHtml(this.truncateText(conn.from_field, 25))}</code></td>
                                    <td><i class="fas fa-long-arrow-alt-right connector-arrow"></i></td>
                                    <td><strong title="${this.escapeHtml(conn.to_instance)}">${this.escapeHtml(this.truncateText(conn.to_instance, 30))}</strong></td>
                                    <td><span class="instance-type-badge small">${this.escapeHtml(conn.to_type || 'Unknown')}</span></td>
                                    <td><code title="${this.escapeHtml(conn.to_field)}">${this.escapeHtml(this.truncateText(conn.to_field, 25))}</code></td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }
    
    displayPipelineDiagrams(mappings, workflowAnalysis) {
        const pipelineContainer = document.getElementById('pipelineDiagramsContainer');
        const workflowContainer = document.getElementById('workflowDiagramContainer');
        
        // Render mapping pipeline diagrams
        if (pipelineContainer) {
            if (!mappings || mappings.length === 0) {
                pipelineContainer.innerHTML = '<p class="empty-message">No mappings found</p>';
            } else {
                let html = '';
                mappings.forEach((mapping, index) => {
                    html += this.renderMappingPipelineDiagram(mapping, index);
                });
                pipelineContainer.innerHTML = html;
            }
        }
        
        // Render workflow diagram
        if (workflowContainer) {
            if (!workflowAnalysis || !workflowAnalysis.tasks || workflowAnalysis.tasks.length === 0) {
                workflowContainer.innerHTML = '<p class="empty-message">No workflow data available</p>';
            } else {
                workflowContainer.innerHTML = this.renderWorkflowDiagram(workflowAnalysis);
            }
        }
    }
    
    renderMappingPipelineDiagram(mapping, index) {
        const mainFlow = mapping.main_flow || [];
        const flowText = mapping.flow_text || '';
        const mappingName = mapping.mapping_name || `Mapping ${index + 1}`;
        
        // Build flow nodes from main_flow
        let flowNodes = [];
        if (mainFlow.length > 0) {
            flowNodes = mainFlow.map(step => ({
                name: step.instance_name,
                type: step.instance_type,
                shortType: this.getShortType(step.instance_type)
            }));
        } else if (flowText) {
            // Parse flow_text as fallback
            const parts = flowText.split(' -> ');
            flowNodes = parts.map(part => {
                const match = part.match(/^(.+?)\s*\((.+?)\)$/);
                if (match) {
                    return { name: match[1], type: match[2], shortType: match[2] };
                }
                return { name: part, type: 'Unknown', shortType: '?' };
            });
        }
        
        if (flowNodes.length === 0) {
            return `
                <div class="pipeline-mapping-card" data-testid="pipeline-${mappingName}">
                    <div class="pipeline-mapping-header">
                        <i class="fas fa-project-diagram"></i>
                        <span class="mapping-name">${this.escapeHtml(mappingName)}</span>
                    </div>
                    <div class="pipeline-diagram-empty">
                        <p>No pipeline flow detected for this mapping</p>
                    </div>
                </div>
            `;
        }
        
        return `
            <div class="pipeline-mapping-card" data-testid="pipeline-${mappingName}">
                <div class="pipeline-mapping-header">
                    <i class="fas fa-project-diagram"></i>
                    <span class="mapping-name">${this.escapeHtml(mappingName)}</span>
                    <span class="pipeline-step-count">${flowNodes.length} steps</span>
                </div>
                <div class="pipeline-diagram-wrapper">
                    <div class="pipeline-flow-diagram">
                        ${flowNodes.map((node, idx) => `
                            <div class="pipeline-node ${this.getNodeColorClass(node.type)}" title="${this.escapeHtml(node.name)} (${this.escapeHtml(node.type)})">
                                <div class="node-icon">${this.getNodeIcon(node.type)}</div>
                                <div class="node-content">
                                    <span class="node-type">${this.escapeHtml(node.shortType)}</span>
                                    <span class="node-name">${this.escapeHtml(this.truncateText(node.name, 20))}</span>
                                </div>
                            </div>
                            ${idx < flowNodes.length - 1 ? '<div class="pipeline-arrow"><i class="fas fa-arrow-right"></i></div>' : ''}
                        `).join('')}
                    </div>
                </div>
                <div class="pipeline-flow-text">
                    <code>${this.escapeHtml(flowText || 'No flow text')}</code>
                </div>
            </div>
        `;
    }
    
    renderWorkflowDiagram(workflowAnalysis) {
        const tasks = workflowAnalysis.tasks || [];
        const workflows = workflowAnalysis.workflows || [];
        const sessions = workflowAnalysis.sessions || [];
        const schedulers = workflowAnalysis.schedulers || [];
        const workflowVariables = workflowAnalysis.workflow_variables || [];
        
        const workflowName = workflows.length > 0 ? workflows[0].name : 'Workflow';
        const workflowDesc = workflows.length > 0 ? workflows[0].description : '';
        
        // Create session lookup by name for mapping info
        const sessionMap = {};
        sessions.forEach(s => { sessionMap[s.name] = s; });
        
        // Create task nodes with session details
        const taskNodes = tasks.filter(t => t.type !== 'Start').map(task => {
            const sessionInfo = sessionMap[task.name] || sessionMap[task.name.replace('s_', '')] || null;
            return {
                name: task.name,
                type: task.type,
                pyspark: task.pyspark_equivalent || 'PySpark Task',
                mapping: sessionInfo ? sessionInfo.mapping_name : null,
                transformCount: sessionInfo ? sessionInfo.transformation_count : 0
            };
        });
        
        // Render workflow variables section
        const variablesHtml = workflowVariables.length > 0 ? `
            <div class="workflow-detail-section">
                <div class="workflow-detail-header">
                    <i class="fas fa-code"></i>
                    <span>Workflow Variables (${workflowVariables.length})</span>
                </div>
                <div class="workflow-variables-list">
                    ${workflowVariables.map(v => `
                        <div class="workflow-variable-item">
                            <span class="var-name">${this.escapeHtml(v.name)}</span>
                            <span class="var-type">${this.escapeHtml(v.datatype)}</span>
                            <span class="var-default" title="Default: ${this.escapeHtml(v.default_value || 'N/A')}">${this.escapeHtml(this.truncateText(v.default_value || 'N/A', 30))}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : '';
        
        // Render scheduler section
        const schedulerHtml = schedulers.length > 0 ? `
            <div class="workflow-detail-section">
                <div class="workflow-detail-header">
                    <i class="fas fa-clock"></i>
                    <span>Scheduler</span>
                </div>
                <div class="scheduler-details">
                    ${schedulers.map(s => `
                        <div class="scheduler-item">
                            <div class="scheduler-main">
                                <span class="scheduler-name">${this.escapeHtml(s.name)}</span>
                                <span class="scheduler-type-badge ${this.getScheduleTypeClass(s.schedule_type)}">${this.escapeHtml(s.schedule_type || 'ONDEMAND')}</span>
                                ${s.reusable ? '<span class="reusable-badge">Reusable</span>' : ''}
                            </div>
                            ${s.start_date || s.end_date ? `
                                <div class="scheduler-dates">
                                    ${s.start_date ? `<span><i class="fas fa-calendar-alt"></i> Start: ${this.escapeHtml(s.start_date)}</span>` : ''}
                                    ${s.end_date ? `<span><i class="fas fa-calendar-times"></i> End: ${this.escapeHtml(s.end_date)}</span>` : ''}
                                </div>
                            ` : ''}
                            ${s.repeat_interval ? `<div class="scheduler-interval"><i class="fas fa-sync"></i> Repeat: ${this.escapeHtml(s.repeat_interval)}</div>` : ''}
                            <div class="scheduler-pyspark"><i class="fas fa-arrow-right"></i> ${this.escapeHtml(s.pyspark_equivalent)}</div>
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : '';
        
        // Render sessions with mapping names section
        const sessionsHtml = sessions.length > 0 ? `
            <div class="workflow-detail-section">
                <div class="workflow-detail-header">
                    <i class="fas fa-cogs"></i>
                    <span>Sessions (${sessions.length})</span>
                </div>
                <div class="sessions-list">
                    ${sessions.map(s => `
                        <div class="session-detail-item">
                            <div class="session-header-row">
                                <span class="session-name">${this.escapeHtml(s.name)}</span>
                                ${s.is_valid ? '<span class="valid-badge">Valid</span>' : '<span class="invalid-badge">Invalid</span>'}
                            </div>
                            <div class="session-mapping-row">
                                <i class="fas fa-project-diagram"></i>
                                <span class="mapping-name-ref">${this.escapeHtml(s.mapping_name || 'No mapping')}</span>
                                <span class="transform-count">${s.transformation_count || 0} transformations</span>
                            </div>
                            ${(s.pre_session_components && s.pre_session_components.length > 0) || 
                              (s.post_success_components && s.post_success_components.length > 0) || 
                              (s.post_failure_components && s.post_failure_components.length > 0) ? `
                                <div class="session-components">
                                    ${s.pre_session_components && s.pre_session_components.length > 0 ? `
                                        <span class="component-badge pre"><i class="fas fa-play"></i> Pre: ${s.pre_session_components.length}</span>
                                    ` : ''}
                                    ${s.post_success_components && s.post_success_components.length > 0 ? `
                                        <span class="component-badge success"><i class="fas fa-check"></i> Post-Success: ${s.post_success_components.length}</span>
                                    ` : ''}
                                    ${s.post_failure_components && s.post_failure_components.length > 0 ? `
                                        <span class="component-badge failure"><i class="fas fa-times"></i> Post-Failure: ${s.post_failure_components.length}</span>
                                    ` : ''}
                                </div>
                            ` : ''}
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : '';
        
        if (tasks.length === 0 && sessions.length === 0) {
            return '<p class="empty-message">No workflow data available</p>';
        }
        
        return `
            <div class="workflow-diagram-card detailed">
                <div class="workflow-diagram-header">
                    <i class="fas fa-sitemap"></i>
                    <span class="workflow-name">${this.escapeHtml(workflowName)}</span>
                    <span class="task-count">${taskNodes.length} tasks</span>
                </div>
                ${workflowDesc ? `<div class="workflow-description"><i class="fas fa-info-circle"></i> ${this.escapeHtml(workflowDesc)}</div>` : ''}
                
                <div class="workflow-details-container">
                    ${schedulerHtml}
                    ${variablesHtml}
                    ${sessionsHtml}
                </div>
                
                <div class="workflow-flow-section">
                    <div class="workflow-flow-header">
                        <i class="fas fa-stream"></i>
                        <span>Task Flow</span>
                    </div>
                    <div class="workflow-flow-diagram">
                        <div class="workflow-start-node">
                            <i class="fas fa-play-circle"></i>
                            <span>Start</span>
                        </div>
                        <div class="workflow-arrow"><i class="fas fa-arrow-down"></i></div>
                        ${taskNodes.map((task, idx) => `
                            <div class="workflow-task-node ${task.mapping ? 'has-mapping' : ''}" title="${this.escapeHtml(task.pyspark)}">
                                <div class="task-icon">${this.getTaskIcon(task.type)}</div>
                                <div class="task-content">
                                    <span class="task-type">${this.escapeHtml(task.type)}</span>
                                    <span class="task-name">${this.escapeHtml(task.name)}</span>
                                    ${task.mapping ? `<span class="task-mapping"><i class="fas fa-link"></i> ${this.escapeHtml(this.truncateText(task.mapping, 40))}</span>` : ''}
                                    ${task.transformCount > 0 ? `<span class="task-transforms">${task.transformCount} transforms</span>` : ''}
                                </div>
                            </div>
                            <div class="workflow-arrow"><i class="fas fa-arrow-down"></i></div>
                        `).join('')}
                        <div class="workflow-end-node">
                            <i class="fas fa-stop-circle"></i>
                            <span>End</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    getScheduleTypeClass(scheduleType) {
        const typeMap = {
            'ONDEMAND': 'schedule-ondemand',
            'DAILY': 'schedule-daily',
            'WEEKLY': 'schedule-weekly',
            'MONTHLY': 'schedule-monthly',
            'HOURLY': 'schedule-hourly',
            'CUSTOMIZED': 'schedule-custom'
        };
        return typeMap[scheduleType] || 'schedule-default';
    }
    
    displayRawJson(result) {
        this.fullJsonData = result;
        this.currentJsonTab = 'analysis';
        
        // Store separate JSON sections
        this.jsonSections = {
            analysis: result.analysis || {},
            workflow: result.workflow_analysis || {},
            full: result
        };
        
        // Set up JSON tab handlers
        document.querySelectorAll('.json-tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.json-tab-btn').forEach(b => b.classList.remove('active'));
                e.target.closest('.json-tab-btn').classList.add('active');
                this.currentJsonTab = e.target.closest('.json-tab-btn').dataset.jsonTab;
                this.renderJsonViewer();
            });
        });
        
        // Copy button
        const copyBtn = document.getElementById('copyJsonBtn');
        if (copyBtn) {
            copyBtn.addEventListener('click', () => {
                const jsonData = JSON.stringify(this.jsonSections[this.currentJsonTab], null, 2);
                navigator.clipboard.writeText(jsonData).then(() => {
                    this.showToast('JSON copied to clipboard', 'success');
                }).catch(() => {
                    this.showToast('Failed to copy', 'error');
                });
            });
        }
        
        // Download button
        const downloadBtn = document.getElementById('downloadJsonBtn');
        if (downloadBtn) {
            downloadBtn.addEventListener('click', () => {
                const jsonData = JSON.stringify(this.jsonSections[this.currentJsonTab], null, 2);
                const blob = new Blob([jsonData], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `parsed_${this.currentJsonTab}_${Date.now()}.json`;
                a.click();
                URL.revokeObjectURL(url);
                this.showToast('JSON downloaded', 'success');
            });
        }
        
        // Expand/Collapse button
        this.jsonExpanded = false;
        const expandBtn = document.getElementById('expandCollapseBtn');
        if (expandBtn) {
            expandBtn.addEventListener('click', () => {
                this.jsonExpanded = !this.jsonExpanded;
                expandBtn.innerHTML = this.jsonExpanded 
                    ? '<i class="fas fa-compress-alt"></i> Collapse All'
                    : '<i class="fas fa-expand-alt"></i> Expand All';
                this.renderJsonViewer();
            });
        }
        
        this.renderJsonViewer();
    }
    
    renderJsonViewer() {
        const viewer = document.getElementById('jsonViewer');
        if (!viewer) return;
        
        const data = this.jsonSections[this.currentJsonTab];
        const depth = this.jsonExpanded ? 100 : 2;
        
        viewer.innerHTML = `<code>${this.syntaxHighlightJson(data, depth)}</code>`;
    }
    
    syntaxHighlightJson(obj, maxDepth = 2, currentDepth = 0, indent = 0) {
        if (obj === null) return '<span class="json-null">null</span>';
        if (obj === undefined) return '<span class="json-undefined">undefined</span>';
        
        const indentStr = '  '.repeat(indent);
        const type = typeof obj;
        
        if (type === 'string') {
            const escaped = this.escapeHtml(obj);
            const truncated = escaped.length > 100 ? escaped.substring(0, 100) + '...' : escaped;
            return `<span class="json-string">"${truncated}"</span>`;
        }
        if (type === 'number') return `<span class="json-number">${obj}</span>`;
        if (type === 'boolean') return `<span class="json-boolean">${obj}</span>`;
        
        if (Array.isArray(obj)) {
            if (obj.length === 0) return '<span class="json-bracket">[]</span>';
            if (currentDepth >= maxDepth) {
                return `<span class="json-bracket">[</span><span class="json-collapsed" title="Click to expand">...${obj.length} items</span><span class="json-bracket">]</span>`;
            }
            
            let html = '<span class="json-bracket">[</span>\n';
            obj.forEach((item, idx) => {
                html += indentStr + '  ' + this.syntaxHighlightJson(item, maxDepth, currentDepth + 1, indent + 1);
                if (idx < obj.length - 1) html += ',';
                html += '\n';
            });
            html += indentStr + '<span class="json-bracket">]</span>';
            return html;
        }
        
        if (type === 'object') {
            const keys = Object.keys(obj);
            if (keys.length === 0) return '<span class="json-bracket">{}</span>';
            if (currentDepth >= maxDepth) {
                return `<span class="json-bracket">{</span><span class="json-collapsed" title="Click to expand">...${keys.length} keys</span><span class="json-bracket">}</span>`;
            }
            
            let html = '<span class="json-bracket">{</span>\n';
            keys.forEach((key, idx) => {
                html += indentStr + '  <span class="json-key">"' + this.escapeHtml(key) + '"</span>: ';
                html += this.syntaxHighlightJson(obj[key], maxDepth, currentDepth + 1, indent + 1);
                if (idx < keys.length - 1) html += ',';
                html += '\n';
            });
            html += indentStr + '<span class="json-bracket">}</span>';
            return html;
        }
        
        return String(obj);
    }
    
    openXmlDocsModal() {
        const modal = document.getElementById('xmlDocsModal');
        const container = document.getElementById('xmlDocsMain');
        
        if (modal && container) {
            container.innerHTML = this.getXmlDocsContent();
            modal.classList.add('open');
            document.body.style.overflow = 'hidden';
            
            // Smooth scroll for nav links inside modal
            setTimeout(() => {
                document.querySelectorAll('#xmlDocsModal .docs-nav-link').forEach(link => {
                    link.addEventListener('click', (e) => {
                        e.preventDefault();
                        const targetId = link.getAttribute('href').substring(1);
                        const target = document.getElementById(targetId);
                        if (target) {
                            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }
                    });
                });
            }, 100);
        }
    }
    
    closeXmlDocsModal() {
        const modal = document.getElementById('xmlDocsModal');
        if (modal) {
            modal.classList.remove('open');
            document.body.style.overflow = '';
        }
    }
    
    openPySparkGuideModal() {
        const modal = document.getElementById('pysparkGuideModal');
        const container = document.getElementById('pysparkGuideMain');
        
        if (modal && container) {
            container.innerHTML = this.getPySparkGuideContent();
            modal.classList.add('open');
            document.body.style.overflow = 'hidden';
            
            setTimeout(() => {
                document.querySelectorAll('#pysparkGuideModal .docs-nav-link').forEach(link => {
                    link.addEventListener('click', (e) => {
                        e.preventDefault();
                        const targetId = link.getAttribute('href').substring(1);
                        const target = document.getElementById(targetId);
                        if (target) {
                            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }
                    });
                });
            }, 100);
        }
    }
    
    closePySparkGuideModal() {
        const modal = document.getElementById('pysparkGuideModal');
        if (modal) {
            modal.classList.remove('open');
            document.body.style.overflow = '';
        }
    }
    
    getPySparkGuideContent() {
        return `
            <div class="doc-section" id="guide-overview">
                <h3 class="doc-section-title"><i class="fas fa-info-circle"></i> Overview</h3>
                <p class="doc-intro">This guide explains how the Informatica to PySpark Converter transforms each Informatica PowerCenter component into equivalent PySpark code. The converter analyzes XML exports and generates production-ready PySpark jobs.</p>
                <div class="doc-description">
                    <strong>Conversion Philosophy:</strong> Each Informatica transformation is mapped to its closest PySpark equivalent using DataFrame API operations. The generated code maintains data lineage and transformation logic while leveraging Spark's distributed processing capabilities.
                </div>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Component</th><th>PySpark Equivalent</th><th>Notes</th></tr></thead>
                        <tbody>
                            <tr><td>Mapping</td><td>PySpark Job Script</td><td>Complete ETL pipeline as a Python file</td></tr>
                            <tr><td>Session</td><td>Spark Session + Config</td><td>Runtime configuration and parameters</td></tr>
                            <tr><td>Workflow</td><td>Orchestration DAG</td><td>Airflow DAG or Databricks Workflow</td></tr>
                            <tr><td>Source</td><td>spark.read()</td><td>DataFrame reader with schema</td></tr>
                            <tr><td>Target</td><td>df.write()</td><td>DataFrame writer with mode</td></tr>
                            <tr><td>Transformation</td><td>DataFrame Operations</td><td>select, filter, join, groupBy, etc.</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="guide-architecture">
                <h3 class="doc-section-title"><i class="fas fa-sitemap"></i> Generated Code Architecture</h3>
                <p class="doc-description">The converter generates a complete PySpark project structure with modular, maintainable code.</p>
                <div class="doc-hierarchy-tree">
<pre class="hierarchy-code">generated_output/
├── job.py              # Main PySpark job entry point
├── config.yaml         # Configuration (connections, paths)
├── runtime_lib.py      # Reusable utility functions
├── transformations/    # Transformation logic modules
│   ├── expressions.py  # Expression evaluations
│   └── lookups.py      # Lookup implementations
└── report.json         # Conversion report and metadata</pre>
                </div>
                <h4 class="doc-subtitle">Code Generation Pattern</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Generated job.py structure
from pyspark.sql import SparkSession
from pyspark.sql.functions import *

def main():
    spark = SparkSession.builder.appName("mapping_name").getOrCreate()
    
    # Read Sources
    df_source = spark.read.format("jdbc")...
    
    # Apply Transformations
    df_transformed = df_source.select(...)
    
    # Write to Targets
    df_transformed.write.format("jdbc")...

if __name__ == "__main__":
    main()</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-sources">
                <h3 class="doc-section-title"><i class="fas fa-database"></i> Source Definition Conversion</h3>
                <p class="doc-description">Informatica SOURCE elements are converted to PySpark DataFrame readers with appropriate format and options.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Attribute</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td>DATABASETYPE="Oracle"</td><td><code>spark.read.format("jdbc").option("driver", "oracle.jdbc.driver.OracleDriver")</code></td></tr>
                            <tr><td>DATABASETYPE="SQL Server"</td><td><code>spark.read.format("jdbc").option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")</code></td></tr>
                            <tr><td>DATABASETYPE="FlatFile"</td><td><code>spark.read.format("csv") or format("text")</code></td></tr>
                            <tr><td>OWNERNAME + NAME</td><td><code>.option("dbtable", "schema.table_name")</code></td></tr>
                            <tr><td>SOURCEFIELD elements</td><td>Schema definition with StructType</td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Example Conversion</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Informatica Source: SRC_CUSTOMER (Oracle)
df_customer = spark.read \\
    .format("jdbc") \\
    .option("url", config["source_jdbc_url"]) \\
    .option("dbtable", "SALES.CUSTOMER") \\
    .option("user", config["source_user"]) \\
    .option("password", config["source_password"]) \\
    .load()</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-targets">
                <h3 class="doc-section-title"><i class="fas fa-bullseye"></i> Target Definition Conversion</h3>
                <p class="doc-description">Informatica TARGET elements are converted to PySpark DataFrame writers with appropriate write modes.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Setting</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td>Insert Mode</td><td><code>.mode("append")</code></td></tr>
                            <tr><td>Update Mode</td><td><code>MERGE INTO (Delta) or upsert logic</code></td></tr>
                            <tr><td>Truncate + Insert</td><td><code>.mode("overwrite")</code></td></tr>
                            <tr><td>Pre SQL</td><td>Execute via JDBC before write</td></tr>
                            <tr><td>Post SQL</td><td>Execute via JDBC after write</td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Example Conversion</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Informatica Target: TGT_CUSTOMER_DIM
df_final.write \\
    .format("jdbc") \\
    .option("url", config["target_jdbc_url"]) \\
    .option("dbtable", "DW.CUSTOMER_DIM") \\
    .mode("overwrite") \\
    .save()</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-sq">
                <h3 class="doc-section-title"><i class="fas fa-filter"></i> Source Qualifier Conversion</h3>
                <p class="doc-description">Source Qualifier transformations handle SQL overrides, joins between sources, and filtering at the source level.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>SQ Feature</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td>SQL Query Override</td><td><code>.option("query", "SELECT ... FROM ...")</code></td></tr>
                            <tr><td>Filter Condition</td><td><code>.option("query", "SELECT * FROM t WHERE ...")</code></td></tr>
                            <tr><td>Source Join</td><td>Push down join in query or separate join operation</td></tr>
                            <tr><td>Distinct</td><td><code>.distinct()</code></td></tr>
                            <tr><td>Sorted Ports</td><td><code>.orderBy(...)</code> (if needed downstream)</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="guide-expression">
                <h3 class="doc-section-title"><i class="fas fa-calculator"></i> Expression Transformation</h3>
                <p class="doc-description">Expression transformations are converted to PySpark select() with column expressions using SQL functions.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Function</th><th>PySpark Equivalent</th></tr></thead>
                        <tbody>
                            <tr><td><code>IIF(cond, true, false)</code></td><td><code>when(cond, true_val).otherwise(false_val)</code></td></tr>
                            <tr><td><code>DECODE(val, m1, r1, m2, r2, def)</code></td><td><code>when(val == m1, r1).when(val == m2, r2).otherwise(def)</code></td></tr>
                            <tr><td><code>NVL(val, default)</code></td><td><code>coalesce(val, default)</code></td></tr>
                            <tr><td><code>SUBSTR(str, start, len)</code></td><td><code>substring(str, start, len)</code></td></tr>
                            <tr><td><code>TO_DATE(str, fmt)</code></td><td><code>to_date(str, fmt)</code></td></tr>
                            <tr><td><code>LTRIM/RTRIM(str)</code></td><td><code>ltrim(str) / rtrim(str)</code></td></tr>
                            <tr><td><code>|| (concatenation)</code></td><td><code>concat(...)</code></td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Example Conversion</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Informatica Expression: FULL_NAME = FNAME || ' ' || LNAME
df = df.withColumn("FULL_NAME", concat(col("FNAME"), lit(" "), col("LNAME")))

# Informatica: STATUS_DESC = IIF(STATUS='A', 'Active', 'Inactive')  
df = df.withColumn("STATUS_DESC", 
    when(col("STATUS") == "A", "Active").otherwise("Inactive")
)</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-filter">
                <h3 class="doc-section-title"><i class="fas fa-funnel-dollar"></i> Filter Transformation</h3>
                <p class="doc-description">Filter transformations are directly converted to PySpark filter() or where() operations.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Filter</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td><code>FILTER_CONDITION = STATUS = 'A'</code></td><td><code>df.filter(col("STATUS") == "A")</code></td></tr>
                            <tr><td><code>AMOUNT > 1000 AND REGION = 'US'</code></td><td><code>df.filter((col("AMOUNT") > 1000) & (col("REGION") == "US"))</code></td></tr>
                            <tr><td><code>ISNULL(FIELD) = FALSE</code></td><td><code>df.filter(col("FIELD").isNotNull())</code></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="guide-lookup">
                <h3 class="doc-section-title"><i class="fas fa-search"></i> Lookup Transformation</h3>
                <p class="doc-description">Lookup transformations are converted to left joins with the lookup table/DataFrame.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Lookup</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td>Lookup Table</td><td>Read as separate DataFrame</td></tr>
                            <tr><td>Lookup Condition</td><td>Join condition in <code>.join()</code></td></tr>
                            <tr><td>Return Ports</td><td>Selected columns from lookup DataFrame</td></tr>
                            <tr><td>Default Value</td><td><code>coalesce(lookup_col, lit(default))</code></td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Example Conversion</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Informatica Lookup: LKP_PRODUCT on PRODUCT_ID
df_product = spark.read.format("jdbc")...  # Lookup source

df = df.join(
    df_product.select("PRODUCT_ID", "PRODUCT_NAME", "CATEGORY"),
    on="PRODUCT_ID",
    how="left"
)</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-joiner">
                <h3 class="doc-section-title"><i class="fas fa-code-branch"></i> Joiner Transformation</h3>
                <p class="doc-description">Joiner transformations are converted to PySpark join operations with the specified join type.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Join Type</th><th>PySpark Join Type</th></tr></thead>
                        <tbody>
                            <tr><td>Normal (Inner)</td><td><code>how="inner"</code></td></tr>
                            <tr><td>Master Outer</td><td><code>how="left"</code></td></tr>
                            <tr><td>Detail Outer</td><td><code>how="right"</code></td></tr>
                            <tr><td>Full Outer</td><td><code>how="outer"</code></td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Example Conversion</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Informatica Joiner: JNR_ORDER_CUSTOMER (Master Outer)
df_result = df_orders.join(
    df_customers,
    on=df_orders["CUSTOMER_ID"] == df_customers["CUST_ID"],
    how="left"
)</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-aggregator">
                <h3 class="doc-section-title"><i class="fas fa-layer-group"></i> Aggregator Transformation</h3>
                <p class="doc-description">Aggregator transformations are converted to PySpark groupBy() with aggregate functions.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Aggregate</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td>Group By Ports</td><td><code>.groupBy("col1", "col2")</code></td></tr>
                            <tr><td><code>SUM(AMOUNT)</code></td><td><code>.agg(sum("AMOUNT"))</code></td></tr>
                            <tr><td><code>COUNT(*)</code></td><td><code>.agg(count("*"))</code></td></tr>
                            <tr><td><code>AVG(VALUE)</code></td><td><code>.agg(avg("VALUE"))</code></td></tr>
                            <tr><td><code>MAX/MIN</code></td><td><code>.agg(max("col"), min("col"))</code></td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Example Conversion</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Informatica Aggregator: AGG_SALES_BY_REGION
df_agg = df.groupBy("REGION", "PRODUCT_CATEGORY").agg(
    sum("SALES_AMOUNT").alias("TOTAL_SALES"),
    count("ORDER_ID").alias("ORDER_COUNT"),
    avg("UNIT_PRICE").alias("AVG_PRICE")
)</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-sorter">
                <h3 class="doc-section-title"><i class="fas fa-sort"></i> Sorter Transformation</h3>
                <p class="doc-description">Sorter transformations are converted to PySpark orderBy() operations.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Sorter</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td>Sort Key (Ascending)</td><td><code>.orderBy(col("column").asc())</code></td></tr>
                            <tr><td>Sort Key (Descending)</td><td><code>.orderBy(col("column").desc())</code></td></tr>
                            <tr><td>Multiple Keys</td><td><code>.orderBy(col("c1").asc(), col("c2").desc())</code></td></tr>
                            <tr><td>Distinct</td><td><code>.dropDuplicates()</code></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="guide-router">
                <h3 class="doc-section-title"><i class="fas fa-random"></i> Router Transformation</h3>
                <p class="doc-description">Router transformations split data into multiple output groups based on conditions, converted to multiple filtered DataFrames.</p>
                <h4 class="doc-subtitle">Example Conversion</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Informatica Router: RTR_BY_STATUS with groups
# Group1: STATUS = 'ACTIVE'
# Group2: STATUS = 'PENDING'  
# Default: all others

df_active = df.filter(col("STATUS") == "ACTIVE")
df_pending = df.filter(col("STATUS") == "PENDING")
df_default = df.filter(~col("STATUS").isin(["ACTIVE", "PENDING"]))</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-update">
                <h3 class="doc-section-title"><i class="fas fa-edit"></i> Update Strategy Transformation</h3>
                <p class="doc-description">Update Strategy determines insert/update/delete behavior, converted to appropriate write modes or merge operations.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Update Strategy</th><th>PySpark Implementation</th></tr></thead>
                        <tbody>
                            <tr><td><code>DD_INSERT</code></td><td><code>.mode("append")</code></td></tr>
                            <tr><td><code>DD_UPDATE</code></td><td>Delta MERGE or custom upsert</td></tr>
                            <tr><td><code>DD_DELETE</code></td><td>Delta DELETE or flag-based</td></tr>
                            <tr><td><code>DD_REJECT</code></td><td>Filter out rejected rows</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="guide-sequence">
                <h3 class="doc-section-title"><i class="fas fa-hashtag"></i> Sequence Generator</h3>
                <p class="doc-description">Sequence Generator creates unique IDs, converted to monotonically_increasing_id() or row_number().</p>
                <h4 class="doc-subtitle">Example Conversion</h4>
                <div class="code-example">
                    <pre class="hierarchy-code"># Informatica Sequence: SEQ_CUSTOMER_KEY
from pyspark.sql.window import Window

df = df.withColumn("CUSTOMER_KEY", 
    monotonically_increasing_id() + lit(start_value)
)

# Or with row_number for deterministic sequence
window = Window.orderBy("CUSTOMER_ID")
df = df.withColumn("CUSTOMER_KEY", row_number().over(window))</pre>
                </div>
            </div>
            
            <div class="doc-section" id="guide-workflow">
                <h3 class="doc-section-title"><i class="fas fa-stream"></i> Workflow Orchestration</h3>
                <p class="doc-description">Informatica Workflows are converted to orchestration configurations for Airflow, Databricks Workflows, or similar tools.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Informatica Component</th><th>Orchestration Equivalent</th></tr></thead>
                        <tbody>
                            <tr><td>Workflow</td><td>DAG / Job Cluster</td></tr>
                            <tr><td>Session</td><td>Task / Job</td></tr>
                            <tr><td>Scheduler</td><td>Cron trigger / Schedule</td></tr>
                            <tr><td>Decision Task</td><td>Branch operator / Condition</td></tr>
                            <tr><td>Email Task</td><td>Notification task</td></tr>
                            <tr><td>Worklet</td><td>Sub-DAG / Task Group</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }
    
    getXmlDocsContent() {
        return `
            <div class="doc-section" id="doc-overview">
                <h3 class="doc-section-title"><i class="fas fa-info-circle"></i> Overview</h3>
                <p class="doc-intro">This reference documents how each Informatica Workflow XML element is used and its importance during the process of parsing and converting into PySpark code.</p>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead>
                            <tr><th>Element (Tag)</th><th>XML Path</th><th>Use / Purpose</th></tr>
                        </thead>
                        <tbody>
                            <tr><td><code>REPOSITORY</code></td><td>//REPOSITORY</td><td>Root of the XML structure; contains metadata about the repository itself.</td></tr>
                            <tr><td><code>FOLDER</code></td><td>//FOLDER</td><td>Contains all mappings, sources, targets, transformations. Acts like a project workspace.</td></tr>
                            <tr><td><code>SOURCE</code></td><td>//SOURCE</td><td>Defines the structure of the source table/file. Required for reading data in PySpark.</td></tr>
                            <tr><td><code>SOURCEFIELD</code></td><td>//SOURCE/SOURCEFIELD</td><td>Provides schema/column details of the source. Used to define Spark DataFrame schema.</td></tr>
                            <tr><td><code>TARGET</code></td><td>//TARGET</td><td>Defines the destination structure for writing data. Important for JDBC writes.</td></tr>
                            <tr><td><code>TARGETFIELD</code></td><td>//TARGET/TARGETFIELD</td><td>Field-level metadata for the target table. Used to match and validate output schema.</td></tr>
                            <tr><td><code>TRANSFORMATION</code></td><td>//TRANSFORMATION</td><td>Main logic units like Expression, Lookup, Filter, etc. These drive the PySpark logic generation.</td></tr>
                            <tr><td><code>TRANSFORMFIELD</code></td><td>//TRANSFORMFIELD</td><td>Defines columns and logic inside each transformation (e.g., derived fields, expressions).</td></tr>
                            <tr><td><code>INSTANCE</code></td><td>//INSTANCE</td><td>Represents instantiations of transformations, sources, or targets in a mapping.</td></tr>
                            <tr><td><code>CONNECTOR</code></td><td>//CONNECTOR</td><td>Links the fields from one instance to another (data lineage). Guides PySpark chaining/join logic.</td></tr>
                            <tr><td><code>MAPPING</code></td><td>//MAPPING</td><td>Container that holds one complete ETL logic from source to target. This is converted to PySpark.</td></tr>
                            <tr><td><code>WORKFLOW</code></td><td>//WORKFLOW</td><td>Defines the orchestration (control flow) of mappings and sessions. Useful for DAG sequencing.</td></tr>
                            <tr><td><code>SESSION</code></td><td>//SESSION</td><td>Execution context for a mapping. Contains parameter values and runtime configuration.</td></tr>
                            <tr><td><code>TABLEATTRIBUTE</code></td><td>//TABLEATTRIBUTE</td><td>Contains custom SQL overrides, Pre/Post SQL commands, partitioning details.</td></tr>
                            <tr><td><code>METADATAEXTENSION</code></td><td>//METADATAEXTENSION</td><td>Extra properties, annotations or lineage info. Useful for custom logic injection.</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-hierarchy">
                <h3 class="doc-section-title"><i class="fas fa-sitemap"></i> XML Hierarchy Structure</h3>
                <div class="doc-hierarchy-tree">
<pre class="hierarchy-code">&lt;REPOSITORY&gt;
  ├── &lt;FOLDER&gt;
  │     ├── &lt;SOURCE&gt;
  │     │     └── &lt;SOURCEFIELD /&gt;
  │     ├── &lt;TARGET&gt;
  │     │     └── &lt;TARGETFIELD /&gt;
  │     ├── &lt;TRANSFORMATION&gt;
  │     │     ├── &lt;TRANSFORMFIELD /&gt;
  │     │     └── &lt;TABLEATTRIBUTE /&gt;
  │     ├── &lt;INSTANCE /&gt;
  │     ├── &lt;CONNECTOR /&gt;
  │     ├── &lt;MAPPING /&gt;
  │     ├── &lt;SESSION /&gt;
  │     ├── &lt;WORKFLOW /&gt;
  │     └── &lt;METADATAEXTENSION /&gt;
  └── &lt;/FOLDER&gt;
&lt;/REPOSITORY&gt;</pre>
                </div>
            </div>
            
            <div class="doc-section" id="doc-repository">
                <h3 class="doc-section-title"><i class="fas fa-database"></i> &lt;REPOSITORY&gt; Tag</h3>
                <p class="doc-description">Root of the XML structure; contains metadata about the repository itself.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"Domain_repo"</td><td>Name of the Informatica repository</td></tr>
                            <tr><td><code>VERSION</code></td><td>"181"</td><td>Version of the repository for compatibility</td></tr>
                            <tr><td><code>CODEPAGE</code></td><td>"UTF-8"</td><td>Character encoding used</td></tr>
                            <tr><td><code>DATABASETYPE</code></td><td>"Oracle"</td><td>Type of database being used</td></tr>
                            <tr><td><code>OWNER</code></td><td>"Administrator"</td><td>Owner of the repository</td></tr>
                            <tr><td><code>SHARED</code></td><td>"YES" / "NO"</td><td>Whether repository is shared between projects</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-folder">
                <h3 class="doc-section-title"><i class="fas fa-folder"></i> &lt;FOLDER&gt; Tag</h3>
                <p class="doc-description">Contains all mappings, sources, targets, transformations. Acts like a project workspace.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"Sales"</td><td>Name of the folder/project</td></tr>
                            <tr><td><code>GROUP</code></td><td>"Development"</td><td>Logical grouping or team associated</td></tr>
                            <tr><td><code>OWNER</code></td><td>"Administrator"</td><td>Person or user account that owns the folder</td></tr>
                            <tr><td><code>SHARED</code></td><td>"YES" / "NO"</td><td>Whether shared across multiple users</td></tr>
                            <tr><td><code>DESCRIPTION</code></td><td>"ETL jobs for Sales"</td><td>Optional documentation</td></tr>
                            <tr><td><code>VERSIONNUMBER</code></td><td>"1"</td><td>Internal version tracking</td></tr>
                            <tr><td><code>ISVALID</code></td><td>"YES"</td><td>Folder structure validity</td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Child Elements</h4>
                <div class="doc-child-elements">
                    <span class="doc-child mandatory">SOURCE</span>
                    <span class="doc-child mandatory">TARGET</span>
                    <span class="doc-child mandatory">TRANSFORMATION</span>
                    <span class="doc-child mandatory">MAPPING</span>
                    <span class="doc-child optional">SESSION</span>
                    <span class="doc-child optional">WORKFLOW</span>
                    <span class="doc-child optional">TABLEATTRIBUTE</span>
                </div>
            </div>
            
            <div class="doc-section" id="doc-source">
                <h3 class="doc-section-title"><i class="fas fa-table"></i> &lt;SOURCE&gt; Tag</h3>
                <p class="doc-description">Defines the structure of the source table/file, including DB type and owner. Required for reading data in PySpark.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"SRC_CUSTOMER"</td><td>Logical name of the source in the mapping</td></tr>
                            <tr><td><code>DATABASETYPE</code></td><td>"Oracle", "FlatFile"</td><td>Type of database or source system. Important for JDBC configs</td></tr>
                            <tr><td><code>DBDNAME</code></td><td>"ORCL_DB_DEFN"</td><td>Database definition name used by Informatica</td></tr>
                            <tr><td><code>OBJECTTYPE</code></td><td>"TABLE", "VIEW"</td><td>Type of source object</td></tr>
                            <tr><td><code>OWNERNAME</code></td><td>"dbo", "admin"</td><td>Schema or owner of the source object</td></tr>
                            <tr><td><code>BUSINESSNAME</code></td><td>"Customer Table"</td><td>Optional business-friendly name</td></tr>
                            <tr><td><code>DESCRIPTION</code></td><td>"Source customer table"</td><td>Human-readable description</td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Child Element: &lt;SOURCEFIELD&gt;</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"CUSTOMER_ID"</td><td>Name of the source field (column)</td></tr>
                            <tr><td><code>DATATYPE</code></td><td>"decimal", "string"</td><td>Data type of the field. Maps to Spark SQL types</td></tr>
                            <tr><td><code>PRECISION</code></td><td>"10"</td><td>Total number of digits (for numeric types)</td></tr>
                            <tr><td><code>SCALE</code></td><td>"0"</td><td>Number of digits after decimal point</td></tr>
                            <tr><td><code>NULLABLE</code></td><td>"NULL", "NOTNULL"</td><td>Whether field can have NULL values</td></tr>
                            <tr><td><code>KEYTYPE</code></td><td>"PRIMARY", "NOT A KEY"</td><td>Primary key indicator</td></tr>
                            <tr><td><code>FIELDNUMBER</code></td><td>"1", "2"</td><td>Position of field in source definition</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-target">
                <h3 class="doc-section-title"><i class="fas fa-bullseye"></i> &lt;TARGET&gt; Tag</h3>
                <p class="doc-description">Defines the destination structure for writing data. Important for JDBC writes in PySpark.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"TGT_CUSTOMER"</td><td>Logical name of the target table or file</td></tr>
                            <tr><td><code>DATABASETYPE</code></td><td>"Oracle", "SQL Server"</td><td>Type of target system. Important for JDBC driver</td></tr>
                            <tr><td><code>DBDNAME</code></td><td>"ORCL_DB_DEFN"</td><td>Database definition name</td></tr>
                            <tr><td><code>OBJECTTYPE</code></td><td>"TABLE", "FILE"</td><td>Type of target object</td></tr>
                            <tr><td><code>OWNERNAME</code></td><td>"dbo"</td><td>Schema/owner of the target</td></tr>
                            <tr><td><code>TABLEOPTIONS</code></td><td>"TRUNCATE"</td><td>How table should be handled before loading</td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Child Element: &lt;TARGETFIELD&gt;</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"CUSTOMER_ID"</td><td>Name of the target column</td></tr>
                            <tr><td><code>DATATYPE</code></td><td>"decimal", "string"</td><td>Data type. Maps to Spark SQL types</td></tr>
                            <tr><td><code>PRECISION</code></td><td>"10"</td><td>Total digits for numeric values</td></tr>
                            <tr><td><code>SCALE</code></td><td>"0"</td><td>Decimal digits</td></tr>
                            <tr><td><code>KEYTYPE</code></td><td>"PRIMARY"</td><td>Primary key indicator</td></tr>
                            <tr><td><code>NULLABLE</code></td><td>"NULL"</td><td>Whether null values allowed</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-transformation">
                <h3 class="doc-section-title"><i class="fas fa-cogs"></i> &lt;TRANSFORMATION&gt; Tag</h3>
                <p class="doc-description">Main logic units like Expression, Lookup, Filter, etc. These drive the PySpark logic generation.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"EXP_CUST_FULLNAME"</td><td>Logical name of the transformation</td></tr>
                            <tr><td><code>TYPE</code></td><td>"Expression", "Lookup", "Filter"</td><td>Type of transformation logic. Essential for PySpark mapping</td></tr>
                            <tr><td><code>REUSABLE</code></td><td>"YES" / "NO"</td><td>Whether transformation is reusable across mappings</td></tr>
                            <tr><td><code>DESCRIPTION</code></td><td>"Concatenates first and last name"</td><td>Optional description</td></tr>
                            <tr><td><code>TRANSFORMATION_SCOPE</code></td><td>"ROW", "ALLINPUT"</td><td>Scope: per row or across all input</td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Child Element: &lt;TRANSFORMFIELD&gt;</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"FULLNAME"</td><td>Name of the port (field)</td></tr>
                            <tr><td><code>DATATYPE</code></td><td>"string", "decimal"</td><td>Data type of the port</td></tr>
                            <tr><td><code>PORTTYPE</code></td><td>"INPUT", "OUTPUT", "VARIABLE"</td><td>Port direction</td></tr>
                            <tr><td><code>EXPRESSION</code></td><td>"FNAME || ' ' || LNAME"</td><td>Transformation expression logic</td></tr>
                            <tr><td><code>PRECISION</code></td><td>"100"</td><td>Max length or digits</td></tr>
                        </tbody>
                    </table>
                </div>
                <h4 class="doc-subtitle">Transformation Types</h4>
                <div class="doc-transform-types">
                    <span class="transform-type expression">Expression</span>
                    <span class="transform-type filter">Filter</span>
                    <span class="transform-type lookup">Lookup</span>
                    <span class="transform-type joiner">Joiner</span>
                    <span class="transform-type aggregator">Aggregator</span>
                    <span class="transform-type router">Router</span>
                    <span class="transform-type sorter">Sorter</span>
                    <span class="transform-type update">Update Strategy</span>
                    <span class="transform-type sequence">Sequence Generator</span>
                    <span class="transform-type normalizer">Normalizer</span>
                    <span class="transform-type sq">Source Qualifier</span>
                </div>
            </div>
            
            <div class="doc-section" id="doc-mapping">
                <h3 class="doc-section-title"><i class="fas fa-project-diagram"></i> &lt;MAPPING&gt; Tag</h3>
                <p class="doc-description">Container that holds one complete ETL logic from source to target. This is what will be converted to PySpark.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"m_customer_load"</td><td>Name of the mapping</td></tr>
                            <tr><td><code>DESCRIPTION</code></td><td>"Load customer data"</td><td>Mapping description</td></tr>
                            <tr><td><code>ISVALID</code></td><td>"YES"</td><td>Validation status</td></tr>
                            <tr><td><code>VERSIONNUMBER</code></td><td>"1"</td><td>Version number</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-workflow">
                <h3 class="doc-section-title"><i class="fas fa-stream"></i> &lt;WORKFLOW&gt; Tag</h3>
                <p class="doc-description">Defines the orchestration (control flow) of mappings and sessions. Useful for DAG sequencing.</p>
                <h4 class="doc-subtitle">PySpark Equivalent: Databricks Workflow / Airflow DAG</h4>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"wf_daily_load"</td><td>Workflow name</td></tr>
                            <tr><td><code>DESCRIPTION</code></td><td>"Daily ETL workflow"</td><td>Description</td></tr>
                            <tr><td><code>SCHEDULERNAME</code></td><td>"Scheduler"</td><td>Associated scheduler</td></tr>
                            <tr><td><code>SUSPEND_ON_ERROR</code></td><td>"YES"</td><td>Error handling behavior</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-session">
                <h3 class="doc-section-title"><i class="fas fa-play-circle"></i> &lt;SESSION&gt; Tag</h3>
                <p class="doc-description">Execution context for a mapping. Contains parameter values and runtime configuration. May provide Pre/Post SQL.</p>
                <h4 class="doc-subtitle">PySpark Equivalent: PySpark Script/Notebook Task</h4>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"s_customer_load"</td><td>Session name</td></tr>
                            <tr><td><code>MAPPINGNAME</code></td><td>"m_customer_load"</td><td>Associated mapping</td></tr>
                            <tr><td><code>ISVALID</code></td><td>"YES"</td><td>Validation status</td></tr>
                            <tr><td><code>REUSABLE</code></td><td>"NO"</td><td>Whether session is reusable</td></tr>
                            <tr><td><code>SORTORDER</code></td><td>"Binary"</td><td>Sort order for session data</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-instance">
                <h3 class="doc-section-title"><i class="fas fa-cube"></i> &lt;INSTANCE&gt; Tag</h3>
                <p class="doc-description">Represents instantiations of transformations, sources, or targets in a mapping. Helps trace data flow.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>NAME</code></td><td>"SRC_CUSTOMER_inst"</td><td>Instance name</td></tr>
                            <tr><td><code>TYPE</code></td><td>"SOURCE", "TARGET", "TRANSFORMATION"</td><td>Type of instance</td></tr>
                            <tr><td><code>TRANSFORMATION_NAME</code></td><td>"EXP_CALC"</td><td>Reference to transformation</td></tr>
                            <tr><td><code>TRANSFORMATION_TYPE</code></td><td>"Expression"</td><td>Type of referenced transformation</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-connector">
                <h3 class="doc-section-title"><i class="fas fa-link"></i> &lt;CONNECTOR&gt; Tag</h3>
                <p class="doc-description">Links the fields from one instance to another (data lineage). Guides PySpark chaining/join logic.</p>
                <h4 class="doc-subtitle">Attributes</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>Attribute</th><th>Example</th><th>Description</th></tr></thead>
                        <tbody>
                            <tr><td><code>FROMINSTANCE</code></td><td>"SQ_CUSTOMER"</td><td>Source instance name</td></tr>
                            <tr><td><code>FROMINSTANCETYPE</code></td><td>"Source Qualifier"</td><td>Source instance type</td></tr>
                            <tr><td><code>FROMFIELD</code></td><td>"CUSTOMER_ID"</td><td>Source field name</td></tr>
                            <tr><td><code>TOINSTANCE</code></td><td>"EXP_TRANSFORM"</td><td>Target instance name</td></tr>
                            <tr><td><code>TOINSTANCETYPE</code></td><td>"Expression"</td><td>Target instance type</td></tr>
                            <tr><td><code>TOFIELD</code></td><td>"IN_CUSTOMER_ID"</td><td>Target field name</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="doc-section" id="doc-tableattribute">
                <h3 class="doc-section-title"><i class="fas fa-sliders-h"></i> &lt;TABLEATTRIBUTE&gt; Tag</h3>
                <p class="doc-description">Contains custom SQL overrides, Pre/Post SQL commands, partitioning details. Important for JDBC query overrides.</p>
                <h4 class="doc-subtitle">Common NAME Values</h4>
                <div class="doc-table-container">
                    <table class="doc-table">
                        <thead><tr><th>NAME</th><th>Context</th><th>Purpose</th></tr></thead>
                        <tbody>
                            <tr><td><code>Sql Query</code></td><td>&lt;SOURCE&gt;</td><td>SQL override to replace default query</td></tr>
                            <tr><td><code>Pre SQL</code></td><td>&lt;TARGET&gt; / &lt;SESSION&gt;</td><td>Statements to execute before data load</td></tr>
                            <tr><td><code>Post SQL</code></td><td>&lt;TARGET&gt; / &lt;SESSION&gt;</td><td>Statements to execute after data load</td></tr>
                            <tr><td><code>Truncate Target Table</code></td><td>&lt;TARGET&gt;</td><td>Whether to truncate target before inserting</td></tr>
                            <tr><td><code>Update Strategy Expression</code></td><td>&lt;TRANSFORMATION&gt;</td><td>Insert/Update/Delete logic</td></tr>
                            <tr><td><code>Sorted Input</code></td><td>&lt;LOOKUP&gt; / &lt;AGGREGATOR&gt;</td><td>Performance optimization flag</td></tr>
                            <tr><td><code>Lookup condition</code></td><td>&lt;LOOKUP&gt;</td><td>Join condition for lookup transformation</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }
    
    getShortType(typeStr) {
        const typeMap = {
            'Source Qualifier': 'SQ',
            'Expression': 'EXP',
            'Filter': 'FIL',
            'Lookup Procedure': 'LKP',
            'Stored Procedure': 'SP',
            'Update Strategy': 'UPD',
            'Aggregator': 'AGG',
            'Joiner': 'JNR',
            'Router': 'RTR',
            'Sorter': 'SRT',
            'Union': 'UN',
            'Sequence Generator': 'SEQ',
            'Normalizer': 'NRM',
            'Source Definition': 'SRC',
            'Target Definition': 'TGT',
            'SOURCE': 'SRC',
            'TARGET': 'TGT'
        };
        return typeMap[typeStr] || (typeStr ? typeStr.substring(0, 3).toUpperCase() : '?');
    }
    
    getNodeColorClass(typeStr) {
        const colorMap = {
            'Source Qualifier': 'node-source',
            'Source Definition': 'node-source',
            'SOURCE': 'node-source',
            'Target Definition': 'node-target',
            'TARGET': 'node-target',
            'Expression': 'node-transform',
            'Filter': 'node-filter',
            'Lookup Procedure': 'node-lookup',
            'Stored Procedure': 'node-sp',
            'Joiner': 'node-joiner',
            'Aggregator': 'node-aggregator',
            'Sorter': 'node-sorter',
            'Router': 'node-router',
            'Update Strategy': 'node-update'
        };
        return colorMap[typeStr] || 'node-default';
    }
    
    getNodeIcon(typeStr) {
        const iconMap = {
            'Source Qualifier': '<i class="fas fa-database"></i>',
            'Source Definition': '<i class="fas fa-database"></i>',
            'SOURCE': '<i class="fas fa-database"></i>',
            'Target Definition': '<i class="fas fa-bullseye"></i>',
            'TARGET': '<i class="fas fa-bullseye"></i>',
            'Expression': '<i class="fas fa-code"></i>',
            'Filter': '<i class="fas fa-filter"></i>',
            'Lookup Procedure': '<i class="fas fa-search"></i>',
            'Stored Procedure': '<i class="fas fa-terminal"></i>',
            'Joiner': '<i class="fas fa-code-branch"></i>',
            'Aggregator': '<i class="fas fa-layer-group"></i>',
            'Sorter': '<i class="fas fa-sort"></i>',
            'Router': '<i class="fas fa-random"></i>',
            'Update Strategy': '<i class="fas fa-edit"></i>'
        };
        return iconMap[typeStr] || '<i class="fas fa-cog"></i>';
    }
    
    getTaskIcon(typeStr) {
        const iconMap = {
            'Session': '<i class="fas fa-play"></i>',
            'Command': '<i class="fas fa-terminal"></i>',
            'Email': '<i class="fas fa-envelope"></i>',
            'Decision': '<i class="fas fa-question-circle"></i>',
            'Assignment': '<i class="fas fa-equals"></i>',
            'Timer': '<i class="fas fa-clock"></i>',
            'Event Wait': '<i class="fas fa-hourglass-half"></i>',
            'Event Raise': '<i class="fas fa-bolt"></i>'
        };
        return iconMap[typeStr] || '<i class="fas fa-tasks"></i>';
    }
    
    displayWorkflowAnalysis(workflowAnalysis) {
        if (!workflowAnalysis) return;
        
        // Display orchestration mapping table
        const orchestrationBody = document.getElementById('orchestrationTableBody');
        if (workflowAnalysis.orchestration_mapping && workflowAnalysis.orchestration_mapping.length > 0) {
            orchestrationBody.innerHTML = workflowAnalysis.orchestration_mapping.map(item => `
                <tr>
                    <td><strong>${item.element}</strong></td>
                    <td><span class="count-badge">${item.count}</span></td>
                    <td><span class="pyspark-equivalent">${item.pyspark_equivalent}</span></td>
                    <td class="notes-cell">${item.notes}</td>
                </tr>
            `).join('');
        } else {
            orchestrationBody.innerHTML = '<tr><td colspan="4" class="text-center">No orchestration elements found</td></tr>';
        }
        
        // Display workflows
        const workflowsList = document.getElementById('workflowsList');
        if (workflowAnalysis.workflows && workflowAnalysis.workflows.length > 0) {
            workflowsList.innerHTML = workflowAnalysis.workflows.map(wf => `
                <div class="workflow-card">
                    <div class="workflow-card-header">
                        <span class="workflow-name">${wf.name}</span>
                        <div class="workflow-badges">
                            <span class="status-badge ${wf.is_valid ? 'valid' : 'invalid'}">
                                ${wf.is_valid ? 'Valid' : 'Invalid'}
                            </span>
                            ${wf.is_restartable ? '<span class="status-badge restartable">Restartable</span>' : ''}
                        </div>
                    </div>
                    <div class="workflow-card-body">
                        <div class="pyspark-mapping">
                            <i class="fas fa-arrow-right"></i>
                            <span class="pyspark-equivalent">${wf.pyspark_equivalent}</span>
                        </div>
                        <p class="workflow-note">Map to job definition with retry policies and scheduling</p>
                    </div>
                </div>
            `).join('');
        } else {
            workflowsList.innerHTML = '<p class="empty-message">No workflows found</p>';
        }
        
        // Display tasks
        const tasksBody = document.getElementById('tasksTableBody');
        if (workflowAnalysis.tasks && workflowAnalysis.tasks.length > 0) {
            tasksBody.innerHTML = workflowAnalysis.tasks.map(task => `
                <tr>
                    <td><strong>${task.name}</strong></td>
                    <td><span class="type-badge task">${task.type}</span></td>
                    <td><span class="pyspark-equivalent">${task.pyspark_equivalent}</span></td>
                    <td class="notes-cell">${task.description || 'Custom implementation required'}</td>
                </tr>
            `).join('');
        } else {
            tasksBody.innerHTML = '<tr><td colspan="4" class="text-center">No tasks found</td></tr>';
        }
        
        // Display task dependencies
        const dependenciesList = document.getElementById('dependenciesList');
        if (workflowAnalysis.task_dependencies && workflowAnalysis.task_dependencies.length > 0) {
            dependenciesList.innerHTML = workflowAnalysis.task_dependencies.map(dep => `
                <div class="dependency-item">
                    <span class="task-name from">${dep.from_task}</span>
                    <i class="fas fa-arrow-right"></i>
                    <span class="task-name to">${dep.to_task}</span>
                    <div class="pyspark-equivalent-inline">
                        PySpark: <code>${dep.from_task} >> ${dep.to_task}</code>
                    </div>
                </div>
            `).join('');
        } else {
            dependenciesList.innerHTML = '<p class="empty-message">No task dependencies found</p>';
        }
        
        // Display schedulers
        const schedulersList = document.getElementById('schedulersList');
        if (workflowAnalysis.schedulers && workflowAnalysis.schedulers.length > 0) {
            schedulersList.innerHTML = workflowAnalysis.schedulers.map(sched => `
                <div class="scheduler-card">
                    <div class="scheduler-header">${sched.name}</div>
                    <div class="scheduler-details">
                        <span>Type: ${sched.type || 'N/A'}</span>
                        <span>Start: ${sched.start_time || 'N/A'}</span>
                        <span>Interval: ${sched.interval || 'N/A'}</span>
                    </div>
                    <div class="pyspark-mapping">
                        <i class="fas fa-arrow-right"></i>
                        <span class="pyspark-equivalent">${sched.pyspark_equivalent}</span>
                    </div>
                </div>
            `).join('');
        } else {
            schedulersList.innerHTML = '<p class="empty-message">No schedulers found</p>';
        }
        
        // Display workflow variables
        const variablesBody = document.getElementById('variablesTableBody');
        if (workflowAnalysis.workflow_variables && workflowAnalysis.workflow_variables.length > 0) {
            variablesBody.innerHTML = workflowAnalysis.workflow_variables.map(variable => `
                <tr>
                    <td><code>${variable.name}</code></td>
                    <td>${variable.datatype}</td>
                    <td>${variable.default_value}</td>
                    <td><span class="pyspark-equivalent">${variable.pyspark_equivalent}</span></td>
                </tr>
            `).join('');
        } else {
            variablesBody.innerHTML = '<tr><td colspan="4" class="text-center">No workflow variables found</td></tr>';
        }
    }
    
    prepareConfigForm(mapping) {
        const sourceConfigItems = document.getElementById('sourceConfigItems');
        sourceConfigItems.innerHTML = mapping.sources.map((source, index) => `
            <div class="config-item" data-source-index="${index}">
                <div class="config-item-header">
                    <div class="config-item-title">
                        <i class="fas fa-database"></i>
                        <span>${source.name}</span>
                    </div>
                    <span class="type-badge ${source.type.toLowerCase()}">${source.type}</span>
                </div>
                ${source.type === 'SQL' ? this.renderSQLConfig(source, index) : this.renderFileConfig(source, index)}
            </div>
        `).join('');
        
        const targetConfigItems = document.getElementById('targetConfigItems');
        targetConfigItems.innerHTML = mapping.targets.map((target, index) => `
            <div class="config-item" data-target-index="${index}">
                <div class="config-item-header">
                    <div class="config-item-title">
                        <i class="fas fa-bullseye"></i>
                        <span>${target.name}</span>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Output Format</label>
                        <select class="target-format" data-target="${target.name}" data-testid="select-target-format-${index}">
                            <option value="delta">Delta</option>
                            <option value="parquet">Parquet</option>
                            <option value="csv">CSV</option>
                            <option value="jdbc">JDBC (Database)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Write Mode</label>
                        <select class="target-mode" data-target="${target.name}" data-testid="select-target-mode-${index}">
                            <option value="append">Append</option>
                            <option value="overwrite">Overwrite</option>
                            <option value="error">Error if exists</option>
                            <option value="ignore">Ignore</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Destination Path / Table</label>
                        <input type="text" class="target-path" data-target="${target.name}" 
                               placeholder="/path/to/output or table_name" data-testid="input-target-path-${index}">
                    </div>
                </div>
            </div>
        `).join('');
    }
    
    renderSQLConfig(source, index) {
        return `
            <div class="form-row">
                <div class="form-group">
                    <label>Connection Alias</label>
                    <input type="text" class="source-connection" data-source="${source.name}" 
                           value="${source.db_name || ''}" placeholder="Connection alias" 
                           data-testid="input-source-connection-${index}">
                </div>
            </div>
        `;
    }
    
    renderFileConfig(source, index) {
        return `
            <div class="form-row">
                <div class="form-group">
                    <label>File Format</label>
                    <select class="source-format" data-source="${source.name}" data-testid="select-source-format-${index}">
                        <option value="csv">CSV</option>
                        <option value="parquet">Parquet</option>
                        <option value="dat">DAT</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Location</label>
                    <div class="radio-group">
                        <label class="radio-option">
                            <input type="radio" name="location-${source.name}" value="local" checked>
                            Local
                        </label>
                        <label class="radio-option">
                            <input type="radio" name="location-${source.name}" value="s3">
                            S3
                        </label>
                    </div>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>File Path</label>
                    <input type="text" class="source-path" data-source="${source.name}" 
                           placeholder="/path/to/file.csv or s3://bucket/path" 
                           data-testid="input-source-path-${index}">
                </div>
            </div>
        `;
    }
    
    addConnection() {
        const alias = document.getElementById('dbAlias').value.trim();
        const type = document.getElementById('dbType').value;
        const host = document.getElementById('dbHost').value.trim();
        const port = document.getElementById('dbPort').value.trim();
        const dbName = document.getElementById('dbName').value.trim();
        
        if (!alias) {
            this.showToast('Please enter a connection alias', 'warning');
            return;
        }
        
        this.userConfig.db_connections[alias] = {
            type: type,
            host: host || '${DB_HOST}',
            port: port || '1433',
            database: dbName || 'database_name',
            user: '${DB_USER}',
            password: '${DB_PASSWORD}'
        };
        
        this.renderConnections();
        
        document.getElementById('dbAlias').value = '';
        document.getElementById('dbHost').value = '';
        document.getElementById('dbPort').value = '';
        document.getElementById('dbName').value = '';
        
        this.showToast(`Connection "${alias}" added`, 'success');
    }
    
    renderConnections() {
        const list = document.getElementById('connectionsList');
        const connections = Object.entries(this.userConfig.db_connections);
        
        if (connections.length === 0) {
            list.innerHTML = '';
            return;
        }
        
        list.innerHTML = connections.map(([alias, config]) => `
            <div class="connection-item">
                <div class="connection-info">
                    <i class="fas fa-plug"></i>
                    <span><strong>${alias}</strong> - ${config.type} (${config.host}:${config.port})</span>
                </div>
                <button class="icon-btn" onclick="app.removeConnection('${alias}')" data-testid="button-remove-connection-${alias}">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');
    }
    
    removeConnection(alias) {
        delete this.userConfig.db_connections[alias];
        this.renderConnections();
        this.showToast(`Connection "${alias}" removed`, 'success');
    }
    
    collectConfig() {
        this.userConfig.sources = [];
        this.userConfig.targets = [];
        
        if (this.analysisData && this.analysisData.mappings.length > 0) {
            const mapping = this.analysisData.mappings[0];
            
            mapping.sources.forEach(source => {
                const config = {
                    source_name: source.name,
                    source_type: source.type
                };
                
                if (source.type === 'SQL') {
                    const connInput = document.querySelector(`.source-connection[data-source="${source.name}"]`);
                    config.connection_alias = connInput ? connInput.value : source.db_name;
                } else {
                    const formatSelect = document.querySelector(`.source-format[data-source="${source.name}"]`);
                    const pathInput = document.querySelector(`.source-path[data-source="${source.name}"]`);
                    const locationRadio = document.querySelector(`input[name="location-${source.name}"]:checked`);
                    
                    config.file_format = formatSelect ? formatSelect.value : 'csv';
                    config.file_path = pathInput ? pathInput.value : '';
                    config.file_location = locationRadio ? locationRadio.value : 'local';
                }
                
                this.userConfig.sources.push(config);
            });
            
            mapping.targets.forEach(target => {
                const formatSelect = document.querySelector(`.target-format[data-target="${target.name}"]`);
                const modeSelect = document.querySelector(`.target-mode[data-target="${target.name}"]`);
                const pathInput = document.querySelector(`.target-path[data-target="${target.name}"]`);
                
                this.userConfig.targets.push({
                    target_name: target.name,
                    output_format: formatSelect ? formatSelect.value : 'delta',
                    write_mode: modeSelect ? modeSelect.value : 'append',
                    destination_path: pathInput ? pathInput.value : '',
                    table_name: target.name
                });
            });
        }
    }
    
    async generateCode() {
        if (!this.artifactId) {
            this.showToast('No analysis data available', 'error');
            return;
        }
        
        this.collectConfig();
        
        this.goToStep(4);
        this.setStatus('processing', 'Generating...');
        
        document.getElementById('generationStatus').classList.remove('hidden');
        document.getElementById('generationResult').classList.add('hidden');
        
        this.animateProgress();
        
        try {
            const response = await fetch('/api/generate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    artifact_id: this.artifactId,
                    config: this.userConfig
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.displayGenerationResult(result.result);
                this.showToast('Code generated successfully', 'success');
            } else {
                this.showToast(result.error || 'Generation failed', 'error');
            }
        } catch (error) {
            console.error('Generation error:', error);
            this.showToast('Failed to generate code', 'error');
        } finally {
            this.setStatus('ready', 'Ready');
        }
    }
    
    animateProgress() {
        const progressFill = document.getElementById('progressFill');
        const progressText = document.getElementById('progressText');
        
        const steps = [
            { progress: 20, text: 'Parsing mapping...' },
            { progress: 40, text: 'Building transformation graph...' },
            { progress: 60, text: 'Generating PySpark code...' },
            { progress: 80, text: 'Creating configuration files...' },
            { progress: 100, text: 'Finalizing...' }
        ];
        
        let stepIndex = 0;
        const interval = setInterval(() => {
            if (stepIndex < steps.length) {
                progressFill.style.width = steps[stepIndex].progress + '%';
                progressText.textContent = steps[stepIndex].text;
                stepIndex++;
            } else {
                clearInterval(interval);
            }
        }, 400);
    }
    
    displayGenerationResult(result) {
        document.getElementById('generationStatus').classList.add('hidden');
        document.getElementById('generationResult').classList.remove('hidden');
        
        document.getElementById('filesGenerated').textContent = result.files.length;
        
        let coverage = 100;
        if (result.reports && result.reports.length > 0) {
            coverage = result.reports[0].coverage_percent || 100;
        }
        document.getElementById('coveragePercent').textContent = coverage.toFixed(0);
        
        const filesList = document.getElementById('filesList');
        filesList.innerHTML = result.files.map(file => {
            const icon = this.getFileIcon(file.file_type);
            return `
                <div class="file-item" onclick="app.viewFile('${file.filename}')" data-testid="file-item-${file.filename}">
                    <div class="file-item-icon">
                        <i class="fas fa-${icon}"></i>
                    </div>
                    <div class="file-item-info">
                        <span class="file-item-name">${file.filename}</span>
                        <span class="file-item-type">${file.file_type}</span>
                    </div>
                    <div class="file-item-action">
                        <i class="fas fa-external-link-alt"></i>
                    </div>
                </div>
            `;
        }).join('');
        
        this.displayReport(result.reports);
    }
    
    getFileIcon(fileType) {
        const icons = {
            python: 'file-code',
            yaml: 'file-alt',
            json: 'file-alt'
        };
        return icons[fileType] || 'file';
    }
    
    displayReport(reports) {
        const reportContent = document.getElementById('reportContent');
        
        if (!reports || reports.length === 0) {
            reportContent.innerHTML = '<p>No issues found.</p>';
            return;
        }
        
        const report = reports[0];
        const items = [];
        
        report.warnings.forEach(w => {
            items.push({ severity: 'warning', message: w.message, details: w.details });
        });
        
        report.errors.forEach(e => {
            items.push({ severity: 'error', message: e.message, details: e.details });
        });
        
        report.manual_items.forEach(m => {
            items.push({ severity: 'info', message: m.message, details: m.details });
        });
        
        if (items.length === 0) {
            reportContent.innerHTML = `
                <div class="report-item">
                    <div class="report-item-icon info">
                        <i class="fas fa-check"></i>
                    </div>
                    <div class="report-item-content">
                        <div class="report-item-message">Conversion completed with no issues</div>
                    </div>
                </div>
            `;
            return;
        }
        
        reportContent.innerHTML = items.map(item => `
            <div class="report-item">
                <div class="report-item-icon ${item.severity}">
                    <i class="fas fa-${item.severity === 'error' ? 'times' : item.severity === 'warning' ? 'exclamation' : 'info'}"></i>
                </div>
                <div class="report-item-content">
                    <div class="report-item-message">${item.message}</div>
                    ${item.details ? `<div class="report-item-details">${item.details}</div>` : ''}
                </div>
            </div>
        `).join('');
    }
    
    async viewFile(filename) {
        try {
            const response = await fetch(`/api/artifact/${this.artifactId}/file/${filename}`);
            const result = await response.json();
            
            if (result.success) {
                document.getElementById('codeModalTitle').textContent = filename;
                document.getElementById('codeContent').textContent = result.content;
                document.getElementById('codeModal').classList.add('active');
            } else {
                this.showToast('Failed to load file', 'error');
            }
        } catch (error) {
            console.error('Error loading file:', error);
            this.showToast('Failed to load file', 'error');
        }
    }
    
    closeModal() {
        document.getElementById('codeModal').classList.remove('active');
    }
    
    copyCode() {
        const code = document.getElementById('codeContent').textContent;
        navigator.clipboard.writeText(code).then(() => {
            this.showToast('Code copied to clipboard', 'success');
        }).catch(() => {
            this.showToast('Failed to copy code', 'error');
        });
    }
    
    downloadZip() {
        if (!this.artifactId) return;
        
        window.location.href = `/api/artifact/${this.artifactId}/download`;
    }
    
    switchTab(tabName) {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabName);
        });
        
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.toggle('active', content.id === tabName + 'Tab');
        });
    }
    
    goToStep(step) {
        for (let i = 1; i < step; i++) {
            document.querySelector(`.step-item[data-step="${i}"]`).classList.add('completed');
        }
        
        document.querySelectorAll('.step-item').forEach(item => {
            const itemStep = parseInt(item.dataset.step);
            item.classList.toggle('active', itemStep === step);
        });
        
        document.querySelectorAll('.step-panel').forEach(panel => {
            panel.classList.remove('active');
        });
        document.getElementById(`step${step}Panel`).classList.add('active');
        
        this.currentStep = step;
    }
    
    startOver() {
        this.currentStep = 1;
        this.artifactId = null;
        this.analysisData = null;
        this.selectedFile = null;
        this.userConfig = {
            sources: [],
            targets: [],
            db_connections: {}
        };
        
        document.getElementById('fileInput').value = '';
        document.getElementById('fileInfo').classList.add('hidden');
        document.getElementById('analyzeBtn').disabled = true;
        
        document.querySelectorAll('.step-item').forEach(item => {
            item.classList.remove('active', 'completed');
        });
        document.querySelector('.step-item[data-step="1"]').classList.add('active');
        
        document.querySelectorAll('.step-panel').forEach(panel => {
            panel.classList.remove('active');
        });
        document.getElementById('step1Panel').classList.add('active');
    }
    
    setStatus(status, text) {
        const badge = document.getElementById('statusBadge');
        badge.dataset.status = status;
        badge.querySelector('.status-text').textContent = text;
    }
    
    showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        const icons = {
            success: 'check-circle',
            error: 'times-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        
        toast.innerHTML = `
            <i class="fas fa-${icons[type]} toast-icon"></i>
            <span class="toast-message">${message}</span>
            <button class="toast-close" onclick="this.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.remove();
        }, 5000);
    }
}

const app = new App();
