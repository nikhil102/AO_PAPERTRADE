# Informatica XML to PySpark Converter

## Overview
Enterprise tool for Capital Group that converts Informatica PowerCenter mapping and workflow XML exports to equivalent PySpark code with configuration files.

## Tech Stack
- **Backend**: Python 3.11 + Flask (port 5000)
- **Frontend**: Plain HTML/CSS/JavaScript (no frameworks)
- **XML Parsing**: lxml
- **Graph Analysis**: NetworkX
- **Template Engine**: Jinja2
- **Data Validation**: Pydantic

## Project Structure
```
├── main.py                       # Entry point - runs Flask app
├── src/
│   ├── app.py                    # Flask application with routes
│   └── converter/
│       ├── models.py             # Pydantic data models
│       ├── infa_xml_parser.py    # Informatica XML parser
│       ├── analyzer.py           # Mapping analyzer
│       ├── graph_builder.py      # DAG builder with NetworkX
│       ├── expr_scanner.py       # Expression scanner (LKP, SP, $PM)
│       ├── expr_translator.py    # Informatica to PySpark expression translator
│       ├── ir.py                 # Intermediate representation
│       ├── handlers.py           # Transformation handlers
│       ├── codegen.py            # PySpark code generator
│       ├── report.py             # Conversion report builder
│       └── service.py            # Service orchestrator
├── templates/
│   ├── job.py.j2                 # PySpark job template
│   ├── runtime_lib.py.j2         # Runtime library template
│   └── config.yaml.j2            # Configuration template
├── static/
│   ├── index.html                # Frontend HTML
│   ├── css/style.css             # Styles
│   └── js/app.js                 # JavaScript application
├── output/                       # Generated files output directory
└── src/uploads/                  # Uploaded XML files
```

## API Endpoints
- `GET /` - Serve frontend
- `GET /api/health` - Health check
- `POST /api/analyze` - Analyze uploaded XML file
- `POST /api/generate` - Generate PySpark code with user configuration
- `GET /api/artifact/<id>` - Get artifact information
- `GET /api/artifact/<id>/download` - Download generated ZIP
- `GET /api/artifact/<id>/file/<filename>` - View specific generated file

## Supported Informatica Features
- Source types: SQL databases, flat files (CSV, DAT, Parquet)
- Transformations: Source Qualifier, Expression, Filter, Lookup, Joiner, Aggregator, Sorter, Router, Union, Update Strategy
- Expression translation: IIF, DECODE, NVL, TO_CHAR, TO_DATE, string functions, aggregations
- $PM variables resolution
- :LKP and :SP references detection

## Running the Application
The application runs via `python main.py` on port 5000.
Flask serves both the static frontend files and API endpoints.

## User Workflow
1. **Upload**: Upload Informatica POWERMART XML export
2. **Analyze**: Review detected mappings, sources, targets, transformations
3. **Configure**: Set source connections, file paths, target destinations
4. **Generate**: Download PySpark job, runtime library, and config files

## Design Preferences
- Professional wizard-style UI with 4 steps
- Inter font for UI text, JetBrains Mono for code
- Dark mode support via theme toggle
- System-based design with Linear + Notion hybrid patterns
