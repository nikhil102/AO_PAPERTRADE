"""Transform Handlers - handles conversion of each transformation type."""
from typing import Dict, List, Optional, Any
from .models import (
    MappingDefinition, Transformation, Instance, Connector,
    SourceDefinition, TargetDefinition, UserConfig, SourceConfig, TargetConfig
)
from .ir import (
    IRPlan, IRStep, ReadSQLStep, ReadFileStep, ApplySourceQualifierStep,
    ApplyFilterStep, ApplyExpressionStep, ApplyLookupStep, ApplyJoinerStep,
    ApplyAggregatorStep, ApplySorterStep, ApplyUnionStep,
    ApplyUpdateStrategyStep, WriteTargetStep, ComputedColumn
)
from .expr_translator import ExpressionTranslator
from .graph_builder import GraphBuilder


class TransformHandlers:
    """Handles conversion of Informatica transformations to IR steps."""
    
    def __init__(self, mapping: MappingDefinition, user_config: UserConfig):
        self.mapping = mapping
        self.user_config = user_config
        self.expr_translator = ExpressionTranslator(mapping_name=mapping.name)
        self.transform_map: Dict[str, Transformation] = {}
        self.instance_map: Dict[str, Instance] = {}
        self.source_map: Dict[str, SourceDefinition] = {}
        self.target_map: Dict[str, TargetDefinition] = {}
        self.df_counter = 0
        self.current_df_map: Dict[str, str] = {}
        
        self._build_maps()
    
    def _build_maps(self):
        """Build lookup maps for quick access."""
        for transform in self.mapping.transformations:
            self.transform_map[transform.name] = transform
        
        for instance in self.mapping.instances:
            self.instance_map[instance.name] = instance
        
        for source in self.mapping.sources:
            self.source_map[source.name] = source
        
        for target in self.mapping.targets:
            self.target_map[target.name] = target
    
    def _get_df_name(self, prefix: str = "df") -> str:
        """Generate unique DataFrame name."""
        self.df_counter += 1
        return f"{prefix}_{self.df_counter}"
    
    def _get_source_config(self, source_name: str) -> Optional[SourceConfig]:
        """Get user config for a source."""
        for config in self.user_config.sources:
            if config.source_name == source_name:
                return config
        return None
    
    def _get_target_config(self, target_name: str) -> Optional[TargetConfig]:
        """Get user config for a target."""
        for config in self.user_config.targets:
            if config.target_name == target_name:
                return config
        return None
    
    def build_ir_plan(self) -> IRPlan:
        """Build complete IR plan from mapping."""
        plan = IRPlan(mapping_name=self.mapping.name)
        
        graph_builder = GraphBuilder(self.mapping)
        graph_builder.build()
        ordered_instances = graph_builder.get_topological_order()
        
        for inst_name in ordered_instances:
            instance = self.instance_map.get(inst_name)
            if not instance:
                continue
            
            inst_type = instance.type or instance.transformation_type
            
            if inst_type == "SOURCE":
                step = self._handle_source(instance, plan)
                if step:
                    plan.add_step(step)
            
            elif inst_type == "Source Qualifier":
                step = self._handle_source_qualifier(instance, plan)
                if step:
                    plan.add_step(step)
            
            elif inst_type == "Filter":
                step = self._handle_filter(instance, plan)
                if step:
                    plan.add_step(step)
            
            elif inst_type == "Expression":
                step = self._handle_expression(instance, plan)
                if step:
                    plan.add_step(step)
            
            elif inst_type == "Lookup Procedure":
                steps = self._handle_lookup(instance, plan)
                for step in steps:
                    plan.add_step(step)
            
            elif inst_type == "Joiner":
                step = self._handle_joiner(instance, plan)
                if step:
                    plan.add_step(step)
            
            elif inst_type == "Aggregator":
                step = self._handle_aggregator(instance, plan)
                if step:
                    plan.add_step(step)
            
            elif inst_type == "Sorter":
                step = self._handle_sorter(instance, plan)
                if step:
                    plan.add_step(step)
            
            elif inst_type == "Union":
                step = self._handle_union(instance, plan)
                if step:
                    plan.add_step(step)
            
            elif inst_type == "Update Strategy":
                step = self._handle_update_strategy(instance, plan)
                if step:
                    plan.add_step(step)
            
            elif inst_type == "TARGET":
                step = self._handle_target(instance, plan)
                if step:
                    plan.add_step(step)
            
            else:
                plan.add_warning(f"Unsupported transformation type: {inst_type} ({inst_name})")
        
        return plan
    
    def _handle_source(self, instance: Instance, plan: IRPlan) -> Optional[IRStep]:
        """Handle source instance."""
        source_name = instance.transformation_name or instance.name.replace("1", "")
        source = None
        
        for s in self.mapping.sources:
            if s.name == source_name or source_name.startswith(s.name):
                source = s
                break
        
        if not source:
            plan.add_warning(f"Source definition not found: {source_name}")
            return None
        
        df_name = self._get_df_name("df_src")
        self.current_df_map[instance.name] = df_name
        
        source_config = self._get_source_config(source.name)
        
        from .models import SourceType
        if source.source_type == SourceType.SQL:
            conn_alias = source_config.connection_alias if source_config else source.db_name
            return ReadSQLStep(
                step_name=f"read_{instance.name}",
                df_output=df_name,
                connection_alias=conn_alias,
                table_name=source.name
            )
        else:
            file_format = source_config.file_format.value if source_config and source_config.file_format else "csv"
            file_path = source_config.file_path if source_config else f"/data/{source.name}"
            options = {}
            if source_config:
                options = {
                    "delimiter": source_config.delimiter,
                    "header": str(source_config.header).lower(),
                    "quote": source_config.quote_char
                }
            return ReadFileStep(
                step_name=f"read_{instance.name}",
                df_output=df_name,
                file_format=file_format,
                file_path=file_path,
                options=options
            )
    
    def _handle_source_qualifier(self, instance: Instance, plan: IRPlan) -> Optional[IRStep]:
        """Handle Source Qualifier transformation."""
        input_df = self._get_input_df(instance.name)
        if not input_df:
            plan.add_warning(f"No input DataFrame found for {instance.name}")
            input_df = "df_source"
        
        df_output = self._get_df_name("df_sq")
        self.current_df_map[instance.name] = df_output
        
        transform = self.transform_map.get(instance.transformation_name or instance.name)
        
        sql_query = ""
        filter_cond = ""
        distinct = False
        
        if transform:
            sql_query = transform.table_attributes.get("Sql Query", "")
            filter_cond = transform.table_attributes.get("Source Filter", "")
            distinct = transform.table_attributes.get("Select Distinct", "NO") == "YES"
        
        if filter_cond:
            filter_cond = self.expr_translator.translate(filter_cond)
        
        return ApplySourceQualifierStep(
            step_name=f"apply_{instance.name}",
            df_input=input_df,
            df_output=df_output,
            sql_query=sql_query,
            filter_condition=filter_cond,
            distinct=distinct
        )
    
    def _handle_filter(self, instance: Instance, plan: IRPlan) -> Optional[IRStep]:
        """Handle Filter transformation."""
        input_df = self._get_input_df(instance.name)
        if not input_df:
            plan.add_warning(f"No input DataFrame found for {instance.name}")
            input_df = "df_input"
        
        df_output = self._get_df_name("df_fil")
        self.current_df_map[instance.name] = df_output
        
        transform = self.transform_map.get(instance.transformation_name or instance.name)
        condition = ""
        
        if transform:
            condition = transform.table_attributes.get("Filter Condition", "")
            if not condition:
                for field in transform.fields:
                    if field.expression and field.name.upper() == "FILTER_CONDITION":
                        condition = field.expression
                        break
        
        if condition:
            condition = self.expr_translator.translate(condition)
        else:
            condition = "True"
            plan.add_warning(f"No filter condition found for {instance.name}")
        
        return ApplyFilterStep(
            step_name=f"apply_{instance.name}",
            df_input=input_df,
            df_output=df_output,
            condition=condition
        )
    
    def _handle_expression(self, instance: Instance, plan: IRPlan) -> Optional[IRStep]:
        """Handle Expression transformation."""
        input_df = self._get_input_df(instance.name)
        if not input_df:
            plan.add_warning(f"No input DataFrame found for {instance.name}")
            input_df = "df_input"
        
        df_output = self._get_df_name("df_exp")
        self.current_df_map[instance.name] = df_output
        
        transform = self.transform_map.get(instance.transformation_name or instance.name)
        computed_columns = []
        
        if transform:
            for field in transform.fields:
                if field.expression and "OUTPUT" in field.port_type:
                    translated = self.expr_translator.translate(field.expression)
                    computed_columns.append(ComputedColumn(
                        name=field.name,
                        expression=translated,
                        datatype=field.datatype
                    ))
        
        return ApplyExpressionStep(
            step_name=f"apply_{instance.name}",
            df_input=input_df,
            df_output=df_output,
            computed_columns=computed_columns
        )
    
    def _handle_lookup(self, instance: Instance, plan: IRPlan) -> List[IRStep]:
        """Handle Lookup Procedure transformation."""
        steps = []
        
        input_df = self._get_input_df(instance.name)
        
        transform = self.transform_map.get(instance.transformation_name or instance.name)
        if not transform:
            plan.add_warning(f"Lookup transformation not found: {instance.name}")
            return steps
        
        lookup_df = self._get_df_name("df_lkp")
        
        lookup_sql = transform.table_attributes.get("Lookup Sql Override", "")
        lookup_table = transform.table_attributes.get("Lookup table name", "")
        
        if lookup_sql:
            steps.append(ReadSQLStep(
                step_name=f"read_{instance.name}",
                df_output=lookup_df,
                connection_alias="lookup_db",
                query=lookup_sql
            ))
        elif lookup_table:
            steps.append(ReadSQLStep(
                step_name=f"read_{instance.name}",
                df_output=lookup_df,
                connection_alias="lookup_db",
                table_name=lookup_table
            ))
        
        plan.lookup_dfs[instance.name] = lookup_df
        
        if input_df:
            df_output = self._get_df_name("df_lkp_result")
            self.current_df_map[instance.name] = df_output
            
            lookup_cond = transform.table_attributes.get("Lookup condition", "")
            
            steps.append(ApplyLookupStep(
                step_name=f"apply_{instance.name}",
                df_input=input_df,
                df_output=df_output,
                lookup_df=lookup_df,
                join_condition=lookup_cond,
                lookup_type="left"
            ))
        
        return steps
    
    def _handle_joiner(self, instance: Instance, plan: IRPlan) -> Optional[IRStep]:
        """Handle Joiner transformation."""
        transform = self.transform_map.get(instance.transformation_name or instance.name)
        
        inputs = self._get_all_input_dfs(instance.name)
        if len(inputs) < 2:
            plan.add_warning(f"Joiner {instance.name} needs 2 inputs, found {len(inputs)}")
            return None
        
        df_output = self._get_df_name("df_jnr")
        self.current_df_map[instance.name] = df_output
        
        join_condition = ""
        join_type = "inner"
        
        if transform:
            join_condition = transform.table_attributes.get("Join Condition", "")
            join_type_attr = transform.table_attributes.get("Join Type", "Normal")
            if "Master Outer" in join_type_attr:
                join_type = "left"
            elif "Detail Outer" in join_type_attr:
                join_type = "right"
            elif "Full Outer" in join_type_attr:
                join_type = "full"
        
        return ApplyJoinerStep(
            step_name=f"apply_{instance.name}",
            df_master=inputs[0],
            df_detail=inputs[1],
            df_output=df_output,
            join_condition=join_condition,
            join_type=join_type
        )
    
    def _handle_aggregator(self, instance: Instance, plan: IRPlan) -> Optional[IRStep]:
        """Handle Aggregator transformation."""
        input_df = self._get_input_df(instance.name)
        if not input_df:
            input_df = "df_input"
        
        df_output = self._get_df_name("df_agg")
        self.current_df_map[instance.name] = df_output
        
        transform = self.transform_map.get(instance.transformation_name or instance.name)
        
        group_by = []
        aggregations = {}
        
        if transform:
            for field in transform.fields:
                if "GROUP BY" in field.port_type.upper():
                    group_by.append(field.name)
                elif field.expression and "OUTPUT" in field.port_type:
                    aggregations[field.name] = self.expr_translator.translate(field.expression)
        
        return ApplyAggregatorStep(
            step_name=f"apply_{instance.name}",
            df_input=input_df,
            df_output=df_output,
            group_by=group_by,
            aggregations=aggregations
        )
    
    def _handle_sorter(self, instance: Instance, plan: IRPlan) -> Optional[IRStep]:
        """Handle Sorter transformation."""
        input_df = self._get_input_df(instance.name)
        if not input_df:
            input_df = "df_input"
        
        df_output = self._get_df_name("df_srt")
        self.current_df_map[instance.name] = df_output
        
        transform = self.transform_map.get(instance.transformation_name or instance.name)
        sort_columns = []
        
        if transform:
            for field in transform.fields:
                sort_dir = transform.table_attributes.get(f"{field.name} Sort Direction", "ASC")
                sort_columns.append({
                    "column": field.name,
                    "direction": sort_dir
                })
        
        return ApplySorterStep(
            step_name=f"apply_{instance.name}",
            df_input=input_df,
            df_output=df_output,
            sort_columns=sort_columns
        )
    
    def _handle_union(self, instance: Instance, plan: IRPlan) -> Optional[IRStep]:
        """Handle Union transformation."""
        inputs = self._get_all_input_dfs(instance.name)
        
        if not inputs:
            plan.add_warning(f"No inputs found for Union {instance.name}")
            return None
        
        df_output = self._get_df_name("df_un")
        self.current_df_map[instance.name] = df_output
        
        return ApplyUnionStep(
            step_name=f"apply_{instance.name}",
            df_inputs=inputs,
            df_output=df_output,
            union_all=True
        )
    
    def _handle_update_strategy(self, instance: Instance, plan: IRPlan) -> Optional[IRStep]:
        """Handle Update Strategy transformation."""
        input_df = self._get_input_df(instance.name)
        if not input_df:
            input_df = "df_input"
        
        df_output = self._get_df_name("df_upd")
        self.current_df_map[instance.name] = df_output
        
        transform = self.transform_map.get(instance.transformation_name or instance.name)
        strategy_expr = "DD_INSERT"
        
        if transform:
            strategy_expr = transform.table_attributes.get("Update Strategy Expression", "DD_INSERT")
        
        return ApplyUpdateStrategyStep(
            step_name=f"apply_{instance.name}",
            df_input=input_df,
            df_output=df_output,
            strategy_expression=strategy_expr
        )
    
    def _handle_target(self, instance: Instance, plan: IRPlan) -> Optional[IRStep]:
        """Handle target instance."""
        input_df = self._get_input_df(instance.name)
        if not input_df:
            plan.add_warning(f"No input DataFrame found for target {instance.name}")
            input_df = "df_final"
        
        target_name = instance.transformation_name or instance.name.replace("1", "")
        target = None
        
        for t in self.mapping.targets:
            if t.name == target_name or target_name.startswith(t.name):
                target = t
                break
        
        target_config = self._get_target_config(target.name if target else target_name)
        
        sink_type = "delta"
        path = ""
        table_name = target.name if target else target_name
        mode = "append"
        
        if target_config:
            sink_type = target_config.output_format
            path = target_config.destination_path
            table_name = target_config.table_name or table_name
            mode = target_config.write_mode
        
        return WriteTargetStep(
            step_name=f"write_{instance.name}",
            df_input=input_df,
            sink_type=sink_type,
            path=path,
            table_name=table_name,
            mode=mode,
            format=sink_type
        )
    
    def _get_input_df(self, instance_name: str) -> Optional[str]:
        """Get input DataFrame name for an instance."""
        for connector in self.mapping.connectors:
            if connector.to_instance == instance_name:
                from_inst = connector.from_instance
                if from_inst in self.current_df_map:
                    return self.current_df_map[from_inst]
        return None
    
    def _get_all_input_dfs(self, instance_name: str) -> List[str]:
        """Get all input DataFrame names for an instance."""
        inputs = []
        for connector in self.mapping.connectors:
            if connector.to_instance == instance_name:
                from_inst = connector.from_instance
                if from_inst in self.current_df_map:
                    df = self.current_df_map[from_inst]
                    if df not in inputs:
                        inputs.append(df)
        return inputs
