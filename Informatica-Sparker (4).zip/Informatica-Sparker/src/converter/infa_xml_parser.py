"""Informatica XML Parser - parses POWERMART mapping and workflow XML files."""
from lxml import etree
from typing import List, Dict, Any, Optional, Tuple
from .models import (
    SourceDefinition, SourceField, SourceType, FileFormat,
    TargetDefinition, TargetField,
    Transformation, TransformField,
    Instance, Connector, MappingDefinition
)


class InfaXMLParser:
    """Parser for Informatica POWERMART XML exports."""
    
    SQL_DB_TYPES = {
        "microsoft sql server", "oracle", "db2", "sybase", 
        "teradata", "netezza", "postgresql", "mysql", "informix",
        "sql server"
    }
    
    FILE_INDICATORS = {
        "source file directory", "source file name", "delimited",
        "flat file", "line sequential", "code page", "file type"
    }
    
    def __init__(self, xml_content: bytes):
        self.xml_content = xml_content
        self.tree = None
        self.root = None
        self.xml_type = "UNKNOWN"
        self.folder_name = ""
        self.repository_name = ""
        
    def parse(self) -> bool:
        """Parse the XML content."""
        try:
            self.tree = etree.fromstring(self.xml_content)
            self.root = self.tree
            
            if self.root.tag == "POWERMART":
                self.xml_type = "POWERMART"
                repo = self.root.find(".//REPOSITORY")
                if repo is not None:
                    self.repository_name = repo.get("NAME", "")
                folder = self.root.find(".//FOLDER")
                if folder is not None:
                    self.folder_name = folder.get("NAME", "")
            elif self.root.find(".//WORKFLOW") is not None:
                self.xml_type = "WORKFLOW"
            
            return True
        except Exception as e:
            print(f"Error parsing XML: {e}")
            return False
    
    def get_mappings(self) -> List[MappingDefinition]:
        """Extract all mapping definitions from the XML."""
        mappings = []
        
        for mapping_elem in self.root.findall(".//MAPPING"):
            mapping = self._parse_mapping(mapping_elem)
            mappings.append(mapping)
        
        return mappings
    
    def _parse_mapping(self, mapping_elem) -> MappingDefinition:
        """Parse a single mapping element."""
        mapping = MappingDefinition(
            name=mapping_elem.get("NAME", ""),
            description=mapping_elem.get("DESCRIPTION", ""),
            is_valid=mapping_elem.get("ISVALID", "YES") == "YES"
        )
        
        folder = self.root.find(".//FOLDER")
        if folder is not None:
            for source_elem in folder.findall("SOURCE"):
                source = self._parse_source(source_elem)
                mapping.sources.append(source)
            
            for target_elem in folder.findall("TARGET"):
                target = self._parse_target(target_elem)
                mapping.targets.append(target)
        
        for transform_elem in mapping_elem.findall("TRANSFORMATION"):
            transform = self._parse_transformation(transform_elem)
            mapping.transformations.append(transform)
        
        for instance_elem in mapping_elem.findall("INSTANCE"):
            instance = self._parse_instance(instance_elem)
            mapping.instances.append(instance)
        
        for connector_elem in mapping_elem.findall("CONNECTOR"):
            connector = self._parse_connector(connector_elem)
            mapping.connectors.append(connector)
        
        return mapping
    
    def _parse_source(self, source_elem) -> SourceDefinition:
        """Parse a source definition."""
        source = SourceDefinition(
            name=source_elem.get("NAME", ""),
            database_type=source_elem.get("DATABASETYPE", ""),
            db_name=source_elem.get("DBDNAME", ""),
            owner_name=source_elem.get("OWNERNAME", "")
        )
        
        source.source_type = self._detect_source_type(source_elem)
        
        if source.source_type == SourceType.FILE:
            source.file_format = self._detect_file_format(source_elem)
        
        for attr_elem in source_elem.findall("TABLEATTRIBUTE"):
            attr_name = attr_elem.get("NAME", "")
            attr_value = attr_elem.get("VALUE", "")
            source.table_attributes[attr_name] = attr_value
        
        for field_elem in source_elem.findall("SOURCEFIELD"):
            field = SourceField(
                name=field_elem.get("NAME", ""),
                datatype=field_elem.get("DATATYPE", ""),
                precision=int(field_elem.get("PRECISION", "0")),
                scale=int(field_elem.get("SCALE", "0")),
                nullable=field_elem.get("NULLABLE", "NULL") == "NULL",
                key_type=field_elem.get("KEYTYPE", "NOT A KEY")
            )
            source.fields.append(field)
        
        return source
    
    def _parse_target(self, target_elem) -> TargetDefinition:
        """Parse a target definition."""
        target = TargetDefinition(
            name=target_elem.get("NAME", ""),
            database_type=target_elem.get("DATABASETYPE", ""),
            table_options=target_elem.get("TABLEOPTIONS", "")
        )
        
        for field_elem in target_elem.findall("TARGETFIELD"):
            field = TargetField(
                name=field_elem.get("NAME", ""),
                datatype=field_elem.get("DATATYPE", ""),
                precision=int(field_elem.get("PRECISION", "0")),
                scale=int(field_elem.get("SCALE", "0")),
                nullable=field_elem.get("NULLABLE", "NULL") == "NULL",
                key_type=field_elem.get("KEYTYPE", "NOT A KEY")
            )
            target.fields.append(field)
        
        return target
    
    def _parse_transformation(self, transform_elem) -> Transformation:
        """Parse a transformation definition."""
        transform = Transformation(
            name=transform_elem.get("NAME", ""),
            type=transform_elem.get("TYPE", ""),
            description=transform_elem.get("DESCRIPTION", ""),
            reusable=transform_elem.get("REUSABLE", "NO") == "YES"
        )
        
        for attr_elem in transform_elem.findall("TABLEATTRIBUTE"):
            attr_name = attr_elem.get("NAME", "")
            attr_value = attr_elem.get("VALUE", "")
            transform.table_attributes[attr_name] = attr_value
        
        for field_elem in transform_elem.findall("TRANSFORMFIELD"):
            field = TransformField(
                name=field_elem.get("NAME", ""),
                datatype=field_elem.get("DATATYPE", ""),
                port_type=field_elem.get("PORTTYPE", "INPUT/OUTPUT"),
                precision=int(field_elem.get("PRECISION", "0")),
                scale=int(field_elem.get("SCALE", "0")),
                expression=field_elem.get("EXPRESSION", None),
                default_value=field_elem.get("DEFAULTVALUE", None)
            )
            transform.fields.append(field)
        
        return transform
    
    def _parse_instance(self, instance_elem) -> Instance:
        """Parse a mapping instance."""
        return Instance(
            name=instance_elem.get("NAME", ""),
            type=instance_elem.get("TYPE", ""),
            transformation_name=instance_elem.get("TRANSFORMATION_NAME", ""),
            transformation_type=instance_elem.get("TRANSFORMATION_TYPE", ""),
            description=instance_elem.get("DESCRIPTION", "")
        )
    
    def _parse_connector(self, connector_elem) -> Connector:
        """Parse a connector definition."""
        return Connector(
            from_instance=connector_elem.get("FROMINSTANCE", ""),
            from_field=connector_elem.get("FROMFIELD", ""),
            to_instance=connector_elem.get("TOINSTANCE", ""),
            to_field=connector_elem.get("TOFIELD", ""),
            from_instance_type=connector_elem.get("FROMINSTANCETYPE", ""),
            to_instance_type=connector_elem.get("TOINSTANCETYPE", "")
        )
    
    def _detect_source_type(self, source_elem) -> SourceType:
        """Detect if source is SQL or FILE based on attributes."""
        db_type = source_elem.get("DATABASETYPE", "").lower()
        
        if any(sql_type in db_type for sql_type in self.SQL_DB_TYPES):
            return SourceType.SQL
        
        for attr_elem in source_elem.findall("TABLEATTRIBUTE"):
            attr_name = attr_elem.get("NAME", "").lower()
            if any(indicator in attr_name for indicator in self.FILE_INDICATORS):
                return SourceType.FILE
        
        if source_elem.get("DBDNAME", ""):
            return SourceType.SQL
        
        return SourceType.UNKNOWN
    
    def _detect_file_format(self, source_elem) -> FileFormat:
        """Detect file format from attributes or file name."""
        for attr_elem in source_elem.findall("TABLEATTRIBUTE"):
            attr_name = attr_elem.get("NAME", "").lower()
            attr_value = attr_elem.get("VALUE", "").lower()
            
            if "file name" in attr_name or "filename" in attr_name:
                if ".parquet" in attr_value:
                    return FileFormat.PARQUET
                elif ".csv" in attr_value:
                    return FileFormat.CSV
                elif ".dat" in attr_value:
                    return FileFormat.DAT
        
        return FileFormat.UNKNOWN
    
    def get_workflow_analysis(self) -> Dict[str, Any]:
        """Extract workflow analysis information from the XML."""
        workflow_analysis = {
            "workflows": [],
            "sessions": [],
            "tasks": [],
            "task_dependencies": [],
            "worklets": [],
            "schedulers": [],
            "workflow_variables": [],
            "orchestration_mapping": []
        }
        
        # Find all workflows
        for wf_elem in self.root.findall(".//WORKFLOW"):
            workflow = {
                "name": wf_elem.get("NAME", ""),
                "description": wf_elem.get("DESCRIPTION", ""),
                "is_valid": wf_elem.get("ISVALID", "YES") == "YES",
                "is_restartable": wf_elem.get("REUSABLE_SCHEDULER", "") == "YES",
                "pyspark_equivalent": "Databricks Workflow / Airflow DAG"
            }
            workflow_analysis["workflows"].append(workflow)
            
            # Extract tasks from workflow
            for task_elem in wf_elem.findall("TASK"):
                task = {
                    "name": task_elem.get("NAME", ""),
                    "type": task_elem.get("TYPE", ""),
                    "description": task_elem.get("DESCRIPTION", ""),
                    "pyspark_equivalent": self._get_task_pyspark_equivalent(task_elem.get("TYPE", ""))
                }
                workflow_analysis["tasks"].append(task)
            
            # Extract workflow links (dependencies)
            for link_elem in wf_elem.findall("WORKFLOWLINK"):
                dependency = {
                    "from_task": link_elem.get("FROMTASK", ""),
                    "to_task": link_elem.get("TOTASK", ""),
                    "condition": link_elem.get("CONDITION", "")
                }
                workflow_analysis["task_dependencies"].append(dependency)
            
            # Extract workflow variables
            for var_elem in wf_elem.findall("WORKFLOWVARIABLE"):
                variable = {
                    "name": var_elem.get("NAME", ""),
                    "datatype": var_elem.get("DATATYPE", ""),
                    "default_value": var_elem.get("DEFAULTVALUE", "N/A"),
                    "pyspark_equivalent": "Airflow Variable / Databricks parameter / Environment variable"
                }
                workflow_analysis["workflow_variables"].append(variable)
            
            # Extract scheduler
            for sched_elem in wf_elem.findall("SCHEDULER"):
                schedule_info = sched_elem.find("SCHEDULEINFO")
                schedule_type = schedule_info.get("SCHEDULETYPE", "ONDEMAND") if schedule_info is not None else "ONDEMAND"
                start_date = schedule_info.get("STARTDATE", "") if schedule_info is not None else ""
                end_date = schedule_info.get("ENDDATE", "") if schedule_info is not None else ""
                repeat_interval = schedule_info.get("REPEATINTERVAL", "") if schedule_info is not None else ""
                
                scheduler = {
                    "name": sched_elem.get("NAME", "Scheduler"),
                    "description": sched_elem.get("DESCRIPTION", ""),
                    "reusable": sched_elem.get("REUSABLE", "NO") == "YES",
                    "schedule_type": schedule_type,
                    "start_date": start_date,
                    "end_date": end_date,
                    "repeat_interval": repeat_interval,
                    "pyspark_equivalent": self._get_scheduler_pyspark_equivalent(schedule_type)
                }
                workflow_analysis["schedulers"].append(scheduler)
        
        # Find all sessions with detailed info
        for session_elem in self.root.findall(".//SESSION"):
            # Extract session components (pre/post session assignments)
            pre_session = []
            post_success = []
            post_failure = []
            
            for comp in session_elem.findall("SESSIONCOMPONENT"):
                comp_type = comp.get("TYPE", "")
                comp_name = comp.get("REFOBJECTNAME", "")
                if "Pre-session" in comp_type:
                    pre_session.append(comp_name)
                elif "success" in comp_type.lower():
                    post_success.append(comp_name)
                elif "failure" in comp_type.lower():
                    post_failure.append(comp_name)
            
            # Extract transformation instances in session
            transformations = []
            for trans_inst in session_elem.findall("SESSTRANSFORMATIONINST"):
                transformations.append({
                    "name": trans_inst.get("SINSTANCENAME", ""),
                    "type": trans_inst.get("TRANSFORMATIONTYPE", ""),
                    "pipeline": trans_inst.get("PIPELINE", "")
                })
            
            session = {
                "name": session_elem.get("NAME", ""),
                "mapping_name": session_elem.get("MAPPINGNAME", ""),
                "description": session_elem.get("DESCRIPTION", ""),
                "is_valid": session_elem.get("ISVALID", "YES") == "YES",
                "reusable": session_elem.get("REUSABLE", "NO") == "YES",
                "sort_order": session_elem.get("SORTORDER", "Binary"),
                "pre_session_components": pre_session,
                "post_success_components": post_success,
                "post_failure_components": post_failure,
                "transformation_count": len(transformations),
                "pyspark_equivalent": "PySpark Script/Notebook task"
            }
            workflow_analysis["sessions"].append(session)
        
        # Find worklets
        for worklet_elem in self.root.findall(".//WORKLET"):
            worklet = {
                "name": worklet_elem.get("NAME", ""),
                "description": worklet_elem.get("DESCRIPTION", ""),
                "pyspark_equivalent": "Nested DAG / TaskGroup"
            }
            workflow_analysis["worklets"].append(worklet)
        
        # Build orchestration mapping reference
        workflow_analysis["orchestration_mapping"] = self._build_orchestration_mapping(workflow_analysis)
        
        return workflow_analysis
    
    def _get_task_pyspark_equivalent(self, task_type: str) -> str:
        """Get PySpark equivalent for task type."""
        mapping = {
            "SESSION": "PySpark Script/Notebook task",
            "COMMAND": "BashOperator / Shell task",
            "START": "DAG start (implicit)",
            "DECISION": "BranchPythonOperator",
            "ASSIGNMENT": "PythonOperator (variable assignment)",
            "EMAIL": "EmailOperator",
            "TIMER": "TimeSensor / Wait task",
            "EVENT_WAIT": "ExternalTaskSensor",
            "EVENT_RAISE": "TriggerDagRunOperator"
        }
        return mapping.get(task_type.upper(), f"PythonOperator (custom for {task_type})")
    
    def _get_scheduler_pyspark_equivalent(self, schedule_type: str) -> str:
        """Get PySpark equivalent for scheduler type."""
        mapping = {
            "ONDEMAND": "Manual trigger / API trigger",
            "DAILY": "schedule_interval='@daily' / cron('0 0 * * *')",
            "WEEKLY": "schedule_interval='@weekly' / cron('0 0 * * 0')",
            "MONTHLY": "schedule_interval='@monthly' / cron('0 0 1 * *')",
            "HOURLY": "schedule_interval='@hourly' / cron('0 * * * *')",
            "CUSTOMIZED": "Custom cron expression",
            "RUN_EVERY_N": "timedelta-based schedule"
        }
        return mapping.get(schedule_type.upper(), f"Custom schedule ({schedule_type})")
    
    def _build_orchestration_mapping(self, analysis: Dict) -> List[Dict]:
        """Build orchestration mapping reference table."""
        mapping = []
        
        # Count elements
        mapping_count = len(self.root.findall(".//MAPPING"))
        workflow_count = len(analysis["workflows"])
        session_count = len(analysis["sessions"])
        task_count = len(analysis["tasks"])
        link_count = len(analysis["task_dependencies"])
        scheduler_count = len(analysis["schedulers"])
        variable_count = len(analysis["workflow_variables"])
        
        if mapping_count > 0:
            mapping.append({
                "element": "MAPPING",
                "count": mapping_count,
                "pyspark_equivalent": "PySpark DataFrame Pipeline / Notebook",
                "notes": "Convert transformations to DataFrame operations with spark.read/write"
            })
        
        if workflow_count > 0:
            mapping.append({
                "element": "WORKFLOW",
                "count": workflow_count,
                "pyspark_equivalent": "Databricks Workflow / Airflow DAG",
                "notes": "Create job definition with name, retry policies, and scheduling"
            })
        
        if session_count > 0:
            mapping.append({
                "element": "SESSION",
                "count": session_count,
                "pyspark_equivalent": "PySpark Script/Notebook task",
                "notes": "Convert mapping to PySpark script. Use spark.read for sources, df.write for targets"
            })
        
        if link_count > 0:
            mapping.append({
                "element": "WORKFLOWLINK",
                "count": link_count,
                "pyspark_equivalent": "Task dependencies (>>)",
                "notes": "Define task1 >> task2 chains in Airflow or depends_on in Databricks"
            })
        
        if scheduler_count > 0:
            mapping.append({
                "element": "SCHEDULER",
                "count": scheduler_count,
                "pyspark_equivalent": "schedule_interval / Job trigger",
                "notes": "Convert schedule to cron expression or Databricks trigger"
            })
        
        if variable_count > 0:
            mapping.append({
                "element": "WORKFLOWVARIABLE",
                "count": variable_count,
                "pyspark_equivalent": "DAG variables / Job parameters",
                "notes": "Pass via config dict, env vars, or Airflow Variables"
            })
        
        # Add task types
        for task in analysis["tasks"]:
            task_type = task["type"]
            existing = next((m for m in mapping if m["element"] == task_type), None)
            if existing:
                existing["count"] += 1
            else:
                mapping.append({
                    "element": task_type,
                    "count": 1,
                    "pyspark_equivalent": task["pyspark_equivalent"],
                    "notes": f"Custom implementation required for {task_type}"
                })
        
        return mapping
    
    def get_configs(self) -> List[Dict[str, Any]]:
        """Extract all CONFIG elements from the XML with their attributes."""
        configs = []
        
        # Descriptions for common Informatica config attributes
        attr_descriptions = {
            "Constraint based load ordering": "Determines if target data loading follows referential integrity constraints",
            "Cache LOOKUP() function": "Enables caching for LOOKUP() function to improve performance",
            "Default buffer block size": "Size of memory buffer blocks for data processing",
            "Line Sequential buffer length": "Buffer size for line sequential file processing",
            "Maximum Memory Allowed For Auto Memory Attributes": "Maximum memory allocation for automatic memory settings",
            "Maximum Percentage of Total Memory Allowed For Auto Memory Attributes": "Percentage of total memory for auto memory settings",
            "Additional Concurrent Pipelines for Lookup Cache Creation": "Number of parallel pipelines for lookup cache building",
            "Pre-build lookup cache": "Whether to build lookup caches before mapping execution",
            "Optimization Level": "Level of query optimization (None, Normal, Medium, Full)",
            "DateTime Format String": "Default format for datetime values",
            "Pre 85 Timestamp Compatibility": "Backward compatibility for timestamp handling",
            "Log Options": "Session logging configuration options",
            "Save session log by": "Criteria for saving session logs (runs, time, size)",
            "Save session log for these runs": "Number of session runs to retain logs",
            "Session Log File Max Size": "Maximum size of session log file before rotation",
            "Session Log File Max Time Period": "Maximum time period for session log retention",
            "Maximum Partial Session Log Files": "Maximum number of partial log files to keep",
            "Writer Commit Statistics Log Frequency": "Frequency of logging writer commit statistics",
            "Writer Commit Statistics Log Interval": "Time interval for writer commit statistics",
            "Stop on errors": "Number of errors before stopping the session",
            "Override tracing": "Override default tracing level for debugging",
            "On Stored Procedure error": "Action when stored procedure fails (Stop, Continue)",
            "On Pre-session command task error": "Action when pre-session command fails",
            "On Pre-Post SQL error": "Action when Pre/Post SQL fails",
            "Enable Recovery": "Enable session recovery for restartability",
            "Error Log Type": "Type of error logging (None, Flat File, Database)",
            "Error Log Table Name Prefix": "Prefix for database error log tables",
            "Error Log File Name": "Name of the error log file",
            "Log Source Row Data": "Whether to log source row data on errors",
            "Data Column Delimiter": "Delimiter for data columns in error logs",
            "Dynamic Partitioning": "Enable dynamic pipeline partitioning",
            "Number of Partitions": "Number of partitions for parallel processing",
            "Multiplication Factor": "Factor for calculating dynamic partitions",
            "Is Enabled": "Whether the configuration or feature is enabled",
            "Custom Properties": "User-defined custom properties",
            "Advanced": "Advanced configuration settings"
        }
        
        for config_elem in self.root.findall(".//CONFIG"):
            config = {
                "name": config_elem.get("NAME", ""),
                "description": config_elem.get("DESCRIPTION", ""),
                "is_default": config_elem.get("ISDEFAULT", "NO") == "YES",
                "version": config_elem.get("VERSIONNUMBER", ""),
                "attributes": []
            }
            
            for attr_elem in config_elem.findall("ATTRIBUTE"):
                attr_name = attr_elem.get("NAME", "")
                attr = {
                    "name": attr_name,
                    "value": attr_elem.get("VALUE", ""),
                    "description": attr_descriptions.get(attr_name, "")
                }
                config["attributes"].append(attr)
            
            configs.append(config)
        
        return configs
