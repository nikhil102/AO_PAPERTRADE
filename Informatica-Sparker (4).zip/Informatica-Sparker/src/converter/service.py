"""Service - orchestrates the analysis and conversion process."""
import os
import json
import zipfile
import uuid
from datetime import datetime
from typing import Optional, Dict, Any, List
from .infa_xml_parser import InfaXMLParser
from .analyzer import Analyzer
from .handlers import TransformHandlers
from .codegen import CodeGenerator
from .report import ReportBuilder
from .models import (
    AnalysisResult, UserConfig, GenerationResult, 
    GeneratedFile, ConversionReport, SourceConfig, TargetConfig,
    SourceType, FileFormat, FileLocation
)


class ConversionService:
    """Orchestrates the XML analysis and PySpark conversion process."""
    
    def __init__(self, output_dir: str = "output", template_dir: str = "templates"):
        self.output_dir = output_dir
        self.template_dir = template_dir
        self.artifacts: Dict[str, Dict[str, Any]] = {}
        
        os.makedirs(output_dir, exist_ok=True)
    
    def analyze(self, xml_content: bytes, filename: str = "") -> Dict[str, Any]:
        """Analyze XML and return analysis result with artifact ID."""
        artifact_id = str(uuid.uuid4())[:8]
        
        artifact_dir = os.path.join(self.output_dir, artifact_id)
        os.makedirs(artifact_dir, exist_ok=True)
        
        input_path = os.path.join(artifact_dir, "input.xml")
        with open(input_path, "wb") as f:
            f.write(xml_content)
        
        parser = InfaXMLParser(xml_content)
        if not parser.parse():
            return {
                "success": False,
                "error": "Failed to parse XML file",
                "artifact_id": artifact_id
            }
        
        mappings = parser.get_mappings()
        
        analyzer = Analyzer(
            mappings=mappings,
            xml_type=parser.xml_type,
            folder_name=parser.folder_name,
            repository_name=parser.repository_name
        )
        
        analysis_result = analyzer.analyze()
        
        # Get workflow analysis
        workflow_analysis = parser.get_workflow_analysis()
        
        # Get CONFIG elements from XML
        configs = parser.get_configs()
        
        analysis_path = os.path.join(artifact_dir, "analysis.json")
        with open(analysis_path, "w") as f:
            json.dump(analysis_result.model_dump(), f, indent=2)
        
        self.artifacts[artifact_id] = {
            "parser": parser,
            "mappings": mappings,
            "analysis": analysis_result,
            "workflow_analysis": workflow_analysis,
            "configs": configs,
            "created_at": datetime.now().isoformat(),
            "filename": filename
        }
        
        return {
            "success": True,
            "artifact_id": artifact_id,
            "analysis": analysis_result.model_dump(),
            "workflow_analysis": workflow_analysis,
            "configs": configs
        }
    
    def generate(self, artifact_id: str, user_config_dict: Dict[str, Any]) -> Dict[str, Any]:
        """Generate PySpark code based on user configuration."""
        if artifact_id not in self.artifacts:
            analysis_path = os.path.join(self.output_dir, artifact_id, "analysis.json")
            if not os.path.exists(analysis_path):
                return {
                    "success": False,
                    "error": f"Artifact not found: {artifact_id}"
                }
            
            with open(analysis_path, "r") as f:
                analysis_data = json.load(f)
            
            input_path = os.path.join(self.output_dir, artifact_id, "input.xml")
            with open(input_path, "rb") as f:
                xml_content = f.read()
            
            parser = InfaXMLParser(xml_content)
            parser.parse()
            mappings = parser.get_mappings()
            
            self.artifacts[artifact_id] = {
                "parser": parser,
                "mappings": mappings,
                "analysis": AnalysisResult(**analysis_data)
            }
        
        artifact = self.artifacts[artifact_id]
        mappings = artifact["mappings"]
        
        user_config = self._parse_user_config(artifact_id, user_config_dict)
        
        config_path = os.path.join(self.output_dir, artifact_id, "config_user.json")
        with open(config_path, "w") as f:
            json.dump(user_config.model_dump(), f, indent=2)
        
        result = GenerationResult(artifact_id=artifact_id)
        artifact_dir = os.path.join(self.output_dir, artifact_id)
        
        codegen = CodeGenerator(template_dir=self.template_dir)
        
        for mapping in mappings:
            handlers = TransformHandlers(mapping, user_config)
            ir_plan = handlers.build_ir_plan()
            
            generated_files = codegen.generate(ir_plan, user_config)
            
            for gen_file in generated_files:
                file_path = os.path.join(artifact_dir, gen_file.filename)
                with open(file_path, "w") as f:
                    f.write(gen_file.content)
                result.files.append(gen_file)
            
            job_content = ""
            for gf in generated_files:
                if gf.filename.startswith("job_"):
                    job_content = gf.content
                    break
            
            report_builder = ReportBuilder(ir_plan, job_content)
            report = report_builder.build()
            report.generated_files = [gf.filename for gf in generated_files]
            result.reports.append(report)
            
            report_path = os.path.join(artifact_dir, f"report_{mapping.name}.json")
            with open(report_path, "w") as f:
                json.dump(report.model_dump(), f, indent=2)
        
        result.mappings_processed = len(mappings)
        
        zip_path = self._create_zip(artifact_id, result)
        result.zip_path = zip_path
        
        return {
            "success": True,
            "artifact_id": artifact_id,
            "result": result.model_dump(),
            "zip_path": zip_path
        }
    
    def _parse_user_config(self, artifact_id: str, config_dict: Dict[str, Any]) -> UserConfig:
        """Parse user configuration from dictionary."""
        sources = []
        for src in config_dict.get("sources", []):
            source_config = SourceConfig(
                source_name=src.get("source_name", ""),
                source_type=SourceType(src.get("source_type", "SQL")),
                connection_alias=src.get("connection_alias"),
                file_format=FileFormat(src.get("file_format", "csv")) if src.get("file_format") else None,
                file_location=FileLocation(src.get("file_location", "local")) if src.get("file_location") else None,
                file_path=src.get("file_path"),
                delimiter=src.get("delimiter", ","),
                header=src.get("header", True),
                quote_char=src.get("quote_char", '"'),
                escape_char=src.get("escape_char", "\\"),
                encoding=src.get("encoding", "UTF-8")
            )
            sources.append(source_config)
        
        targets = []
        for tgt in config_dict.get("targets", []):
            target_config = TargetConfig(
                target_name=tgt.get("target_name", ""),
                output_format=tgt.get("output_format", "delta"),
                destination_path=tgt.get("destination_path", ""),
                table_name=tgt.get("table_name", ""),
                write_mode=tgt.get("write_mode", "append")
            )
            targets.append(target_config)
        
        db_connections = config_dict.get("db_connections", {})
        
        return UserConfig(
            artifact_id=artifact_id,
            sources=sources,
            targets=targets,
            db_connections=db_connections
        )
    
    def _create_zip(self, artifact_id: str, result: GenerationResult) -> str:
        """Create ZIP file with all generated files."""
        artifact_dir = os.path.join(self.output_dir, artifact_id)
        zip_filename = f"{artifact_id}_pyspark.zip"
        zip_path = os.path.join(artifact_dir, zip_filename)
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for gen_file in result.files:
                file_path = os.path.join(artifact_dir, gen_file.filename)
                if os.path.exists(file_path):
                    zipf.write(file_path, gen_file.filename)
            
            for report in result.reports:
                report_filename = f"report_{report.mapping_name}.json"
                report_path = os.path.join(artifact_dir, report_filename)
                if os.path.exists(report_path):
                    zipf.write(report_path, report_filename)
        
        return zip_path
    
    def get_artifact(self, artifact_id: str) -> Optional[Dict[str, Any]]:
        """Get artifact information."""
        if artifact_id in self.artifacts:
            artifact = self.artifacts[artifact_id]
            return {
                "artifact_id": artifact_id,
                "created_at": artifact.get("created_at"),
                "filename": artifact.get("filename"),
                "analysis": artifact.get("analysis").model_dump() if artifact.get("analysis") else None
            }
        
        artifact_dir = os.path.join(self.output_dir, artifact_id)
        if os.path.exists(artifact_dir):
            analysis_path = os.path.join(artifact_dir, "analysis.json")
            if os.path.exists(analysis_path):
                with open(analysis_path, "r") as f:
                    analysis_data = json.load(f)
                return {
                    "artifact_id": artifact_id,
                    "analysis": analysis_data
                }
        
        return None
    
    def get_download_path(self, artifact_id: str) -> Optional[str]:
        """Get path to download ZIP file."""
        artifact_dir = os.path.join(self.output_dir, artifact_id)
        zip_path = os.path.join(artifact_dir, f"{artifact_id}_pyspark.zip")
        
        if os.path.exists(zip_path):
            return zip_path
        
        return None
