"""Expression Translator - translates Informatica expressions to PySpark."""
import re
from typing import Dict, List, Optional, Tuple


class ExpressionTranslator:
    """Translates Informatica expressions to PySpark/SQL expressions."""
    
    FUNCTION_MAP = {
        'IIF': 'when',
        'DECODE': 'when',
        'NVL': 'coalesce',
        'ISNULL': 'isnull',
        'IS_SPACES': 'trim({}) == ""',
        'IS_NUMBER': 'cast({} as double).isNotNull()',
        'TO_CHAR': 'cast({} as string)',
        'TO_DATE': 'to_date',
        'TO_DECIMAL': 'cast({} as decimal)',
        'TO_INTEGER': 'cast({} as int)',
        'TO_BIGINT': 'cast({} as bigint)',
        'TO_FLOAT': 'cast({} as float)',
        'SUBSTR': 'substring',
        'INSTR': 'instr',
        'LTRIM': 'ltrim',
        'RTRIM': 'rtrim',
        'TRIM': 'trim',
        'UPPER': 'upper',
        'LOWER': 'lower',
        'LENGTH': 'length',
        'LPAD': 'lpad',
        'RPAD': 'rpad',
        'CONCAT': 'concat',
        'REPLACE': 'regexp_replace',
        'REG_REPLACE': 'regexp_replace',
        'REG_MATCH': 'regexp_extract',
        'ROUND': 'round',
        'TRUNC': 'trunc',
        'ABS': 'abs',
        'MOD': 'mod',
        'POWER': 'pow',
        'SQRT': 'sqrt',
        'FLOOR': 'floor',
        'CEIL': 'ceil',
        'LOG': 'log',
        'EXP': 'exp',
        'SYSDATE': 'current_date()',
        'SYSTIMESTAMP': 'current_timestamp()',
        'SESSSTARTTIME': 'current_timestamp()',
        'ADD_TO_DATE': 'date_add',
        'DATE_DIFF': 'datediff',
        'GET_DATE_PART': 'date_part',
        'SET_DATE_PART': None,
        'LAST_DAY': 'last_day',
        'MAKE_DATE_TIME': 'to_timestamp',
        'SUM': 'sum',
        'COUNT': 'count',
        'AVG': 'avg',
        'MIN': 'min',
        'MAX': 'max',
        'FIRST': 'first',
        'LAST': 'last',
        'MEDIAN': 'percentile_approx({}, 0.5)',
        'STDDEV': 'stddev',
        'VARIANCE': 'variance',
    }
    
    def __init__(self, mapping_name: str = "", pm_variables: Dict[str, str] = None):
        self.mapping_name = mapping_name
        self.pm_variables = pm_variables or {}
        self.warnings: List[str] = []
        
    def translate(self, expression: str, context: str = "column") -> str:
        """Translate an Informatica expression to PySpark."""
        if not expression:
            return ""
        
        result = expression
        
        result = self._replace_pm_variables(result)
        
        result = self._translate_iif(result)
        
        result = self._translate_decode(result)
        
        result = self._translate_functions(result)
        
        result = self._translate_operators(result)
        
        result = self._clean_up(result)
        
        return result
    
    def _replace_pm_variables(self, expr: str) -> str:
        """Replace $PM variables with actual values."""
        result = expr
        
        result = re.sub(
            r'\$PMMappingName',
            f'"{self.mapping_name}"',
            result,
            flags=re.IGNORECASE
        )
        
        result = re.sub(
            r'\$PMWorkflowName',
            f'"{self.mapping_name}"',
            result,
            flags=re.IGNORECASE
        )
        
        result = re.sub(
            r'\$PMSessionName',
            f'"{self.mapping_name}"',
            result,
            flags=re.IGNORECASE
        )
        
        result = re.sub(
            r'\$PMFolderName',
            '"default"',
            result,
            flags=re.IGNORECASE
        )
        
        for var_name, var_value in self.pm_variables.items():
            result = re.sub(
                re.escape(var_name),
                f'"{var_value}"',
                result,
                flags=re.IGNORECASE
            )
        
        remaining_pm = re.findall(r'\$PM[A-Za-z_][A-Za-z0-9_]*', result)
        for pm_var in remaining_pm:
            self.warnings.append(f"Unresolved PM variable: {pm_var}")
            result = result.replace(pm_var, f'lit("{pm_var}")')
        
        return result
    
    def _translate_iif(self, expr: str) -> str:
        """Translate IIF(condition, true_val, false_val) to when/otherwise."""
        pattern = re.compile(r'IIF\s*\(', re.IGNORECASE)
        
        while pattern.search(expr):
            match = pattern.search(expr)
            if not match:
                break
            
            start = match.end()
            args = self._extract_function_args(expr, start - 1)
            
            if len(args) >= 2:
                condition = args[0]
                true_val = args[1]
                false_val = args[2] if len(args) > 2 else "None"
                
                pyspark_expr = f"when({condition}, {true_val}).otherwise({false_val})"
                
                full_match = expr[match.start():self._find_closing_paren(expr, match.end() - 1) + 1]
                expr = expr.replace(full_match, pyspark_expr, 1)
            else:
                break
        
        return expr
    
    def _translate_decode(self, expr: str) -> str:
        """Translate DECODE to chained when statements."""
        pattern = re.compile(r'DECODE\s*\(', re.IGNORECASE)
        
        while pattern.search(expr):
            match = pattern.search(expr)
            if not match:
                break
            
            start = match.end()
            args = self._extract_function_args(expr, start - 1)
            
            if len(args) >= 3:
                test_expr = args[0]
                pairs = args[1:]
                
                when_clauses = []
                default_val = "None"
                
                i = 0
                while i < len(pairs) - 1:
                    search_val = pairs[i]
                    result_val = pairs[i + 1]
                    when_clauses.append(f"when({test_expr} == {search_val}, {result_val})")
                    i += 2
                
                if len(pairs) % 2 == 1:
                    default_val = pairs[-1]
                
                pyspark_expr = ".".join(when_clauses) + f".otherwise({default_val})"
                
                full_match = expr[match.start():self._find_closing_paren(expr, match.end() - 1) + 1]
                expr = expr.replace(full_match, pyspark_expr, 1)
            else:
                break
        
        return expr
    
    def _translate_functions(self, expr: str) -> str:
        """Translate Informatica functions to PySpark equivalents."""
        result = expr
        
        for infa_func, spark_func in self.FUNCTION_MAP.items():
            if spark_func is None:
                continue
            
            pattern = re.compile(rf'\b{infa_func}\s*\(', re.IGNORECASE)
            
            if '{}' in spark_func:
                while pattern.search(result):
                    match = pattern.search(result)
                    if not match:
                        break
                    
                    args = self._extract_function_args(result, match.end() - 1)
                    if args:
                        new_func = spark_func.format(args[0])
                        full_match = result[match.start():self._find_closing_paren(result, match.end() - 1) + 1]
                        result = result.replace(full_match, new_func, 1)
                    else:
                        break
            else:
                result = pattern.sub(f'{spark_func}(', result)
        
        return result
    
    def _translate_operators(self, expr: str) -> str:
        """Translate operators."""
        result = expr
        
        result = re.sub(r'\|\|', ' + ', result)
        
        result = re.sub(r'\bAND\b', '&', result, flags=re.IGNORECASE)
        result = re.sub(r'\bOR\b', '|', result, flags=re.IGNORECASE)
        result = re.sub(r'\bNOT\b', '~', result, flags=re.IGNORECASE)
        
        result = re.sub(r"'([^']*)'", r'"\1"', result)
        
        return result
    
    def _clean_up(self, expr: str) -> str:
        """Clean up the translated expression."""
        result = expr
        
        result = re.sub(r'\s+', ' ', result)
        result = result.strip()
        
        return result
    
    def _extract_function_args(self, expr: str, start_paren: int) -> List[str]:
        """Extract arguments from a function call."""
        if start_paren >= len(expr) or expr[start_paren] != '(':
            return []
        
        args = []
        current_arg = ""
        depth = 0
        
        for i in range(start_paren + 1, len(expr)):
            char = expr[i]
            
            if char == '(':
                depth += 1
                current_arg += char
            elif char == ')':
                if depth == 0:
                    if current_arg.strip():
                        args.append(current_arg.strip())
                    break
                depth -= 1
                current_arg += char
            elif char == ',' and depth == 0:
                args.append(current_arg.strip())
                current_arg = ""
            else:
                current_arg += char
        
        return args
    
    def _find_closing_paren(self, expr: str, start: int) -> int:
        """Find the position of the closing parenthesis."""
        depth = 0
        for i in range(start, len(expr)):
            if expr[i] == '(':
                depth += 1
            elif expr[i] == ')':
                depth -= 1
                if depth == 0:
                    return i
        return len(expr) - 1
