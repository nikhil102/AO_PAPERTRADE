"""Tiny static server for the fastrecon docs site.

Plain stdlib http.server — no Node, no framework. Reads PORT from env so
it slots cleanly into a Replit workflow.
"""
from __future__ import annotations

import os
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PORT = int(os.environ.get("PORT", "5000"))
ROOT = Path(__file__).resolve().parent


class NoCacheHandler(SimpleHTTPRequestHandler):
    def end_headers(self) -> None:
        # Disable caching during development so edits show up immediately.
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def log_message(self, fmt: str, *args) -> None:
        print("[docs] " + (fmt % args), flush=True)


def main() -> None:
    handler = partial(NoCacheHandler, directory=str(ROOT))
    server = ThreadingHTTPServer(("0.0.0.0", PORT), handler)
    print(f"[docs] serving {ROOT} on http://0.0.0.0:{PORT}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("[docs] shutting down", flush=True)
        server.shutdown()


if __name__ == "__main__":
    main()
