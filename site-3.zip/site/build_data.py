"""Build site/data.js from examples/*.py + examples/captured/*.txt.

The static site loads `data.js` and renders examples client-side, so the
content stays in lockstep with the executable, tested example scripts.
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EXAMPLES = ROOT / "examples"
CAPTURED = EXAMPLES / "captured"
OUT = ROOT / "site" / "data.js"

# id -> (title, category, blurb)
META = {
    "01_csv_vs_csv":               ("CSV vs CSV",                        "files",  "Reconcile two CSV files by primary key — the canonical entry point."),
    "02_parquet_vs_parquet":       ("Parquet vs Parquet",                "files",  "Same flow, different source class. Columnar inputs."),
    "03_csv_vs_parquet":           ("CSV vs Parquet",                    "files",  "Cross-format: heterogeneous sources reconcile transparently."),
    "04_sql_table_vs_sql_table":   ("SQL table vs SQL table",            "sql",    "Both sides resolved through SQLAlchemy URIs."),
    "05_sql_table_vs_sql_query":   ("SQL table vs SQL query",            "sql",    "Reshape one side on the fly with SQL before the diff."),
    "06_sql_query_vs_sql_query":   ("SQL query vs SQL query",            "sql",    "Reconcile two computed views — totals only, ignoring the rest."),
    "07_sql_vs_csv":               ("SQL table vs CSV",                  "mixed",  "Prove a CSV export matches its source table byte-for-byte."),
    "08_sql_vs_parquet":           ("SQL query vs Parquet",              "mixed",  "ETL-export reconciliation against a Parquet file."),
    "10_compare_modes":            ("Every compare_mode",                "modes",  "Walk schema, rowcount, names_only, keyed, sampled, profile, hash."),
    "11_recon_config":             ("ReconConfig: tolerances & casing",  "config", "Tame noisy data — case, trim, null, numeric tolerance."),
    "12_column_mapping_and_excludes": ("Column mapping & excludes",      "config", "Reconcile across renames; ignore noisy columns entirely."),
    "13_partitioning":             ("Partitioned compare",               "scale",  "Split the work into N buckets — value, hash, or range."),
    "14_hash_mode_fingerprint":    ("Hash-mode fingerprint",             "modes",  "One xxhash64 per side. The cheapest 'are these identical?' check."),
    "15_row_hash_fast_path":       ("ReconConfig.row_hash",              "scale",  "Per-row 64-bit hash — much faster on wide tables."),
    "16_output_formats":           ("Output formats",                    "output", "Render the same result as text, JSON, HTML, JUnit XML, dict, CSV."),
    "17_source_autodetect":        ("source() autodetect",               "files",  "Pick the right Source class from the path extension."),
    "18_json_source":              ("JSON / NDJSON source",              "files",  "Reconcile newline-delimited JSON against CSV."),
    "19_hash_compare_direct":      ("hash_compare() low-level API",      "modes",  "Drive fingerprint comparison directly with a DuckDBEngine."),
    "20_error_handling":           ("Error handling",                    "config", "compare() reports failures as a ReconResult with status=ERROR."),
}


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8") if p.exists() else ""


def build():
    examples = []
    for stem, (title, category, blurb) in META.items():
        code = read_text(EXAMPLES / f"{stem}.py")
        output = read_text(CAPTURED / f"{stem}.txt")
        examples.append(
            {
                "id": stem,
                "title": title,
                "category": category,
                "blurb": blurb,
                "code": code,
                "output": output,
            }
        )

    # Setup script for data fixtures.
    setup_code = read_text(EXAMPLES / "setup_data.py")

    payload = {
        "version": "0.9.1",
        "examples": examples,
        "setup": {
            "id": "setup_data",
            "title": "Sample data fixtures",
            "category": "intro",
            "blurb": "Generates the CSV, Parquet, and SQLite fixtures every example uses.",
            "code": setup_code,
            "output": "created:\n  data/demo.sqlite     12288 bytes\n  data/left.csv          124 bytes\n  data/left.parquet     2798 bytes\n  data/right.csv         122 bytes\n  data/right.parquet    2796 bytes",
        },
    }
    OUT.write_text("window.FASTRECON_DOCS = " + json.dumps(payload, indent=2) + ";\n")
    print(f"wrote {OUT}  ({OUT.stat().st_size} bytes, {len(examples)} examples)")


if __name__ == "__main__":
    build()
