# m_UPWebPlan_FD_MRO_HII_PartAttributes - PySpark Conversion

This code was auto-generated from Informatica PowerCenter XML by the Informatica to PySpark Converter.

## 1. Environment Variables Setup

### PowerShell
```powershell
# Required environment variables (MSSQL for both source and target)
$env:MSSQL_HOST='your_server.com\INSTANCE'
$env:MSSQL_USER='spark_user'
$env:MSSQL_PASSWORD='your_mssql_password'
$env:MSSQL_DRIVER_JAR='C:/Drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
$env:SRC_SYSTEM_NM='SSC'
$env:ENV_NAME='development'
$env:LOG_LEVEL='INFO'
```

### Bash/Linux
```bash
# Required environment variables (MSSQL for both source and target)
export MSSQL_HOST='your_server.com\INSTANCE'
export MSSQL_USER='spark_user'
export MSSQL_PASSWORD='your_mssql_password'
export MSSQL_DRIVER_JAR='/opt/drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
export SRC_SYSTEM_NM='SSC'
export ENV_NAME='development'
export LOG_LEVEL='INFO'
```

## 2. Target Table Schema

### Target: FF_UP_ELEC_WebPlan_PartAttributes (Database: msscdm_dev3)

```sql
-- MSSQL CREATE TABLE syntax
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FF_UP_ELEC_WebPlan_PartAttributes]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[FF_UP_ELEC_WebPlan_PartAttributes] (
        [PARTNUMBER] NVARCHAR(80) NULL,
        [PLANT] NVARCHAR(4) NULL,
        [STORAGE_LOCATION] NVARCHAR(4) NULL,
        [SKUACTIVE] NVARCHAR(1) NULL,
        [SKUCUST2] NVARCHAR(80) NULL,
        [SKUCUST3] NVARCHAR(80) NULL,
        [SL] NUMERIC(18,0) NULL,
        [ISASLITEM] NVARCHAR(1) NULL,
        [SLDA] NUMERIC(18,2) NULL,
        [SLDS] NUMERIC(18,2) NULL,
        [SLSETEOQ] NUMERIC(18,2) NULL,
        [AC4] NVARCHAR(80) NULL,
        [PC8_CATALOG_LT] NVARCHAR(80) NULL,
        [PARTFAMILYNAME] NVARCHAR(80) NULL,
        [PARTCRITICAL] NVARCHAR(255) NULL,
        [EOQ] NUMERIC(18,0) NULL,
        [MFG_LT] NUMERIC(18,0) NULL,
        [COLD_START_LEAD_TIME] NUMERIC(18,0) NULL,
        [HW_SBU] NVARCHAR(40) NULL,
        [HW_PART_FAMILY] NVARCHAR(80) NULL,
        [HW_LI_CLASS] NVARCHAR(80) NULL,
        [HW_CAMPAIGN] NVARCHAR(30) NULL,
        [HW_EIS] NVARCHAR(120) NULL,
        [HW_ICAO] NVARCHAR(30) NULL,
        [HW_LRU_DETAILS] NVARCHAR(2000) NULL,
        [HW_DEMAND_PLANNER] NVARCHAR(80) NULL
    )
END
```

## 3. What is $$SRC_SYSTEM_NM?

`$$SRC_SYSTEM_NM` is an Informatica runtime parameter used in mapping/workflow sessions.

**How to find the value:**
1. Open Workflow Manager
2. Open the workflow
3. In the Session task -> Properties / Config Object, check the Parameter File path
4. Open that `.par` file and search for `SRC_SYSTEM_NM`

In this config, the default is set to `SSC`. Override via environment variable if needed:
```powershell
$env:SRC_SYSTEM_NM='YOUR_VALUE'
```

## 4. How to Run

### Quick Run (config in same folder)
```bash
python m_upwebplan_fd_mro_hii_partattributes.py
```

### With custom config path
```powershell
$env:CONFIG_PATH='C:\path\to\config_m_upwebplan_fd_mro_hii_partattributes.yml'
python m_upwebplan_fd_mro_hii_partattributes.py
```

## 5. Files Generated

- `m_upwebplan_fd_mro_hii_partattributes.py` - Main PySpark mapping code
- `config_m_upwebplan_fd_mro_hii_partattributes.yml` - Configuration file with environment variables
- `README.md` - This documentation file

## 6. Notes

- Passwords with special characters (like `$`, `@`, `*`) must use single quotes in PowerShell
- The `SRC_ROWID` column is typically set as IDENTITY in MSSQL if not mapped from source
- Target database is fixed as msscdm_dev3
- Review and test the generated code before production use
