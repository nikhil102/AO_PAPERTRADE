# m_SalesOrder_FD_MRO - PySpark Conversion

This code was auto-generated from Informatica PowerCenter XML by the Informatica to PySpark Converter.

## 1. Environment Variables Setup

### PowerShell
```powershell
# Required environment variables (MSSQL for both source and target)
$env:MSSQL_HOST='your_server.com\INSTANCE'
$env:MSSQL_USER='spark_user'
$env:MSSQL_PASSWORD='your_mssql_password'
$env:MSSQL_DRIVER_JAR='C:/Drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
$env:SRC_SYSTEM_NM='SSC'
$env:ENV_NAME='development'
$env:LOG_LEVEL='INFO'
```

### Bash/Linux
```bash
# Required environment variables (MSSQL for both source and target)
export MSSQL_HOST='your_server.com\INSTANCE'
export MSSQL_USER='spark_user'
export MSSQL_PASSWORD='your_mssql_password'
export MSSQL_DRIVER_JAR='/opt/drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
export SRC_SYSTEM_NM='SSC'
export ENV_NAME='development'
export LOG_LEVEL='INFO'
```

## 2. Target Table Schema

### Target: IPCSSOURCE_SALES_ORDER (Database: msscdm_dev3)

```sql
-- MSSQL CREATE TABLE syntax
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPCSSOURCE_SALES_ORDER]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[IPCSSOURCE_SALES_ORDER] (
        [DOWNLOADID] NVARCHAR(18) NOT NULL,
        [HOSTSALESORDERID] NVARCHAR(80) NOT NULL,
        [HOSTPARTID] NVARCHAR(80) NULL,
        [HOSTLOCID] NVARCHAR(80) NULL,
        [SALESORDERDTDUE] NVARCHAR(8) NULL,
        [SALESORDERDTRECEIVED] NVARCHAR(8) NULL,
        [SALESORDERDTPROMISED] NVARCHAR(8) NULL,
        [ORDEREDQTY] NVARCHAR(18) NULL,
        [PROMISEDQTY] NVARCHAR(18) NULL,
        [SHIPPEDQTY] NVARCHAR(18) NULL,
        [OPENQTY] NVARCHAR(18) NULL,
        [HOSTCUSTOMERID] NVARCHAR(80) NULL,
        [HOSTCUSTOMERNAME] NVARCHAR(80) NULL,
        [SALESORDERSTATUS] NVARCHAR(1) NULL,
        [PRIORITY] NVARCHAR(18) NULL,
        [COUNTINORDERPLAN] NVARCHAR(1) NULL,
        [BACKORDER] NVARCHAR(1) NULL,
        [PRODUCTIONORDER] NVARCHAR(1) NULL,
        [KITBOM] NVARCHAR(1) NULL,
        [ORDERPLANORDERID] NVARCHAR(18) NULL,
        [HOSTPARTKITSALESORDERID] NVARCHAR(80) NULL,
        [HOSTDESTINATIONLOCID] NVARCHAR(80) NULL,
        [COUNTINNETTING] NVARCHAR(1) NULL,
        [DATA_SOURCE] NVARCHAR(20) NULL,
        [BUSINESS_UNIT_NM] NVARCHAR(20) NOT NULL,
        [EDIT_ID] NVARCHAR(20) NULL,
        [EDIT_DT] DATE NOT NULL
    )
END
```

## 3. What is $$SRC_SYSTEM_NM?

`$$SRC_SYSTEM_NM` is an Informatica runtime parameter used in mapping/workflow sessions.

**How to find the value:**
1. Open Workflow Manager
2. Open the workflow
3. In the Session task -> Properties / Config Object, check the Parameter File path
4. Open that `.par` file and search for `SRC_SYSTEM_NM`

In this config, the default is set to `SSC`. Override via environment variable if needed:
```powershell
$env:SRC_SYSTEM_NM='YOUR_VALUE'
```

## 4. How to Run

### Quick Run (config in same folder)
```bash
python m_salesorder_fd_mro.py
```

### With custom config path
```powershell
$env:CONFIG_PATH='C:\path\to\config_m_salesorder_fd_mro.yml'
python m_salesorder_fd_mro.py
```

## 5. Files Generated

- `m_salesorder_fd_mro.py` - Main PySpark mapping code
- `config_m_salesorder_fd_mro.yml` - Configuration file with environment variables
- `README.md` - This documentation file

## 6. Notes

- Passwords with special characters (like `$`, `@`, `*`) must use single quotes in PowerShell
- The `SRC_ROWID` column is typically set as IDENTITY in MSSQL if not mapped from source
- Target database is fixed as msscdm_dev3
- Review and test the generated code before production use
