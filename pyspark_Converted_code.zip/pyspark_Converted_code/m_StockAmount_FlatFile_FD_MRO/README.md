# m_StockAmount_FlatFile_FD_MRO - PySpark Conversion

This code was auto-generated from Informatica PowerCenter XML by the Informatica to PySpark Converter.

## 1. Environment Variables Setup

### PowerShell
```powershell
# Required environment variables (MSSQL for both source and target)
$env:MSSQL_HOST='your_server.com\INSTANCE'
$env:MSSQL_USER='spark_user'
$env:MSSQL_PASSWORD='your_mssql_password'
$env:MSSQL_DRIVER_JAR='C:/Drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
$env:SRC_SYSTEM_NM='SSC'
$env:ENV_NAME='development'
$env:LOG_LEVEL='INFO'
```

### Bash/Linux
```bash
# Required environment variables (MSSQL for both source and target)
export MSSQL_HOST='your_server.com\INSTANCE'
export MSSQL_USER='spark_user'
export MSSQL_PASSWORD='your_mssql_password'
export MSSQL_DRIVER_JAR='/opt/drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
export SRC_SYSTEM_NM='SSC'
export ENV_NAME='development'
export LOG_LEVEL='INFO'
```

## 2. Target Table Schema

### Target: FF_STOCK_AMOUNT (Database: msscdm_dev3)

```sql
-- MSSQL CREATE TABLE syntax
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FF_STOCK_AMOUNT]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[FF_STOCK_AMOUNT] (
        [DOWNLOADID] NUMERIC(18,0) NOT NULL,
        [HOSTPARTID] NVARCHAR(160) NOT NULL,
        [HOSTLOCID] NVARCHAR(160) NOT NULL,
        [ONORDER] NUMERIC(18,0) NULL,
        [BACKORDER] NUMERIC(18,0) NULL,
        [INREPAIR] NUMERIC(18,0) NULL,
        [INRETURN] NUMERIC(18,0) NULL,
        [ONHANDNEW] NUMERIC(18,0) NULL,
        [ONHANDFIXED] NUMERIC(18,0) NULL,
        [ONHANDBAD] NUMERIC(18,0) NULL,
        [INRETURNGOOD] NUMERIC(18,0) NULL,
        [INRETURNBAD] NUMERIC(18,0) NULL,
        [INREPAIRGOOD] NUMERIC(18,0) NULL,
        [INREPAIRBAD] NUMERIC(18,0) NULL,
        [ALLOCATED] NUMERIC(18,0) NULL,
        [AMOUNTCUSTOM1] NVARCHAR(160) NULL,
        [AMOUNTCUSTOM2] NVARCHAR(160) NULL,
        [AMOUNTCUSTOM3] NVARCHAR(160) NULL,
        [AMOUNTCUSTOM4] NVARCHAR(160) NULL,
        [AMOUNTCUSTOM5] NVARCHAR(160) NULL,
        [AMOUNTCUSTOM6] NVARCHAR(160) NULL,
        [AMOUNTCUSTOM7] NVARCHAR(160) NULL,
        [AMOUNTCUSTOM8] NVARCHAR(160) NULL,
        [AMOUNTCUSTOM9] NVARCHAR(160) NULL,
        [AMOUNTCUSTOM10] NVARCHAR(160) NULL
    )
END
```

### Target: IPCSSOURCE_STOCK_AMOUNT_AGG (Database: msscdm_dev3)

```sql
-- MSSQL CREATE TABLE syntax
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPCSSOURCE_STOCK_AMOUNT_AGG]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[IPCSSOURCE_STOCK_AMOUNT_AGG] (
        [DOWNLOADID] NVARCHAR(18) NOT NULL,
        [HOSTPARTID] NVARCHAR(640) NOT NULL,
        [HOSTLOCID] NVARCHAR(640) NOT NULL,
        [ONORDER] NVARCHAR(18) NULL,
        [BACKORDER] NVARCHAR(18) NULL,
        [INREPAIR] NVARCHAR(18) NULL,
        [INRETURN] NVARCHAR(18) NULL,
        [ONHANDNEW] NVARCHAR(18) NULL,
        [ONHANDFIXED] NVARCHAR(18) NULL,
        [ONHANDBAD] NVARCHAR(18) NULL,
        [INRETURNGOOD] NVARCHAR(18) NULL,
        [INRETURNBAD] NVARCHAR(18) NULL,
        [INREPAIRGOOD] NVARCHAR(18) NULL,
        [INREPAIRBAD] NVARCHAR(18) NULL,
        [ALLOCATED] NVARCHAR(18) NULL,
        [AMOUNTCUSTOM1] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM2] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM3] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM4] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM5] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM6] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM7] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM8] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM9] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM10] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM11] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM12] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM13] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM14] NVARCHAR(640) NULL,
        [AMOUNTCUSTOM15] NVARCHAR(640) NULL,
        [BUSINESS_UNIT_NM] NVARCHAR(20) NOT NULL,
        [EDIT_ID] NVARCHAR(20) NULL,
        [EDIT_DT] DATE NOT NULL,
        [MAPPING_NAME] NVARCHAR(80) NULL
    )
END
```

## 3. What is $$SRC_SYSTEM_NM?

`$$SRC_SYSTEM_NM` is an Informatica runtime parameter used in mapping/workflow sessions.

**How to find the value:**
1. Open Workflow Manager
2. Open the workflow
3. In the Session task -> Properties / Config Object, check the Parameter File path
4. Open that `.par` file and search for `SRC_SYSTEM_NM`

In this config, the default is set to `SSC`. Override via environment variable if needed:
```powershell
$env:SRC_SYSTEM_NM='YOUR_VALUE'
```

## 4. How to Run

### Quick Run (config in same folder)
```bash
python m_stockamount_flatfile_fd_mro.py
```

### With custom config path
```powershell
$env:CONFIG_PATH='C:\path\to\config_m_stockamount_flatfile_fd_mro.yml'
python m_stockamount_flatfile_fd_mro.py
```

## 5. Files Generated

- `m_stockamount_flatfile_fd_mro.py` - Main PySpark mapping code
- `config_m_stockamount_flatfile_fd_mro.yml` - Configuration file with environment variables
- `README.md` - This documentation file

## 6. Notes

- Passwords with special characters (like `$`, `@`, `*`) must use single quotes in PowerShell
- The `SRC_ROWID` column is typically set as IDENTITY in MSSQL if not mapped from source
- Target database is fixed as msscdm_dev3
- Review and test the generated code before production use
