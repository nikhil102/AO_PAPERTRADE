# m_PartFamily_FS_MRO - PySpark Conversion

This code was auto-generated from Informatica PowerCenter XML by the Informatica to PySpark Converter.

## 1. Environment Variables Setup

### PowerShell
```powershell
# Required environment variables (MSSQL for both source and target)
$env:MSSQL_HOST='your_server.com\INSTANCE'
$env:MSSQL_USER='spark_user'
$env:MSSQL_PASSWORD='your_mssql_password'
$env:MSSQL_DRIVER_JAR='C:/Drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
$env:SRC_SYSTEM_NM='SSC'
$env:ENV_NAME='development'
$env:LOG_LEVEL='INFO'
```

### Bash/Linux
```bash
# Required environment variables (MSSQL for both source and target)
export MSSQL_HOST='your_server.com\INSTANCE'
export MSSQL_USER='spark_user'
export MSSQL_PASSWORD='your_mssql_password'
export MSSQL_DRIVER_JAR='/opt/drivers/mssql-jdbc-12.4.2.jre11.jar'

# Optional parameters (with defaults)
export SRC_SYSTEM_NM='SSC'
export ENV_NAME='development'
export LOG_LEVEL='INFO'
```

## 2. Target Table Schema

### Target: IPCSSOURCE_PART_FAMILY (Database: msscdm_dev3)

```sql
-- MSSQL CREATE TABLE syntax
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IPCSSOURCE_PART_FAMILY]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[IPCSSOURCE_PART_FAMILY] (
        [DOWNLOADID] NVARCHAR(38) NOT NULL,
        [HOSTPARTFAMILYID] NVARCHAR(50) NOT NULL,
        [FAMILYNAME] NVARCHAR(50) NULL,
        [RR_MONTHS] NVARCHAR(38) NULL,
        [BUSINESS_UNIT_NM] NVARCHAR(20) NOT NULL,
        [EDIT_ID] NVARCHAR(20) NULL,
        [EDIT_DT] DATE NOT NULL
    )
END
```

## 3. What is $$SRC_SYSTEM_NM?

`$$SRC_SYSTEM_NM` is an Informatica runtime parameter used in mapping/workflow sessions.

**How to find the value:**
1. Open Workflow Manager
2. Open the workflow
3. In the Session task -> Properties / Config Object, check the Parameter File path
4. Open that `.par` file and search for `SRC_SYSTEM_NM`

In this config, the default is set to `SSC`. Override via environment variable if needed:
```powershell
$env:SRC_SYSTEM_NM='YOUR_VALUE'
```

## 4. How to Run

### Quick Run (config in same folder)
```bash
python m_partfamily_fs_mro.py
```

### With custom config path
```powershell
$env:CONFIG_PATH='C:\path\to\config_m_partfamily_fs_mro.yml'
python m_partfamily_fs_mro.py
```

## 5. Files Generated

- `m_partfamily_fs_mro.py` - Main PySpark mapping code
- `config_m_partfamily_fs_mro.yml` - Configuration file with environment variables
- `README.md` - This documentation file

## 6. Notes

- Passwords with special characters (like `$`, `@`, `*`) must use single quotes in PowerShell
- The `SRC_ROWID` column is typically set as IDENTITY in MSSQL if not mapped from source
- Target database is fixed as msscdm_dev3
- Review and test the generated code before production use
