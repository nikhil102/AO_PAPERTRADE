"""
Mapping: m_landing_party_external_id_delta
Converted 1:1 from Informatica PowerCenter XML -> PySpark.

Approach:
- Source Qualifier + Lookup SQL Overrides are executed as SQL Server pushdown via JDBC (no Spark-SQL reimplementation).
- Expression logic is replicated 1:1 in Spark (only status derivations exist in this mapping).
- Union + Update Strategy are replicated; Update Strategy in XML is DD_INSERT (0) so writes are append inserts.
- Target is PostgreSQL (as per your connection details).

Required env vars:
  - MSSQL_PASSWORD
  - PG_PASSWORD
Optional:
  - SRC_SYSTEM_NM (default: SSC)
  - CONFIG_PATH (default: config_m_landing_party_external_id_delta_pg_v2.yml)
"""

from __future__ import annotations
import os
import re
import logging
from typing import Dict, Any

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, lit, when, trim
import yaml


# -----------------------------------------------------------------------------
# Logging
# -----------------------------------------------------------------------------
def _setup_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s - %(message)s"
    )


# -----------------------------------------------------------------------------
# Config helpers (supports ${VAR} and ${VAR:default})
# -----------------------------------------------------------------------------
_ENV_PATTERN = re.compile(r"\$\{([A-Z0-9_]+)(?::([^}]*))?\}", re.IGNORECASE)

def _expand_env(value: Any) -> Any:
    if not isinstance(value, str):
        return value

    def repl(m: re.Match) -> str:
        var = m.group(1)
        default = m.group(2)
        v = os.getenv(var)
        if v is None or v == "":
            return default if default is not None else ""
        return v

    return _ENV_PATTERN.sub(repl, value)

def load_config(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    def walk(x):
        if isinstance(x, dict):
            return {k: walk(v) for k, v in x.items()}
        if isinstance(x, list):
            return [walk(v) for v in x]
        return _expand_env(x)

    return walk(raw)


# -----------------------------------------------------------------------------
# Spark session
# -----------------------------------------------------------------------------
def get_spark_session(app_name: str, spark_conf: Dict[str, Any]) -> SparkSession:
    b = SparkSession.builder.appName(app_name)
    configs = (spark_conf or {}).get("configs", {})
    for k, v in configs.items():
        if v is None:
            continue
        b = b.config(k, str(v))
    return b.getOrCreate()


# -----------------------------------------------------------------------------
# JDBC helpers
# -----------------------------------------------------------------------------
def jdbc_read_query(spark: SparkSession, conn: Dict[str, Any], query: str) -> DataFrame:
    dbtable = f"({query}) AS src"
    return (
        spark.read.format("jdbc")
        .option("url", conn["jdbc_url"])
        .option("dbtable", dbtable)
        .option("user", conn.get("user", ""))
        .option("password", conn.get("password", ""))
        .option("driver", conn.get("driver", ""))
        .option("fetchsize", str(conn.get("fetchsize", "10000")))
        .load()
    )

def jdbc_write(df: DataFrame, conn: Dict[str, Any], dbtable: str, mode: str = "append") -> None:
    (
        df.write.format("jdbc")
        .option("url", conn["jdbc_url"])
        .option("dbtable", dbtable)
        .option("user", conn.get("user", ""))
        .option("password", conn.get("password", ""))
        .option("driver", conn.get("driver", ""))
        .mode(mode)
        .save()
    )

def to_lower(df: DataFrame) -> DataFrame:
    return df.toDF(*[c.lower() for c in df.columns])

def substitute_informatica_params(sql: str, params: Dict[str, str]) -> str:
    # Replace $$PARAM with a SQL literal
    def repl(m: re.Match) -> str:
        key = m.group(1)
        val = params.get(key, "")
        if val == "":
            raise ValueError(f"Missing required parameter value for $${key} (set env var or config).")
        v = str(val).strip()
        if (v.startswith("'") and v.endswith("'")) or (v.startswith('"') and v.endswith('"')):
            return v
        return f"'{v}'"
    return re.sub(r"\$\$([A-Z0-9_]+)", repl, sql, flags=re.IGNORECASE)


# -----------------------------------------------------------------------------
# SQL extracted 1:1 from Informatica XML
# -----------------------------------------------------------------------------
SQ_SQL = {
  "SQ_today_party_external_id_xform": r"""SELECT TGT.SRC_ROWID,
	TGT.CREATED_DATE,
	TGT.CREATED_BY,
--	TGT.LAST_UPDATED_DATE,
      CASE WHEN TGT.SOURCE_SYSTEM IN ('SFDC','SALESCONNECT','DORIS') THEN getdate()

WHEN ((TGT.source_system ='EI' AND TGT.EXTERNAL_IDENTIFIER_TYPE_ID=864) OR (TGT.source_system ='RPA' AND TGT.EXTERNAL_IDENTIFIER_TYPE_ID=877)) AND TGT.LAST_UPDATED_DATE <= SRC.LAST_UPDATED_DATE
 THEN 
	   (select parameter_value_date from etl_config where parameter_name='PLAN_CONTACT_BATCH_CYCLE_DATE')

WHEN TGT.LAST_UPDATED_DATE <= SRC.LAST_UPDATED_DATE
	  THEN 
	  (select parameter_value_date from etl_config where parameter_name='BATCH_CYCLE_DATE')
		 ELSE
		 TGT.LAST_UPDATED_DATE
		 END AS LAST_UPDATED_DATE,
	TGT.LAST_UPDATED_BY ,
	TGT.DELETED_INDICATOR,
	TGT.SOURCE_EXTENAL_IDENTIFIER_ID ,
	TGT.SOURCE_PARTY_ID ,
	TGT.EXTERNAL_IDENTIFIER_TYPE_ID,
	TGT.EXTERNAL_IDENTIFIER_VALUE ,
	TGT.SOURCE_SYSTEM ,
	CASE WHEN  TGT.PARENT_SOURCE_SYSTEM IS NULL
	THEN TGT.SOURCE_SYSTEM
	ELSE
	TGT.PARENT_SOURCE_SYSTEM
	END AS PARENT_SOURCE_SYSTEM,
      TGT.DEFERRED_OWNERSHIP_IND,
     TGT.EXT_IDENTIFIER_STATUS_IND,
TGT.SURV_ASST_CODE_C
FROM
 TODAY_PARTY_EXTERNAL_ID_XFORM TGT INNER JOIN 
(SELECT 
                XFRM.SOURCE_PARTY_ROLE_ID,
                XFRM.ROLE_TYPE_ID,
                XFRM.SOURCE_PARTY_ID,
                XFRM.SOURCE_SYSTEM,
                PREV.LAST_UPDATED_DATE
FROM
TODAY_PARTY_ROLE_XFORM XFRM,
PREV_PARTY_ROLE PREV
WHERE PREV.SOURCE_PARTY_ROLE_ID=XFRM.SOURCE_PARTY_ROLE_ID
AND PREV.SOURCE_SYSTEM         = XFRM.SOURCE_SYSTEM
AND XFRM.SOURCE_SYSTEM = $$SRC_SYSTEM_NM
AND (   
                Isnull(PREV.STATUS_ID,0)   != Isnull(XFRM.STATUS_ID,0)                
                )
                AND XFRM.REJECT_ERROR_CODE IS NULL
                ) SRC
                ON ( SRC.SOURCE_PARTY_ID = TGT.SOURCE_PARTY_ID
                AND SRC.SOURCE_SYSTEM = TGT.SOURCE_SYSTEM)""",
  "SQ_today_party_external_id_xform_ins": r"""SELECT 	XFRM.SRC_ROWID,
	XFRM.CREATED_DATE,
	XFRM.CREATED_BY,
--	XFRM.LAST_UPDATED_DATE,
      CASE WHEN XFRM.SOURCE_SYSTEM IN ('SFDC','SALESCONNECT','DORIS') THEN getdate()

WHEN ((XFRM.source_system ='EI' AND XFRM.EXTERNAL_IDENTIFIER_TYPE_ID=864) OR (XFRM.source_system ='RPA' AND XFRM.EXTERNAL_IDENTIFIER_TYPE_ID=877)) AND DATEDIFF(hh,XFRM.LAST_UPDATED_DATE,ISNULL((select parameter_value_date from etl_config where parameter_name='PLAN_CONTACT_BATCH_CYCLE_DATE'),XFRM.LAST_UPDATED_DATE)) > 24
 THEN 
	   (select parameter_value_date from etl_config where parameter_name='PLAN_CONTACT_BATCH_CYCLE_DATE')
WHEN DATEDIFF(hh,XFRM.LAST_UPDATED_DATE,ISNULL((select parameter_value_date from etl_config where parameter_name='BATCH_CYCLE_DATE'),XFRM.LAST_UPDATED_DATE)) > 24
	 THEN
	 (select parameter_value_date from etl_config where parameter_name='BATCH_CYCLE_DATE')
	 ELSE
	 LAST_UPDATED_DATE
	 END AS LAST_UPDATED_DATE,
	XFRM.LAST_UPDATED_BY ,
	XFRM.DELETED_INDICATOR,
	XFRM.SOURCE_EXTENAL_IDENTIFIER_ID ,
	XFRM.SOURCE_PARTY_ID ,
	XFRM.EXTERNAL_IDENTIFIER_TYPE_ID,
	XFRM.EXTERNAL_IDENTIFIER_VALUE ,
	XFRM.SOURCE_SYSTEM ,
	CASE WHEN  XFRM.PARENT_SOURCE_SYSTEM IS NULL
	THEN XFRM.SOURCE_SYSTEM
	ELSE
	XFRM.PARENT_SOURCE_SYSTEM
	END AS PARENT_SOURCE_SYSTEM,
 'INS'  AS DEL_INS_UPD_FLAG ,
     XFRM.DEFERRED_OWNERSHIP_IND,
    XFRM.EXT_IDENTIFIER_STATUS_IND,
   XFRM.SURV_ASST_CODE_C
FROM
 TODAY_PARTY_EXTERNAL_ID_XFORM XFRM
 INNER JOIN ( SELECT SOURCE_EXTENAL_IDENTIFIER_ID , SOURCE_SYSTEM
			  FROM TODAY_PARTY_EXTERNAL_ID_XFORM
			  EXCEPT
			  SELECT SOURCE_EXTENAL_IDENTIFIER_ID , SOURCE_SYSTEM
			  FROM PREV_PARTY_EXTERNAL_ID) DELTA
ON 	(	XFRM.SOURCE_EXTENAL_IDENTIFIER_ID = DELTA.SOURCE_EXTENAL_IDENTIFIER_ID AND XFRM.SOURCE_SYSTEM=DELTA.SOURCE_SYSTEM   )
WHERE ISNULL(XFRM.EXTERNAL_IDENTIFIER_TYPE_ID,0)<>9999
AND XFRM.SOURCE_SYSTEM =$$SRC_SYSTEM_NM""",
  "SQ_today_party_external_id_xform_upd": r"""SELECT XFRM.SRC_ROWID,
	XFRM.CREATED_DATE,
	XFRM.CREATED_BY,
--	XFRM.LAST_UPDATED_DATE,
      CASE WHEN XFRM.SOURCE_SYSTEM IN ('SFDC','SALESCONNECT','DORIS') THEN getdate()
WHEN ((XFRM.source_system ='EI' AND XFRM.EXTERNAL_IDENTIFIER_TYPE_ID=864) OR (XFRM.source_system ='RPA' AND XFRM.EXTERNAL_IDENTIFIER_TYPE_ID=877)) AND XFRM.LAST_UPDATED_DATE <= PREV.LAST_UPDATED_DATE
 THEN 
	   (select parameter_value_date from etl_config where parameter_name='PLAN_CONTACT_BATCH_CYCLE_DATE')
WHEN XFRM.LAST_UPDATED_DATE <= PREV.LAST_UPDATED_DATE
	  THEN 
	  (select parameter_value_date from etl_config where parameter_name='BATCH_CYCLE_DATE')
		 ELSE
		 XFRM.LAST_UPDATED_DATE
		 END AS LAST_UPDATED_DATE,
	XFRM.LAST_UPDATED_BY ,
	XFRM.DELETED_INDICATOR,
	XFRM.SOURCE_EXTENAL_IDENTIFIER_ID ,
	XFRM.SOURCE_PARTY_ID ,
	XFRM.EXTERNAL_IDENTIFIER_TYPE_ID,
	XFRM.EXTERNAL_IDENTIFIER_VALUE ,
	XFRM.SOURCE_SYSTEM ,
	CASE WHEN  XFRM.PARENT_SOURCE_SYSTEM IS NULL
	THEN XFRM.SOURCE_SYSTEM
	ELSE
	XFRM.PARENT_SOURCE_SYSTEM
	END AS PARENT_SOURCE_SYSTEM,
   'UPD'  AS DEL_INS_UPD_FLAG,
      XFRM.DEFERRED_OWNERSHIP_IND,
     XFRM.EXT_IDENTIFIER_STATUS_IND,
	 XFRM.SURV_ASST_CODE_C
FROM
 TODAY_PARTY_EXTERNAL_ID_XFORM XFRM,
 PREV_PARTY_EXTERNAL_ID PREV
WHERE PREV.SOURCE_EXTENAL_IDENTIFIER_ID=XFRM.SOURCE_EXTENAL_IDENTIFIER_ID
AND PREV.SOURCE_SYSTEM         = XFRM.SOURCE_SYSTEM
AND XFRM.SOURCE_SYSTEM = $$SRC_SYSTEM_NM
AND (
    Isnull(PREV.EXTERNAL_IDENTIFIER_TYPE_ID,0)   != Isnull(XFRM.EXTERNAL_IDENTIFIER_TYPE_ID,0)  OR
	Isnull(PREV.EXTERNAL_IDENTIFIER_VALUE,0)   != Isnull(XFRM.EXTERNAL_IDENTIFIER_VALUE,0) COLLATE sql_latin1_general_cp1_cs_as OR
	Isnull(PREV.SOURCE_PARTY_ID,'~#') != Isnull(XFRM.SOURCE_PARTY_ID,'~#') COLLATE sql_latin1_general_cp1_cs_as OR
	Isnull(PREV.PARENT_SOURCE_SYSTEM,'~#') != Isnull(XFRM.PARENT_SOURCE_SYSTEM,'~#') COLLATE sql_latin1_general_cp1_cs_as OR
      Isnull(PREV.DEFERRED_OWNERSHIP_IND,'~#') != Isnull(XFRM.DEFERRED_OWNERSHIP_IND,'~#') COLLATE sql_latin1_general_cp1_cs_as  OR
      Isnull(PREV.EXT_IDENTIFIER_STATUS_IND,'~#') != Isnull(XFRM.EXT_IDENTIFIER_STATUS_IND,'~#') COLLATE sql_latin1_general_cp1_cs_as OR
	      Isnull(PREV.SURV_ASST_CODE_C,'~#') != Isnull(XFRM.SURV_ASST_CODE_C,'~#') COLLATE sql_latin1_general_cp1_cs_as

	)""",
  "SQ_today_party_external_id_xform_del": r"""SELECT PREV.SRC_ROWID,
	PREV.CREATED_DATE,
	PREV.CREATED_BY,
       --PREV.LAST_UPDATED_DATE,
	   CASE 

WHEN ((PREV.source_system ='EI' AND PREV.EXTERNAL_IDENTIFIER_TYPE_ID=864) OR (PREV.source_system ='RPA' AND PREV.EXTERNAL_IDENTIFIER_TYPE_ID=877)) THEN 
	   (select parameter_value_date from etl_config where parameter_name='PLAN_CONTACT_BATCH_CYCLE_DATE')   
	   ELSE
      (select parameter_value_date from etl_config where parameter_name='BATCH_CYCLE_DATE') END AS LAST_UPDATED_DATE,
	PREV.LAST_UPDATED_BY ,
	CASE 
	WHEN PREV.source_system IN ('SSC') AND PREV.EXTERNAL_IDENTIFIER_TYPE_ID IN ('862','863') THEN NULL
	WHEN DEL.SOURCE_SYSTEM IS NULL THEN
    'Y' 
    ELSE 
    NULL END AS DELETED_INDICATOR,
	PREV.SOURCE_EXTENAL_IDENTIFIER_ID ,
	PREV.SOURCE_PARTY_ID ,
	PREV.EXTERNAL_IDENTIFIER_TYPE_ID,
	PREV.EXTERNAL_IDENTIFIER_VALUE ,
	PREV.SOURCE_SYSTEM ,
	CASE WHEN  PREV.PARENT_SOURCE_SYSTEM IS NULL
	THEN PREV.SOURCE_SYSTEM
	ELSE
	PREV.PARENT_SOURCE_SYSTEM
	END AS PARENT_SOURCE_SYSTEM,
   'DEL'  AS DEL_INS_UPD_FLAG,
     PREV.DEFERRED_OWNERSHIP_IND,
     --PREV.EXT_IDENTIFIER_STATUS_IND,
	 CASE 
	WHEN 
	((PREV.source_system ='EI' AND PREV.EXTERNAL_IDENTIFIER_TYPE_ID=864) OR (PREV.source_system ='RPA' AND PREV.EXTERNAL_IDENTIFIER_TYPE_ID=877)) 
	THEN 'I'
	When PREV.source_system IN ('SSC') THEN 'I'
	ELSE 
	PREV.EXT_IDENTIFIER_STATUS_IND
	END AS EXT_IDENTIFIER_STATUS_IND,
	 PREV.SURV_ASST_CODE_C
FROM
 PREV_PARTY_EXTERNAL_ID PREV
 INNER JOIN ( SELECT  SOURCE_EXTENAL_IDENTIFIER_ID,SOURCE_SYSTEM
			  FROM PREV_PARTY_EXTERNAL_ID
			  EXCEPT
			  SELECT  SOURCE_EXTENAL_IDENTIFIER_ID,SOURCE_SYSTEM
			  FROM TODAY_PARTY_EXTERNAL_ID_XFORM ) DELTA
ON 	(	PREV.SOURCE_EXTENAL_IDENTIFIER_ID = DELTA.SOURCE_EXTENAL_IDENTIFIER_ID AND PREV.SOURCE_SYSTEM=DELTA.SOURCE_SYSTEM AND DELTA.SOURCE_SYSTEM= $$SRC_SYSTEM_NM)
LEFT JOIN CDM_DELTA_SOURCE_SYSTEM DEL ON 
(PREV.source_system = DEL.SOURCE_SYSTEM AND DEL.DELTA_LOGIC = 'I' and DEL.ENTITY_TYPE='PARTY')--CDM-4560""",
}

LKP_SQL = {
  "LKP_TODAY_PARTY_ROLE_XFORM": r"""SELECT distinct prole.role_type_id as role_type_id, prole.source_party_id as source_party_id 
,CASE WHEN  prole.PARENT_SOURCE_SYSTEM IS NULL
	THEN prole.SOURCE_SYSTEM
	ELSE
	prole.PARENT_SOURCE_SYSTEM
	END AS parent_source_system
	FROM today_party_role_xform prole, today_party_xform pr
	where prole.source_party_id = pr.source_party_id
	and prole.source_system = pr.source_system
and prole.status_id <> 1802""",
  "LKPTRANS1": r"""SELECT distinct prole.role_type_id as role_type_id, prole.source_party_id as source_party_id 
,CASE WHEN  prole.PARENT_SOURCE_SYSTEM IS NULL
	THEN prole.SOURCE_SYSTEM
	ELSE
	prole.PARENT_SOURCE_SYSTEM
	END AS parent_source_system
FROM today_party_role_xform prole, today_party_xform pr
where ltrim(rtrim(prole.source_party_id)) = ltrim(rtrim(pr.source_party_id))
and ltrim(rtrim(prole.source_system)) = ltrim(rtrim(pr.source_system))
and prole.status_id <> 1802""",
  "LKP_C_LDG_PARTY_EXT_ID": r"""SELECT distinct C_LDG_PARTY_EXTERNAL_ID.SOURCE_PARTY_ID as SOURCE_PARTY_ID, C_LDG_PARTY_EXTERNAL_ID.SOURCE_EXTENAL_IDENTIFIER_ID as SOURCE_EXTENAL_IDENTIFIER_ID, C_LDG_PARTY_EXTERNAL_ID.SOURCE_SYSTEM as SOURCE_SYSTEM FROM C_LDG_PARTY_EXTERNAL_ID""",
}


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
def main() -> None:
    config_path = os.getenv("CONFIG_PATH", "config_m_landing_party_external_id_delta_pg_v2.yml")
    cfg = load_config(config_path)

    _setup_logging(cfg.get("environment", {}).get("log_level", "INFO"))
    log = logging.getLogger("m_landing_party_external_id_delta")

    spark = get_spark_session(cfg.get("spark", {}).get("app_name", "m_landing_party_external_id_delta"), cfg.get("spark", {}))

    mssql = cfg["connections"]["mssql"]
    pg = cfg["connections"]["postgres"]
    src_system_nm = (cfg.get("params", {}) or {}).get("SRC_SYSTEM_NM") or os.getenv("SRC_SYSTEM_NM", "SSC")
    params = {"SRC_SYSTEM_NM": src_system_nm}
    log.info("Using SRC_SYSTEM_NM=%s", src_system_nm)

    # -------------------------------------------------------------------------
    # Lookups (SQL Server)
    # -------------------------------------------------------------------------
    # Role lookup for XFORM stream (no trim in SQL override)
    lkp_role_xform = to_lower(jdbc_read_query(spark, mssql, substitute_informatica_params(LKP_SQL["LKP_TODAY_PARTY_ROLE_XFORM"], params)))
    lkp_role_xform = lkp_role_xform.select(
        col("source_party_id").alias("lkp_source_party_id"),
        col("parent_source_system").alias("lkp_parent_source_system"),
        col("role_type_id").alias("active_role_type_id")
    ).dropDuplicates(["lkp_source_party_id", "lkp_parent_source_system"])

    # Role lookup for UNION stream (SQL override trims keys) => we also trim both sides to match 1:1 behavior
    lkp_role_trim = to_lower(jdbc_read_query(spark, mssql, substitute_informatica_params(LKP_SQL["LKPTRANS1"], params)))
    lkp_role_trim = lkp_role_trim.select(
        trim(col("source_party_id")).alias("lkp_source_party_id_t"),
        trim(col("parent_source_system")).alias("lkp_parent_source_system_t"),
        col("role_type_id").alias("active_role_type_id_t")
    ).dropDuplicates(["lkp_source_party_id_t", "lkp_parent_source_system_t"])

    # Duplicate check lookup
    lkp_cldg = to_lower(jdbc_read_query(spark, mssql, substitute_informatica_params(LKP_SQL["LKP_C_LDG_PARTY_EXT_ID"], params)))
    lkp_cldg = lkp_cldg.select(
        col("source_extenal_identifier_id").alias("lkp_source_extenal_identifier_id"),
        col("source_system").alias("lkp_source_system"),
        col("source_party_id").alias("record_check")
    ).dropDuplicates(["lkp_source_extenal_identifier_id", "lkp_source_system"])

    # -------------------------------------------------------------------------
    # Stream A: SQ_today_party_external_id_xform -> EXPTRANS1 -> UPDTRANS1 -> LKP_C_LDG + LKP_TODAY_ROLE -> EXPTRANS2 -> FILTRANS -> Target
    # -------------------------------------------------------------------------
    df_a = to_lower(jdbc_read_query(spark, mssql, substitute_informatica_params(SQ_SQL["SQ_today_party_external_id_xform"], params)))

    df_a = df_a.join(
        lkp_cldg,
        (df_a["source_extenal_identifier_id"] == lkp_cldg["lkp_source_extenal_identifier_id"]) &
        (df_a["source_system"] == lkp_cldg["lkp_source_system"]),
        "left"
    ).join(
        lkp_role_xform,
        (df_a["source_party_id"] == lkp_role_xform["lkp_source_party_id"]) &
        (df_a["parent_source_system"] == lkp_role_xform["lkp_parent_source_system"]),
        "left"
    )

    # EXPTRANS2: O_EXTERNAL_IDENTIFIER_STATUS = IIF(ISNULL(active_role_type_id),'I','A')
    df_a = df_a.withColumn(
        "ext_identifier_status_ind",
        when(col("active_role_type_id").isNull(), lit("I")).otherwise(lit("A"))
    )

    # FILTRANS: ISNULL(DUPS_RECORD_CHECK) => record_check IS NULL
    df_a_out = (
        df_a.filter(col("record_check").isNull())
            .select(
                "src_rowid",
                "created_date","created_by","last_updated_date","last_updated_by","deleted_indicator",
                "source_extenal_identifier_id","source_party_id","external_identifier_type_id",
                "external_identifier_value","source_system","parent_source_system",
                "deferred_ownership_ind","ext_identifier_status_ind","surv_asst_code_c"
            )
    )

    # -------------------------------------------------------------------------
    # Stream B: INS/UPD/DEL -> EXPs -> UNION -> UPDTRANS -> LKPTRANS1 -> EXPTRANS -> Target
    # -------------------------------------------------------------------------
    def _read_sq(name: str) -> DataFrame:
        return to_lower(jdbc_read_query(spark, mssql, substitute_informatica_params(SQ_SQL[name], params)))

    df_ins = _read_sq("SQ_today_party_external_id_xform_ins")
    df_upd = _read_sq("SQ_today_party_external_id_xform_upd")
    df_del = _read_sq("SQ_today_party_external_id_xform_del")

    common = [
        "src_rowid",
        "created_date","created_by","last_updated_date","last_updated_by","deleted_indicator",
        "source_extenal_identifier_id","source_party_id","external_identifier_type_id",
        "external_identifier_value","source_system","parent_source_system",
        "deferred_ownership_ind","ext_identifier_status_ind","surv_asst_code_c"
    ]

    for n, df in [("INS", df_ins), ("UPD", df_upd), ("DEL", df_del)]:
        missing = [c for c in common if c not in df.columns]
        if missing:
            raise ValueError(f"{n} SQ missing expected columns: {missing}. Check Informatica SQL aliases.")

    df_u = df_ins.select(*common).unionByName(df_upd.select(*common)).unionByName(df_del.select(*common))

    # EXPTRANS (final): IIF(source_system='SSC', EXT_IDENTIFIER_STATUS_IND, IIF(ISNULL(Active_Role_type_id),'I','A'))
    df_u = df_u.join(
        lkp_role_trim,
        (trim(df_u["source_party_id"]) == lkp_role_trim["lkp_source_party_id_t"]) &
        (trim(df_u["parent_source_system"]) == lkp_role_trim["lkp_parent_source_system_t"]),
        "left"
    ).withColumn(
        "ext_identifier_status_ind",
        when(col("source_system") == lit("SSC"), col("ext_identifier_status_ind"))
        .otherwise(when(col("active_role_type_id_t").isNull(), lit("I")).otherwise(lit("A")))
    )

    df_u_out = df_u.select(*common)

    # -------------------------------------------------------------------------
    # Write to Postgres (both streams insert)
    # -------------------------------------------------------------------------
    tgt_table = pg.get("dbtable", "public.test_table_associate_territory_coverage_viv_1")
    mode = pg.get("mode", "append")

    # NOTE: Counting triggers action; keep if you want logs, else comment out for performance.
    log.info("Writing Stream A to %s (mode=%s)", tgt_table, mode)
    jdbc_write(df_a_out, pg, tgt_table, mode=mode)

    log.info("Writing Stream B to %s (mode=%s)", tgt_table, mode)
    jdbc_write(df_u_out, pg, tgt_table, mode=mode)

    log.info("Done.")


if __name__ == "__main__":
    main()
