# Informatica XML to PySpark Converter

## Overview

This is an enterprise productivity tool that converts Informatica PowerCenter XML mapping and workflow files to PySpark code. The application provides a web-based interface for uploading XML files, analyzing their structure, configuring conversion options, and generating executable PySpark scripts. The tool is designed for data engineering teams migrating ETL pipelines from Informatica to Spark-based architectures.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Single Page Application**: Static HTML/CSS/JavaScript served by Flask
- **Design System**: Linear + Notion hybrid patterns with Inter font for UI and JetBrains Mono for code
- **UI Framework**: Custom CSS with CSS variables for theming (light/dark mode support)
- **Visualization**: Mermaid.js for data flow diagrams
- **Step-based Workflow**: 4-step process (Upload → Analyze → Configure → Generate)

### Backend Architecture
- **Web Framework**: Flask (Python) serving REST API endpoints
- **Core Processing Pipeline**:
  1. `InfaXMLParser` - Parses POWERMART XML exports using lxml
  2. `Analyzer` - Analyzes mappings for transformation types and dependencies
  3. `GraphBuilder` - Builds DAG using NetworkX for topological ordering
  4. `TransformHandlers` - Converts each transformation type to IR steps
  5. `CodeGenerator` - Generates PySpark code using Jinja2 templates
  6. `WorkflowBuilder` - Creates workflow orchestration from workflow XML

### Intermediate Representation (IR)
- Custom IR layer (`ir.py`) defines step types: ReadSQL, ApplyFilter, ApplyExpression, ApplyLookup, ApplyJoiner, WriteTarget, etc.
- Enables clean separation between parsing and code generation
- Supports multiple output formats through template swapping

### Code Generation Strategy
- **Self-contained output**: Each generated mapping file includes embedded utilities
- **Template-based**: Jinja2 templates in `/templates` directory
- **Configuration**: Environment variable resolution with `${VAR:default}` syntax
- **Database connections**: Predefined mappings for enterprise database aliases (MSSQL primary)

### Key Design Decisions
1. **Why lxml over ElementTree**: Better XPath support and performance for large XML files
2. **Why NetworkX for DAG**: Reliable topological sorting for transformation ordering
3. **Why Pydantic models**: Type safety and validation for complex data structures
4. **Why self-contained output files**: Reduces deployment complexity - no lib/ folder dependencies

## External Dependencies

### Python Packages
- **Flask**: Web framework for API and static file serving
- **lxml**: XML parsing with XPath support
- **NetworkX**: Graph operations for transformation DAG
- **Pydantic**: Data validation and settings management
- **Jinja2**: Template engine for code generation
- **PyYAML**: Configuration file handling

### Frontend Libraries (CDN)
- **Mermaid.js**: Diagram generation for data flow visualization
- **Font Awesome**: Icon library
- **Google Fonts**: Inter and JetBrains Mono typefaces

### Target Database Systems
- **Microsoft SQL Server**: Primary source/lookup database (JDBC)
- **PostgreSQL**: Supported as target database
- **Delta Lake**: Default output format for generated PySpark code

### Runtime Dependencies (Generated Code)
- **PySpark**: Target execution environment
- **jaydebeapi**: JDBC connectivity from Python
- **JDBC Drivers**: SQL Server driver required at runtime

### Environment Variables Required
- `MSSQL_PASSWORD`: SQL Server credentials
- `PG_PASSWORD`: PostgreSQL credentials (if using Postgres targets)
- `SRC_SYSTEM_NM`: Source system identifier (optional, defaults to 'SSC')