"""Quality Analyzer - Comprehensive validation and improvement of PySpark code."""
import re
import ast
from typing import Dict, List, Any, Optional, Tuple


INFORMATICA_TO_PYSPARK_FUNCTIONS = {
    'IIF': 'when',
    'DECODE': 'when',
    'NVL': 'coalesce',
    'NVL2': 'when',
    'ISNULL': 'isnull',
    'TO_CHAR': 'cast',
    'TO_DATE': 'to_date',
    'TO_DECIMAL': 'cast',
    'TO_INTEGER': 'cast',
    'TO_FLOAT': 'cast',
    'LTRIM': 'ltrim',
    'RTRIM': 'rtrim',
    'TRIM': 'trim',
    'UPPER': 'upper',
    'LOWER': 'lower',
    'SUBSTR': 'substring',
    'LPAD': 'lpad',
    'RPAD': 'rpad',
    'CONCAT': 'concat',
    'LENGTH': 'length',
    'INSTR': 'instr',
    'REPLACE': 'regexp_replace',
    'SUM': 'sum',
    'COUNT': 'count',
    'AVG': 'avg',
    'MIN': 'min',
    'MAX': 'max',
    'ROUND': 'round',
    'TRUNC': 'trunc',
    'ABS': 'abs',
    'SYSDATE': 'current_date',
    'SYSTIMESTAMP': 'current_timestamp',
    'ADD_TO_DATE': 'date_add',
    'DATE_DIFF': 'datediff',
    'GET_DATE_PART': 'date_part',
    'LAST_DAY': 'last_day'
}


class QualityAnalyzer:
    """Analyzes PySpark code against Informatica XML and improves quality."""
    
    def __init__(self, target_platform: str = 'local', 
                 output_format: str = 'parquet',
                 naming_convention: str = 'snake_case'):
        self.target_platform = target_platform
        self.output_format = output_format
        self.naming_convention = naming_convention
        self.fixes = []
        self.warnings = []
        self.manual_review = []
        self.element_coverage = []
        self.syntax_errors = []
        self.expression_audit = []
        self.variable_resolution = []
        self.data_flow_validation = []
        self.schema_validation = []
        self.performance_hints = []
        self.security_checks = []
    
    def analyze_and_improve(self, xml_content: str, pyspark_code: str,
                           xml_filename: str = '', pyspark_filename: str = '') -> Dict[str, Any]:
        """Main entry point - analyze XML and PySpark code, return improved code."""
        self.fixes = []
        self.warnings = []
        self.manual_review = []
        self.element_coverage = []
        self.syntax_errors = []
        self.expression_audit = []
        self.variable_resolution = []
        self.data_flow_validation = []
        self.schema_validation = []
        self.performance_hints = []
        self.security_checks = []
        
        try:
            xml_mappings = self._parse_xml_comprehensive(xml_content)
            matched_mapping = self._match_mapping_smart(xml_mappings, pyspark_code, pyspark_filename)
            
            mapping_info = None
            if matched_mapping:
                mapping_info = {
                    'name': matched_mapping.get('name', ''),
                    'sources_count': len(matched_mapping.get('sources', [])),
                    'targets_count': len(matched_mapping.get('targets', [])),
                    'transformations_count': len(matched_mapping.get('transformations', []))
                }
            else:
                self.warnings.append("Could not match PySpark file to any mapping in XML")
            
            self._validate_pyspark_syntax(pyspark_code)
            
            improved_code = self._improve_code_comprehensive(pyspark_code, matched_mapping)
            
            if matched_mapping:
                self._validate_element_coverage(improved_code, matched_mapping)
                self._validate_expressions(improved_code, matched_mapping)
                self._validate_parameters_variables(improved_code, matched_mapping)
                self._validate_data_flow(improved_code, matched_mapping)
                self._validate_lookup_joins(improved_code, matched_mapping)
                self._validate_update_strategy(improved_code, matched_mapping)
                self._validate_schema(improved_code, matched_mapping)
                self._validate_performance(improved_code, matched_mapping)
                self._validate_security(improved_code, matched_mapping)
            
            improved_code = self._ensure_runnable(improved_code)
            
            score_breakdown = self._calculate_score_detailed()
            diff = self._generate_diff(pyspark_code, improved_code)
            
            return {
                "success": True,
                "improved_code": improved_code,
                "quality_score": score_breakdown['total_score'],
                "score_breakdown": score_breakdown,
                "fixes": self.fixes,
                "warnings": self.warnings,
                "manual_review": self.manual_review,
                "element_coverage": self.element_coverage,
                "syntax_errors": self.syntax_errors,
                "expression_audit": self.expression_audit,
                "variable_resolution": self.variable_resolution,
                "data_flow_validation": self.data_flow_validation,
                "schema_validation": self.schema_validation,
                "performance_hints": self.performance_hints,
                "security_checks": self.security_checks,
                "diff": diff,
                "matched_mapping": mapping_info,
                "all_mappings": [m.get('name', '') for m in xml_mappings],
                "target_platform": self.target_platform
            }
            
        except Exception as e:
            import traceback
            return {
                "success": False,
                "error": str(e),
                "traceback": traceback.format_exc(),
                "improved_code": pyspark_code,
                "quality_score": 0,
                "fixes": [],
                "warnings": [f"Analysis error: {str(e)}"],
                "manual_review": [],
                "element_coverage": [],
                "syntax_errors": []
            }
    
    def _parse_xml_comprehensive(self, xml_content: str) -> List[Dict[str, Any]]:
        """Parse Informatica XML and extract comprehensive mapping information."""
        from lxml import etree
        mappings = []
        
        try:
            root = etree.fromstring(xml_content.encode('utf-8'))
            
            for mapping in root.iter('MAPPING'):
                mapping_info = {
                    'name': mapping.get('NAME', ''),
                    'description': mapping.get('DESCRIPTION', ''),
                    'sources': [],
                    'targets': [],
                    'transformations': [],
                    'connectors': [],
                    'source_qualifiers': [],
                    'lookups': [],
                    'expressions': [],
                    'filters': [],
                    'joiners': [],
                    'aggregators': [],
                    'sorters': [],
                    'routers': [],
                    'update_strategies': []
                }
                
                for source in mapping.iter('SOURCE'):
                    source_info = {
                        'name': source.get('NAME', ''),
                        'dbname': source.get('DATABASETYPE', ''),
                        'owner': source.get('OWNERNAME', ''),
                        'fields': []
                    }
                    for field in source.iter('SOURCEFIELD'):
                        source_info['fields'].append({
                            'name': field.get('NAME', ''),
                            'datatype': field.get('DATATYPE', ''),
                            'precision': field.get('PRECISION', ''),
                            'scale': field.get('SCALE', '')
                        })
                    mapping_info['sources'].append(source_info)
                
                for target in mapping.iter('TARGET'):
                    target_info = {
                        'name': target.get('NAME', ''),
                        'dbname': target.get('DATABASETYPE', ''),
                        'owner': target.get('OWNERNAME', ''),
                        'fields': []
                    }
                    for field in target.iter('TARGETFIELD'):
                        target_info['fields'].append({
                            'name': field.get('NAME', ''),
                            'datatype': field.get('DATATYPE', ''),
                            'precision': field.get('PRECISION', ''),
                            'scale': field.get('SCALE', ''),
                            'nullable': field.get('NULLABLE', 'YES')
                        })
                    mapping_info['targets'].append(target_info)
                
                for transform in mapping.iter('TRANSFORMATION'):
                    trans_type = transform.get('TYPE', '')
                    trans_info = {
                        'name': transform.get('NAME', ''),
                        'type': trans_type,
                        'description': transform.get('DESCRIPTION', ''),
                        'fields': [],
                        'table_attributes': {}
                    }
                    
                    for field in transform.iter('TRANSFORMFIELD'):
                        field_info = {
                            'name': field.get('NAME', ''),
                            'expression': field.get('EXPRESSION', ''),
                            'datatype': field.get('DATATYPE', ''),
                            'porttype': field.get('PORTTYPE', ''),
                            'defaultvalue': field.get('DEFAULTVALUE', '')
                        }
                        trans_info['fields'].append(field_info)
                    
                    for attr in transform.iter('TABLEATTRIBUTE'):
                        attr_name = attr.get('NAME', '')
                        attr_value = attr.get('VALUE', '')
                        trans_info['table_attributes'][attr_name] = attr_value
                    
                    mapping_info['transformations'].append(trans_info)
                    
                    if trans_type == 'Source Qualifier':
                        mapping_info['source_qualifiers'].append(trans_info)
                    elif trans_type == 'Lookup Procedure':
                        mapping_info['lookups'].append(trans_info)
                    elif trans_type == 'Expression':
                        mapping_info['expressions'].append(trans_info)
                    elif trans_type == 'Filter':
                        mapping_info['filters'].append(trans_info)
                    elif trans_type == 'Joiner':
                        mapping_info['joiners'].append(trans_info)
                    elif trans_type == 'Aggregator':
                        mapping_info['aggregators'].append(trans_info)
                    elif trans_type == 'Sorter':
                        mapping_info['sorters'].append(trans_info)
                    elif trans_type == 'Router':
                        mapping_info['routers'].append(trans_info)
                    elif trans_type == 'Update Strategy':
                        mapping_info['update_strategies'].append(trans_info)
                
                for connector in mapping.iter('CONNECTOR'):
                    mapping_info['connectors'].append({
                        'from_instance': connector.get('FROMINSTANCE', ''),
                        'from_field': connector.get('FROMFIELD', ''),
                        'to_instance': connector.get('TOINSTANCE', ''),
                        'to_field': connector.get('TOFIELD', '')
                    })
                
                mappings.append(mapping_info)
                
        except Exception as e:
            self.warnings.append(f"XML parsing warning: {str(e)}")
        
        return mappings
    
    def _match_mapping_smart(self, xml_mappings: List[Dict], pyspark_code: str, 
                             pyspark_filename: str) -> Optional[Dict]:
        """Smart matching of PySpark file to the correct mapping in XML."""
        if not xml_mappings:
            return None
        
        if len(xml_mappings) == 1:
            self.fixes.append(f"Matched to single mapping: {xml_mappings[0]['name']}")
            return xml_mappings[0]
        
        filename_lower = pyspark_filename.lower().replace('.py', '')
        
        for mapping in xml_mappings:
            mapping_name = mapping['name'].lower()
            if f"mapping_{mapping_name}" == filename_lower:
                self.fixes.append(f"Exact filename match: {mapping['name']}")
                return mapping
            if mapping_name == filename_lower.replace('mapping_', ''):
                self.fixes.append(f"Filename match (without prefix): {mapping['name']}")
                return mapping
        
        for mapping in xml_mappings:
            mapping_name_clean = mapping['name'].lower().replace('_', '').replace('-', '')
            filename_clean = filename_lower.replace('_', '').replace('-', '').replace('mapping', '')
            if mapping_name_clean in filename_clean or filename_clean in mapping_name_clean:
                self.fixes.append(f"Fuzzy filename match: {mapping['name']}")
                return mapping
        
        code_lower = pyspark_code.lower()
        for mapping in xml_mappings:
            if f"mapping: {mapping['name'].lower()}" in code_lower:
                self.fixes.append(f"Code comment match: {mapping['name']}")
                return mapping
            if f'"{mapping["name"].lower()}"' in code_lower:
                self.fixes.append(f"Code string match: {mapping['name']}")
                return mapping
        
        self.warnings.append(f"Multiple mappings found ({len(xml_mappings)}), using first: {xml_mappings[0]['name']}")
        return xml_mappings[0]
    
    def _validate_pyspark_syntax(self, code: str) -> bool:
        """Validate PySpark code syntax using Python AST parser."""
        try:
            ast.parse(code)
            self.fixes.append("PySpark code syntax is valid")
            return True
        except SyntaxError as e:
            self.syntax_errors.append({
                'line': e.lineno,
                'offset': e.offset,
                'message': str(e.msg),
                'text': e.text.strip() if e.text else ''
            })
            self.warnings.append(f"Syntax error at line {e.lineno}: {e.msg}")
            return False
    
    def _improve_code_comprehensive(self, code: str, mapping: Optional[Dict]) -> str:
        """Apply comprehensive improvements to the PySpark code."""
        improved = code
        
        improved = self._fix_syntax_errors_auto(improved)
        improved = self._fix_imports(improved)
        improved = self._fix_spark_session(improved)
        improved = self._fix_expr_issues(improved)
        improved = self._fix_column_references(improved)
        improved = self._fix_join_conditions(improved)
        improved = self._fix_filter_conditions(improved)
        improved = self._fix_write_operations(improved)
        improved = self._apply_platform_settings(improved)
        
        return improved
    
    def _fix_syntax_errors_auto(self, code: str) -> str:
        """Attempt to auto-fix common syntax errors."""
        fixed = code
        
        fixed = re.sub(r'expr\(""\)', 'lit(None)', fixed)
        fixed = re.sub(r'expr\("NULL"\)', 'lit(None)', fixed, flags=re.IGNORECASE)
        
        lines = fixed.split('\n')
        fixed_lines = []
        for line in lines:
            open_parens = line.count('(')
            close_parens = line.count(')')
            if open_parens > close_parens:
                line = line + ')' * (open_parens - close_parens)
                self.fixes.append(f"Fixed unbalanced parentheses in line")
            fixed_lines.append(line)
        fixed = '\n'.join(fixed_lines)
        
        return fixed
    
    def _fix_imports(self, code: str) -> str:
        """Ensure all required PySpark imports are present."""
        fixed = code
        
        required_imports = [
            ('from pyspark.sql import SparkSession', 'SparkSession'),
            ('from pyspark.sql.functions import *', 'col('),
            ('from pyspark.sql.types import *', 'StructType'),
        ]
        
        for import_stmt, indicator in required_imports:
            if indicator in fixed and import_stmt not in fixed:
                if 'import' in fixed:
                    first_import = fixed.find('import')
                    line_start = fixed.rfind('\n', 0, first_import) + 1
                    fixed = fixed[:line_start] + import_stmt + '\n' + fixed[line_start:]
                    self.fixes.append(f"Added missing import: {import_stmt.split('import')[1].strip()}")
        
        return fixed
    
    def _fix_spark_session(self, code: str) -> str:
        """Ensure proper SparkSession initialization for target platform."""
        fixed = code
        
        if 'SparkSession' not in fixed and 'spark' in fixed.lower():
            self.warnings.append("SparkSession initialization may be missing")
        
        if self.target_platform == 'local':
            if 'SparkSession.builder' in fixed:
                if '.master(' not in fixed:
                    fixed = fixed.replace(
                        'SparkSession.builder',
                        'SparkSession.builder.master("local[*]")'
                    )
                    self.fixes.append("Added local master configuration for standalone Spark")
        
        elif self.target_platform == 'eks':
            if '.master("local' in fixed:
                self.warnings.append("Local master detected - remove for EKS deployment")
        
        return fixed
    
    def _fix_expr_issues(self, code: str) -> str:
        """Fix issues with expr() and SQL expressions."""
        fixed = code
        
        patterns = [
            (r'expr\("([^"]*)\s*&\s*([^"]*)"\)', r'expr("\1 AND \2")', "& to AND"),
            (r'expr\("([^"]*)\s*\|\s*([^"]*)"\)', r'expr("\1 OR \2")', "| to OR"),
            (r'expr\("ISNULL\(([^)]+)\)"\)', r'isnull(col("\1"))', "ISNULL to isnull"),
            (r'expr\("NVL\(([^,]+),\s*([^)]+)\)"\)', r'coalesce(col("\1"), \2)', "NVL to coalesce"),
        ]
        
        for pattern, replacement, description in patterns:
            if re.search(pattern, fixed, re.IGNORECASE):
                fixed = re.sub(pattern, replacement, fixed, flags=re.IGNORECASE)
                self.fixes.append(f"Fixed expression: {description}")
        
        return fixed
    
    def _fix_column_references(self, code: str) -> str:
        """Fix bare column references in expressions."""
        fixed = code
        
        bare_col_in_filter = r'\.filter\(([A-Za-z_][A-Za-z0-9_]*)\s*(==|!=|>|<|>=|<=)\s*'
        matches = re.findall(bare_col_in_filter, fixed)
        for match in matches:
            col_name = match[0]
            if col_name not in ['True', 'False', 'None', 'col', 'expr', 'lit', 'when', 'F']:
                old = f'.filter({col_name} '
                new = f'.filter(col("{col_name}") '
                if old in fixed:
                    fixed = fixed.replace(old, new)
                    self.fixes.append(f"Wrapped bare column '{col_name}' in col()")
        
        return fixed
    
    def _fix_join_conditions(self, code: str) -> str:
        """Fix join condition issues."""
        fixed = code
        
        bare_join = r'\.join\([^,]+,\s*([A-Za-z_][A-Za-z0-9_]*)\s*==\s*'
        matches = re.findall(bare_join, fixed)
        for col_name in matches:
            if col_name not in ['col', 'expr', 'lit', 'F']:
                self.warnings.append(f"Join condition may need col() wrapper for: {col_name}")
        
        return fixed
    
    def _fix_filter_conditions(self, code: str) -> str:
        """Fix filter condition syntax."""
        fixed = code
        
        if '.filter("")' in fixed or ".filter('')" in fixed:
            fixed = fixed.replace('.filter("")', '.filter(lit(True))')
            fixed = fixed.replace(".filter('')", '.filter(lit(True))')
            self.fixes.append("Replaced empty filter with lit(True)")
        
        return fixed
    
    def _fix_write_operations(self, code: str) -> str:
        """Fix write operation issues."""
        fixed = code
        
        if '.write.' in fixed and '.mode(' not in fixed:
            fixed = re.sub(
                r'\.write\.format\(',
                '.write.mode("overwrite").format(',
                fixed
            )
            if '.write.mode(' in fixed:
                self.fixes.append("Added default write mode: overwrite")
        
        if self.output_format == 'delta':
            if '.write.parquet(' in fixed:
                fixed = fixed.replace('.write.parquet(', '.write.format("delta").save(')
                self.fixes.append("Changed write format to delta")
            if '.format("parquet")' in fixed:
                fixed = fixed.replace('.format("parquet")', '.format("delta")')
                self.fixes.append("Changed format from parquet to delta")
        
        return fixed
    
    def _apply_platform_settings(self, code: str) -> str:
        """Apply platform-specific settings."""
        fixed = code
        
        if self.target_platform == 'local':
            if 'spark.read.jdbc' in fixed:
                if '.option("driver"' not in fixed:
                    self.warnings.append("JDBC driver option may be needed for local Spark")
        
        elif self.target_platform == 'eks':
            if '.master("local' in fixed:
                self.warnings.append("Remove local master for EKS - cluster manager handles this")
            if 'spark.read.jdbc' in fixed:
                self.warnings.append("Ensure JDBC driver JARs are available in EKS pod")
        
        elif self.target_platform == 'databricks':
            if 'fetchsize' not in fixed.lower() and 'spark.read.jdbc' in fixed:
                self.warnings.append("Add fetchsize for better JDBC performance on Databricks")
        
        return fixed
    
    def _validate_element_coverage(self, code: str, mapping: Dict) -> None:
        """Validate that all XML mapping elements are covered in PySpark code."""
        code_lower = code.lower()
        
        for source in mapping.get('sources', []):
            source_name = source['name']
            source_dbtype = source.get('dbname', '')
            found = source_name.lower() in code_lower
            
            details = []
            is_file_source = source_dbtype.lower() in ['flat file', 'flatfile', 'csv', 'parquet', 'delimited']
            
            if is_file_source:
                if '.csv' in code_lower or 'read.csv' in code_lower:
                    details.append('CSV read method detected')
                elif '.parquet' in code_lower or 'read.parquet' in code_lower:
                    details.append('Parquet read method detected')
                elif 'read.text' in code_lower:
                    details.append('Text read method detected')
                else:
                    details.append('File read method not found')
                    self.warnings.append(f"Source '{source_name}' is file type but no file read method found")
                
                path_patterns = re.findall(r'["\']([^"\']*\.(csv|parquet|dat|txt))["\']', code, re.IGNORECASE)
                if path_patterns:
                    details.append(f'File paths: {[p[0] for p in path_patterns[:3]]}')
                else:
                    self.warnings.append(f"Source '{source_name}': No file path with extension found")
            else:
                if 'read.jdbc' in code_lower or 'read.format("jdbc")' in code_lower:
                    details.append('JDBC read method detected')
                elif 'spark.sql' in code_lower:
                    details.append('SQL read method detected')
                else:
                    details.append('DB read method not detected')
            
            self.element_coverage.append({
                'type': 'Source',
                'name': source_name,
                'covered': found,
                'fields_count': len(source.get('fields', [])),
                'source_type': 'File' if is_file_source else 'Database',
                'details': details
            })
            if not found:
                self.manual_review.append(f"Source '{source_name}' not found in code")
        
        for target in mapping.get('targets', []):
            target_name = target['name']
            target_dbtype = target.get('dbname', '')
            found = target_name.lower() in code_lower
            
            details = []
            is_file_target = target_dbtype.lower() in ['flat file', 'flatfile', 'csv', 'parquet', 'delimited']
            
            if is_file_target:
                if '.parquet' in code_lower or 'write.parquet' in code_lower:
                    details.append('Parquet write method detected')
                elif '.csv' in code_lower or 'write.csv' in code_lower:
                    details.append('CSV write method detected')
                elif 'write.format("delta")' in code_lower:
                    details.append('Delta write method detected')
                else:
                    details.append('File write method not found')
                    self.warnings.append(f"Target '{target_name}' is file type but no file write method found")
                
                write_paths = re.findall(r'\.save\(["\']([^"\']+)["\']\)', code, re.IGNORECASE)
                write_paths += re.findall(r'\.parquet\(["\']([^"\']+)["\']\)', code, re.IGNORECASE)
                write_paths += re.findall(r'\.csv\(["\']([^"\']+)["\']\)', code, re.IGNORECASE)
                if write_paths:
                    details.append(f'Output paths: {write_paths[:3]}')
            else:
                if 'write.jdbc' in code_lower or 'write.format("jdbc")' in code_lower:
                    details.append('JDBC write method detected')
                elif 'insertInto' in code:
                    details.append('insertInto method detected')
                else:
                    details.append('DB write method not detected')
            
            self.element_coverage.append({
                'type': 'Target',
                'name': target_name,
                'covered': found,
                'fields_count': len(target.get('fields', [])),
                'target_type': 'File' if is_file_target else 'Database',
                'details': details
            })
            if not found:
                self.manual_review.append(f"Target '{target_name}' not found in code")
        
        for sq in mapping.get('source_qualifiers', []):
            sq_name = sq['name']
            sql_query = sq.get('table_attributes', {}).get('Sql Query', '')
            
            details = []
            found = 'read' in code_lower or 'load' in code_lower
            
            if sql_query:
                details.append(f'SQL Query defined: {sql_query[:50]}...' if len(sql_query) > 50 else f'SQL Query: {sql_query}')
                if 'spark.sql' in code or '.option("query"' in code_lower or '.option("dbtable"' in code_lower:
                    details.append('SQL execution method found')
                else:
                    self.warnings.append(f"Source Qualifier '{sq_name}' has SQL query but no SQL execution in code")
            
            source_filter = sq.get('table_attributes', {}).get('Source Filter', '')
            if source_filter:
                details.append(f'Source Filter: {source_filter}')
                if 'filter' in code_lower or 'where' in code_lower:
                    details.append('Filter implementation found')
                else:
                    self.warnings.append(f"Source Qualifier '{sq_name}' has filter but .filter()/.where() not found")
            
            self.element_coverage.append({
                'type': 'Source Qualifier',
                'name': sq_name,
                'covered': found,
                'fields_count': len(sq.get('fields', [])),
                'details': details
            })
        
        for expr in mapping.get('expressions', []):
            expr_name = expr['name']
            expr_fields = expr.get('fields', [])
            
            details = []
            found = 'withColumn' in code or 'select' in code_lower
            
            computed_fields = [f for f in expr_fields if f.get('expression') and f['expression'] != f['name']]
            details.append(f'Computed fields: {len(computed_fields)}')
            
            for field in computed_fields[:5]:
                field_name = field['name']
                field_expr = field.get('expression', '')
                if field_name.lower() in code_lower:
                    details.append(f"Field '{field_name}' found")
                else:
                    self.warnings.append(f"Expression field '{field_name}' from '{expr_name}' not found in code")
            
            self.element_coverage.append({
                'type': 'Expression',
                'name': expr_name,
                'covered': found,
                'fields_count': len(expr_fields),
                'computed_fields': len(computed_fields),
                'details': details
            })
        
        for flt in mapping.get('filters', []):
            flt_name = flt['name']
            flt_fields = flt.get('fields', [])
            
            details = []
            found = 'filter' in code_lower or 'where' in code_lower
            
            filter_cond = None
            for field in flt_fields:
                if field.get('expression'):
                    filter_cond = field['expression']
                    break
            
            if filter_cond:
                details.append(f'Filter condition: {filter_cond[:60]}' if len(filter_cond) > 60 else f'Filter: {filter_cond}')
                filter_patterns = re.findall(r'\.filter\(([^)]+)\)', code)
                filter_patterns += re.findall(r'\.where\(([^)]+)\)', code)
                if filter_patterns:
                    details.append(f'PySpark filters found: {len(filter_patterns)}')
                else:
                    self.warnings.append(f"Filter '{flt_name}' defined but no .filter()/.where() in code")
            
            self.element_coverage.append({
                'type': 'Filter',
                'name': flt_name,
                'covered': found,
                'fields_count': len(flt_fields),
                'details': details
            })
        
        for lkp in mapping.get('lookups', []):
            lkp_name = lkp['name']
            lkp_attrs = lkp.get('table_attributes', {})
            
            details = []
            found = 'join' in code_lower or 'lookup' in code_lower
            
            lookup_table = lkp_attrs.get('Lookup table name', '')
            lookup_condition = lkp_attrs.get('Lookup condition', '')
            
            if lookup_table:
                details.append(f'Lookup table: {lookup_table}')
                if lookup_table.lower() in code_lower:
                    details.append('Lookup table referenced in code')
                else:
                    self.warnings.append(f"Lookup '{lkp_name}' table '{lookup_table}' not found in code")
            
            if lookup_condition:
                details.append(f'Condition: {lookup_condition[:50]}' if len(lookup_condition) > 50 else f'Condition: {lookup_condition}')
            
            join_patterns = re.findall(r'\.join\([^)]+\)', code)
            if join_patterns:
                details.append(f'Join operations found: {len(join_patterns)}')
            else:
                self.warnings.append(f"Lookup '{lkp_name}' requires join but no .join() found")
            
            self.element_coverage.append({
                'type': 'Lookup',
                'name': lkp_name,
                'covered': found,
                'fields_count': len(lkp.get('fields', [])),
                'details': details
            })
        
        for agg in mapping.get('aggregators', []):
            agg_name = agg['name']
            agg_fields = agg.get('fields', [])
            
            details = []
            found = 'groupBy' in code or 'agg' in code_lower
            
            group_by_fields = [f for f in agg_fields if f.get('porttype') == 'INPUT/OUTPUT']
            agg_functions = [f for f in agg_fields if f.get('expression') and any(fn in f['expression'].upper() for fn in ['SUM', 'COUNT', 'AVG', 'MIN', 'MAX'])]
            
            details.append(f'Group by fields: {len(group_by_fields)}')
            details.append(f'Aggregate functions: {len(agg_functions)}')
            
            groupby_patterns = re.findall(r'\.groupBy\([^)]+\)', code)
            agg_patterns = re.findall(r'\.agg\([^)]+\)', code)
            
            if groupby_patterns:
                details.append(f'groupBy operations: {len(groupby_patterns)}')
            else:
                self.warnings.append(f"Aggregator '{agg_name}' requires groupBy but not found")
            
            if agg_patterns:
                details.append(f'agg operations: {len(agg_patterns)}')
            
            self.element_coverage.append({
                'type': 'Aggregator',
                'name': agg_name,
                'covered': found,
                'fields_count': len(agg_fields),
                'details': details
            })
        
        for transform in mapping.get('transformations', []):
            trans_name = transform['name']
            trans_type = transform['type']
            
            if trans_type in ['Source Qualifier', 'Expression', 'Filter', 'Lookup Procedure', 'Aggregator']:
                continue
            
            found = False
            details = []
            
            if trans_type == 'Joiner':
                found = 'join' in code_lower
                join_type = transform.get('table_attributes', {}).get('Join Type', '')
                if join_type:
                    details.append(f'Join type: {join_type}')
            elif trans_type == 'Sorter':
                found = 'orderBy' in code or 'sort' in code_lower
                sort_fields = [f for f in transform.get('fields', []) if f.get('porttype') == 'INPUT/OUTPUT']
                details.append(f'Sort fields: {len(sort_fields)}')
            elif trans_type == 'Router':
                found = 'when' in code_lower or 'filter' in code_lower
                groups = transform.get('table_attributes', {}).get('Number of groups', '0')
                details.append(f'Router groups: {groups}')
            elif trans_type == 'Update Strategy':
                found = 'merge' in code_lower or 'update' in code_lower
                strategy = transform.get('table_attributes', {}).get('Update Strategy Expression', '')
                if strategy:
                    details.append(f'Strategy: {strategy[:40]}')
            else:
                found = trans_name.lower() in code_lower
            
            self.element_coverage.append({
                'type': f'Transformation ({trans_type})',
                'name': trans_name,
                'covered': found,
                'fields_count': len(transform.get('fields', [])),
                'details': details
            })
            
            if not found:
                self.warnings.append(f"{trans_type} '{trans_name}' may not be implemented")
    
    def _ensure_runnable(self, code: str) -> str:
        """Ensure the code is runnable with proper structure."""
        fixed = code
        
        if 'if __name__' not in fixed:
            if 'def main(' in fixed or 'def run(' in fixed:
                pass
            else:
                self.warnings.append("Consider adding if __name__ == '__main__' block")
        
        if 'spark.stop()' not in fixed and 'SparkSession' in fixed:
            self.warnings.append("Consider adding spark.stop() at the end for cleanup")
        
        return fixed
    
    def _calculate_score_detailed(self) -> Dict[str, Any]:
        """Calculate detailed quality score with category breakdown."""
        
        syntax_score = self._calculate_syntax_score()
        mapping_score = self._calculate_mapping_coverage_score()
        transformation_score = self._calculate_transformation_fidelity_score()
        data_quality_score = self._calculate_data_quality_score()
        operational_score = self._calculate_operational_readiness_score()
        
        weights = {
            'syntax_lint': 0.20,
            'mapping_coverage': 0.25,
            'transformation_fidelity': 0.25,
            'data_quality': 0.15,
            'operational_readiness': 0.15
        }
        
        total_score = (
            syntax_score['score'] * weights['syntax_lint'] +
            mapping_score['score'] * weights['mapping_coverage'] +
            transformation_score['score'] * weights['transformation_fidelity'] +
            data_quality_score['score'] * weights['data_quality'] +
            operational_score['score'] * weights['operational_readiness']
        )
        
        self.score_breakdown = {
            'total_score': int(total_score),
            'categories': {
                'syntax_lint': {
                    'score': syntax_score['score'],
                    'weight': 20,
                    'label': 'Syntax & Lint',
                    'description': 'Python syntax, PySpark API correctness',
                    'issues': syntax_score['issues'],
                    'suggestions': syntax_score['suggestions']
                },
                'mapping_coverage': {
                    'score': mapping_score['score'],
                    'weight': 25,
                    'label': 'Mapping Coverage',
                    'description': 'Sources, Targets, all transformations covered',
                    'issues': mapping_score['issues'],
                    'suggestions': mapping_score['suggestions']
                },
                'transformation_fidelity': {
                    'score': transformation_score['score'],
                    'weight': 25,
                    'label': 'Transformation Fidelity',
                    'description': 'Expressions, Filters, Lookups, Aggregators accurately converted',
                    'issues': transformation_score['issues'],
                    'suggestions': transformation_score['suggestions']
                },
                'data_quality': {
                    'score': data_quality_score['score'],
                    'weight': 15,
                    'label': 'Data Quality',
                    'description': 'Schema alignment, data types, nullability',
                    'issues': data_quality_score['issues'],
                    'suggestions': data_quality_score['suggestions']
                },
                'operational_readiness': {
                    'score': operational_score['score'],
                    'weight': 15,
                    'label': 'Operational Readiness',
                    'description': 'Logging, error handling, SparkSession config',
                    'issues': operational_score['issues'],
                    'suggestions': operational_score['suggestions']
                }
            }
        }
        
        return self.score_breakdown
    
    def _calculate_syntax_score(self) -> Dict[str, Any]:
        """Calculate Syntax & Lint score (20% weight)."""
        score = 100
        issues = []
        suggestions = []
        
        score -= len(self.syntax_errors) * 20
        for err in self.syntax_errors:
            issues.append(f"Syntax error: {err}")
        
        critical_warnings = [w for w in self.warnings if 'error' in w.lower() or 'missing' in w.lower()]
        score -= len(critical_warnings) * 5
        
        if self.syntax_errors:
            suggestions.append("Fix Python syntax errors before proceeding")
        if not self.syntax_errors and score < 100:
            suggestions.append("Review PySpark API usage for best practices")
        if score >= 100:
            suggestions.append("Syntax looks good!")
        
        return {'score': max(0, min(100, score)), 'issues': issues, 'suggestions': suggestions}
    
    def _calculate_mapping_coverage_score(self) -> Dict[str, Any]:
        """Calculate Mapping Coverage score (25% weight)."""
        score = 100
        issues = []
        suggestions = []
        
        sources = [e for e in self.element_coverage if e.get('type') == 'Source']
        targets = [e for e in self.element_coverage if e.get('type') == 'Target']
        
        if sources:
            source_covered = sum(1 for s in sources if s.get('covered'))
            source_pct = (source_covered / len(sources)) * 100
            if source_pct < 100:
                issues.append(f"Sources covered: {source_covered}/{len(sources)}")
                score -= (100 - source_pct) * 0.4
        
        if targets:
            target_covered = sum(1 for t in targets if t.get('covered'))
            target_pct = (target_covered / len(targets)) * 100
            if target_pct < 100:
                issues.append(f"Targets covered: {target_covered}/{len(targets)}")
                score -= (100 - target_pct) * 0.4
        
        for item in self.manual_review:
            if 'source' in item.lower() or 'target' in item.lower():
                score -= 5
                issues.append(item)
        
        if score < 80:
            suggestions.append("Ensure all source tables/files are being read with spark.read")
            suggestions.append("Verify all target tables/files have corresponding df.write operations")
        elif score < 100:
            suggestions.append("Review uncovered sources/targets for completeness")
        else:
            suggestions.append("All mappings covered!")
        
        return {'score': max(0, min(100, int(score))), 'issues': issues, 'suggestions': suggestions}
    
    def _calculate_transformation_fidelity_score(self) -> Dict[str, Any]:
        """Calculate Transformation Fidelity score (25% weight)."""
        score = 100
        issues = []
        suggestions = []
        
        transformations = [e for e in self.element_coverage if 'Transformation' in e.get('type', '') or e.get('type') in ['Source Qualifier', 'Expression', 'Filter', 'Lookup', 'Aggregator']]
        
        if transformations:
            covered = sum(1 for t in transformations if t.get('covered'))
            total = len(transformations)
            coverage_pct = (covered / total) * 100 if total > 0 else 100
            
            if coverage_pct < 100:
                score = int(coverage_pct)
                issues.append(f"Transformations covered: {covered}/{total}")
        
        if self.expression_audit:
            expr_issues = [e for e in self.expression_audit if e.get('issues')]
            if expr_issues:
                score -= len(expr_issues) * 3
                for expr in expr_issues[:3]:
                    issues.append(f"Expression '{expr['field']}': {expr['issues'][0]}")
        
        trans_warnings = [w for w in self.warnings if any(t in w.lower() for t in ['expression', 'filter', 'lookup', 'aggregator', 'joiner'])]
        score -= len(trans_warnings) * 2
        
        if score < 70:
            suggestions.append("Review Expression transformations - ensure IIF/DECODE/NVL are translated to when/coalesce")
            suggestions.append("Verify Filter conditions use .filter() or .where()")
            suggestions.append("Check Lookup implementations use proper .join() operations")
        elif score < 90:
            suggestions.append("Minor transformation issues detected - review warnings")
        else:
            suggestions.append("Transformation fidelity looks good!")
        
        return {'score': max(0, min(100, int(score))), 'issues': issues, 'suggestions': suggestions}
    
    def _calculate_data_quality_score(self) -> Dict[str, Any]:
        """Calculate Data Quality score (15% weight)."""
        score = 100
        issues = []
        suggestions = []
        
        for element in self.element_coverage:
            details = element.get('details', [])
            for detail in details:
                if 'not found' in detail.lower() or 'not detected' in detail.lower():
                    score -= 5
                    issues.append(detail)
        
        data_flow_issues = [f for f in self.data_flow_validation if not f.get('found')]
        score -= len(data_flow_issues) * 10
        for flow in data_flow_issues[:3]:
            issues.append(f"{flow['element']}: {flow['expected_operation']} not found")
        
        if score < 70:
            suggestions.append("Verify data types match between source and target schemas")
            suggestions.append("Ensure file paths include proper extensions (.csv, .parquet)")
            suggestions.append("Check read/write methods match source/target types")
        elif score < 90:
            suggestions.append("Review data flow for potential schema mismatches")
        else:
            suggestions.append("Data quality checks passed!")
        
        return {'score': max(0, min(100, int(score))), 'issues': issues, 'suggestions': suggestions}
    
    def _calculate_operational_readiness_score(self) -> Dict[str, Any]:
        """Calculate Operational Readiness score (15% weight)."""
        score = 100
        issues = []
        suggestions = []
        
        operational_warnings = [w for w in self.warnings if any(k in w.lower() for k in ['sparksession', 'main', 'stop', 'logging', 'config'])]
        score -= len(operational_warnings) * 5
        for w in operational_warnings:
            issues.append(w)
        
        if self.variable_resolution:
            unresolved = [v for v in self.variable_resolution if not v.get('resolved')]
            score -= len(unresolved) * 8
            for v in unresolved[:3]:
                issues.append(f"Unresolved {v['type']}: {v['name']}")
        
        if score < 70:
            suggestions.append("Add proper SparkSession initialization with platform-specific settings")
            suggestions.append("Include if __name__ == '__main__' block for standalone execution")
            suggestions.append("Add spark.stop() for proper cleanup")
            suggestions.append("Resolve all $PM parameters and $$ variables")
        elif score < 90:
            suggestions.append("Consider adding logging and error handling")
        else:
            suggestions.append("Operational readiness looks good!")
        
        return {'score': max(0, min(100, int(score))), 'issues': issues, 'suggestions': suggestions}
    
    def _generate_diff(self, original: str, improved: str) -> str:
        """Generate a diff between original and improved code."""
        if original == improved:
            return "No changes made"
        
        original_lines = original.split('\n')
        improved_lines = improved.split('\n')
        
        diff_lines = []
        max_lines = max(len(original_lines), len(improved_lines))
        
        for i in range(min(100, max_lines)):
            orig_line = original_lines[i] if i < len(original_lines) else ''
            imp_line = improved_lines[i] if i < len(improved_lines) else ''
            
            if orig_line != imp_line:
                if orig_line:
                    diff_lines.append(f"- L{i+1}: {orig_line}")
                if imp_line:
                    diff_lines.append(f"+ L{i+1}: {imp_line}")
        
        if max_lines > 100:
            diff_lines.append(f"... ({max_lines - 100} more lines)")
        
        return '\n'.join(diff_lines) if diff_lines else "No significant changes"
    
    def _validate_expressions(self, code: str, mapping: Dict) -> None:
        """Validate Informatica expression translations to PySpark."""
        code_lower = code.lower()
        
        for expr_trans in mapping.get('expressions', []):
            trans_name = expr_trans['name']
            
            for field in expr_trans.get('fields', []):
                field_name = field.get('name', '')
                expression = field.get('expression', '')
                
                if not expression or expression == field_name:
                    continue
                
                audit_entry = {
                    'transformation': trans_name,
                    'field': field_name,
                    'informatica_expression': expression,
                    'issues': [],
                    'pyspark_equivalent': None,
                    'found_in_code': False
                }
                
                for infa_func, pyspark_func in INFORMATICA_TO_PYSPARK_FUNCTIONS.items():
                    if infa_func in expression.upper():
                        if pyspark_func in code_lower:
                            audit_entry['pyspark_equivalent'] = pyspark_func
                            audit_entry['found_in_code'] = True
                        else:
                            audit_entry['issues'].append(f"Function {infa_func} should translate to {pyspark_func}")
                
                if 'IIF(' in expression.upper():
                    if 'when(' in code_lower and 'otherwise(' in code_lower:
                        audit_entry['found_in_code'] = True
                    else:
                        audit_entry['issues'].append("IIF requires when().otherwise() pattern")
                
                if 'DECODE(' in expression.upper():
                    if 'when(' in code_lower:
                        audit_entry['found_in_code'] = True
                    else:
                        audit_entry['issues'].append("DECODE requires chained when() calls")
                
                if 'NVL(' in expression.upper():
                    if 'coalesce(' in code_lower:
                        audit_entry['found_in_code'] = True
                    else:
                        audit_entry['issues'].append("NVL should use coalesce()")
                
                if 'TO_DATE(' in expression.upper():
                    if 'to_date(' in code_lower:
                        audit_entry['found_in_code'] = True
                    else:
                        audit_entry['issues'].append("TO_DATE should use to_date()")
                
                if audit_entry['issues']:
                    for issue in audit_entry['issues']:
                        self.warnings.append(f"Expression '{field_name}': {issue}")
                
                self.expression_audit.append(audit_entry)
    
    def _validate_parameters_variables(self, code: str, mapping: Dict) -> None:
        """Validate $PM parameters and $$variables resolution."""
        pm_pattern = r'\$PM(\w+)'
        var_pattern = r'\$\$(\w+)'
        
        all_expressions = []
        for trans in mapping.get('transformations', []):
            for field in trans.get('fields', []):
                expr = field.get('expression', '')
                if expr:
                    all_expressions.append((trans['name'], field['name'], expr))
            for attr_name, attr_value in trans.get('table_attributes', {}).items():
                if isinstance(attr_value, str):
                    all_expressions.append((trans['name'], attr_name, attr_value))
        
        pm_vars = set()
        session_vars = set()
        
        for trans_name, field_name, expr in all_expressions:
            for match in re.findall(pm_pattern, expr):
                pm_vars.add(match)
            for match in re.findall(var_pattern, expr):
                session_vars.add(match)
        
        for pm_var in pm_vars:
            var_entry = {
                'type': 'Parameter ($PM)',
                'name': pm_var,
                'resolved': False,
                'resolution_method': None
            }
            
            if pm_var.lower() in code.lower():
                var_entry['resolved'] = True
                var_entry['resolution_method'] = 'Direct reference'
            elif 'config' in code.lower() and pm_var.lower() in code.lower():
                var_entry['resolved'] = True
                var_entry['resolution_method'] = 'Config file'
            elif 'getenv' in code.lower() or 'environ' in code.lower():
                var_entry['resolved'] = True
                var_entry['resolution_method'] = 'Environment variable'
            else:
                self.warnings.append(f"Parameter $PM{pm_var} not resolved in code")
            
            self.variable_resolution.append(var_entry)
        
        for sess_var in session_vars:
            var_entry = {
                'type': 'Session Variable ($$)',
                'name': sess_var,
                'resolved': False,
                'resolution_method': None
            }
            
            if sess_var.lower() in code.lower():
                var_entry['resolved'] = True
                var_entry['resolution_method'] = 'Direct reference'
            else:
                self.warnings.append(f"Session variable $${sess_var} not resolved in code")
            
            self.variable_resolution.append(var_entry)
    
    def _validate_data_flow(self, code: str, mapping: Dict) -> None:
        """Validate source-to-target data flow matches the mapping pipeline."""
        code_lower = code.lower()
        
        sources = mapping.get('sources', [])
        targets = mapping.get('targets', [])
        
        for source in sources:
            source_name = source['name']
            source_dbtype = source.get('dbname', '')
            
            flow_entry = {
                'element': f"Source: {source_name}",
                'element_type': 'source',
                'expected_operation': None,
                'found': False,
                'details': []
            }
            
            is_file = source_dbtype.lower() in ['flat file', 'flatfile', 'csv', 'parquet', 'delimited']
            
            if is_file:
                flow_entry['expected_operation'] = 'spark.read.csv/parquet/text'
                if any(x in code_lower for x in ['read.csv', 'read.parquet', 'read.text', 'read.format']):
                    flow_entry['found'] = True
                    flow_entry['details'].append('File read operation found')
                else:
                    self.warnings.append(f"Source '{source_name}' is file type but no spark.read.* found")
            else:
                flow_entry['expected_operation'] = 'spark.read.jdbc or spark.sql'
                if 'read.jdbc' in code_lower or 'spark.sql' in code_lower or 'read.format("jdbc")' in code_lower:
                    flow_entry['found'] = True
                    flow_entry['details'].append('Database read operation found')
                else:
                    self.warnings.append(f"Source '{source_name}' is DB type but no JDBC/SQL read found")
            
            self.data_flow_validation.append(flow_entry)
        
        for target in targets:
            target_name = target['name']
            target_dbtype = target.get('dbname', '')
            
            flow_entry = {
                'element': f"Target: {target_name}",
                'element_type': 'target',
                'expected_operation': None,
                'found': False,
                'details': []
            }
            
            is_file = target_dbtype.lower() in ['flat file', 'flatfile', 'csv', 'parquet', 'delimited']
            
            if is_file:
                flow_entry['expected_operation'] = 'df.write.parquet/csv/format'
                if any(x in code_lower for x in ['write.parquet', 'write.csv', 'write.format', '.save(']):
                    flow_entry['found'] = True
                    flow_entry['details'].append('File write operation found')
                else:
                    self.warnings.append(f"Target '{target_name}' is file type but no df.write.* found")
            else:
                flow_entry['expected_operation'] = 'df.write.jdbc or insertInto'
                if 'write.jdbc' in code_lower or 'insertinto' in code_lower or 'write.format("jdbc")' in code_lower:
                    flow_entry['found'] = True
                    flow_entry['details'].append('Database write operation found')
                else:
                    self.warnings.append(f"Target '{target_name}' is DB type but no JDBC write found")
            
            self.data_flow_validation.append(flow_entry)
    
    def _validate_lookup_joins(self, code: str, mapping: Dict) -> None:
        """Validate Lookup transformations are properly converted to joins."""
        code_lower = code.lower()
        
        for lookup in mapping.get('lookups', []):
            lkp_name = lookup['name']
            lkp_attrs = lookup.get('table_attributes', {})
            
            lookup_table = lkp_attrs.get('Lookup table name', '')
            lookup_condition = lkp_attrs.get('Lookup condition', '')
            lookup_sql = lkp_attrs.get('Lookup Sql Override', '')
            
            coverage_entry = {
                'type': 'Lookup Join Validation',
                'name': lkp_name,
                'covered': False,
                'details': []
            }
            
            if 'join' in code_lower:
                coverage_entry['covered'] = True
                coverage_entry['details'].append('Join operation found')
                
                if 'broadcast(' in code_lower:
                    coverage_entry['details'].append('Broadcast hint detected (optimized)')
                
                if '.cache()' in code_lower or '.persist()' in code_lower:
                    coverage_entry['details'].append('Caching detected for lookup dataset')
                
                if 'left' in code_lower and 'join' in code_lower:
                    coverage_entry['details'].append('Left join detected (matches lookup behavior)')
            else:
                self.warnings.append(f"Lookup '{lkp_name}' requires join but none found")
            
            if lookup_table:
                if lookup_table.lower() in code_lower:
                    coverage_entry['details'].append(f'Lookup table "{lookup_table}" referenced')
                else:
                    self.warnings.append(f"Lookup table '{lookup_table}' not found in code")
            
            if lookup_condition:
                coverage_entry['details'].append(f'Condition to validate: {lookup_condition[:50]}')
            
            self.element_coverage.append(coverage_entry)
    
    def _validate_update_strategy(self, code: str, mapping: Dict) -> None:
        """Validate Update Strategy transformations."""
        code_lower = code.lower()
        
        for upd_strat in mapping.get('update_strategies', []):
            strat_name = upd_strat['name']
            strat_attrs = upd_strat.get('table_attributes', {})
            strat_expr = strat_attrs.get('Update Strategy Expression', '')
            
            coverage_entry = {
                'type': 'Update Strategy Validation',
                'name': strat_name,
                'covered': False,
                'details': []
            }
            
            if strat_expr:
                coverage_entry['details'].append(f'Strategy expression: {strat_expr[:60]}')
            
            has_insert = 'DD_INSERT' in strat_expr.upper() if strat_expr else False
            has_update = 'DD_UPDATE' in strat_expr.upper() if strat_expr else False
            has_delete = 'DD_DELETE' in strat_expr.upper() if strat_expr else False
            has_reject = 'DD_REJECT' in strat_expr.upper() if strat_expr else False
            
            if has_update or has_delete:
                if 'merge' in code_lower or 'when matched' in code_lower:
                    coverage_entry['covered'] = True
                    coverage_entry['details'].append('Delta MERGE pattern detected')
                elif 'update' in code_lower or 'mode("overwrite")' in code_lower:
                    coverage_entry['covered'] = True
                    coverage_entry['details'].append('Update/overwrite mode detected')
                else:
                    self.warnings.append(f"Update Strategy '{strat_name}' has UPDATE/DELETE but no merge/update logic found")
            
            if has_insert and not has_update and not has_delete:
                if '.write.' in code_lower:
                    coverage_entry['covered'] = True
                    coverage_entry['details'].append('Insert-only strategy with write operation')
            
            if has_reject:
                coverage_entry['details'].append('REJECT strategy detected - ensure error handling')
            
            if 'write.format("delta")' in code_lower:
                coverage_entry['details'].append('Delta Lake format detected')
            
            self.element_coverage.append(coverage_entry)
    
    def _validate_schema(self, code: str, mapping: Dict) -> None:
        """Validate schema: data type precision, scale, nullability match.
        
        Note: This provides heuristic-based hints by searching for patterns in code.
        For full validation, inspect the actual StructType definitions and compare field-by-field.
        """
        import re
        
        INFORMATICA_TO_SPARK_TYPES = {
            'string': ('StringType', 'string'),
            'varchar': ('StringType', 'string'),
            'char': ('StringType', 'string'),
            'nstring': ('StringType', 'string'),
            'text': ('StringType', 'string'),
            'integer': ('IntegerType', 'int'),
            'int': ('IntegerType', 'int'),
            'small int': ('ShortType', 'short'),
            'smallint': ('ShortType', 'short'),
            'bigint': ('LongType', 'long'),
            'long': ('LongType', 'long'),
            'decimal': ('DecimalType', 'decimal'),
            'number': ('DecimalType', 'decimal'),
            'numeric': ('DecimalType', 'decimal'),
            'double': ('DoubleType', 'double'),
            'float': ('FloatType', 'float'),
            'real': ('FloatType', 'float'),
            'date': ('DateType', 'date'),
            'datetime': ('TimestampType', 'timestamp'),
            'timestamp': ('TimestampType', 'timestamp'),
            'date/time': ('TimestampType', 'timestamp'),
            'binary': ('BinaryType', 'binary'),
            'boolean': ('BooleanType', 'boolean')
        }
        
        struct_matches = re.findall(r'StructField\s*\(\s*["\'](\w+)["\']', code)
        schema_columns = set(c.lower() for c in struct_matches)
        
        cast_patterns = re.findall(r'\.cast\s*\(\s*["\']?(\w+)', code, re.IGNORECASE)
        cast_types = set(t.lower() for t in cast_patterns)
        
        for target in mapping.get('targets', []):
            target_name = target.get('name', '')
            fields = target.get('fields', [])
            
            for field in fields:
                field_name = field.get('name', '')
                datatype = field.get('datatype', '').lower()
                precision = field.get('precision', '')
                scale = field.get('scale', '')
                nullable = field.get('nullable', 'YES')
                
                validation = {
                    'target': target_name,
                    'field': field_name,
                    'informatica_type': datatype,
                    'precision': precision,
                    'scale': scale,
                    'nullable': nullable,
                    'issues': [],
                    'recommendations': []
                }
                
                field_in_code = field_name.lower() in code.lower() or f"'{field_name}'" in code or f'"{field_name}"' in code
                field_in_schema = field_name.lower() in schema_columns
                
                if not field_in_code:
                    validation['issues'].append(f"Column '{field_name}' not referenced in generated code")
                    validation['recommendations'].append(f"Ensure '{field_name}' is included in select/withColumn operations")
                
                type_info = INFORMATICA_TO_SPARK_TYPES.get(datatype)
                if type_info and datatype in ['decimal', 'number', 'numeric']:
                    if precision and scale:
                        decimal_pattern = rf'DecimalType\s*\(\s*{precision}\s*,\s*{scale}\s*\)'
                        if not re.search(decimal_pattern, code, re.IGNORECASE):
                            if field_in_code:
                                validation['issues'].append(f"Precision({precision},{scale}) not explicitly defined")
                                validation['recommendations'].append(f"Use .cast(DecimalType({precision},{scale})) for '{field_name}'")
                
                if nullable in ['NOTNULL', 'NO', 'N']:
                    field_notnull_pattern = rf"(col\s*\(\s*['\"]?{re.escape(field_name)}['\"]?\s*\)\s*\.isNotNull|{re.escape(field_name)}.*nullable\s*=\s*False)"
                    if not re.search(field_notnull_pattern, code, re.IGNORECASE):
                        validation['issues'].append(f"NOT NULL constraint not enforced for '{field_name}'")
                        validation['recommendations'].append(f"Add .filter(col('{field_name}').isNotNull()) before write")
                
                if validation['issues']:
                    self.schema_validation.append(validation)
        
        decimal_sources = []
        for source in mapping.get('sources', []):
            for field in source.get('fields', []):
                datatype = field.get('datatype', '').lower()
                if datatype in ['decimal', 'number', 'numeric']:
                    precision = field.get('precision', '')
                    scale = field.get('scale', '')
                    if precision and scale:
                        decimal_sources.append({
                            'source': source.get('name', ''),
                            'field': field.get('name', ''),
                            'precision': precision,
                            'scale': scale
                        })
        
        if decimal_sources and 'DecimalType' not in code:
            for src in decimal_sources[:3]:
                self.schema_validation.append({
                    'target': f"Source: {src['source']}",
                    'field': src['field'],
                    'informatica_type': 'decimal',
                    'precision': src['precision'],
                    'scale': src['scale'],
                    'nullable': 'YES',
                    'issues': ['No DecimalType found in code for source decimal fields'],
                    'recommendations': [f"Define DecimalType({src['precision']},{src['scale']}) for '{src['field']}'"]
                })
    
    def _validate_performance(self, code: str, mapping: Dict) -> None:
        """Validate performance: broadcast hints, partitioning, caching.
        
        Note: These are heuristic-based recommendations. Actual performance tuning
        depends on data sizes, cluster configuration, and runtime characteristics.
        """
        import re
        code_lower = code.lower()
        
        has_broadcast = 'broadcast(' in code_lower
        has_cache = '.cache()' in code_lower or '.persist(' in code_lower
        has_partition = '.partitionby(' in code_lower or 'partitionby=' in code_lower
        
        join_count = len(re.findall(r'\.join\s*\(', code, re.IGNORECASE))
        groupby_count = len(re.findall(r'\.groupby\s*\(', code, re.IGNORECASE))
        
        lookups = mapping.get('lookups', [])
        if lookups:
            if has_broadcast:
                self.performance_hints.append({
                    'type': 'Broadcast Join',
                    'element': f"{len(lookups)} lookup(s)",
                    'current_state': 'implemented',
                    'recommendation': 'Broadcast hint detected - optimized for small lookup tables',
                    'priority': 'low'
                })
            elif join_count > 0:
                lkp_names = [l.get('name', 'lookup') for l in lookups[:3]]
                self.performance_hints.append({
                    'type': 'Broadcast Join',
                    'element': ', '.join(lkp_names),
                    'current_state': 'missing',
                    'recommendation': f"Consider broadcast() for lookup joins ({join_count} joins detected). Use for tables <10MB.",
                    'priority': 'high' if len(lookups) > 1 else 'medium'
                })
            
            if len(lookups) > 1:
                if has_cache:
                    self.performance_hints.append({
                        'type': 'DataFrame Caching',
                        'element': f"{len(lookups)} lookups",
                        'current_state': 'implemented',
                        'recommendation': 'Caching detected - good for reused lookup DataFrames',
                        'priority': 'low'
                    })
                else:
                    self.performance_hints.append({
                        'type': 'DataFrame Caching',
                        'element': f"{len(lookups)} lookups",
                        'current_state': 'suggested',
                        'recommendation': 'Multiple lookups detected - consider .cache() for reused lookup DataFrames',
                        'priority': 'medium'
                    })
        
        targets = mapping.get('targets', [])
        if targets and '.write' in code_lower:
            if has_partition:
                self.performance_hints.append({
                    'type': 'Output Partitioning',
                    'element': f"{len(targets)} target(s)",
                    'current_state': 'implemented',
                    'recommendation': 'partitionBy detected - output will be partitioned',
                    'priority': 'low'
                })
            else:
                has_date_cols = any(
                    f.get('datatype', '').lower() in ['date', 'datetime', 'timestamp']
                    for t in targets for f in t.get('fields', [])
                )
                if has_date_cols:
                    self.performance_hints.append({
                        'type': 'Output Partitioning',
                        'element': ', '.join(t.get('name', '') for t in targets[:2]),
                        'current_state': 'suggested',
                        'recommendation': 'Date columns detected - consider .partitionBy("date_col") for better query performance',
                        'priority': 'medium'
                    })
        
        aggregators = mapping.get('aggregators', [])
        if aggregators and groupby_count > 0:
            if 'repartition(' in code_lower:
                self.performance_hints.append({
                    'type': 'Aggregation Optimization',
                    'element': f"{len(aggregators)} aggregator(s)",
                    'current_state': 'implemented',
                    'recommendation': 'Repartition before groupBy detected - reduces shuffle skew',
                    'priority': 'low'
                })
            elif len(aggregators) > 1 or groupby_count > 1:
                self.performance_hints.append({
                    'type': 'Aggregation Optimization',
                    'element': f"{len(aggregators)} aggregator(s), {groupby_count} groupBy(s)",
                    'current_state': 'suggested',
                    'recommendation': 'Multiple aggregations - consider .repartition() before groupBy to reduce shuffle',
                    'priority': 'medium'
                })
        
        if 'coalesce(' in code_lower:
            self.performance_hints.append({
                'type': 'File Reduction',
                'element': 'Output',
                'current_state': 'implemented',
                'recommendation': 'coalesce() detected - reduces output file count',
                'priority': 'low'
            })
    
    def _validate_security(self, code: str, mapping: Dict) -> None:
        """Validate security: PII masking, secret handling.
        
        Note: PII detection is pattern-based on field names. Masking verification
        searches for common masking functions near the field name but cannot trace
        full data lineage. Manual review recommended for sensitive data handling.
        """
        import re
        code_lower = code.lower()
        
        PII_PATTERNS = {
            'ssn': ('Social Security Number', 'critical'),
            'social_security': ('Social Security Number', 'critical'),
            'credit_card': ('Credit Card Number', 'critical'),
            'card_number': ('Credit Card Number', 'critical'),
            'ccn': ('Credit Card Number', 'critical'),
            'email': ('Email Address', 'high'),
            'phone': ('Phone Number', 'high'),
            'phone_number': ('Phone Number', 'high'),
            'dob': ('Date of Birth', 'high'),
            'date_of_birth': ('Date of Birth', 'high'),
            'birth_date': ('Date of Birth', 'high'),
            'passport': ('Passport Number', 'critical'),
            'driver_license': ('Driver License', 'high'),
            'dl_number': ('Driver License', 'high'),
            'bank_account': ('Bank Account', 'critical'),
            'account_number': ('Account Number', 'high'),
            'routing_number': ('Routing Number', 'high'),
            'salary': ('Salary (Sensitive)', 'medium'),
            'income': ('Income (Sensitive)', 'medium'),
            'password': ('Password', 'critical'),
            'pwd': ('Password', 'critical'),
            'secret': ('Secret', 'critical'),
            'api_key': ('API Key', 'critical'),
            'access_token': ('Access Token', 'critical'),
            'private_key': ('Private Key', 'critical')
        }
        
        pii_fields_detected = []
        
        for source in mapping.get('sources', []):
            for field in source.get('fields', []):
                field_name = field.get('name', '')
                field_lower = field_name.lower()
                
                for pattern, (pii_type, severity) in PII_PATTERNS.items():
                    if pattern in field_lower:
                        field_ref = f"{source.get('name', '')}.{field_name}"
                        pii_fields_detected.append((field_name, pii_type, severity, 'source'))
                        
                        mask_pattern = rf"(sha2|md5|hash|mask|encrypt|xxxx|regexp_replace).*{re.escape(field_name)}"
                        field_masked = bool(re.search(mask_pattern, code, re.IGNORECASE))
                        
                        if field_masked:
                            self.security_checks.append({
                                'type': 'PII Masking',
                                'element': field_ref,
                                'category': pii_type,
                                'severity': 'low',
                                'status': 'masked',
                                'recommendations': [f"Column '{field_name}' appears to be masked/hashed - good practice"]
                            })
                        else:
                            self.security_checks.append({
                                'type': 'PII Detection',
                                'element': field_ref,
                                'category': pii_type,
                                'severity': severity,
                                'status': 'unmasked',
                                'recommendations': [
                                    f"Mask {pii_type}: sha2(col('{field_name}'), 256)",
                                    f"Partial mask: regexp_replace(col('{field_name}'), '(\\\\d{{5}})(\\\\d{{4}})', 'XXX-XX-$2')"
                                ]
                            })
                        break
        
        for target in mapping.get('targets', []):
            for field in target.get('fields', []):
                field_name = field.get('name', '')
                field_lower = field_name.lower()
                
                for pattern, (pii_type, severity) in PII_PATTERNS.items():
                    if pattern in field_lower:
                        already_detected = any(f[0] == field_name for f in pii_fields_detected)
                        if not already_detected:
                            self.security_checks.append({
                                'type': 'PII in Target',
                                'element': f"{target.get('name', '')}.{field_name}",
                                'category': pii_type,
                                'severity': severity,
                                'status': 'warning',
                                'recommendations': [
                                    f"Ensure {pii_type} is masked before writing",
                                    "Consider column-level encryption for data at rest"
                                ]
                            })
                        break
        
        SECRET_PATTERNS = [
            (r'password\s*=\s*["\'][^"\']{3,}["\']', 'Hardcoded password'),
            (r'pwd\s*=\s*["\'][^"\']{3,}["\']', 'Hardcoded password'),
            (r'secret\s*=\s*["\'][^"\']{3,}["\']', 'Hardcoded secret'),
            (r'api_key\s*=\s*["\'][^"\']{3,}["\']', 'Hardcoded API key'),
            (r'access_token\s*=\s*["\'][^"\']{3,}["\']', 'Hardcoded token'),
            (r'jdbc:[^"\']*password=[^&\s"\']{3,}', 'JDBC password in URL'),
        ]
        
        for pattern, desc in SECRET_PATTERNS:
            match = re.search(pattern, code, re.IGNORECASE)
            if match:
                self.security_checks.append({
                    'type': 'Hardcoded Secret',
                    'element': desc,
                    'category': 'Credential Exposure',
                    'severity': 'critical',
                    'status': 'violation',
                    'recommendations': [
                        "Remove hardcoded credentials immediately",
                        "Use: os.environ.get('DB_PASSWORD')",
                        "Or: spark.conf.get('spark.secret.password')",
                        "For production: AWS Secrets Manager / HashiCorp Vault"
                    ]
                })
                break
        
        if 'os.environ' in code_lower or 'getenv' in code_lower:
            self.security_checks.append({
                'type': 'Secret Management',
                'element': 'Environment Variables',
                'category': 'Good Practice',
                'severity': 'low',
                'status': 'good',
                'recommendations': ["Environment variables used for configuration - good practice"]
            })
        
        if 'spark.conf.get' in code_lower:
            self.security_checks.append({
                'type': 'Secret Management',
                'element': 'Spark Config',
                'category': 'Good Practice',
                'severity': 'low',
                'status': 'good',
                'recommendations': ["Spark config used - secrets passed at runtime"]
            })
