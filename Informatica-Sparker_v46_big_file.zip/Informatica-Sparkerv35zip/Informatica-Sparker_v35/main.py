#!/usr/bin/env python3
"""Main entry point for the Informatica XML to PySpark Converter."""
import os
import sys

# Add src to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from app import app

if __name__ == "__main__":
    port = int(os.environ.get('PORT', 5000))
    print(f"Starting Informatica XML to PySpark Converter on port {port}")
    app.run(host='0.0.0.0', port=port, debug=True)
