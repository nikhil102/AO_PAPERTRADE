// OpsMind Connectors Directory Redesigned Controller

let activeCategory = 'all';
let searchQuery = '';
let activeConnectorId = null;

// Official Vector Brand Logos Database
const BRAND_LOGOS = {
  aws: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 3a9 9 0 0 0-9 9c0 2 .7 3.9 1.9 5.4L3 21l3.6-1.1c1.4.7 3 1.1 4.7 1.1a9 9 0 0 0 9-9 9 9 0 0 0-9-9z" fill="#232F3E"/><path d="M6 14.5c2.5 1.5 5.5 1.5 8 0 M13.5 13.5l1.5 2-2.5.5" stroke="#FF9900" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  
  gcp: `<svg viewBox="0 0 24 24" width="24" height="24"><path d="M21.35 11.1h-9.17v2.73h6.51c-.33 1.56-1.56 2.95-3.24 3.5v2.9h5.15c3.01-2.77 4.75-6.86 4.75-11.75 0-.68-.06-1.34-.17-1.95z" fill="#4285F4"/><path d="M12.18 21c2.43 0 4.47-.8 5.96-2.18l-5.15-2.9c-.8.54-1.85.9-3 .9c-2.3 0-4.26-1.51-4.96-3.55H.41v3.05C2.19 19.86 6.84 21 12.18 21z" fill="#34A853"/><path d="M7.22 13.27c-.2-.54-.3-1.12-.3-1.72c0-.6.1-1.18.3-1.72V6.78H.41C-.26 8.21-.6 9.81-.6 11.55c0 1.74.34 3.34 1.01 4.77l6.81-3.05z" fill="#FBBC05"/><path d="M12.18 5.48c1.32 0 2.5.45 3.44 1.34l2.58-2.58C16.64 2.82 14.6 2 12.18 2c-5.34 0-10 1.14-11.77 4.78l6.81 3.05c.7-2.04 2.66-3.55 4.96-3.55z" fill="#EA4335"/></svg>`,
  
  azure: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M2.5 12L12 2.5 21.5 12 12 21.5 2.5 12z" fill="#007FFF"/><path d="M8 12l4-4 4 4-4 4-4-4z" fill="#ffffff"/></svg>`,
  
  digitalocean: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><circle cx="12" cy="12" r="9" fill="#0080FF"/><rect x="8" y="8" width="5" height="5" fill="#ffffff"/><rect x="11" y="11" width="5" height="5" fill="#0080FF"/></svg>`,
  
  heroku: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 2L4 7v10l8 5 8-5V7l-8-5z" fill="#430098"/><path d="M12 6v12M9 9l3-3 3 3" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/></svg>`,
  
  databricks: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 2L3 7v10l9 5 9-5V7l-9-5z" fill="#FF3621"/><path d="M12 6l5 3-5 3-5-3 5-3z" fill="#ffffff"/></svg>`,
  
  snowflake: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 2v20M2 12h20M5 5l14 14M5 19L19 5" stroke="#29B6F6" stroke-width="2.5" stroke-linecap="round"/><circle cx="12" cy="12" r="3" fill="#29B6F6"/></svg>`,
  
  airflow: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 22c5.5 0 10-4.5 10-10S17.5 2 12 2 2 6.5 2 12s4.5 10 10 10z" fill="#017A86"/><path d="M12 6v12M6 12h12" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/></svg>`,
  
  dbt: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 2L2 7v10l10 5 10-5V7l-10-5z" fill="#FF6B4A"/><circle cx="12" cy="12" r="4" fill="#ffffff"/></svg>`,
  
  spark: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 2L3 9l9 13 9-13-9-7z" fill="#E25A28"/><circle cx="12" cy="11" r="3" fill="#ffffff"/></svg>`,
  
  kafka: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><circle cx="12" cy="12" r="10" fill="#231F20"/><path d="M7 12h10M12 7v10" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/></svg>`,
  
  jira: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M11.5 2.5L2 12h6.5l3-3.5L15 12h6.5L12 2.5h-.5z" fill="#0052CC"/><path d="M12 21.5L21.5 12h-6.5l-3 3.5-3.5-3.5H2l10 9.5z" fill="#0052CC"/></svg>`,
  
  servicenow: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2z" fill="#293E40"/><path d="M8 8l4 4 4-4" stroke="#81B5A3" stroke-width="2" stroke-linecap="round"/></svg>`,
  
  pagerduty: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><circle cx="12" cy="12" r="9" fill="#04A750"/><path d="M8 8h8v8H8z" fill="#ffffff"/></svg>`,
  
  zendesk: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M2 12C2 6.5 6.5 2 12 2s10 4.5 10 10-4.5 10-10 10S2 17.5 2 12z" fill="#03363D"/><path d="M8 10l4 4 4-4" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round"/></svg>`,
  
  github: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 2C6.5 2 2 6.5 2 12c0 4.4 2.9 8.2 6.8 9.5.5.1.7-.2.7-.5v-1.7c-2.8.6-3.4-1.3-3.4-1.3-.5-1.2-1.1-1.5-1.1-1.5-.9-.6.1-.6.1-.6 1 .1 1.5 1 1.5 1 .9 1.5 2.3 1.1 2.9.8.1-.6.4-1 .6-1.3-2.2-.3-4.6-1.1-4.6-5 0-1.1.4-2 1-2.7-.1-.3-.4-1.3.1-2.7 0 0 .9-.3 2.8 1a9.7 9.7 0 0 1 5 0c1.9-1.3 2.8-1 2.8-1 .5 1.4.2 2.4.1 2.7.6.7 1 1.6 1 2.7 0 3.8-2.4 4.7-4.6 4.9.4.3.7.9.7 1.9v2.8c0 .3.2.6.7.5C19.1 20.2 22 16.4 22 12c0-5.5-4.5-10-10-10z" fill="#24292E"/></svg>`,
  
  gitlab: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 2L2 10l3 11h14l3-11L12 2z" fill="#E24329"/><path d="M12 2L5 21h14L12 2z" fill="#FC6D26"/></svg>`,
  
  jenkins: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2z" fill="#D39E82"/><circle cx="12" cy="10" r="4" fill="#F0F0F0"/></svg>`,
  
  terraform: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M4 6l8-4 8 4v12l-8 4-8-4V6z" fill="#7B42BC"/><path d="M12 2v10M4 6l8 4 8-4" stroke="#ffffff" stroke-width="1.5"/></svg>`,
  
  circleci: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><circle cx="12" cy="12" r="9" stroke="#343434" stroke-width="3"/><circle cx="12" cy="12" r="5" fill="#343434"/></svg>`,
  
  argocd: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 2l10 18H2L12 2z" fill="#EF6C00"/><circle cx="12" cy="13" r="3" fill="#ffffff"/></svg>`,
  
  slack: `<svg viewBox="0 0 24 24" width="24" height="24"><circle cx="6" cy="6" r="2" fill="#E01E5A"/><circle cx="18" cy="6" r="2" fill="#36C5F0"/><circle cx="6" cy="18" r="2" fill="#2EB67D"/><circle cx="18" cy="18" r="2" fill="#ECB22E"/><rect x="8" y="4" width="4" height="4" rx="1" fill="#E01E5A"/><rect x="12" y="8" width="4" height="4" rx="1" fill="#36C5F0"/><rect x="8" y="12" width="4" height="4" rx="1" fill="#2EB67D"/><rect x="4" y="8" width="4" height="4" rx="1" fill="#ECB22E"/></svg>`,
  
  teams: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#4B53BC"/><path d="M9 7h6v10H9z" fill="#ffffff"/></svg>`,
  
  confluence: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 2L2 12h7l3-3.5L15 12h7L12 2z" fill="#0052CC"/></svg>`,
  
  notion: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="3" fill="#000000"/><path d="M7 7h3v10H7z M14 7h3v10h-3z M10 7l4 10" stroke="#ffffff" stroke-width="2"/></svg>`,
  
  zoom: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="5" width="12" height="14" rx="3" fill="#2D8CFF"/><polygon points="17 8 21 5 21 19 17 16" fill="#2D8CFF"/></svg>`,
  
  datadog: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#632CA6"/><circle cx="12" cy="12" r="5" stroke="#ffffff" stroke-width="2"/></svg>`,
  
  splunk: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#F25F22"/><path d="M8 8h8v8H8z" fill="#ffffff"/></svg>`,
  
  prometheus: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><circle cx="12" cy="12" r="9" stroke="#E6522C" stroke-width="2.5"/><path d="M12 6v12M6 12h12" stroke="#E6522C" stroke-width="2"/></svg>`,
  
  grafana: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#F89C1C"/><path d="M7 16l3-6 4 4 4-8" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/></svg>`,
  
  postgresql: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#336791"/><path d="M7 7h10v10H7z" fill="#ffffff"/></svg>`,
  
  sqlserver: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#CC292B"/><path d="M7 7h10v10H7z" fill="#ffffff"/></svg>`,
  
  oracle: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#F02025"/><circle cx="12" cy="12" r="5" stroke="#ffffff" stroke-width="2"/></svg>`,
  
  mongodb: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#13AA52"/><path d="M12 6v12" stroke="#ffffff" stroke-width="3"/></svg>`,
  
  redis: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#D82C20"/><circle cx="12" cy="12" r="4" fill="#ffffff"/></svg>`,
  
  mysql: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#00758F"/><path d="M8 8l8 8M16 8l-8 8" stroke="#ffffff" stroke-width="2"/></svg>`,
  
  powerbi: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#F2C811"/><path d="M7 15h2v2H7z M11 11h2v6h-2z M15 7h2v10h-2z" fill="#ffffff"/></svg>`,
  
  tableau: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#E97627"/><circle cx="12" cy="12" r="6" stroke="#ffffff" stroke-width="2"/></svg>`,
  
  metabase: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#509EE3"/><circle cx="12" cy="12" r="5" fill="#ffffff"/></svg>`,
  
  looker: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#4285F4"/><path d="M8 8h8v8H8z" fill="#ffffff"/></svg>`,
  
  salesforce: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2z" fill="#00A1E0"/><path d="M6 14a3 3 0 0 1 3-3 4 4 0 0 1 7.5-1A3 3 0 0 1 18 14a2.5 2.5 0 0 1-2.5 2.5h-7A2.5 2.5 0 0 1 6 14z" fill="#ffffff"/></svg>`,
  
  workday: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#005CB9"/><circle cx="12" cy="12" r="5" stroke="#ffffff" stroke-width="2.5"/></svg>`,
  
  hubspot: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#FF7A59"/><circle cx="12" cy="12" r="4" fill="#ffffff"/></svg>`,
  
  stripe: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#635BFF"/><path d="M10 8h4 M12 8v8 M10 16h4" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round"/></svg>`
};

// Brand Color Accents Database for Neon Hover Glows
const BRAND_COLORS = {
  aws: '#FF9900',
  gcp: '#4285F4',
  azure: '#007FFF',
  digitalocean: '#0080FF',
  heroku: '#430098',
  databricks: '#FF3621',
  snowflake: '#29B6F6',
  airflow: '#017A86',
  dbt: '#FF6B4A',
  spark: '#E25A28',
  kafka: '#a3a3a3',
  jira: '#0052CC',
  servicenow: '#293E40',
  pagerduty: '#04A750',
  zendesk: '#03363D',
  github: '#24292E',
  gitlab: '#E24329',
  jenkins: '#D39E82',
  terraform: '#7B42BC',
  circleci: '#343434',
  argocd: '#EF6C00',
  slack: '#4A154B',
  teams: '#4B53BC',
  confluence: '#0052CC',
  notion: '#000000',
  zoom: '#2D8CFF',
  datadog: '#632CA6',
  splunk: '#F25F22',
  prometheus: '#E6522C',
  grafana: '#F89C1C',
  postgresql: '#336791',
  sqlserver: '#CC292B',
  oracle: '#F02025',
  mongodb: '#13AA52',
  redis: '#D82C20',
  mysql: '#00758F',
  powerbi: '#F2C811',
  tableau: '#E97627',
  metabase: '#509EE3',
  looker: '#4285F4',
  salesforce: '#00A1E0',
  workday: '#005CB9',
  hubspot: '#FF7A59',
  stripe: '#635BFF'
};

document.addEventListener('DOMContentLoaded', () => {
  renderCategoryTabs();
  renderConnectors();
  setupSearchBar();
});

// Calculate active vs total counts for each category
function getCategoryCounts() {
  const connectors = db.getConnectors();
  const counts = {
    all: { connected: 0, total: connectors.length }
  };
  
  connectors.forEach(c => {
    if (c.status === 'Connected') {
      counts.all.connected++;
    }
    
    if (!counts[c.category]) {
      counts[c.category] = { connected: 0, total: 0 };
    }
    counts[c.category].total++;
    if (c.status === 'Connected') {
      counts[c.category].connected++;
    }
  });
  
  return counts;
}

// Render category filter tabs
function renderCategoryTabs() {
  const tabsContainer = document.getElementById('connector-category-tabs');
  if (!tabsContainer) return;
  
  const counts = getCategoryCounts();
  const categoriesList = [
    { id: 'all', name: 'All Connectors' },
    { id: 'cloud', name: 'Cloud' },
    { id: 'data platform', name: 'Data Platform' },
    { id: 'devops', name: 'DevOps' },
    { id: 'ticketing', name: 'Ticketing' },
    { id: 'monitoring', name: 'Monitoring' },
    { id: 'collaboration', name: 'Collaboration' },
    { id: 'database', name: 'Database' },
    { id: 'bi', name: 'BI' },
    { id: 'business apps', name: 'Business Apps' }
  ];
  
  tabsContainer.innerHTML = categoriesList.map(cat => {
    const data = counts[cat.id] || { connected: 0, total: 0 };
    const isActive = cat.id === activeCategory ? 'active' : '';
    const counterBadge = `<span style="opacity:0.6; font-size:10px; margin-left:6px; font-weight:700;">${data.connected}/${data.total}</span>`;
    
    return `<div class="connector-tab ${isActive}" data-category="${cat.id}">${cat.name} ${counterBadge}</div>`;
  }).join('');
  
  const tabs = tabsContainer.querySelectorAll('.connector-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      activeCategory = tab.getAttribute('data-category');
      renderConnectors();
    });
  });
}

// Render redesigned cards with brand logo vectors and direct config/connect actions
function renderConnectors() {
  const container = document.getElementById('connectors-cards-container');
  if (!container) return;
  
  const connectors = db.getConnectors();
  
  const filtered = connectors.filter(conn => {
    const matchesCategory = activeCategory === 'all' || conn.category === activeCategory;
    const matchesSearch = conn.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          conn.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });
  
  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1/-1; text-align:center; padding: 60px 24px; color: var(--color-text-muted);">
        <div style="font-size:36px; margin-bottom:12px;">🔍</div>
        <h3 style="font-family:'Space Grotesk', sans-serif;">No Integrations Found</h3>
        <p style="font-size:13px; margin-top:4px;">No connectors matched active criteria "${searchQuery}".</p>
      </div>
    `;
    return;
  }
  
  container.innerHTML = filtered.map(conn => {
    let dotColor = 'success';
    let statusClass = 'success';
    let uptime = '99.98%';
    let region = 'us-east-1';
    let borderStyle = '';
    
    if (conn.status === 'Needs Auth') {
      dotColor = 'warning';
      statusClass = 'warning';
      uptime = '92.40%';
      region = 'oauth-expired';
    } else if (conn.status === 'Not Connected') {
      dotColor = 'danger';
      statusClass = 'danger';
      uptime = '0.00%';
      region = 'not-targeted';
    } else if (conn.status === 'Permission Issue') {
      dotColor = 'orange';
      statusClass = 'warning';
      uptime = '99.98%';
      region = 'scope-missing';
    }
    
    // SVG logo matching helper
    const brandSvg = BRAND_LOGOS[conn.id] || `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#64748b"/><text x="5" y="16" fill="#ffffff" font-family="'Space Grotesk', sans-serif" font-weight="700" font-size="12">${conn.name.substring(0,2).toUpperCase()}</text></svg>`;
    const brandColor = BRAND_COLORS[conn.id] || '#64748b';
    
    // Action buttons: "Configure" always on left, dynamic connection action always on right
    let actionButtons = `
      <button class="btn btn-secondary btn-sm btn-configure" onclick="openConnectorDrawer('${conn.id}')">
        <svg class="btn-icon gear-icon" xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.5 1z"></path></svg>
        Configure
      </button>
    `;
    
    if (conn.status === 'Connected') {
      actionButtons += `
        <button class="btn btn-secondary btn-sm btn-disconnect" onclick="disconnectConnector('${conn.id}')">
          <svg class="btn-icon" xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"></path><line x1="12" y1="2" x2="12" y2="12"></line></svg>
          Disconnect
        </button>
      `;
    } else if (conn.status === 'Needs Auth') {
      actionButtons += `
        <button class="btn btn-warning btn-sm btn-reauth" onclick="openConnectorDrawer('${conn.id}')">
          <svg class="btn-icon" xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"></path></svg>
          Re-auth
        </button>
      `;
    } else if (conn.status === 'Permission Issue') {
      actionButtons += `
        <button class="btn btn-danger btn-sm btn-fix" onclick="openConnectorDrawer('${conn.id}')">
          <svg class="btn-icon" xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
          Fix Scope
        </button>
      `;
    } else {
      actionButtons += `
        <button class="btn btn-primary btn-sm btn-connect" onclick="openConnectorDrawer('${conn.id}')">
          <svg class="btn-icon" xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
          Connect
        </button>
      `;
    }
    
    const sparklinePath = conn.status === 'Not Connected' 
      ? 'M0,12 L80,12' 
      : `M0,${Math.floor(Math.random()*10 + 6)} Q15,${Math.floor(Math.random()*18)} 30,${Math.floor(Math.random()*10 + 10)} T60,${Math.floor(Math.random()*16 + 2)} T80,${Math.floor(Math.random()*12 + 6)}`;
    
    const sparklineColor = conn.status === 'Connected' ? 'var(--color-success)' : conn.status === 'Needs Auth' ? 'var(--color-warning)' : 'var(--color-text-muted)';
    
    return `
      <div class="connector-item-card card" style="--brand-color: ${brandColor};">
        <!-- Interactive Tech Corner Brackets -->
        <div class="tech-bracket top-left"></div>
        <div class="tech-bracket top-right"></div>
        <div class="tech-bracket bottom-left"></div>
        <div class="tech-bracket bottom-right"></div>

        <div class="connector-item-header">
          <div class="connector-item-title">
            <div class="connector-logo-stage">
              ${brandSvg}
            </div>
            <div class="connector-item-meta">
              <h4>${conn.name}</h4>
              <span class="connector-item-cat">${conn.category}</span>
            </div>
          </div>
          <span class="status-badge ${statusClass}">
            <span class="status-dot ${dotColor}"></span>
            ${conn.status}
          </span>
        </div>
        
        <!-- Live Telemetry Area -->
        <div class="connector-telemetry-hud">
          <div class="telemetry-info">
            <div class="telemetry-stat">
              <span class="telemetry-label">REGION:</span>
              <span class="telemetry-val">${region}</span>
            </div>
            <div class="telemetry-stat">
              <span class="telemetry-label">UPTIME:</span>
              <span class="telemetry-val">${uptime}</span>
            </div>
          </div>
          
          <div class="telemetry-chart">
            <span class="telemetry-chart-label">LATENCY INDEX</span>
            <svg width="80" height="24" viewBox="0 0 80 24" fill="none" style="filter: drop-shadow(0 0 4px ${sparklineColor}50)">
              <path d="${sparklinePath}" stroke="${sparklineColor}" stroke-width="2" stroke-linecap="round"/>
            </svg>
          </div>
        </div>

        <div class="connector-item-footer">
          ${actionButtons}
        </div>
      </div>
    `;
  }).join('');
}

// Search bar input filter
function setupSearchBar() {
  const searchInput = document.getElementById('connector-search-bar');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value;
      renderConnectors();
    });
  }
}

// Disconnect connector handler
function disconnectConnector(id) {
  if (!confirm('Are you sure you want to disconnect this app? Staged automations using this connector will fail.')) return;
  
  const connectors = db.getConnectors();
  const connIdx = connectors.findIndex(c => c.id === id);
  if (connIdx !== -1) {
    connectors[connIdx].status = 'Not Connected';
    connectors[connIdx].permission = 'No credentials configured';
    db.saveConnectors(connectors);
    
    showToast(`${connectors[connIdx].name} connector disconnected successfully.`, 'warning');
    renderCategoryTabs();
    renderConnectors();
  }
}

// ==========================================
// REDESIGNED SLIDEOVER DRAWER INTERACTION
// ==========================================

function openConnectorDrawer(id) {
  activeConnectorId = id;
  const connectors = db.getConnectors();
  const conn = connectors.find(c => c.id === id);
  if (!conn) return;
  
  const drawer = document.getElementById('connector-details-drawer');
  if (!drawer) return;
  
  const brandSvg = BRAND_LOGOS[conn.id] || `<svg viewBox="0 0 24 24" width="24" height="24" fill="none"><rect x="3" y="3" width="18" height="18" rx="4" fill="#64748b"/><text x="5" y="16" fill="#ffffff" font-family="'Space Grotesk', sans-serif" font-weight="700" font-size="12">${conn.name.substring(0,2).toUpperCase()}</text></svg>`;
  
  const drawerIcon = document.getElementById('drawer-conn-icon');
  if (drawerIcon) {
    drawerIcon.innerHTML = brandSvg;
    drawerIcon.style.backgroundColor = 'transparent';
    drawerIcon.style.border = 'none';
    drawerIcon.style.padding = '0';
  }
  
  document.getElementById('drawer-conn-name').textContent = conn.name;
  document.getElementById('drawer-conn-cat').textContent = conn.category.toUpperCase();
  document.getElementById('drawer-conn-status').textContent = conn.status;
  document.getElementById('drawer-conn-auth').textContent = conn.authType;
  document.getElementById('drawer-conn-env').value = conn.env;
  document.getElementById('drawer-conn-cred').value = '';
  
  // Hide stdout details by default
  document.getElementById('drawer-handshake-details').style.display = 'none';
  document.getElementById('drawer-handshake-stdout').innerHTML = '';
  
  // Status Dot
  let dotColor = 'success';
  if (conn.status === 'Needs Auth') dotColor = 'warning';
  if (conn.status === 'Not Connected') dotColor = 'danger';
  if (conn.status === 'Permission Issue') dotColor = 'orange';
  
  const dot = document.getElementById('drawer-conn-dot');
  if (dot) {
    dot.className = `status-dot ${dotColor}`;
  }
  
  // Generate checkbox scopes checklists
  const scopesList = document.getElementById('drawer-conn-scopes-list');
  if (scopesList) {
    if (conn.scopes.length === 0) {
      scopesList.innerHTML = `<span style="font-size:12px; color:var(--color-text-muted); font-style:italic;">No security scopes parameters requested.</span>`;
    } else {
      scopesList.innerHTML = conn.scopes.map(sc => `
        <label style="display:flex; align-items:center; gap:8px; font-size:12px; cursor:pointer;">
          <input type="checkbox" checked style="accent-color:var(--color-primary);">
          <span style="font-family:monospace;">${sc}</span>
        </label>
      `).join('');
    }
  }
  
  drawer.classList.add('active');
}

function closeConnectorDrawer() {
  const drawer = document.getElementById('connector-details-drawer');
  if (drawer) drawer.classList.remove('active');
}

// Test Connection handshake log generator
function testDrawerConnection() {
  const btn = document.getElementById('drawer-test-btn');
  const detailsDiv = document.getElementById('drawer-handshake-details');
  const stdout = document.getElementById('drawer-handshake-stdout');
  if (!btn || !stdout || !detailsDiv) return;
  
  btn.textContent = 'Verifying...';
  btn.disabled = true;
  
  detailsDiv.style.display = 'block';
  stdout.innerHTML = `<span style="color:var(--color-text-muted)">[16:29:01]</span> INFO: Initiating API client connection handshake...`;
  
  setTimeout(() => {
    stdout.innerHTML += `<br><span style="color:var(--color-text-muted)">[16:29:02]</span> INFO: Sending signed credentials signature header...`;
    
    setTimeout(() => {
      stdout.innerHTML += `<br><span style="color:var(--color-text-muted)">[16:29:03]</span> INFO: Verifying oauth scopes access limits...`;
      
      setTimeout(() => {
        stdout.innerHTML += `<br><span style="color:#22c55e;">[16:29:04] SUCCESS: Handshake verified. Status: 200 OK. Connection Active.</span>`;
        
        btn.textContent = 'Handshake Passed ✓';
        btn.className = 'btn btn-success';
        btn.disabled = false;
        showToast('Connector verified and active!', 'success');
        
        setTimeout(() => {
          btn.textContent = 'Test Handshake';
          btn.className = 'btn btn-warning';
        }, 1500);
      }, 800);
    }, 600);
  }, 800);
}

// Save connector details configuration
function saveDrawerConnectorConfig() {
  if (!activeConnectorId) return;
  
  const connectors = db.getConnectors();
  const connIdx = connectors.findIndex(c => c.id === activeConnectorId);
  
  if (connIdx !== -1) {
    connectors[connIdx].status = 'Connected';
    connectors[connIdx].permission = 'Required access available';
    connectors[connIdx].env = document.getElementById('drawer-conn-env').value;
    
    db.saveConnectors(connectors);
    
    showToast(`${connectors[connIdx].name} credentials saved and authenticated.`, 'success');
    closeConnectorDrawer();
    renderCategoryTabs();
    renderConnectors();
  }
}
