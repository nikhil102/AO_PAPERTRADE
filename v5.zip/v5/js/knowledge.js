// OpsMind Knowledge Library Script

const AVAILABLE_PROJECTS = [
  'AWS & Snowflake Stage',
  'Databricks Fail-Safe',
  'BigQuery Cost Analysis',
  'Clean stale GCP Staging tables',
  'PostgreSQL DB Column Replication Test'
];

let activeFilter = 'all';
let searchKeyword = '';
let currentDocId = null;

document.addEventListener('DOMContentLoaded', () => {
  initKnowledgePage();
});

function initKnowledgePage() {
  loadKnowledgeGrid();
  setupEventListeners();
  populateProjectsFormList();
}

// 1. GRID & RENDERERS
function loadKnowledgeGrid() {
  const kbData = db.getKnowledge() || [];
  const gridEl = document.getElementById('kb-card-grid');
  const emptyStateEl = document.getElementById('kb-empty-state');
  
  if (!gridEl) return;
  
  // Filter & Search data
  const filteredData = kbData.filter(doc => {
    // Type Filter
    if (activeFilter !== 'all' && doc.type !== activeFilter) {
      return false;
    }
    // Search keyword match
    if (searchKeyword) {
      const kw = searchKeyword.toLowerCase();
      const matchTitle = doc.title.toLowerCase().includes(kw);
      const matchSource = doc.source.toLowerCase().includes(kw);
      const matchCategory = doc.category.toLowerCase().includes(kw);
      const matchProjects = doc.projects.some(p => p.toLowerCase().includes(kw));
      return matchTitle || matchSource || matchCategory || matchProjects;
    }
    return true;
  });

  // Update Stats KPIs
  updateKPIs(kbData);

  if (filteredData.length === 0) {
    gridEl.innerHTML = '';
    emptyStateEl.style.display = 'block';
    return;
  }
  
  emptyStateEl.style.display = 'none';
  gridEl.innerHTML = filteredData.map(doc => {
    const projectPills = doc.projects.map(p => `<span class="kb-project-pill">${p}</span>`).join('');
    
    // Icon based on type
    let icon = '📚';
    if (doc.type === 'confluence') icon = '🔗';
    else if (doc.type === 'file') icon = '📁';
    else if (doc.type === 'guideline') icon = '📝';

    return `
      <div class="card kb-card" data-id="${doc.id}">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px;">
          <span class="kb-meta-badge ${doc.type}">${doc.type}</span>
          <span style="font-size:11px; color:var(--color-text-muted); font-weight:600; background:rgba(0,0,0,0.02); padding: 2px 6px; border-radius:4px;">${doc.category}</span>
        </div>
        <h3 style="font-family:'Space Grotesk', sans-serif; font-size:16px; font-weight:700; margin-bottom:8px; color:var(--color-text-dark); display:flex; align-items:center; gap:6px;">
          <span>${icon}</span>
          <span>${doc.title}</span>
        </h3>
        <div style="font-size:12px; color:var(--color-text-muted); word-break:break-all; font-family:monospace; margin-bottom:16px; min-height:36px; line-height:1.4;">
          ${doc.source}
        </div>
        <div style="margin-bottom:16px;">
          <span style="font-size:10px; text-transform:uppercase; color:var(--color-text-muted); font-weight:700; display:block; margin-bottom:6px; letter-spacing:0.3px;">Linked Projects</span>
          <div style="display:flex; flex-wrap:wrap; gap:6px;">
            ${projectPills || '<span style="font-size:11px; font-style:italic; color:var(--color-text-muted);">None</span>'}
          </div>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid var(--color-border); padding-top:12px; margin-top:auto;">
          <span style="font-size:11px; color:var(--color-text-muted);">Synced: ${doc.lastSynced ? doc.lastSynced.split(' ')[0] : 'Never'}</span>
          <button class="btn btn-secondary btn-sm" onclick="openKnowledgeDrawer('${doc.id}')">View Document</button>
        </div>
      </div>
    `;
  }).join('');
}

function updateKPIs(data) {
  const total = data.length;
  const confluence = data.filter(d => d.type === 'confluence').length;
  const file = data.filter(d => d.type === 'file').length;
  const guideline = data.filter(d => d.type === 'guideline').length;

  document.getElementById('kpi-total-docs').textContent = total;
  document.getElementById('kpi-confluence-docs').textContent = confluence;
  document.getElementById('kpi-file-docs').textContent = file;
  document.getElementById('kpi-guideline-docs').textContent = guideline;
}

// Populate multi-selection of projects in modal
function populateProjectsFormList() {
  const listEl = document.getElementById('kb-form-projects-list');
  if (!listEl) return;
  
  listEl.innerHTML = AVAILABLE_PROJECTS.map((proj, idx) => `
    <label style="display:flex; align-items:center; gap:8px; font-size:13px; color:var(--color-text-dark); cursor:pointer;">
      <input type="checkbox" name="kb-form-projects" value="${proj}" style="accent-color:var(--color-primary);">
      <span>${proj}</span>
    </label>
  `).join('');
}

// 2. SEARCH & FILTERS
function setupEventListeners() {
  // Filters click handler
  const filterBtns = document.querySelectorAll('.kb-filter-btn');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeFilter = btn.getAttribute('data-type');
      loadKnowledgeGrid();
    });
  });

  // Search input handler
  const searchBar = document.getElementById('kb-search-bar');
  if (searchBar) {
    searchBar.addEventListener('input', (e) => {
      searchKeyword = e.target.value;
      loadKnowledgeGrid();
    });
  }
}

// Toggle input field labels and properties depending on document source type
function toggleFormInputs() {
  const type = document.getElementById('kb-form-type').value;
  const container = document.getElementById('kb-input-source-path-container');
  const label = document.getElementById('kb-label-source-path');
  const input = document.getElementById('kb-form-source-path');
  
  if (type === 'confluence') {
    container.style.display = 'block';
    label.textContent = 'Confluence Page URL';
    input.placeholder = 'https://confluence.opsmind.org/display/...';
    input.required = true;
    input.value = '';
  } else if (type === 'file') {
    container.style.display = 'block';
    label.textContent = 'Local System File Path';
    input.placeholder = '/workspace/project/schema.sql';
    input.required = true;
    input.value = '';
  } else {
    // Guideline - no source path needed, defaults to Manual Input
    container.style.display = 'none';
    input.required = false;
    input.value = 'Manual Text Input';
  }
}

// 3. ADD MODAL ACTIONS
function openAddKnowledgeModal() {
  const modal = document.getElementById('add-knowledge-modal');
  if (modal) modal.classList.add('active');
  // Reset form
  document.getElementById('add-knowledge-form').reset();
  toggleFormInputs();
}

function closeAddKnowledgeModal() {
  const modal = document.getElementById('add-knowledge-modal');
  if (modal) modal.classList.remove('active');
}

function submitNewKnowledge(event) {
  event.preventDefault();
  
  const title = document.getElementById('kb-form-title').value;
  const type = document.getElementById('kb-form-type').value;
  const category = document.getElementById('kb-form-category').value;
  const source = document.getElementById('kb-form-source-path').value;
  const content = document.getElementById('kb-form-content').value;
  
  // Selected projects
  const checkedBoxes = document.querySelectorAll('input[name="kb-form-projects"]:checked');
  const projects = Array.from(checkedBoxes).map(cb => cb.value);

  const now = new Date();
  const dateStr = now.getFullYear() + '-' + 
    String(now.getMonth() + 1).padStart(2, '0') + '-' + 
    String(now.getDate()).padStart(2, '0') + ' ' + 
    String(now.getHours()).padStart(2, '0') + ':' + 
    String(now.getMinutes()).padStart(2, '0');

  const newDoc = {
    id: 'kb-' + Date.now(),
    title,
    type,
    source,
    category,
    dateAdded: dateStr,
    lastSynced: type === 'guideline' ? 'Manual (Not Checked)' : dateStr,
    projects,
    content
  };

  db.addKnowledge(newDoc);
  loadKnowledgeGrid();
  closeAddKnowledgeModal();
  showToast(`Knowledge resource "${title}" successfully registered.`, 'success');
}

// 4. DRAWER PREVIEWS & SYNC OPERATION
function openKnowledgeDrawer(id) {
  const doc = db.getKnowledge().find(d => d.id === id);
  if (!doc) return;

  currentDocId = id;
  
  document.getElementById('drawer-doc-title').textContent = doc.title;
  document.getElementById('drawer-doc-category').textContent = doc.category;
  document.getElementById('drawer-doc-source').textContent = doc.source;
  document.getElementById('drawer-doc-added').textContent = doc.dateAdded;
  document.getElementById('drawer-doc-synced').textContent = doc.lastSynced;
  
  // Subtitle / Sub-badge
  const subEl = document.getElementById('drawer-doc-subtitle');
  subEl.textContent = doc.type.toUpperCase() + ' DOCUMENT';
  
  // Type icon inside drawer header
  let icon = '📚';
  if (doc.type === 'confluence') icon = '🔗';
  else if (doc.type === 'file') icon = '📁';
  else if (doc.type === 'guideline') icon = '📝';
  document.getElementById('drawer-doc-icon').textContent = icon;

  // Render Projects
  const projectsEl = document.getElementById('drawer-doc-projects');
  if (doc.projects.length === 0) {
    projectsEl.innerHTML = '<span style="font-size:12px; font-style:italic; color:var(--color-text-muted);">No automation projects linked.</span>';
  } else {
    projectsEl.innerHTML = doc.projects.map(p => `<span class="kb-project-pill">${p}</span>`).join('');
  }

  // Render Preview content
  const previewEl = document.getElementById('drawer-doc-content');
  if (doc.type === 'file') {
    previewEl.innerHTML = formatCodePreview(doc.content);
  } else if (doc.type === 'confluence') {
    previewEl.innerHTML = parseWikiMarkup(doc.content);
  } else {
    previewEl.innerHTML = `<div style="font-family:inherit;">${doc.content.replace(/\n/g, '<br>')}</div>`;
  }

  // Clear Audit sync stdout console logs
  const logsEl = document.getElementById('drawer-audit-logs');
  logsEl.innerHTML = '<div style="color:var(--color-text-muted); font-style:italic;">No sync operations run yet. Click "Audit Resync Source" below to verify connection.</div>';

  // Toggle Audit sync button depending on type
  const auditBtn = document.getElementById('btn-audit-resync');
  if (doc.type === 'guideline') {
    auditBtn.style.display = 'none';
  } else {
    auditBtn.style.display = 'block';
    auditBtn.disabled = false;
    auditBtn.textContent = 'Audit Resync Source';
  }

  // Slide drawer open
  const drawer = document.getElementById('kb-details-drawer');
  if (drawer) drawer.classList.add('active');
}

function closeKnowledgeDrawer() {
  const drawer = document.getElementById('kb-details-drawer');
  if (drawer) drawer.classList.remove('active');
}

// 5. FORMATTING PARSERS
function formatCodePreview(text) {
  if (!text) return '';
  const escaped = text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
  return `<pre style="margin: 0; padding: 0; border: none; background: transparent; color: inherit;"><code>${escaped}</code></pre>`;
}

function parseWikiMarkup(text) {
  if (!text) return '';
  let html = text;
  
  // h1. Header
  html = html.replace(/^h1\.\s+(.*)$/gm, '<h1>$1</h1>');
  // h2. Header
  html = html.replace(/^h2\.\s+(.*)$/gm, '<h2>$1</h2>');
  
  // Bold *text*
  html = html.replace(/\*(.*?)\*/g, '<strong>$1</strong>');
  
  // Monospace inline `code`
  html = html.replace(/`(.*?)`/g, '<code style="font-family:monospace; background:rgba(0,0,0,0.06); padding:2px 4px; border-radius:4px;">$1</code>');
  
  // Lists conversion
  let lines = html.split('\n');
  let inUl = false;
  let inOl = false;
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i].trim();
    if (line.startsWith('* ')) {
      if (!inUl) {
        lines[i] = '<ul><li>' + line.substring(2) + '</li>';
        inUl = true;
      } else {
        lines[i] = '<li>' + line.substring(2) + '</li>';
      }
    } else if (line.startsWith('# ')) {
      if (!inOl) {
        lines[i] = '<ol><li>' + line.substring(2) + '</li>';
        inOl = true;
      } else {
        lines[i] = '<li>' + line.substring(2) + '</li>';
      }
    } else {
      if (inUl) {
        lines[i-1] = lines[i-1] + '</ul>';
        inUl = false;
      }
      if (inOl) {
        lines[i-1] = lines[i-1] + '</ol>';
        inOl = false;
      }
    }
  }
  if (inUl) lines[lines.length - 1] += '</ul>';
  if (inOl) lines[lines.length - 1] += '</ol>';
  
  html = lines.join('\n');
  return html.replace(/\n/g, '<br>');
}

// 6. DIAGNOSTICS AUDITING RESYNC
function auditResyncSource() {
  const doc = db.getKnowledge().find(d => d.id === currentDocId);
  if (!doc) return;

  const btn = document.getElementById('btn-audit-resync');
  btn.disabled = true;
  btn.textContent = 'Auditing...';

  const logsEl = document.getElementById('drawer-audit-logs');
  logsEl.innerHTML = '';
  
  const addLogLine = (message, type = 'info') => {
    const line = document.createElement('div');
    line.style.marginBottom = '4px';
    if (type === 'success') line.style.color = 'var(--color-success)';
    else if (type === 'error') line.style.color = 'var(--color-error)';
    else if (type === 'warn') line.style.color = 'var(--color-warning)';
    else line.style.color = '#38bdf8';
    line.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
    logsEl.appendChild(line);
    logsEl.scrollTop = logsEl.scrollHeight;
  };

  const steps = [];
  if (doc.type === 'confluence') {
    steps.push(
      { msg: 'Initiating HTTP handshake with Confluence server...', delay: 400 },
      { msg: 'Resolving DNS hostname: confluence.opsmind.org', delay: 400 },
      { msg: 'HTTP/1.1 200 OK - SSL Handshake successful (TLS 1.3)', delay: 500 },
      { msg: `Fetching content for page URL: ${doc.source}`, delay: 600 },
      { msg: `Page fetched successfully. Extracted page version: v12`, delay: 500 },
      { msg: 'Parsing wiki structure and extracting raw markup text...', delay: 400 },
      { msg: 'Comparison complete: 0 changes detected in target text.', delay: 300 },
      { msg: 'SUCCESS: Confluence resource audited and verified in-sync.', type: 'success', delay: 400 }
    );
  } else if (doc.type === 'file') {
    steps.push(
      { msg: `Checking local file system path: ${doc.source}`, delay: 400 },
      { msg: 'Validating file read permissions for sandbox executor...', delay: 500 },
      { msg: 'Read access GRANTED - Reading local schema definition file...', delay: 500 },
      { msg: `Hashing schema payload: ${Math.random().toString(36).substring(7)}`, delay: 400 },
      { msg: 'Checking Snowflake DDL table metadata alignment...', delay: 600 },
      { msg: 'SUCCESS: Local file schema rules verified in-sync.', type: 'success', delay: 400 }
    );
  } else {
    steps.push(
      { msg: 'Reading manual text guideline input...', delay: 400 },
      { msg: 'Checking compliance tags mappings...', delay: 500 },
      { msg: 'Verified: No external HTTP calls needed for manual compliance policies.', delay: 400 },
      { msg: 'SUCCESS: Guideline document audited and verified.', type: 'success', delay: 300 }
    );
  }

  let index = 0;
  function runStep() {
    if (index < steps.length) {
      const step = steps[index];
      addLogLine(step.msg, step.type || 'info');
      index++;
      setTimeout(runStep, step.delay);
    } else {
      // Complete sync
      btn.disabled = false;
      btn.textContent = 'Audit Resync Source';
      
      // Update DB
      const kb = db.getKnowledge();
      const docIndex = kb.findIndex(d => d.id === currentDocId);
      if (docIndex !== -1) {
        const now = new Date();
        const dateStr = now.getFullYear() + '-' + 
          String(now.getMonth() + 1).padStart(2, '0') + '-' + 
          String(now.getDate()).padStart(2, '0') + ' ' + 
          String(now.getHours()).padStart(2, '0') + ':' + 
          String(now.getMinutes()).padStart(2, '0');
        
        kb[docIndex].lastSynced = dateStr;
        db.saveKnowledge(kb);
        
        // Refresh UI
        document.getElementById('drawer-doc-synced').textContent = dateStr;
        loadKnowledgeGrid();
        showToast(`Document "${doc.title}" resynced and audited successfully.`, 'success');
      }
    }
  }

  runStep();
}
