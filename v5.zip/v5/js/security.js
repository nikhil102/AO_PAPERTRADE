// OpsMind Security Audit & Compliance Controller

let activeScanTimer = null;
let currentTestConnectorId = null;

document.addEventListener('DOMContentLoaded', () => {
  initSecurityPage();
});

function initSecurityPage() {
  loadSecurityDashboard();
}

function loadSecurityDashboard() {
  const connectors = db.getConnectors() || [];
  const control = db.getControl() || { whitelistIPs: [] };
  const approvals = db.getApprovals() || [];

  // 1. FILTER CONFIGURED CONNECTORS (Status is Connected or Needs Auth)
  const configuredConnectors = connectors.filter(c => c.status !== 'Not Connected');
  
  // Render table
  const tbody = document.getElementById('sec-tokens-table-tbody');
  if (tbody) {
    if (configuredConnectors.length === 0) {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding: 24px; color:var(--color-text-muted);">No active credentials configured. Link systems in <a href="connectors.html" style="color:var(--color-primary); text-decoration:underline;">Connectors</a>.</td></tr>`;
    } else {
      tbody.innerHTML = configuredConnectors.map(conn => {
        let statusBadge = '';
        if (conn.status === 'Connected') {
          statusBadge = `<span class="status-badge success" style="font-size: 10px;">ACTIVE</span>`;
        } else {
          statusBadge = `<span class="status-badge danger" style="font-size: 10px;">EXPIRED</span>`;
        }

        const scopeBadges = conn.scopes.map(s => `<span class="sec-scope-badge">${s}</span>`).join('');

        return `
          <tr style="border-bottom:1px solid var(--color-border);">
            <td style="padding:12px 8px; font-weight:700; color:var(--color-text-dark);">${conn.name}</td>
            <td style="padding:12px 8px; color:var(--color-text-muted);">${conn.authType}</td>
            <td style="padding:12px 8px; max-width: 260px;">${scopeBadges || '<span style="font-style:italic; color:var(--color-text-muted);">None</span>'}</td>
            <td style="padding:12px 8px;">${statusBadge}</td>
            <td style="padding:12px 8px; text-align:right;">
              <button class="btn btn-secondary btn-sm" onclick="openTestTokenModal('${conn.id}')" style="margin-right:6px; padding: 4px 10px;">Test</button>
              <button class="btn btn-danger btn-sm" onclick="revokeConnectorToken('${conn.id}')" style="padding: 4px 10px;">Revoke</button>
            </td>
          </tr>
        `;
      }).join('');
    }
  }

  // 2. RENDER WHITELIST RULES
  const firewallIpsEl = document.getElementById('sec-firewall-ips');
  if (firewallIpsEl) {
    const ips = control.whitelistIPs || [];
    if (ips.length === 0) {
      firewallIpsEl.innerHTML = `<span style="font-size:12px; font-style:italic; color:var(--color-error);">NO FIREWALL RULES (Bypass danger!)</span>`;
    } else {
      firewallIpsEl.innerHTML = ips.map(ip => `
        <span class="kb-project-pill ip-badge-item" style="padding: 4px 10px; font-family:monospace; display:flex; align-items:center; gap:6px; background:rgba(0,0,0,0.03); border-color:var(--color-border); font-size:12px; color:var(--color-text-dark);">
          <span style="color:var(--color-success); font-size:10px;">●</span>
          <span>${ip}</span>
        </span>
      `).join('');
    }
    // Update Whitelist KPI
    document.getElementById('sec-kpi-ips').textContent = ips.length;
  }

  // 3. RENDER ACCESS TOKENS KPI
  const activeTokensCount = configuredConnectors.filter(c => c.status === 'Connected').length;
  document.getElementById('sec-kpi-tokens').textContent = activeTokensCount;

  // 4. RENDER HIGH RISK APPROVALS
  const highRiskApprovalsCount = approvals.filter(a => a.riskLevel === 'high').length;
  const riskKpiCard = document.getElementById('sec-kpi-risks');
  const riskIcon = document.getElementById('sec-kpi-risk-icon');
  
  if (riskKpiCard) {
    riskKpiCard.textContent = highRiskApprovalsCount;
    if (highRiskApprovalsCount > 0) {
      riskIcon.style.backgroundColor = 'rgba(239, 68, 68, 0.1)';
      riskIcon.style.color = 'var(--color-error)';
      riskKpiCard.style.color = 'var(--color-error)';
    } else {
      riskIcon.style.backgroundColor = 'rgba(16, 185, 129, 0.1)';
      riskIcon.style.color = 'var(--color-success)';
      riskIcon.innerHTML = '✅';
      riskKpiCard.style.color = 'var(--color-text-dark)';
    }
  }

  // 5. COMPUTE SECURITY HEALTH SCORE
  computeHealthScore(configuredConnectors, control.whitelistIPs || [], highRiskApprovalsCount);
}

function computeHealthScore(configuredConnectors, whitelistIPs, highRiskCount) {
  let score = 100;
  
  // Deductions
  const expiredCount = configuredConnectors.filter(c => c.status !== 'Connected').length;
  score -= (expiredCount * 15); // 15% deduction per expired credential
  
  score -= (highRiskCount * 5); // 5% deduction per unresolved high risk approval
  
  if (whitelistIPs.length === 0) {
    score -= 10; // 10% deduction if no whitelist IPs exist
  }

  // Keep score bounds [20, 100]
  score = Math.max(20, Math.min(100, score));

  // Update UI dial
  const ring = document.getElementById('sec-health-ring');
  const val = document.getElementById('sec-health-value');
  const label = document.getElementById('sec-health-label');
  
  if (ring && val && label) {
    val.textContent = score + '%';
    
    // Circumference = 2 * pi * r = 2 * 3.14159 * 40 = 251.2
    const offset = 251.2 - (251.2 * score) / 100;
    ring.style.strokeDashoffset = offset;

    if (score >= 90) {
      label.textContent = 'SECURE';
      label.style.color = 'var(--color-success)';
      ring.setAttribute('stroke', 'var(--color-success)');
    } else if (score >= 70) {
      label.textContent = 'WARNING';
      label.style.color = 'var(--color-warning)';
      ring.setAttribute('stroke', 'var(--color-warning)');
    } else {
      label.textContent = 'COMPROMISED';
      label.style.color = 'var(--color-error)';
      ring.setAttribute('stroke', 'var(--color-error)');
    }
  }
}

// 6. REVOKE TOKEN MECHANISM
function revokeConnectorToken(id) {
  const connectors = db.getConnectors();
  const connIdx = connectors.findIndex(c => c.id === id);
  if (connIdx === -1) return;

  const name = connectors[connIdx].name;
  
  // Confirm action
  if (confirm(`Are you sure you want to revoke active access tokens for ${name}? CLI sessions and sandbox executors will instantly lose access.`)) {
    connectors[connIdx].status = 'Not Connected';
    db.saveConnectors(connectors);
    loadSecurityDashboard();
    showToast(`Access credentials for ${name} have been revoked.`, 'warning');
  }
}

// 7. TESTING TOKENS MODAL
function openTestTokenModal(id) {
  const connectors = db.getConnectors();
  const conn = connectors.find(c => c.id === id);
  if (!conn) return;

  currentTestConnectorId = id;
  
  document.getElementById('modal-test-connector-name').textContent = conn.name;
  document.getElementById('modal-test-auth-type').textContent = conn.authType;
  
  const iconEl = document.getElementById('modal-test-icon');
  let icon = '🔌';
  if (conn.id === 'aws') icon = '☁️';
  else if (conn.id === 'snowflake') icon = '❄️';
  else if (conn.id === 'databricks') icon = '🧱';
  else if (conn.id === 'slack') icon = '💬';
  else if (conn.id === 'jira') icon = '🎫';
  iconEl.textContent = icon;

  const badge = document.getElementById('modal-test-badge');
  const payloadEl = document.getElementById('modal-test-payload');
  
  if (conn.status === 'Connected') {
    badge.className = 'status-badge success';
    badge.textContent = 'ACTIVE';
    payloadEl.innerHTML = formatJson({
      status: "success",
      authorized: true,
      connector_id: conn.id,
      identity: conn.authType === 'IAM Role' ? "arn:aws:iam::89104820:role/OpsMindIntegration" : "token_session_active",
      scopes: conn.scopes,
      handshake_latency: "24ms",
      checked_at: new Date().toISOString()
    });
  } else {
    badge.className = 'status-badge danger';
    badge.textContent = 'EXPIRED';
    payloadEl.innerHTML = formatJson({
      status: "unauthorized",
      authorized: false,
      connector_id: conn.id,
      error_code: "EXPIRED_TOKEN",
      message: "Session token signature expired. Re-authorization handshake required.",
      checked_at: new Date().toISOString()
    });
  }

  const modal = document.getElementById('sec-test-token-modal');
  if (modal) modal.classList.add('active');
}

function closeTestTokenModal() {
  const modal = document.getElementById('sec-test-token-modal');
  if (modal) modal.classList.remove('active');
}

function formatJson(obj) {
  return `<pre style="margin: 0; padding: 0; background: transparent; border: none; color: inherit; font-size:11px;"><code>${JSON.stringify(obj, null, 2)}</code></pre>`;
}

// 8. INTERACTIVE SCANNERS COMPLIANCE SCAN
function runComplianceScan() {
  const btn = document.getElementById('btn-run-sec-scan');
  btn.disabled = true;
  btn.textContent = 'Scanning...';

  const logsEl = document.getElementById('sec-scan-logs');
  logsEl.innerHTML = '';

  const addLogLine = (message, type = 'info') => {
    const line = document.createElement('div');
    line.style.marginBottom = '4px';
    if (type === 'success') line.style.color = 'var(--color-success)';
    else if (type === 'error') line.style.color = 'var(--color-error)';
    else if (type === 'warn') line.style.color = 'var(--color-warning)';
    else line.style.color = '#38bdf8';
    line.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
    logsEl.appendChild(line);
    logsEl.scrollTop = logsEl.scrollHeight;
  };

  const connectors = db.getConnectors() || [];
  const control = db.getControl() || { whitelistIPs: [] };
  const expiredCount = connectors.filter(c => c.status === 'Needs Auth').length;

  const steps = [
    { msg: 'SEC: Initializing automated compliance scanner v2.1...', delay: 300 },
    { msg: 'SEC: Scanning files directory hierarchies for access permissions...', delay: 400 },
    { msg: 'SEC: CHECK-1: Least-privilege bound enforcements checking...', delay: 400 },
    { msg: 'SEC: CHECK-1 PASSED: Sandbox workspace isolated from main directories.', type: 'success', delay: 300 },
    { msg: 'SEC: CHECK-2: Firewall IP Whitelist rules check...', delay: 500 },
    { msg: `SEC: CHECK-2 PASSED: ${control.whitelistIPs.length} whitelist rules active in sandbox gateway.`, type: 'success', delay: 400 },
    { msg: 'SEC: CHECK-3: Snowflake S3 Buckets encryption properties audit...', delay: 600 },
    { msg: 'SEC: CHECK-3 PASSED: AWS S3 staging buckets SSE-S3 encrypted (Verified via AWS Stage Setup Guide).', type: 'success', delay: 300 },
    { msg: 'SEC: CHECK-4: Session Access Tokens integrity bounds audit...', delay: 500 }
  ];

  if (expiredCount > 0) {
    steps.push(
      { msg: `SEC: CHECK-4 WARNING: ${expiredCount} expired connector token(s) identified in session database.`, type: 'warn', delay: 400 },
      { msg: 'SEC: Auditing signature keys rotation frequency...', delay: 500 },
      { msg: 'SEC: CHECK-5 WARNING: Cryptographic keys rotation has not been run in 45 days.', type: 'warn', delay: 400 },
      { msg: 'SEC: Audit complete: 0 Critical Failures, 2 Warnings identified. Security Score: 85%.', type: 'warn', delay: 500 }
    );
  } else {
    steps.push(
      { msg: 'SEC: CHECK-4 PASSED: All active integration token sessions are valid.', type: 'success', delay: 400 },
      { msg: 'SEC: Auditing signature keys rotation frequency...', delay: 500 },
      { msg: 'SEC: CHECK-5 WARNING: Cryptographic keys rotation has not been run in 45 days.', type: 'warn', delay: 400 },
      { msg: 'SEC: Audit complete: 0 Critical Failures, 1 Warning identified. Security Score: 98%.', type: 'success', delay: 500 }
    );
  }

  let index = 0;
  function runStep() {
    if (index < steps.length) {
      const step = steps[index];
      addLogLine(step.msg, step.type || 'info');
      index++;
      setTimeout(runStep, step.delay);
    } else {
      btn.disabled = false;
      btn.textContent = '🚀 Run Compliance Scan';
      showToast('Compliance audit scan completed successfully.', 'success');
      
      // Update rules visual layout status dynamically
      const keyRotationBadge = document.getElementById('rule-key-rotation-badge');
      if (keyRotationBadge) {
        keyRotationBadge.className = 'sec-rule-badge warning';
        keyRotationBadge.textContent = 'WARNING';
      }
      
      // Highlight scan completion results on index dial if needed
      loadSecurityDashboard();
    }
  }

  runStep();
}
