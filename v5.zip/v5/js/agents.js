// OpsMind Agents Management Logic

let activeFilterStatus = 'all';
let activeSearchQuery = '';
let activeAgentId = null;

// Initialize Page
document.addEventListener('DOMContentLoaded', () => {
  renderAgents();
  renderConnectorCheckboxes();
  setupSearch();
  updateKPIs();
});

// Calculate and Update telemetry summaries
function updateKPIs() {
  const agents = db.getAgents() || [];
  
  const activeCount = agents.filter(a => a.status === 'Active').length;
  const totalRuns = agents.reduce((sum, a) => sum + (a.runsCount || 0), 0);
  
  // Calculate average success rate
  let successSum = 0;
  let successCount = 0;
  agents.forEach(a => {
    if (a.successRate) {
      const val = parseFloat(a.successRate.replace('%', ''));
      if (!isNaN(val)) {
        successSum += val;
        successCount++;
      }
    }
  });
  const avgSuccess = successCount > 0 ? (successSum / successCount).toFixed(1) : '100.0';

  const kpiActive = document.getElementById('kpi-active-agents');
  const kpiSuccess = document.getElementById('kpi-success-rate');
  const kpiRuns = document.getElementById('kpi-total-runs');

  if (kpiActive) kpiActive.textContent = activeCount;
  if (kpiSuccess) kpiSuccess.textContent = `${avgSuccess}%`;
  if (kpiRuns) kpiRuns.textContent = totalRuns.toLocaleString();
}

// Render dynamic checkboxes for connectors inside modal
function renderConnectorCheckboxes() {
  const grid = document.getElementById('agent-form-connectors-grid');
  if (!grid) return;
  
  const connectors = db.getConnectors() || [];
  
  if (connectors.length === 0) {
    grid.innerHTML = `<span style="font-size:11px; color:var(--color-text-muted);">No integration connectors configured.</span>`;
    return;
  }

  grid.innerHTML = connectors.map(conn => `
    <label class="sys-checkbox-pill" style="display:flex; align-items:center; gap:6px; cursor:pointer; margin-bottom:4px;">
      <input type="checkbox" name="agent-form-connectors" value="${conn.id}" style="accent-color:var(--color-primary);">
      <span>${conn.name}</span>
    </label>
  `).join('');
}

// Binds search query to filter agents in real time
function setupSearch() {
  const searchBar = document.getElementById('agents-search-bar');
  if (searchBar) {
    searchBar.addEventListener('input', (e) => {
      activeSearchQuery = e.target.value.toLowerCase().trim();
      renderAgents();
    });
  }
}

// Render Agent lists based on active filters and search queries
function renderAgents() {
  const container = document.getElementById('agents-cards-container');
  if (!container) return;

  const agents = db.getAgents() || [];
  
  // Filter list
  const filtered = agents.filter(agent => {
    // Status Filter
    if (activeFilterStatus !== 'all' && agent.status !== activeFilterStatus) {
      return false;
    }
    // Search Query Filter
    if (activeSearchQuery) {
      const matchName = agent.name.toLowerCase().includes(activeSearchQuery);
      const matchRole = agent.role.toLowerCase().includes(activeSearchQuery);
      const matchModel = agent.model.toLowerCase().includes(activeSearchQuery);
      if (!matchName && !matchRole && !matchModel) {
        return false;
      }
    }
    return true;
  });

  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; text-align:center; padding:48px; background:var(--bg-card); border-radius:var(--border-radius); border:var(--glass-border); box-shadow:var(--shadow-md);">
        <span style="font-size:40px; display:block; margin-bottom:16px;">🔍</span>
        <h4 style="font-family:'Space Grotesk', sans-serif; font-size:16px; margin-bottom:8px;">No Agents Found</h4>
        <p style="color:var(--color-text-muted); font-size:13px; max-width:400px; margin:0 auto;">No AI agent models match the selected query. Create a custom agent or reset the active filter tags.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(agent => {
    // Status color
    let statusClass = 'success';
    if (agent.status === 'Idle') statusClass = 'info';
    if (agent.status === 'Maintenance') statusClass = 'warning';

    // Model gradient styling
    let modelBg = 'linear-gradient(135deg, #a855f7, #6366f1)';
    if (agent.model.includes('Gemini 1.5 Pro')) {
      modelBg = 'linear-gradient(135deg, #1e3a8a, #3b82f6)';
    } else if (agent.model.includes('Gemini 3.5 Flash')) {
      modelBg = 'linear-gradient(135deg, #0ea5e9, #10b981)';
    } else if (agent.model.includes('Claude')) {
      modelBg = 'linear-gradient(135deg, #f97316, #ea580c)';
    }

    // Connected labels
    const connectorsHtml = (agent.connectors || []).map(connId => {
      const details = (db.getConnectors() || []).find(c => c.id === connId);
      const name = details ? details.name : connId;
      return `<span style="font-size:10px; background:rgba(255,255,255,0.06); padding:2px 8px; border-radius:4px; border:1px solid var(--color-border); text-transform:uppercase;">${name}</span>`;
    }).join(' ');

    const checkedState = agent.status === 'Active' ? 'checked' : '';

    return `
      <div class="card" style="display:flex; flex-direction:column; gap:16px;">
        <div style="display:flex; justify-content:space-between; align-items:flex-start;">
          <div style="display:flex; align-items:center; gap:12px;">
            <div class="avatar" style="width:40px; height:40px; font-size:16px; background:${modelBg}; border-radius:10px;">🤖</div>
            <div>
              <h3 style="font-family:'Space Grotesk', sans-serif; font-size:15px; font-weight:700; color:var(--color-text-dark);">${agent.name}</h3>
              <span class="status-badge ${statusClass}" style="font-size:8px; padding:1px 6px; border-radius:4px; text-transform:uppercase; margin-top:2px;">${agent.status}</span>
            </div>
          </div>
          
          <!-- Switch Toggle Button -->
          <label style="position:relative; display:inline-block; width:36px; height:20px; cursor:pointer; user-select:none;">
            <input type="checkbox" ${checkedState} style="opacity:0; width:0; height:0;" onchange="toggleAgentActive('${agent.id}', this.checked)">
            <span style="position:absolute; cursor:pointer; top:0; left:0; right:0; bottom:0; background-color:#e2e8f0; transition:0.3s; border-radius:34px; box-shadow:inset 0 1px 3px rgba(0,0,0,0.1);" class="toggle-slider"></span>
          </label>
        </div>

        <p style="color:var(--color-text-muted); font-size:12px; line-height:1.5; flex:1;">${agent.role}</p>

        <!-- Stats summary row -->
        <div style="display:grid; grid-template-columns: repeat(3, 1fr); gap:8px; background:rgba(0,0,0,0.01); border:1px solid var(--color-border); border-radius:var(--border-radius-sm); padding:10px; text-align:center; font-size:11px;">
          <div>
            <span style="color:var(--color-text-muted); font-size:9px; text-transform:uppercase; display:block;">Runs</span>
            <strong style="font-family:'Space Grotesk', sans-serif; color:var(--color-text-dark); margin-top:2px; display:block;">${agent.runsCount || 0}</strong>
          </div>
          <div>
            <span style="color:var(--color-text-muted); font-size:9px; text-transform:uppercase; display:block;">Success</span>
            <strong style="color:var(--color-success); margin-top:2px; display:block;">${agent.successRate || '100%'}</strong>
          </div>
          <div>
            <span style="color:var(--color-text-muted); font-size:9px; text-transform:uppercase; display:block;">Latency</span>
            <strong style="color:var(--color-secondary); margin-top:2px; display:block;">${agent.avgLatency || '0s'}</strong>
          </div>
        </div>

        <div style="font-size:11px; display:flex; flex-direction:column; gap:6px; border-top:1px solid var(--color-border); padding-top:12px;">
          <div style="display:flex; justify-content:space-between;">
            <span style="color:var(--color-text-muted);">Model:</span>
            <span style="font-weight:600; color:var(--color-text-dark);">${agent.model}</span>
          </div>
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:4px; margin-top:2px;">
            <span style="color:var(--color-text-muted);">Security Scopes:</span>
            <div style="display:flex; gap:4px; flex-wrap:wrap;">
              ${agent.connectors && agent.connectors.length > 0 ? connectorsHtml : '<span style="color:var(--color-text-muted); font-style:italic;">None linked</span>'}
            </div>
          </div>
        </div>

        <div style="margin-top:auto; padding-top:4px; display:flex; gap:8px;">
          <button class="btn btn-secondary btn-sm" style="flex:1;" onclick="openAgentDrawer('${agent.id}')">View Audit Logs</button>
        </div>
      </div>
    `;
  }).join('');
  
  // Apply toggle slider CSS animations dynamically
  const styleEl = document.getElementById('dynamic-toggle-style') || document.createElement('style');
  styleEl.id = 'dynamic-toggle-style';
  styleEl.innerHTML = `
    input:checked + .toggle-slider {
      background-color: var(--color-primary) !important;
    }
    input:checked + .toggle-slider:before {
      transform: translateX(16px) !important;
    }
    .toggle-slider:before {
      position: absolute;
      content: "";
      height: 14px;
      width: 14px;
      left: 3px;
      bottom: 3px;
      background-color: white;
      transition: 0.3s;
      border-radius: 50%;
      box-shadow: 0 1px 3px rgba(0,0,0,0.25);
    }
  `;
  document.head.appendChild(styleEl);
}

// Inline toggle event handler
function toggleAgentActive(agentId, checked) {
  const agents = db.getAgents() || [];
  const idx = agents.findIndex(a => a.id === agentId);
  if (idx !== -1) {
    const nextStatus = checked ? 'Active' : 'Idle';
    agents[idx].status = nextStatus;
    db.saveAgents(agents);
    showToast(`Agent "${agents[idx].name}" set to ${nextStatus}`, checked ? 'success' : 'info');
    updateKPIs();
    renderAgents();
  }
}

// Status tag filter handler
function filterAgentStatus(status, btn) {
  activeFilterStatus = status;
  
  // Set tab active styling
  const buttons = document.querySelectorAll('.btn-filter');
  buttons.forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  renderAgents();
}

// Modal open/close actions
function openCreateAgentModal() {
  const modal = document.getElementById('create-agent-modal');
  if (modal) {
    document.getElementById('agent-form-name').value = '';
    document.getElementById('agent-form-role').value = '';
    document.getElementById('agent-form-model').value = 'Gemini 1.5 Pro';
    
    // Clear check boxes
    document.querySelectorAll('input[name="agent-form-connectors"]').forEach(cb => cb.checked = false);
    
    modal.classList.add('active');
  }
}

function closeCreateAgentModal() {
  const modal = document.getElementById('create-agent-modal');
  if (modal) modal.classList.remove('active');
}

// Submit custom agent creation payload
function submitCreateAgent() {
  const name = document.getElementById('agent-form-name').value.trim();
  const role = document.getElementById('agent-form-role').value.trim();
  const model = document.getElementById('agent-form-model').value;
  const connectors = Array.from(document.querySelectorAll('input[name="agent-form-connectors"]:checked')).map(cb => cb.value);

  if (!name) {
    showToast('Please enter an Agent Name.', 'warning');
    return;
  }
  if (!role) {
    showToast('Please define the Agent objective prompt.', 'warning');
    return;
  }

  const newAgent = {
    id: `agent_${Date.now()}`,
    name: name,
    role: role,
    model: model,
    connectors: connectors,
    status: 'Active',
    runsCount: 0,
    successRate: '100%',
    avgLatency: '0.0s'
  };

  db.addAgent(newAgent);
  closeCreateAgentModal();
  updateKPIs();
  renderAgents();
  showToast(`Agent "${name}" provisioned successfully!`, 'success');
}

// Sliding Drawer actions
function openAgentDrawer(agentId) {
  const drawer = document.getElementById('agent-details-drawer');
  if (!drawer) return;

  activeAgentId = agentId;
  const agent = db.getAgents().find(a => a.id === agentId);
  if (!agent) return;

  document.getElementById('drawer-agent-name').textContent = agent.name;
  document.getElementById('drawer-agent-model').textContent = agent.model;
  document.getElementById('drawer-agent-runs').textContent = agent.runsCount || 0;
  document.getElementById('drawer-agent-success').textContent = agent.successRate || '100%';
  document.getElementById('drawer-agent-latency').textContent = agent.avgLatency || '0s';
  document.getElementById('drawer-agent-role').textContent = agent.role;

  // Render associated connectors icons
  const conContainer = document.getElementById('drawer-agent-connectors');
  if (conContainer) {
    if (agent.connectors && agent.connectors.length > 0) {
      conContainer.innerHTML = agent.connectors.map(cId => {
        const cDetails = db.getConnectors().find(c => c.id === cId);
        const name = cDetails ? cDetails.name : cId;
        return `<span style="font-size:11px; background:rgba(79, 99, 246, 0.1); color:var(--color-primary); border:1px solid rgba(79, 99, 246, 0.2); border-radius:4px; padding:4px 10px; font-weight:600;">🔗 ${name}</span>`;
      }).join('');
    } else {
      conContainer.innerHTML = `<span style="font-size:12px; color:var(--color-text-muted); font-style:italic;">No infrastructure integrations mapped.</span>`;
    }
  }

  // Pre-load default idle stdout logs
  const logBox = document.getElementById('drawer-agent-logs');
  if (logBox) {
    logBox.innerHTML = `
<span style="color:#6b7280;">[SYSTEM] TELEMETRY INITIALIZED • IDLE</span>
<span style="color:#6b7280;">[SYSTEM] Waiting for orchestration pipeline runs...</span>
    `;
  }

  drawer.classList.add('active');
}

function closeAgentDrawer() {
  const drawer = document.getElementById('agent-details-drawer');
  if (drawer) drawer.classList.remove('active');
}

// Mocks runtime diagnostics check output stream in drawer
function testAgentHandshake() {
  const btn = document.getElementById('drawer-agent-test-btn');
  const logBox = document.getElementById('drawer-agent-logs');
  if (!btn || !logBox || !activeAgentId) return;

  btn.textContent = 'Auditing...';
  btn.disabled = true;

  const agent = db.getAgents().find(a => a.id === activeAgentId);
  const connectors = agent.connectors || [];

  logBox.innerHTML = `<span style="color:#38bdf8;">[INIT] Initializing handshake diagnostics for ${agent.name}...</span>`;
  logBox.scrollTop = logBox.scrollHeight;

  setTimeout(() => {
    logBox.innerHTML += `<br><span style="color:#38bdf8;">[LLM] Connecting to Provider endpoint: target=${agent.model}</span>`;
    logBox.scrollTop = logBox.scrollHeight;

    setTimeout(() => {
      logBox.innerHTML += `<br><span style="color:#10b981;">[LLM] Model connection handshake success. status=200</span>`;
      logBox.scrollTop = logBox.scrollHeight;

      if (connectors.length > 0) {
        logBox.innerHTML += `<br><span style="color:#38bdf8;">[INTEGRATIONS] Found ${connectors.length} associated integration scopes. Validating...</span>`;
        logBox.scrollTop = logBox.scrollHeight;

        let index = 0;
        function testNextConnector() {
          if (index < connectors.length) {
            const connId = connectors[index];
            const conn = db.getConnectors().find(c => c.id === connId);
            const name = conn ? conn.name : connId;
            const status = conn ? conn.status : 'Disconnected';
            
            setTimeout(() => {
              if (status === 'Connected') {
                logBox.innerHTML += `<br><span style="color:#10b981;">[INTEGRATIONS] ✓ Link checked: name=${name} state=CONNECTED authType=${conn.authType}</span>`;
              } else {
                logBox.innerHTML += `<br><span style="color:#ef4444;">[INTEGRATIONS] ✗ Link error: name=${name} state=${status.toUpperCase()} permission_block</span>`;
              }
              logBox.scrollTop = logBox.scrollHeight;
              index++;
              testNextConnector();
            }, 600);
          } else {
            finishHandshake();
          }
        }
        testNextConnector();
      } else {
        setTimeout(() => {
          logBox.innerHTML += `<br><span style="color:#eab308;">[INTEGRATIONS] Warning: No active infrastructure nodes connected. Running in sandbox.</span>`;
          logBox.scrollTop = logBox.scrollHeight;
          finishHandshake();
        }, 800);
      }
    }, 600);
  }, 600);

  function finishHandshake() {
    setTimeout(() => {
      const isHealthy = connectors.every(cId => {
        const c = db.getConnectors().find(conn => conn.id === cId);
        return c && c.status === 'Connected';
      });

      if (isHealthy) {
        logBox.innerHTML += `<br><br><span style="color:#10b981; font-weight:700;">[STATUS] AUDIT COMPLETED. AGENT STATE HEALTHY ✓</span>`;
        showToast('Agent handshake diagnostics passed.', 'success');
      } else {
        logBox.innerHTML += `<br><br><span style="color:#ef4444; font-weight:700;">[STATUS] AUDIT FAILED. UNRESOLVED SECURITY LINK DEVIATIONS ✗</span>`;
        showToast('Agent diagnostics found errors. Re-verify connectors.', 'error');
      }
      logBox.scrollTop = logBox.scrollHeight;

      btn.textContent = 'Test Handshake';
      btn.disabled = false;
    }, 800);
  }
}
