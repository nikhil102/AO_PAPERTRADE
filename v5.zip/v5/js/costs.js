// OpsMind Cost & Usage Page Controller

const DEFAULT_RECOMMENDATIONS = [
  { id: 'rec-1', title: 'Purge stale GCP Staging tables', description: 'Removes unused staging BigQuery tables inactive for > 14 days.', savings: 15.50, provider: 'gcp', status: 'PENDING' },
  { id: 'rec-2', title: 'Delete unused AWS EBS volumes', description: 'Cleans up unattached root and data block store volumes.', savings: 45.00, provider: 'aws', status: 'PENDING' },
  { id: 'rec-3', title: 'Resize idle Databricks clusters', description: 'Reconfigures cluster sizing policies for inactive development workers.', savings: 120.00, provider: 'databricks', status: 'PENDING' }
];

document.addEventListener('DOMContentLoaded', () => {
  initCostsDashboard();
  setupSettingsForm();
  setupRunsSearch();
});

// Load Recommendations from Storage
function getRecommendations() {
  if (!localStorage.getItem('opsmind_recommendations')) {
    localStorage.setItem('opsmind_recommendations', JSON.stringify(DEFAULT_RECOMMENDATIONS));
  }
  return JSON.parse(localStorage.getItem('opsmind_recommendations'));
}

// Save Recommendations to Storage
function saveRecommendations(data) {
  localStorage.setItem('opsmind_recommendations', JSON.stringify(data));
}

// Initialize and render Dashboard metrics
function initCostsDashboard() {
  const budget = db.getBudget() || { limitCap: 5000, spentCloud: 4514.80, alertThreshold: 90 };
  const runs = db.getRuns() || [];
  
  // Calculate Cumulative Runs cost
  const runsSum = runs.reduce((acc, run) => {
    const val = parseFloat(run.cost.replace('$', ''));
    return acc + (isNaN(val) ? 0 : val);
  }, 0);
  
  const totalSpent = budget.spentCloud + runsSum;
  const percentage = (totalSpent / budget.limitCap) * 100;
  const remainingTokensBudget = budget.limitCap - totalSpent;
  
  // Update KPI displays
  const kpiBudgetSpent = document.getElementById('kpi-budget-spent');
  const kpiBudgetPercentage = document.getElementById('kpi-budget-percentage');
  const kpiBudgetLimit = document.getElementById('kpi-budget-limit');
  const kpiBudgetProgress = document.getElementById('kpi-budget-progress');
  const kpiAiTokens = document.getElementById('kpi-ai-tokens');
  const kpiRunsCost = document.getElementById('kpi-runs-cost');
  
  if (kpiBudgetSpent) {
    kpiBudgetSpent.textContent = `$${totalSpent.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }
  if (kpiBudgetPercentage) {
    kpiBudgetPercentage.textContent = `${percentage.toFixed(2)}%`;
  }
  if (kpiBudgetLimit) {
    kpiBudgetLimit.textContent = `of $${budget.limitCap.toLocaleString(undefined, { minimumFractionDigits: 2 })} Limit`;
  }
  if (kpiBudgetProgress) {
    kpiBudgetProgress.style.width = `${Math.min(percentage, 100)}%`;
    // Add color adjustments on warning limits
    if (percentage >= budget.alertThreshold) {
      kpiBudgetProgress.style.background = 'linear-gradient(90deg, var(--color-error), #f43f5e)';
    } else {
      kpiBudgetProgress.style.background = 'linear-gradient(90deg, var(--color-primary), var(--color-secondary))';
    }
  }
  if (kpiAiTokens) {
    kpiAiTokens.textContent = `$${Math.max(remainingTokensBudget, 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }
  if (kpiRunsCost) {
    kpiRunsCost.textContent = `$${runsSum.toFixed(2)}`;
  }
  
  // Warning Banner status update
  const warningBanner = document.getElementById('threshold-warning-banner');
  const warningText = document.getElementById('threshold-warning-text');
  
  if (warningBanner) {
    if (percentage >= budget.alertThreshold) {
      warningBanner.style.display = 'flex';
      if (warningText) {
        warningText.textContent = `Monthly expenditures of $${totalSpent.toFixed(2)} (${percentage.toFixed(2)}%) have exceeded the warning threshold of ${budget.alertThreshold}% of the configured $${budget.limitCap.toLocaleString()} budget cap.`;
      }
    } else {
      warningBanner.style.display = 'none';
    }
  }
  
  // Set values on form fields on initial page load
  const limitInput = document.getElementById('input-limit-cap');
  const thresholdInput = document.getElementById('input-alert-threshold');
  if (limitInput && !limitInput.dataset.initialized) {
    limitInput.value = budget.limitCap;
    limitInput.dataset.initialized = 'true';
  }
  if (thresholdInput && !thresholdInput.dataset.initialized) {
    thresholdInput.value = budget.alertThreshold;
    thresholdInput.dataset.initialized = 'true';
  }
  
  // Render sub-components
  renderRecommendations();
  renderRunsTable();
  
  // Sync sidebar badges
  if (typeof updateSidebarBadges === 'function') {
    updateSidebarBadges();
  }
}

// Setup Form Handlers
function setupSettingsForm() {
  const budgetForm = document.getElementById('budget-settings-form');
  if (!budgetForm) return;
  
  budgetForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const limitCap = parseFloat(document.getElementById('input-limit-cap').value);
    const alertThreshold = parseFloat(document.getElementById('input-alert-threshold').value);
    
    if (isNaN(limitCap) || limitCap <= 0) {
      showToast('Please enter a valid budget limit.', 'error');
      return;
    }
    if (isNaN(alertThreshold) || alertThreshold < 50 || alertThreshold > 100) {
      showToast('Please enter a valid alert threshold between 50% and 100%.', 'error');
      return;
    }
    
    const budget = db.getBudget() || { limitCap: 5000, spentCloud: 4514.80, alertThreshold: 90 };
    budget.limitCap = limitCap;
    budget.alertThreshold = alertThreshold;
    
    db.saveBudget(budget);
    showToast('Budget parameters updated successfully.', 'success');
    
    // Refresh calculations
    initCostsDashboard();
  });
}

// Search input handling
function setupRunsSearch() {
  const searchInput = document.getElementById('costs-search-runs');
  if (!searchInput) return;
  
  searchInput.addEventListener('input', (e) => {
    renderRunsTable(e.target.value);
  });
}

// Render execution runs costs breakdown table
function renderRunsTable(searchQuery = '') {
  const tbody = document.getElementById('costs-runs-table-tbody');
  if (!tbody) return;
  
  const runs = db.getRuns() || [];
  tbody.innerHTML = '';
  
  const query = searchQuery.toLowerCase().trim();
  const filtered = runs.filter(run => {
    return run.id.toLowerCase().includes(query) || run.name.toLowerCase().includes(query);
  });
  
  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:var(--color-text-muted); padding:24px; font-size:12px;">No matching execution runs found.</td></tr>`;
    return;
  }
  
  filtered.forEach(run => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><span style="font-family:monospace; font-weight:700; color:var(--color-primary);">${run.id}</span></td>
      <td style="font-weight:500;">${run.name}</td>
      <td style="color:var(--color-text-muted); font-size:12px;">${run.triggeredBy}</td>
      <td style="font-size:12px;">${run.duration}</td>
      <td style="text-align:right; font-weight:600; color:var(--color-text-dark);">${run.cost}</td>
    `;
    tbody.appendChild(tr);
  });
}

// Render checklist recommendations
function renderRecommendations() {
  const container = document.getElementById('recommendations-container');
  if (!container) return;
  
  const recs = getRecommendations();
  container.innerHTML = '';
  
  let pendingCount = 0;
  let pendingSavings = 0;
  
  recs.forEach(rec => {
    const isApplied = rec.status === 'APPLIED';
    if (!isApplied) {
      pendingCount++;
      pendingSavings += rec.savings;
    }
    
    const card = document.createElement('div');
    card.className = 'costs-rec-card';
    card.innerHTML = `
      <div class="costs-rec-info">
        <span class="costs-rec-title">${rec.title}</span>
        <span class="costs-rec-desc">${rec.description}</span>
        <span class="costs-rec-saving">💰 Est. Savings: $${rec.savings.toFixed(2)}</span>
      </div>
      <div class="costs-rec-action">
        ${isApplied 
          ? `<span class="costs-rec-status applied">Applied</span>` 
          : `<span class="costs-rec-status pending">Pending</span>
             <button class="btn btn-primary" style="padding: 6px 12px; font-size: 11px; font-weight:600; white-space:nowrap;" onclick="applyRecommendation('${rec.id}')">Apply</button>`
        }
      </div>
    `;
    container.appendChild(card);
  });
  
  // Update recommendations KPI indicators
  const kpiSavingOpportunities = document.getElementById('kpi-saving-opportunities');
  const kpiPotentialSavings = document.getElementById('kpi-potential-savings');
  
  if (kpiSavingOpportunities) {
    kpiSavingOpportunities.textContent = `${pendingCount} Option${pendingCount !== 1 ? 's' : ''}`;
  }
  if (kpiPotentialSavings) {
    kpiPotentialSavings.textContent = pendingCount > 0 ? `$${pendingSavings.toFixed(2)} Potential` : 'Optimized';
    if (pendingCount === 0) {
      kpiPotentialSavings.className = 'costs-rec-status applied';
      kpiPotentialSavings.style.fontSize = '11px';
    } else {
      kpiPotentialSavings.className = '';
      kpiPotentialSavings.style.fontSize = '11px';
      kpiPotentialSavings.style.color = 'var(--color-success)';
      kpiPotentialSavings.style.fontWeight = '600';
    }
  }
}

// Action to execute recommendation optimization
window.applyRecommendation = function(id) {
  const recs = getRecommendations();
  const rec = recs.find(r => r.id === id);
  if (!rec) return;
  
  rec.status = 'APPLIED';
  saveRecommendations(recs);
  
  // Register corresponding Audit success run inside runs history database
  const now = new Date();
  const dateStr = now.getFullYear() + '-' + 
    String(now.getMonth() + 1).padStart(2, '0') + '-' + 
    String(now.getDate()).padStart(2, '0') + ' ' + 
    String(now.getHours()).padStart(2, '0') + ':' + 
    String(now.getMinutes()).padStart(2, '0');
    
  const newRun = {
    id: `RUN-${Math.floor(4821 + Math.random() * 1000)}`,
    name: `Cost Audit: Applied "${rec.title}"`,
    date: dateStr,
    duration: '1m 15s',
    cost: '$0.00', // Operations execution itself has zero cost
    status: 'success',
    triggeredBy: 'System (Governance)'
  };
  
  db.addRun(newRun);
  
  showToast(`Applied optimization recommendation: "${rec.title}"`, 'success');
  
  // Refresh layout
  initCostsDashboard();
};
