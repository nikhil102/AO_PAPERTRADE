// Core JavaScript Actions for ADLC Web Platform
document.addEventListener('DOMContentLoaded', () => {
  setupSidebar();
  setupActiveMenuItem();
  setupTheme();
  
  // Page-specific initialization checks
  const pathname = window.location.pathname;
  if (pathname.includes('editor.html')) {
    initEditorPage();
  } else if (pathname.includes('database.html')) {
    initDatabasePage();
  } else if (pathname.includes('secrets.html')) {
    initSecretsPage();
  } else if (pathname.includes('templates.html')) {
    initTemplatesPage();
  } else if (pathname.includes('packages.html')) {
    initPackagesPage();
  } else if (pathname.includes('git.html')) {
    initGitPage();
  } else if (pathname.includes('deployments.html')) {
    initDeploymentsPage();
  } else if (pathname.includes('bounties.html')) {
    initBountiesPage();
  } else if (pathname.includes('settings.html')) {
    initSettingsPage();
  } else if (pathname.includes('login.html') || pathname.includes('signup.html')) {
    initAuthPage();
  }
});

// 1. Persistent Sidebar Controller
function setupSidebar() {
  const sidebar = document.querySelector('.sidebar');
  const toggleBtn = document.querySelector('.sidebar-toggle-btn');
  
  if (!sidebar) return;
  
  // Read state from localStorage
  const isCollapsed = localStorage.getItem('sidebar-collapsed') === 'true';
  if (isCollapsed) {
    sidebar.classList.add('collapsed');
  }
  
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
      localStorage.setItem('sidebar-collapsed', sidebar.classList.contains('collapsed'));
    });
  }
}

// 2. Active Sidebar Item Highlight
function setupActiveMenuItem() {
  const pathname = window.location.pathname;
  const menuItems = document.querySelectorAll('.menu-item');
  menuItems.forEach(item => {
    const href = item.getAttribute('onclick') || '';
    const pageName = href.replace("location.href='", "").replace("'", "");
    if (pageName && pathname.endsWith(pageName)) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  });
}

// 2b. Persistent Theme Controller
function setupTheme() {
  // Migrate old users once to default to light mode
  if (!localStorage.getItem('adlc-migrated-theme-v2')) {
    localStorage.setItem('adlc-theme', 'light-glass');
    localStorage.setItem('adlc-migrated-theme-v2', 'true');
  }
  const activeTheme = localStorage.getItem('adlc-theme') || 'light-glass';
  applyTheme(activeTheme);
}

function applyTheme(theme) {
  if (theme === 'dark-neon') {
    document.body.classList.add('dark-theme');
  } else {
    document.body.classList.remove('dark-theme');
  }
  localStorage.setItem('adlc-theme', theme);
}

// 3. Editor Workspace Simulator (editor.html)
let currentOpenFile = 'index.html';
function initEditorPage() {
  const codeDisplay = document.getElementById('code-display');
  const lineNumbers = document.getElementById('line-numbers');
  const fileNodes = document.querySelectorAll('.file-tree .tree-node');
  const tabContainer = document.querySelector('.editor-tabs');
  const runBtn = document.getElementById('run-code-btn');
  const terminalBody = document.getElementById('terminal-logs');
  const termInput = document.getElementById('term-input');
  
  // Set initial file contents
  if (codeDisplay) {
    codeDisplay.value = ADLC_DATA.files[currentOpenFile] || '';
    updateLineNumbers(codeDisplay.value);
    
    codeDisplay.addEventListener('input', (e) => {
      ADLC_DATA.files[currentOpenFile] = e.target.value;
      updateLineNumbers(e.target.value);
    });
  }
  
  // File Node Click Handlers
  fileNodes.forEach(node => {
    node.addEventListener('click', () => {
      const fileName = node.dataset.file;
      if (fileName) {
        fileNodes.forEach(n => n.classList.remove('active'));
        node.classList.add('active');
        switchFile(fileName);
      }
    });
  });
  
  // Run Code logic
  if (runBtn) {
    runBtn.addEventListener('click', () => {
      runCurrentFile();
    });
  }
  
  // Interactive Terminal console
  if (termInput) {
    termInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const cmd = termInput.value.trim();
        termInput.value = '';
        if (cmd) {
          executeTerminalCmd(cmd);
        }
      }
    });
  }
  
  // AI Chat Bot inside editor
  const chatSendBtn = document.getElementById('chat-send-btn');
  const chatInput = document.getElementById('chat-input');
  if (chatSendBtn && chatInput) {
    chatSendBtn.addEventListener('click', () => {
      sendChatMessage();
    });
    chatInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        sendChatMessage();
      }
    });
  }
}

function switchFile(fileName) {
  currentOpenFile = fileName;
  const codeDisplay = document.getElementById('code-display');
  const tabName = document.getElementById('active-tab-name');
  const tabIcon = document.getElementById('active-tab-icon');
  
  if (codeDisplay) {
    codeDisplay.value = ADLC_DATA.files[fileName] || '';
    updateLineNumbers(codeDisplay.value);
  }
  if (tabName) {
    tabName.textContent = fileName;
  }
  if (tabIcon) {
    tabIcon.className = 'lang-dot';
    if (fileName.endsWith('.html')) tabIcon.classList.add('lang-html');
    else if (fileName.endsWith('.py')) tabIcon.classList.add('lang-python');
    else if (fileName.endsWith('.css')) tabIcon.classList.add('lang-html');
    else if (fileName.endsWith('.js')) tabIcon.classList.add('lang-node');
  }
}

function updateLineNumbers(code) {
  const lineNumbers = document.getElementById('line-numbers');
  if (!lineNumbers) return;
  const lines = code.split('\n').length;
  let nums = '';
  for (let i = 1; i <= Math.max(lines, 1); i++) {
    nums += i + '\n';
  }
  lineNumbers.textContent = nums;
}

function runCurrentFile() {
  const termBody = document.getElementById('terminal-logs');
  if (!termBody) return;
  
  appendTerminalRow('⚡ Starting execution engine...', 'info');
  
  setTimeout(() => {
    if (currentOpenFile.endsWith('.py')) {
      appendTerminalRow('python main.py', 'cmd');
      appendTerminalRow('Initializing ADLC Agent compute task...', 'stdout');
      appendTerminalRow('Approximation: 3.1415926535', 'stdout');
      appendTerminalRow('Process finished with exit code 0', 'success');
    } else if (currentOpenFile.endsWith('.html') || currentOpenFile.endsWith('.js') || currentOpenFile.endsWith('.css')) {
      appendTerminalRow('npm start', 'cmd');
      appendTerminalRow('Creating instant sandboxed environment...', 'stdout');
      appendTerminalRow('Web application running successfully!', 'stdout');
      appendTerminalRow('Local preview server online: http://localhost:3000', 'cyan');
    } else {
      appendTerminalRow(`Running file: ${currentOpenFile}`, 'stdout');
      appendTerminalRow('Process terminated successfully.', 'success');
    }
  }, 600);
}

function appendTerminalRow(text, type = 'stdout') {
  const termBody = document.getElementById('terminal-logs');
  if (!termBody) return;
  
  const div = document.createElement('div');
  div.className = 'terminal-row';
  
  if (type === 'cmd') {
    div.innerHTML = `<span class="terminal-prompt">~/adlc-sandbox$</span> ${text}`;
  } else if (type === 'info') {
    div.style.color = 'var(--text-muted)';
    div.textContent = text;
  } else if (type === 'success') {
    div.style.color = 'var(--accent-green)';
    div.textContent = text;
  } else if (type === 'cyan') {
    div.style.color = 'var(--accent-cyan)';
    div.textContent = text;
  } else {
    div.textContent = text;
  }
  
  termBody.appendChild(div);
  termBody.scrollTop = termBody.scrollHeight;
}

function executeTerminalCmd(cmd) {
  appendTerminalRow(cmd, 'cmd');
  const lowerCmd = cmd.toLowerCase();
  
  if (lowerCmd === 'help') {
    appendTerminalRow('Available Commands:', 'info');
    appendTerminalRow('  help         - Display this manual', 'info');
    appendTerminalRow('  run          - Execute the currently open script', 'info');
    appendTerminalRow('  ls           - List files in current sandbox directory', 'info');
    appendTerminalRow('  git status   - View current staged repository branches', 'info');
    appendTerminalRow('  clear        - Clear console workspace', 'info');
  } else if (lowerCmd === 'clear') {
    const termBody = document.getElementById('terminal-logs');
    if (termBody) termBody.innerHTML = '';
  } else if (lowerCmd === 'run') {
    runCurrentFile();
  } else if (lowerCmd === 'ls') {
    Object.keys(ADLC_DATA.files).forEach(f => {
      appendTerminalRow(`  ${f}`, 'stdout');
    });
  } else if (lowerCmd === 'git status') {
    appendTerminalRow(`On branch ${ADLC_DATA.git.branch}`, 'stdout');
    appendTerminalRow('Your branch is up to date with \'origin/main\'.', 'stdout');
    appendTerminalRow('nothing to commit, working tree clean', 'success');
  } else {
    appendTerminalRow(`adlcsh: command not found: ${cmd}`, 'info');
  }
}

function sendChatMessage() {
  const chatInput = document.getElementById('chat-input');
  const chatBody = document.getElementById('chat-logs');
  if (!chatInput || !chatInput.value.trim() || !chatBody) return;
  
  const text = chatInput.value.trim();
  chatInput.value = '';
  
  // Append User message
  const userDiv = document.createElement('div');
  userDiv.className = 'chat-bubble user';
  userDiv.textContent = text;
  chatBody.appendChild(userDiv);
  chatBody.scrollTop = chatBody.scrollHeight;
  
  // Bot responses
  setTimeout(() => {
    const botDiv = document.createElement('div');
    botDiv.className = 'chat-bubble bot';
    botDiv.textContent = generateAgentAnswer(text);
    chatBody.appendChild(botDiv);
    chatBody.scrollTop = chatBody.scrollHeight;
  }, 800);
}

function generateAgentAnswer(question) {
  const q = question.toLowerCase();
  if (q.includes('help') || q.includes('hello') || q.includes('hi')) {
    return "Hi, I am your ADLC Agent. I can help write code, create database migrations, setup secrets, or run git commits. Try asking: 'how to start server?' or 'explain files'.";
  }
  if (q.includes('server') || q.includes('start') || q.includes('run')) {
    return "To run the application, click on the green 'Run' button at the top or type 'run' in the console below.";
  }
  if (q.includes('db') || q.includes('database')) {
    return "You can check the active storage key-values by selecting the 'Database' tab in your left navigation console.";
  }
  return "I understand your request. Let me analyze this for you. To implement this agentic cycle, you can modify the active file and hit 'Run' to compile.";
}

// 4. Database manager interactions (database.html)
function initDatabasePage() {
  const grid = document.getElementById('db-rows');
  const addBtn = document.getElementById('add-db-btn');
  const keyInput = document.getElementById('db-key');
  const valInput = document.getElementById('db-val');
  
  renderDatabaseRows();
  
  if (addBtn) {
    addBtn.addEventListener('click', () => {
      const key = keyInput.value.trim();
      const val = valInput.value.trim();
      if (key && val) {
        ADLC_DATA.database.push({ key, val });
        keyInput.value = '';
        valInput.value = '';
        renderDatabaseRows();
      }
    });
  }
}

function renderDatabaseRows() {
  const grid = document.getElementById('db-rows');
  if (!grid) return;
  
  grid.innerHTML = '';
  ADLC_DATA.database.forEach((item, index) => {
    const row = document.createElement('div');
    row.className = 'secret-row';
    row.innerHTML = `
      <div style="display:flex; flex-direction:column;">
        <span class="secret-name">${item.key}</span>
        <span class="secret-val" style="font-size:12px;">${item.val}</span>
      </div>
      <button class="btn btn-secondary" onclick="deleteDbRow(${index})" style="padding:4px 8px; font-size:12px; color:var(--accent-red);">Remove</button>
    `;
    grid.appendChild(row);
  });
}

window.deleteDbRow = function(index) {
  ADLC_DATA.database.splice(index, 1);
  renderDatabaseRows();
};

// 5. Secrets Manager (secrets.html)
function initSecretsPage() {
  const addBtn = document.getElementById('add-secret-btn');
  const keyInput = document.getElementById('sec-key');
  const valInput = document.getElementById('sec-val');
  
  renderSecretRows();
  
  if (addBtn) {
    addBtn.addEventListener('click', () => {
      const key = keyInput.value.trim();
      const val = valInput.value.trim();
      if (key && val) {
        ADLC_DATA.secrets.push({ key, val });
        keyInput.value = '';
        valInput.value = '';
        renderSecretRows();
      }
    });
  }
}

function renderSecretRows() {
  const grid = document.getElementById('secrets-grid');
  if (!grid) return;
  
  grid.innerHTML = '';
  ADLC_DATA.secrets.forEach((item, index) => {
    const row = document.createElement('div');
    row.className = 'secret-row';
    row.innerHTML = `
      <div>
        <span class="secret-name" style="margin-right:12px;">${item.key}</span>
        <span class="secret-val" id="sec-val-${index}" data-raw="${item.val}">•••••••••••••••••••••</span>
      </div>
      <div style="display:flex; gap:8px;">
        <button class="btn btn-secondary" onclick="toggleSecretVisible(${index})" style="padding:4px 8px; font-size:12px;">Show</button>
        <button class="btn btn-secondary" onclick="deleteSecretRow(${index})" style="padding:4px 8px; font-size:12px; color:var(--accent-red);">Delete</button>
      </div>
    `;
    grid.appendChild(row);
  });
}

window.toggleSecretVisible = function(index) {
  const valEl = document.getElementById(`sec-val-${index}`);
  const btn = valEl.parentElement.nextElementSibling.firstElementChild;
  
  if (valEl.textContent.includes('•')) {
    valEl.textContent = valEl.dataset.raw;
    btn.textContent = 'Hide';
  } else {
    valEl.textContent = '•••••••••••••••••••••';
    btn.textContent = 'Show';
  }
};

window.deleteSecretRow = function(index) {
  ADLC_DATA.secrets.splice(index, 1);
  renderSecretRows();
};

// 6. Templates Discovery Page Filters (templates.html)
function initTemplatesPage() {
  const searchInput = document.getElementById('template-search');
  const grid = document.getElementById('templates-grid');
  
  renderTemplates(ADLC_DATA.templates);
  
  if (searchInput && grid) {
    searchInput.addEventListener('input', (e) => {
      const q = e.target.value.toLowerCase();
      const filtered = ADLC_DATA.templates.filter(t => 
        t.name.toLowerCase().includes(q) || 
        t.desc.toLowerCase().includes(q) ||
        t.lang.toLowerCase().includes(q)
      );
      renderTemplates(filtered);
    });
  }
}

function renderTemplates(list) {
  const grid = document.getElementById('templates-grid');
  if (!grid) return;
  
  grid.innerHTML = '';
  if (list.length === 0) {
    grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding:40px; color:var(--text-muted);">No templates match your search parameters.</div>';
    return;
  }
  
  list.forEach(t => {
    const card = document.createElement('div');
    card.className = 'project-card';
    card.innerHTML = `
      <div class="project-meta">
        <div>
          <h4 class="project-title">${t.name}</h4>
          <span class="project-lang">
            <span class="lang-dot ${t.icon}"></span>${t.lang}
          </span>
        </div>
      </div>
      <p style="font-size:13px; color:var(--text-secondary); margin:12px 0; overflow:hidden; text-overflow:ellipsis; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical;">${t.desc}</p>
      <div class="project-footer">
        <span>Used by ${t.count} developers</span>
        <button class="btn btn-primary" onclick="location.href='editor.html'" style="padding:4px 10px; font-size:12px;">Fork Template</button>
      </div>
    `;
    grid.appendChild(card);
  });
}

// 7. Packages dependencies manager (packages.html)
function initPackagesPage() {
  const searchInput = document.getElementById('package-search');
  const listContainer = document.getElementById('packages-list');
  
  renderPackages(ADLC_DATA.packages);
  
  if (searchInput && listContainer) {
    searchInput.addEventListener('input', (e) => {
      const q = e.target.value.toLowerCase();
      const filtered = ADLC_DATA.packages.filter(p => 
        p.name.toLowerCase().includes(q) || 
        p.desc.toLowerCase().includes(q)
      );
      renderPackages(filtered);
    });
  }
}

function renderPackages(list) {
  const listContainer = document.getElementById('packages-list');
  if (!listContainer) return;
  
  listContainer.innerHTML = '';
  if (list.length === 0) {
    listContainer.innerHTML = '<div style="text-align:center; padding:40px; color:var(--text-muted);">No software packages found matching query.</div>';
    return;
  }
  
  list.forEach(p => {
    const row = document.createElement('div');
    row.className = 'secret-row';
    row.innerHTML = `
      <div style="flex-grow:1; margin-right:16px;">
        <div style="display:flex; align-items:center; gap:10px;">
          <span class="secret-name" style="color:var(--accent-cyan); font-size:16px;">${p.name}</span>
          <span class="badge badge-purple">${p.version}</span>
        </div>
        <p style="font-size:12px; color:var(--text-secondary); margin-top:4px;">${p.desc}</p>
      </div>
      <div style="text-align:right; flex-shrink:0;">
        <div style="font-size:11px; color:var(--text-muted); margin-bottom:4px;">${p.installs} downloads</div>
        <button class="btn btn-secondary" onclick="installMockPackage('${p.name}')" style="padding:4px 8px; font-size:12px;">Install</button>
      </div>
    `;
    listContainer.appendChild(row);
  });
}

window.installMockPackage = function(name) {
  alert(`Successfully installed ${name} into sandbox environment packages index!`);
};

// 8. Version Control / Git Commit Engine (git.html)
function initGitPage() {
  const commitBtn = document.getElementById('commit-btn');
  const msgInput = document.getElementById('commit-msg');
  
  renderGitCommits();
  
  if (commitBtn) {
    commitBtn.addEventListener('click', () => {
      const msg = msgInput.value.trim();
      if (!msg) {
        alert('Please provide a descriptive git commit commit-message!');
        return;
      }
      
      const newHash = Math.random().toString(16).substring(2, 9);
      ADLC_DATA.git.commits.unshift({
        hash: newHash,
        msg: msg,
        date: 'Just now',
        author: 'You (Developer)'
      });
      
      msgInput.value = '';
      renderGitCommits();
      alert(`Pushed commit: [main ${newHash}] ${msg}`);
    });
  }
}

function renderGitCommits() {
  const container = document.getElementById('git-commits-list');
  if (!container) return;
  
  container.innerHTML = '';
  ADLC_DATA.git.commits.forEach(c => {
    const row = document.createElement('div');
    row.className = 'secret-row';
    row.innerHTML = `
      <div>
        <div style="display:flex; align-items:center; gap:8px;">
          <span class="badge badge-cyan" style="font-family:var(--font-mono);">${c.hash}</span>
          <span class="secret-name">${c.msg}</span>
        </div>
        <div style="font-size:11px; color:var(--text-muted); margin-top:4px;">Committed by ${c.author} • ${c.date}</div>
      </div>
    `;
    container.appendChild(row);
  });
}

// 9. Deployments Server simulation logs streams (deployments.html)
function initDeploymentsPage() {
  const deployBtn = document.getElementById('deploy-btn');
  const logTerminal = document.getElementById('deploy-logs');
  
  if (deployBtn && logTerminal) {
    deployBtn.addEventListener('click', () => {
      deployBtn.disabled = true;
      deployBtn.textContent = 'Deploying...';
      logTerminal.innerHTML = '';
      
      const lines = [
        '[ADLC DEPLOY] Establishing secure cloud container workspace connection...',
        '[ADLC DEPLOY] Packing virtual assets index files...',
        '[ADLC DEPLOY] Compiling bundle (minification checks, tree shaking)...',
        '[ADLC DEPLOY] Provisioning DNS certificate domains hooks...',
        '[ADLC DEPLOY] Initializing container agent status health probes...',
        '[ADLC DEPLOY] Deploy successfully uploaded to node: https://adlc-sandbox-main.adlc.app 🚀'
      ];
      
      let index = 0;
      function streamLog() {
        if (index < lines.length) {
          const div = document.createElement('div');
          div.className = 'terminal-row';
          div.textContent = lines[index];
          if (lines[index].includes('Successfully') || lines[index].includes('🚀')) {
            div.style.color = 'var(--accent-green)';
          } else {
            div.style.color = '#a9b1d6';
          }
          logTerminal.appendChild(div);
          logTerminal.scrollTop = logTerminal.scrollHeight;
          index++;
          setTimeout(streamLog, 700);
        } else {
          deployBtn.disabled = false;
          deployBtn.textContent = 'Redeploy Project';
          const badge = document.getElementById('deployment-status-badge');
          if (badge) {
            badge.textContent = 'Active';
            badge.className = 'badge badge-success';
          }
        }
      }
      
      streamLog();
    });
  }
}

// 10. Bounties (bounties.html)
function initBountiesPage() {
  const list = document.getElementById('bounties-list');
  renderBounties();
}

function renderBounties() {
  const list = document.getElementById('bounties-list');
  if (!list) return;
  
  list.innerHTML = '';
  ADLC_DATA.bounties.forEach(b => {
    const row = document.createElement('div');
    row.className = 'secret-row';
    row.innerHTML = `
      <div style="flex-grow:1; margin-right:12px;">
        <span class="secret-name" style="font-size:16px;">${b.title}</span>
        <div style="display:flex; gap:12px; margin-top:6px; font-size:12px; color:var(--text-muted);">
          <span>By ${b.author}</span>
          <span>Difficulty: <strong>${b.difficulty}</strong></span>
          <span>Deadline: ${b.deadline}</span>
        </div>
      </div>
      <div style="text-align:right; flex-shrink:0;">
        <span style="font-size:18px; font-weight:700; color:var(--accent-green); display:block; margin-bottom:4px;">${b.budget}</span>
        <button class="btn btn-primary" onclick="claimBounty(${b.id})" style="padding:4px 8px; font-size:12px;">Bid</button>
      </div>
    `;
    list.appendChild(row);
  });
}

window.claimBounty = function(id) {
  alert(`Bid submitted for Bounty ID: #${id}! You will receive notifications if selected.`);
};

// 11. Settings page changes (settings.html)
function initSettingsPage() {
  const themeSelect = document.getElementById('editor-theme');
  const sizeSelect = document.getElementById('editor-font-size');
  
  if (themeSelect) {
    const activeTheme = localStorage.getItem('adlc-theme') || 'dark-neon';
    themeSelect.value = activeTheme;
    themeSelect.addEventListener('change', (e) => {
      applyTheme(e.target.value);
    });
  }
  
  if (sizeSelect) {
    sizeSelect.addEventListener('change', (e) => {
      alert(`Adjusted workspace editor fonts to: ${e.target.value}`);
    });
  }
}

// 12. Auth logic checks (login.html, signup.html)
function initAuthPage() {
  const form = document.querySelector('.auth-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      location.href = 'dashboard.html';
    });
  }
}
