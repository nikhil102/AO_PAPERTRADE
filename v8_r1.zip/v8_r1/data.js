// Mock Database configuration for ADLC Web Platform
const ADLC_DATA = {
  templates: [
    { id: 'html-css-js', name: 'HTML, CSS, JS', desc: 'A simple web starter template with vanilla structure', lang: 'HTML', icon: 'lang-html', count: '142k' },
    { id: 'python', name: 'Python Sandbox', desc: 'Ready-to-run Python 3 instance for script and app testing', lang: 'Python', icon: 'lang-python', count: '280k' },
    { id: 'node-js', name: 'Node.js Sandbox', desc: 'Express web server template with hot reloading', lang: 'Node.js', icon: 'lang-node', count: '195k' },
    { id: 'go', name: 'Go Starter', desc: 'Standard workspace configured for compilation and tests', lang: 'Go', icon: 'lang-go', count: '54k' },
    { id: 'react-vite', name: 'React (Vite)', desc: 'Fast client-side rendering with Tailwind and React components', lang: 'HTML', icon: 'lang-html', count: '98k' },
    { id: 'pytorch', name: 'PyTorch ML Platform', desc: 'Deep learning workbench with preconfigured dependencies', lang: 'Python', icon: 'lang-python', count: '76k' }
  ],
  
  packages: [
    { name: 'express', version: '4.18.2', desc: 'Fast, unopinionated, minimalist web framework for node.', installs: '28M/wk' },
    { name: 'lodash', version: '4.17.21', desc: 'Lodash modular utilities for arrays, objects, and arrays.', installs: '42M/wk' },
    { name: 'requests', version: '2.31.0', desc: 'Python HTTP library for human beings. Easy REST APIs.', installs: '15M/wk' },
    { name: 'numpy', version: '1.24.3', desc: 'Fundamental package for scientific computing with Python.', installs: '20M/wk' },
    { name: 'pandas', version: '2.0.2', desc: 'Powerful data structures for data analysis and manipulation.', installs: '12M/wk' },
    { name: 'uuid', version: '9.0.0', desc: 'RFC4122 UUIDs generator for Javascript apps.', installs: '18M/wk' },
    { name: 'chalk', version: '5.2.0', desc: 'Terminal string styling done right. ANSI colors.', installs: '22M/wk' }
  ],
  
  files: {
    'index.html': `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>ADLC Run Sandbox</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <main class="sandbox-container">
    <h1>Welcome to ADLC Agent Sandbox!</h1>
    <p>This workspace is running actively on the cloud.</p>
    <button id="action-btn">Click Me</button>
  </main>
  <script src="script.js"></script>
</body>
</html>`,
    'style.css': `body {
  background: radial-gradient(circle, #0e121a 0%, #06080c 100%);
  color: #fff;
  font-family: system-ui;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}
.sandbox-container {
  text-align: center;
  border: 1px solid rgba(255,255,255,0.1);
  padding: 30px;
  border-radius: 12px;
  background: rgba(255,255,255,0.03);
}`,
    'script.js': `document.getElementById('action-btn').addEventListener('click', () => {
  alert('Agentic life cycle active!');
  console.log('Button clicked in sandbox console');
});`,
    'main.py': `import math
import sys

def calculate_pi_approximation():
    print("Initializing ADLC Agent compute task...")
    pi_est = sum(1 / (16**k) * (4/(8*k+1) - 2/(8*k+4) - 1/(8*k+5) - 1/(8*k+6)) for k in range(5))
    print(f"Approximation: {pi_est}")
    return pi_est

if __name__ == "__main__":
    calculate_pi_approximation()`,
    'README.md': `# ADLC Project Sandbox
This project demonstrates the core Replit-style live runner inside the **ADLC** (Agentic Development Life Cycle) workspace.

## Usage
1. Press the green **Run** button at the top header navbar to spin up a mock server.
2. Interactively modify files or add environment keys to see live reloading.
3. Test terminal commands in the lower tray console.`
  },
  
  secrets: [
    { key: 'DATABASE_URL', val: 'postgres://admin:adlc_sec_893@db.adlc.net/prod' },
    { key: 'OPENAI_API_KEY', val: 'sk-proj-4927XNlksd8123nsadLKJlaksdJ' },
    { key: 'GITHUB_CLIENT_SECRET', val: 'ghs_82ndkLAKDk9021nsdfKLAJDk021nd' }
  ],
  
  database: [
    { key: 'user:session:101', val: '{"id":101,"username":"agent_sigma","status":"active"}' },
    { key: 'config:theme', val: '"dark_neon"' },
    { key: 'stats:runs', val: '4391' }
  ],
  
  bounties: [
    { id: 1, title: 'Build visual IDE Call Stack tracer', budget: '$450', author: '@alex_dev', difficulty: 'Intermediate', deadline: '2 days' },
    { id: 2, title: 'Integrate WebContainer logic for Node.js sandbox', budget: '$1,200', author: '@adlc_core', difficulty: 'Advanced', deadline: '5 days' },
    { id: 3, title: 'Fix CSS alignment errors in Dashboard template list', budget: '$80', author: '@sheryl_k', difficulty: 'Easy', deadline: '6 hours' },
    { id: 4, title: 'Create Rust compiler WebAssembly bindings', budget: '$900', author: '@rustacean', difficulty: 'Advanced', deadline: '3 days' }
  ],
  
  git: {
    branch: 'main',
    commits: [
      { hash: 'e29d71c', msg: 'feat: Add direct console execution trigger', date: '2 hours ago', author: 'ADLC Agent' },
      { hash: '87ab2c1', msg: 'fix: Secret keys masking visibility issue', date: 'Yesterday', author: 'admin@adlc.io' },
      { hash: '1a90c2e', msg: 'docs: Improve README and sandbox commands reference', date: '2 days ago', author: 'ADLC Agent' }
    ]
  },
  
  community: [
    { title: 'How to deploy custom Dockerfiles inside ADLC instances?', author: '@johndoe', replies: 14, likes: 45, tag: 'Deployments' },
    { title: 'Showcase: My new Canvas-based pixel compiler sandbox!', author: '@pixelart', replies: 28, likes: 112, tag: 'Showcase' },
    { title: 'Best practices for organizing Secrets in enterprise environments', author: '@security_ops', replies: 8, likes: 33, tag: 'Secrets' }
  ]
};
